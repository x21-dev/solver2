NAME        
OBJSENSE
  MAX
ROWS
 N  Obj     
 E  writeoff_1
 E  writeoff_2
 E  writeoff_3
 E  writeoff_4
 E  writeoff_5
 E  writeoff_6
 E  writeoff_7
 E  writeoff_8
 E  writeoff_9
 E  writeoff_10
 E  writeoff_11
 E  writeoff_12
 E  writeoff_13
 E  writeoff_14
 E  writeoff_15
 E  writeoff_16
 E  writeoff_17
 E  writeoff_18
 E  writeoff_19
 E  writeoff_20
 E  writeoff_21
 E  writeoff_22
 E  writeoff_23
 E  writeoff_24
 E  writeoff_25
 E  writeoff_26
 E  writeoff_27
 E  writeoff_28
 E  writeoff_29
 E  writeoff_30
 E  writeoff_31
 E  writeoff_32
 E  writeoff_33
 E  writeoff_34
 E  writeoff_35
 E  writeoff_36
 E  writeoff_37
 E  writeoff_38
 E  writeoff_39
 E  writeoff_40
 E  writeoff_41
 E  writeoff_42
 E  writeoff_43
 E  writeoff_44
 E  writeoff_45
 E  writeoff_46
 E  writeoff_47
 E  writeoff_48
 E  writeoff_49
 E  writeoff_50
 E  writeoff_51
 E  writeoff_52
 E  writeoff_53
 E  writeoff_54
 E  writeoff_55
 E  writeoff_56
 E  writeoff_57
 E  writeoff_58
 E  writeoff_59
 E  writeoff_60
 E  stage2_1
 E  stage2_2
 E  stage2_3
 E  stage2_4
 E  stage2_5
 E  stage2_6
 E  stage2_7
 E  stage2_8
 E  stage2_9
 E  stage2_10
 E  stage2_11
 E  stage2_12
 E  stage2_13
 E  stage2_14
 E  stage2_15
 E  stage2_16
 E  stage2_17
 E  stage2_18
 E  stage2_19
 E  stage2_20
 E  stage2_21
 E  stage2_22
 E  stage2_23
 E  stage2_24
 E  stage2_25
 E  stage2_26
 E  stage2_27
 E  stage2_28
 E  stage2_29
 E  stage2_30
 E  stage2_31
 E  stage2_32
 E  stage2_33
 E  stage2_34
 E  stage2_35
 E  stage2_36
 E  stage2_37
 E  stage2_38
 E  stage2_39
 E  stage2_40
 E  stage2_41
 E  stage2_42
 E  stage2_43
 E  stage2_44
 E  stage2_45
 E  stage2_46
 E  stage2_47
 E  stage2_48
 E  stage2_49
 E  stage2_50
 E  stage2_51
 E  stage2_52
 E  stage2_53
 E  stage2_54
 E  stage2_55
 E  stage2_56
 E  stage2_57
 E  stage2_58
 E  stage2_59
 E  stage2_60
 E  stage3_1
 E  stage3_2
 E  stage3_3
 E  stage3_4
 E  stage3_5
 E  stage3_6
 E  stage3_7
 E  stage3_8
 E  stage3_9
 E  stage3_10
 E  stage3_11
 E  stage3_12
 E  stage3_13
 E  stage3_14
 E  stage3_15
 E  stage3_16
 E  stage3_17
 E  stage3_18
 E  stage3_19
 E  stage3_20
 E  stage3_21
 E  stage3_22
 E  stage3_23
 E  stage3_24
 E  stage3_25
 E  stage3_26
 E  stage3_27
 E  stage3_28
 E  stage3_29
 E  stage3_30
 E  stage3_31
 E  stage3_32
 E  stage3_33
 E  stage3_34
 E  stage3_35
 E  stage3_36
 E  stage3_37
 E  stage3_38
 E  stage3_39
 E  stage3_40
 E  stage3_41
 E  stage3_42
 E  stage3_43
 E  stage3_44
 E  stage3_45
 E  stage3_46
 E  stage3_47
 E  stage3_48
 E  stage3_49
 E  stage3_50
 E  stage3_51
 E  stage3_52
 E  stage3_53
 E  stage3_54
 E  stage3_55
 E  stage3_56
 E  stage3_57
 E  stage3_58
 E  stage3_59
 E  stage3_60
 E  provision_1
 E  provision_2
 E  provision_3
 E  provision_4
 E  provision_5
 E  provision_6
 E  provision_7
 E  provision_8
 E  provision_9
 E  provision_10
 E  provision_11
 E  provision_12
 E  provision_13
 E  provision_14
 E  provision_15
 E  provision_16
 E  provision_17
 E  provision_18
 E  provision_19
 E  provision_20
 E  provision_21
 E  provision_22
 E  provision_23
 E  provision_24
 E  provision_25
 E  provision_26
 E  provision_27
 E  provision_28
 E  provision_29
 E  provision_30
 E  provision_31
 E  provision_32
 E  provision_33
 E  provision_34
 E  provision_35
 E  provision_36
 E  provision_37
 E  provision_38
 E  provision_39
 E  provision_40
 E  provision_41
 E  provision_42
 E  provision_43
 E  provision_44
 E  provision_45
 E  provision_46
 E  provision_47
 E  provision_48
 E  provision_49
 E  provision_50
 E  provision_51
 E  provision_52
 E  provision_53
 E  provision_54
 E  provision_55
 E  provision_56
 E  provision_57
 E  provision_58
 E  provision_59
 E  provision_60
 E  loan_1  
 E  loan_2  
 E  loan_3  
 E  loan_4  
 E  loan_5  
 E  loan_6  
 E  loan_7  
 E  loan_8  
 E  loan_9  
 E  loan_10 
 E  loan_11 
 E  loan_12 
 E  loan_13 
 E  loan_14 
 E  loan_15 
 E  loan_16 
 E  loan_17 
 E  loan_18 
 E  loan_19 
 E  loan_20 
 E  loan_21 
 E  loan_22 
 E  loan_23 
 E  loan_24 
 E  loan_25 
 E  loan_26 
 E  loan_27 
 E  loan_28 
 E  loan_29 
 E  loan_30 
 E  loan_31 
 E  loan_32 
 E  loan_33 
 E  loan_34 
 E  loan_35 
 E  loan_36 
 E  loan_37 
 E  loan_38 
 E  loan_39 
 E  loan_40 
 E  loan_41 
 E  loan_42 
 E  loan_43 
 E  loan_44 
 E  loan_45 
 E  loan_46 
 E  loan_47 
 E  loan_48 
 E  loan_49 
 E  loan_50 
 E  loan_51 
 E  loan_52 
 E  loan_53 
 E  loan_54 
 E  loan_55 
 E  loan_56 
 E  loan_57 
 E  loan_58 
 E  loan_59 
 E  loan_60 
 E  term_1  
 E  term_2  
 E  term_3  
 E  term_4  
 E  term_5  
 E  term_6  
 E  term_7  
 E  term_8  
 E  term_9  
 E  term_10 
 E  term_11 
 E  term_12 
 E  term_13 
 E  term_14 
 E  term_15 
 E  term_16 
 E  term_17 
 E  term_18 
 E  term_19 
 E  term_20 
 E  term_21 
 E  term_22 
 E  term_23 
 E  term_24 
 E  term_25 
 E  term_26 
 E  term_27 
 E  term_28 
 E  term_29 
 E  term_30 
 E  term_31 
 E  term_32 
 E  term_33 
 E  term_34 
 E  term_35 
 E  term_36 
 E  term_37 
 E  term_38 
 E  term_39 
 E  term_40 
 E  term_41 
 E  term_42 
 E  term_43 
 E  term_44 
 E  term_45 
 E  term_46 
 E  term_47 
 E  term_48 
 E  term_49 
 E  term_50 
 E  term_51 
 E  term_52 
 E  term_53 
 E  term_54 
 E  term_55 
 E  term_56 
 E  term_57 
 E  term_58 
 E  term_59 
 E  term_60 
 E  whole_1 
 E  whole_2 
 E  whole_3 
 E  whole_4 
 E  whole_5 
 E  whole_6 
 E  whole_7 
 E  whole_8 
 E  whole_9 
 E  whole_10
 E  whole_11
 E  whole_12
 E  whole_13
 E  whole_14
 E  whole_15
 E  whole_16
 E  whole_17
 E  whole_18
 E  whole_19
 E  whole_20
 E  whole_21
 E  whole_22
 E  whole_23
 E  whole_24
 E  whole_25
 E  whole_26
 E  whole_27
 E  whole_28
 E  whole_29
 E  whole_30
 E  whole_31
 E  whole_32
 E  whole_33
 E  whole_34
 E  whole_35
 E  whole_36
 E  whole_37
 E  whole_38
 E  whole_39
 E  whole_40
 E  whole_41
 E  whole_42
 E  whole_43
 E  whole_44
 E  whole_45
 E  whole_46
 E  whole_47
 E  whole_48
 E  whole_49
 E  whole_50
 E  whole_51
 E  whole_52
 E  whole_53
 E  whole_54
 E  whole_55
 E  whole_56
 E  whole_57
 E  whole_58
 E  whole_59
 E  whole_60
 E  capital_1
 E  capital_2
 E  capital_3
 E  capital_4
 E  capital_5
 E  capital_6
 E  capital_7
 E  capital_8
 E  capital_9
 E  capital_10
 E  capital_11
 E  capital_12
 E  capital_13
 E  capital_14
 E  capital_15
 E  capital_16
 E  capital_17
 E  capital_18
 E  capital_19
 E  capital_20
 E  capital_21
 E  capital_22
 E  capital_23
 E  capital_24
 E  capital_25
 E  capital_26
 E  capital_27
 E  capital_28
 E  capital_29
 E  capital_30
 E  capital_31
 E  capital_32
 E  capital_33
 E  capital_34
 E  capital_35
 E  capital_36
 E  capital_37
 E  capital_38
 E  capital_39
 E  capital_40
 E  capital_41
 E  capital_42
 E  capital_43
 E  capital_44
 E  capital_45
 E  capital_46
 E  capital_47
 E  capital_48
 E  capital_49
 E  capital_50
 E  capital_51
 E  capital_52
 E  capital_53
 E  capital_54
 E  capital_55
 E  capital_56
 E  capital_57
 E  capital_58
 E  capital_59
 E  capital_60
 E  short_whole_1
 E  short_whole_2
 E  short_whole_3
 E  short_whole_4
 E  short_whole_5
 E  short_whole_6
 E  short_whole_7
 E  short_whole_8
 E  short_whole_9
 E  short_whole_10
 E  short_whole_11
 E  short_whole_12
 E  short_whole_13
 E  short_whole_14
 E  short_whole_15
 E  short_whole_16
 E  short_whole_17
 E  short_whole_18
 E  short_whole_19
 E  short_whole_20
 E  short_whole_21
 E  short_whole_22
 E  short_whole_23
 E  short_whole_24
 E  short_whole_25
 E  short_whole_26
 E  short_whole_27
 E  short_whole_28
 E  short_whole_29
 E  short_whole_30
 E  short_whole_31
 E  short_whole_32
 E  short_whole_33
 E  short_whole_34
 E  short_whole_35
 E  short_whole_36
 E  short_whole_37
 E  short_whole_38
 E  short_whole_39
 E  short_whole_40
 E  short_whole_41
 E  short_whole_42
 E  short_whole_43
 E  short_whole_44
 E  short_whole_45
 E  short_whole_46
 E  short_whole_47
 E  short_whole_48
 E  short_whole_49
 E  short_whole_50
 E  short_whole_51
 E  short_whole_52
 E  short_whole_53
 E  short_whole_54
 E  short_whole_55
 E  short_whole_56
 E  short_whole_57
 E  short_whole_58
 E  short_whole_59
 E  short_whole_60
 E  balance_1
 E  balance_2
 E  balance_3
 E  balance_4
 E  balance_5
 E  balance_6
 E  balance_7
 E  balance_8
 E  balance_9
 E  balance_10
 E  balance_11
 E  balance_12
 E  balance_13
 E  balance_14
 E  balance_15
 E  balance_16
 E  balance_17
 E  balance_18
 E  balance_19
 E  balance_20
 E  balance_21
 E  balance_22
 E  balance_23
 E  balance_24
 E  balance_25
 E  balance_26
 E  balance_27
 E  balance_28
 E  balance_29
 E  balance_30
 E  balance_31
 E  balance_32
 E  balance_33
 E  balance_34
 E  balance_35
 E  balance_36
 E  balance_37
 E  balance_38
 E  balance_39
 E  balance_40
 E  balance_41
 E  balance_42
 E  balance_43
 E  balance_44
 E  balance_45
 E  balance_46
 E  balance_47
 E  balance_48
 E  balance_49
 E  balance_50
 E  balance_51
 E  balance_52
 E  balance_53
 E  balance_54
 E  balance_55
 E  balance_56
 E  balance_57
 E  balance_58
 E  balance_59
 E  balance_60
 E  lf_1    
 E  lf_2    
 E  lf_3    
 E  lf_4    
 E  lf_5    
 E  lf_6    
 E  lf_7    
 E  lf_8    
 E  lf_9    
 E  lf_10   
 E  lf_11   
 E  lf_12   
 E  lf_13   
 E  lf_14   
 E  lf_15   
 E  lf_16   
 E  lf_17   
 E  lf_18   
 E  lf_19   
 E  lf_20   
 E  lf_21   
 E  lf_22   
 E  lf_23   
 E  lf_24   
 E  lf_25   
 E  lf_26   
 E  lf_27   
 E  lf_28   
 E  lf_29   
 E  lf_30   
 E  lf_31   
 E  lf_32   
 E  lf_33   
 E  lf_34   
 E  lf_35   
 E  lf_36   
 E  lf_37   
 E  lf_38   
 E  lf_39   
 E  lf_40   
 E  lf_41   
 E  lf_42   
 E  lf_43   
 E  lf_44   
 E  lf_45   
 E  lf_46   
 E  lf_47   
 E  lf_48   
 E  lf_49   
 E  lf_50   
 E  lf_51   
 E  lf_52   
 E  lf_53   
 E  lf_54   
 E  lf_55   
 E  lf_56   
 E  lf_57   
 E  lf_58   
 E  lf_59   
 E  lf_60   
 E  lr_1    
 E  lr_2    
 E  lr_3    
 E  lr_4    
 E  lr_5    
 E  lr_6    
 E  lr_7    
 E  lr_8    
 E  lr_9    
 E  lr_10   
 E  lr_11   
 E  lr_12   
 E  lr_13   
 E  lr_14   
 E  lr_15   
 E  lr_16   
 E  lr_17   
 E  lr_18   
 E  lr_19   
 E  lr_20   
 E  lr_21   
 E  lr_22   
 E  lr_23   
 E  lr_24   
 E  lr_25   
 E  lr_26   
 E  lr_27   
 E  lr_28   
 E  lr_29   
 E  lr_30   
 E  lr_31   
 E  lr_32   
 E  lr_33   
 E  lr_34   
 E  lr_35   
 E  lr_36   
 E  lr_37   
 E  lr_38   
 E  lr_39   
 E  lr_40   
 E  lr_41   
 E  lr_42   
 E  lr_43   
 E  lr_44   
 E  lr_45   
 E  lr_46   
 E  lr_47   
 E  lr_48   
 E  lr_49   
 E  lr_50   
 E  lr_51   
 E  lr_52   
 E  lr_53   
 E  lr_54   
 E  lr_55   
 E  lr_56   
 E  lr_57   
 E  lr_58   
 E  lr_59   
 E  lr_60   
 E  lm_1    
 E  lm_2    
 E  lm_3    
 E  lm_4    
 E  lm_5    
 E  lm_6    
 E  lm_7    
 E  lm_8    
 E  lm_9    
 E  lm_10   
 E  lm_11   
 E  lm_12   
 E  lm_13   
 E  lm_14   
 E  lm_15   
 E  lm_16   
 E  lm_17   
 E  lm_18   
 E  lm_19   
 E  lm_20   
 E  lm_21   
 E  lm_22   
 E  lm_23   
 E  lm_24   
 E  lm_25   
 E  lm_26   
 E  lm_27   
 E  lm_28   
 E  lm_29   
 E  lm_30   
 E  lm_31   
 E  lm_32   
 E  lm_33   
 E  lm_34   
 E  lm_35   
 E  lm_36   
 E  lm_37   
 E  lm_38   
 E  lm_39   
 E  lm_40   
 E  lm_41   
 E  lm_42   
 E  lm_43   
 E  lm_44   
 E  lm_45   
 E  lm_46   
 E  lm_47   
 E  lm_48   
 E  lm_49   
 E  lm_50   
 E  lm_51   
 E  lm_52   
 E  lm_53   
 E  lm_54   
 E  lm_55   
 E  lm_56   
 E  lm_57   
 E  lm_58   
 E  lm_59   
 E  lm_60   
 E  tr_1    
 E  tr_2    
 E  tr_3    
 E  tr_4    
 E  tr_5    
 E  tr_6    
 E  tr_7    
 E  tr_8    
 E  tr_9    
 E  tr_10   
 E  tr_11   
 E  tr_12   
 E  tr_13   
 E  tr_14   
 E  tr_15   
 E  tr_16   
 E  tr_17   
 E  tr_18   
 E  tr_19   
 E  tr_20   
 E  tr_21   
 E  tr_22   
 E  tr_23   
 E  tr_24   
 E  tr_25   
 E  tr_26   
 E  tr_27   
 E  tr_28   
 E  tr_29   
 E  tr_30   
 E  tr_31   
 E  tr_32   
 E  tr_33   
 E  tr_34   
 E  tr_35   
 E  tr_36   
 E  tr_37   
 E  tr_38   
 E  tr_39   
 E  tr_40   
 E  tr_41   
 E  tr_42   
 E  tr_43   
 E  tr_44   
 E  tr_45   
 E  tr_46   
 E  tr_47   
 E  tr_48   
 E  tr_49   
 E  tr_50   
 E  tr_51   
 E  tr_52   
 E  tr_53   
 E  tr_54   
 E  tr_55   
 E  tr_56   
 E  tr_57   
 E  tr_58   
 E  tr_59   
 E  tr_60   
 E  tm_1    
 E  tm_2    
 E  tm_3    
 E  tm_4    
 E  tm_5    
 E  tm_6    
 E  tm_7    
 E  tm_8    
 E  tm_9    
 E  tm_10   
 E  tm_11   
 E  tm_12   
 E  tm_13   
 E  tm_14   
 E  tm_15   
 E  tm_16   
 E  tm_17   
 E  tm_18   
 E  tm_19   
 E  tm_20   
 E  tm_21   
 E  tm_22   
 E  tm_23   
 E  tm_24   
 E  tm_25   
 E  tm_26   
 E  tm_27   
 E  tm_28   
 E  tm_29   
 E  tm_30   
 E  tm_31   
 E  tm_32   
 E  tm_33   
 E  tm_34   
 E  tm_35   
 E  tm_36   
 E  tm_37   
 E  tm_38   
 E  tm_39   
 E  tm_40   
 E  tm_41   
 E  tm_42   
 E  tm_43   
 E  tm_44   
 E  tm_45   
 E  tm_46   
 E  tm_47   
 E  tm_48   
 E  tm_49   
 E  tm_50   
 E  tm_51   
 E  tm_52   
 E  tm_53   
 E  tm_54   
 E  tm_55   
 E  tm_56   
 E  tm_57   
 E  tm_58   
 E  tm_59   
 E  tm_60   
 E  liquid_1
 E  liquid_2
 E  liquid_3
 E  liquid_4
 E  liquid_5
 E  liquid_6
 E  liquid_7
 E  liquid_8
 E  liquid_9
 E  liquid_10
 E  liquid_11
 E  liquid_12
 E  liquid_13
 E  liquid_14
 E  liquid_15
 E  liquid_16
 E  liquid_17
 E  liquid_18
 E  liquid_19
 E  liquid_20
 E  liquid_21
 E  liquid_22
 E  liquid_23
 E  liquid_24
 E  liquid_25
 E  liquid_26
 E  liquid_27
 E  liquid_28
 E  liquid_29
 E  liquid_30
 E  liquid_31
 E  liquid_32
 E  liquid_33
 E  liquid_34
 E  liquid_35
 E  liquid_36
 E  liquid_37
 E  liquid_38
 E  liquid_39
 E  liquid_40
 E  liquid_41
 E  liquid_42
 E  liquid_43
 E  liquid_44
 E  liquid_45
 E  liquid_46
 E  liquid_47
 E  liquid_48
 E  liquid_49
 E  liquid_50
 E  liquid_51
 E  liquid_52
 E  liquid_53
 E  liquid_54
 E  liquid_55
 E  liquid_56
 E  liquid_57
 E  liquid_58
 E  liquid_59
 E  liquid_60
 L  l2_haircut_1
 L  l2_haircut_2
 L  l2_haircut_3
 L  l2_haircut_4
 L  l2_haircut_5
 L  l2_haircut_6
 L  l2_haircut_7
 L  l2_haircut_8
 L  l2_haircut_9
 L  l2_haircut_10
 L  l2_haircut_11
 L  l2_haircut_12
 L  l2_haircut_13
 L  l2_haircut_14
 L  l2_haircut_15
 L  l2_haircut_16
 L  l2_haircut_17
 L  l2_haircut_18
 L  l2_haircut_19
 L  l2_haircut_20
 L  l2_haircut_21
 L  l2_haircut_22
 L  l2_haircut_23
 L  l2_haircut_24
 L  l2_haircut_25
 L  l2_haircut_26
 L  l2_haircut_27
 L  l2_haircut_28
 L  l2_haircut_29
 L  l2_haircut_30
 L  l2_haircut_31
 L  l2_haircut_32
 L  l2_haircut_33
 L  l2_haircut_34
 L  l2_haircut_35
 L  l2_haircut_36
 L  l2_haircut_37
 L  l2_haircut_38
 L  l2_haircut_39
 L  l2_haircut_40
 L  l2_haircut_41
 L  l2_haircut_42
 L  l2_haircut_43
 L  l2_haircut_44
 L  l2_haircut_45
 L  l2_haircut_46
 L  l2_haircut_47
 L  l2_haircut_48
 L  l2_haircut_49
 L  l2_haircut_50
 L  l2_haircut_51
 L  l2_haircut_52
 L  l2_haircut_53
 L  l2_haircut_54
 L  l2_haircut_55
 L  l2_haircut_56
 L  l2_haircut_57
 L  l2_haircut_58
 L  l2_haircut_59
 L  l2_haircut_60
 L  l2_cap_1
 L  l2_cap_2
 L  l2_cap_3
 L  l2_cap_4
 L  l2_cap_5
 L  l2_cap_6
 L  l2_cap_7
 L  l2_cap_8
 L  l2_cap_9
 L  l2_cap_10
 L  l2_cap_11
 L  l2_cap_12
 L  l2_cap_13
 L  l2_cap_14
 L  l2_cap_15
 L  l2_cap_16
 L  l2_cap_17
 L  l2_cap_18
 L  l2_cap_19
 L  l2_cap_20
 L  l2_cap_21
 L  l2_cap_22
 L  l2_cap_23
 L  l2_cap_24
 L  l2_cap_25
 L  l2_cap_26
 L  l2_cap_27
 L  l2_cap_28
 L  l2_cap_29
 L  l2_cap_30
 L  l2_cap_31
 L  l2_cap_32
 L  l2_cap_33
 L  l2_cap_34
 L  l2_cap_35
 L  l2_cap_36
 L  l2_cap_37
 L  l2_cap_38
 L  l2_cap_39
 L  l2_cap_40
 L  l2_cap_41
 L  l2_cap_42
 L  l2_cap_43
 L  l2_cap_44
 L  l2_cap_45
 L  l2_cap_46
 L  l2_cap_47
 L  l2_cap_48
 L  l2_cap_49
 L  l2_cap_50
 L  l2_cap_51
 L  l2_cap_52
 L  l2_cap_53
 L  l2_cap_54
 L  l2_cap_55
 L  l2_cap_56
 L  l2_cap_57
 L  l2_cap_58
 L  l2_cap_59
 L  l2_cap_60
 E  ii_1    
 E  ii_2    
 E  ii_3    
 E  ii_4    
 E  ii_5    
 E  ii_6    
 E  ii_7    
 E  ii_8    
 E  ii_9    
 E  ii_10   
 E  ii_11   
 E  ii_12   
 E  ii_13   
 E  ii_14   
 E  ii_15   
 E  ii_16   
 E  ii_17   
 E  ii_18   
 E  ii_19   
 E  ii_20   
 E  ii_21   
 E  ii_22   
 E  ii_23   
 E  ii_24   
 E  ii_25   
 E  ii_26   
 E  ii_27   
 E  ii_28   
 E  ii_29   
 E  ii_30   
 E  ii_31   
 E  ii_32   
 E  ii_33   
 E  ii_34   
 E  ii_35   
 E  ii_36   
 E  ii_37   
 E  ii_38   
 E  ii_39   
 E  ii_40   
 E  ii_41   
 E  ii_42   
 E  ii_43   
 E  ii_44   
 E  ii_45   
 E  ii_46   
 E  ii_47   
 E  ii_48   
 E  ii_49   
 E  ii_50   
 E  ii_51   
 E  ii_52   
 E  ii_53   
 E  ii_54   
 E  ii_55   
 E  ii_56   
 E  ii_57   
 E  ii_58   
 E  ii_59   
 E  ii_60   
 E  ie_1    
 E  ie_2    
 E  ie_3    
 E  ie_4    
 E  ie_5    
 E  ie_6    
 E  ie_7    
 E  ie_8    
 E  ie_9    
 E  ie_10   
 E  ie_11   
 E  ie_12   
 E  ie_13   
 E  ie_14   
 E  ie_15   
 E  ie_16   
 E  ie_17   
 E  ie_18   
 E  ie_19   
 E  ie_20   
 E  ie_21   
 E  ie_22   
 E  ie_23   
 E  ie_24   
 E  ie_25   
 E  ie_26   
 E  ie_27   
 E  ie_28   
 E  ie_29   
 E  ie_30   
 E  ie_31   
 E  ie_32   
 E  ie_33   
 E  ie_34   
 E  ie_35   
 E  ie_36   
 E  ie_37   
 E  ie_38   
 E  ie_39   
 E  ie_40   
 E  ie_41   
 E  ie_42   
 E  ie_43   
 E  ie_44   
 E  ie_45   
 E  ie_46   
 E  ie_47   
 E  ie_48   
 E  ie_49   
 E  ie_50   
 E  ie_51   
 E  ie_52   
 E  ie_53   
 E  ie_54   
 E  ie_55   
 E  ie_56   
 E  ie_57   
 E  ie_58   
 E  ie_59   
 E  ie_60   
 E  imp_1   
 E  imp_2   
 E  imp_3   
 E  imp_4   
 E  imp_5   
 E  imp_6   
 E  imp_7   
 E  imp_8   
 E  imp_9   
 E  imp_10  
 E  imp_11  
 E  imp_12  
 E  imp_13  
 E  imp_14  
 E  imp_15  
 E  imp_16  
 E  imp_17  
 E  imp_18  
 E  imp_19  
 E  imp_20  
 E  imp_21  
 E  imp_22  
 E  imp_23  
 E  imp_24  
 E  imp_25  
 E  imp_26  
 E  imp_27  
 E  imp_28  
 E  imp_29  
 E  imp_30  
 E  imp_31  
 E  imp_32  
 E  imp_33  
 E  imp_34  
 E  imp_35  
 E  imp_36  
 E  imp_37  
 E  imp_38  
 E  imp_39  
 E  imp_40  
 E  imp_41  
 E  imp_42  
 E  imp_43  
 E  imp_44  
 E  imp_45  
 E  imp_46  
 E  imp_47  
 E  imp_48  
 E  imp_49  
 E  imp_50  
 E  imp_51  
 E  imp_52  
 E  imp_53  
 E  imp_54  
 E  imp_55  
 E  imp_56  
 E  imp_57  
 E  imp_58  
 E  imp_59  
 E  imp_60  
 E  pbt_1   
 E  pbt_2   
 E  pbt_3   
 E  pbt_4   
 E  pbt_5   
 E  pbt_6   
 E  pbt_7   
 E  pbt_8   
 E  pbt_9   
 E  pbt_10  
 E  pbt_11  
 E  pbt_12  
 E  pbt_13  
 E  pbt_14  
 E  pbt_15  
 E  pbt_16  
 E  pbt_17  
 E  pbt_18  
 E  pbt_19  
 E  pbt_20  
 E  pbt_21  
 E  pbt_22  
 E  pbt_23  
 E  pbt_24  
 E  pbt_25  
 E  pbt_26  
 E  pbt_27  
 E  pbt_28  
 E  pbt_29  
 E  pbt_30  
 E  pbt_31  
 E  pbt_32  
 E  pbt_33  
 E  pbt_34  
 E  pbt_35  
 E  pbt_36  
 E  pbt_37  
 E  pbt_38  
 E  pbt_39  
 E  pbt_40  
 E  pbt_41  
 E  pbt_42  
 E  pbt_43  
 E  pbt_44  
 E  pbt_45  
 E  pbt_46  
 E  pbt_47  
 E  pbt_48  
 E  pbt_49  
 E  pbt_50  
 E  pbt_51  
 E  pbt_52  
 E  pbt_53  
 E  pbt_54  
 E  pbt_55  
 E  pbt_56  
 E  pbt_57  
 E  pbt_58  
 E  pbt_59  
 E  pbt_60  
 E  loss_1  
 E  loss_2  
 E  loss_3  
 E  loss_4  
 E  loss_5  
 E  loss_6  
 E  loss_7  
 E  loss_8  
 E  loss_9  
 E  loss_10 
 E  loss_11 
 E  loss_12 
 E  loss_13 
 E  loss_14 
 E  loss_15 
 E  loss_16 
 E  loss_17 
 E  loss_18 
 E  loss_19 
 E  loss_20 
 E  loss_21 
 E  loss_22 
 E  loss_23 
 E  loss_24 
 E  loss_25 
 E  loss_26 
 E  loss_27 
 E  loss_28 
 E  loss_29 
 E  loss_30 
 E  loss_31 
 E  loss_32 
 E  loss_33 
 E  loss_34 
 E  loss_35 
 E  loss_36 
 E  loss_37 
 E  loss_38 
 E  loss_39 
 E  loss_40 
 E  loss_41 
 E  loss_42 
 E  loss_43 
 E  loss_44 
 E  loss_45 
 E  loss_46 
 E  loss_47 
 E  loss_48 
 E  loss_49 
 E  loss_50 
 E  loss_51 
 E  loss_52 
 E  loss_53 
 E  loss_54 
 E  loss_55 
 E  loss_56 
 E  loss_57 
 E  loss_58 
 E  loss_59 
 E  loss_60 
 E  tl_1    
 E  tl_2    
 E  tl_3    
 E  tl_4    
 E  tl_5    
 E  tl_6    
 E  tl_7    
 E  tl_8    
 E  tl_9    
 E  tl_10   
 E  tl_11   
 E  tl_12   
 E  tl_13   
 E  tl_14   
 E  tl_15   
 E  tl_16   
 E  tl_17   
 E  tl_18   
 E  tl_19   
 E  tl_20   
 E  tl_21   
 E  tl_22   
 E  tl_23   
 E  tl_24   
 E  tl_25   
 E  tl_26   
 E  tl_27   
 E  tl_28   
 E  tl_29   
 E  tl_30   
 E  tl_31   
 E  tl_32   
 E  tl_33   
 E  tl_34   
 E  tl_35   
 E  tl_36   
 E  tl_37   
 E  tl_38   
 E  tl_39   
 E  tl_40   
 E  tl_41   
 E  tl_42   
 E  tl_43   
 E  tl_44   
 E  tl_45   
 E  tl_46   
 E  tl_47   
 E  tl_48   
 E  tl_49   
 E  tl_50   
 E  tl_51   
 E  tl_52   
 E  tl_53   
 E  tl_54   
 E  tl_55   
 E  tl_56   
 E  tl_57   
 E  tl_58   
 E  tl_59   
 E  tl_60   
 L  tl_use_1
 L  tl_use_2
 L  tl_use_3
 L  tl_use_4
 L  tl_use_5
 L  tl_use_6
 L  tl_use_7
 L  tl_use_8
 L  tl_use_9
 L  tl_use_10
 L  tl_use_11
 L  tl_use_12
 L  tl_use_13
 L  tl_use_14
 L  tl_use_15
 L  tl_use_16
 L  tl_use_17
 L  tl_use_18
 L  tl_use_19
 L  tl_use_20
 L  tl_use_21
 L  tl_use_22
 L  tl_use_23
 L  tl_use_24
 L  tl_use_25
 L  tl_use_26
 L  tl_use_27
 L  tl_use_28
 L  tl_use_29
 L  tl_use_30
 L  tl_use_31
 L  tl_use_32
 L  tl_use_33
 L  tl_use_34
 L  tl_use_35
 L  tl_use_36
 L  tl_use_37
 L  tl_use_38
 L  tl_use_39
 L  tl_use_40
 L  tl_use_41
 L  tl_use_42
 L  tl_use_43
 L  tl_use_44
 L  tl_use_45
 L  tl_use_46
 L  tl_use_47
 L  tl_use_48
 L  tl_use_49
 L  tl_use_50
 L  tl_use_51
 L  tl_use_52
 L  tl_use_53
 L  tl_use_54
 L  tl_use_55
 L  tl_use_56
 L  tl_use_57
 L  tl_use_58
 L  tl_use_59
 L  tl_use_60
 E  tax_1   
 E  tax_2   
 E  tax_3   
 E  tax_4   
 E  tax_5   
 E  tax_6   
 E  tax_7   
 E  tax_8   
 E  tax_9   
 E  tax_10  
 E  tax_11  
 E  tax_12  
 E  tax_13  
 E  tax_14  
 E  tax_15  
 E  tax_16  
 E  tax_17  
 E  tax_18  
 E  tax_19  
 E  tax_20  
 E  tax_21  
 E  tax_22  
 E  tax_23  
 E  tax_24  
 E  tax_25  
 E  tax_26  
 E  tax_27  
 E  tax_28  
 E  tax_29  
 E  tax_30  
 E  tax_31  
 E  tax_32  
 E  tax_33  
 E  tax_34  
 E  tax_35  
 E  tax_36  
 E  tax_37  
 E  tax_38  
 E  tax_39  
 E  tax_40  
 E  tax_41  
 E  tax_42  
 E  tax_43  
 E  tax_44  
 E  tax_45  
 E  tax_46  
 E  tax_47  
 E  tax_48  
 E  tax_49  
 E  tax_50  
 E  tax_51  
 E  tax_52  
 E  tax_53  
 E  tax_54  
 E  tax_55  
 E  tax_56  
 E  tax_57  
 E  tax_58  
 E  tax_59  
 E  tax_60  
 E  np_1    
 E  np_2    
 E  np_3    
 E  np_4    
 E  np_5    
 E  np_6    
 E  np_7    
 E  np_8    
 E  np_9    
 E  np_10   
 E  np_11   
 E  np_12   
 E  np_13   
 E  np_14   
 E  np_15   
 E  np_16   
 E  np_17   
 E  np_18   
 E  np_19   
 E  np_20   
 E  np_21   
 E  np_22   
 E  np_23   
 E  np_24   
 E  np_25   
 E  np_26   
 E  np_27   
 E  np_28   
 E  np_29   
 E  np_30   
 E  np_31   
 E  np_32   
 E  np_33   
 E  np_34   
 E  np_35   
 E  np_36   
 E  np_37   
 E  np_38   
 E  np_39   
 E  np_40   
 E  np_41   
 E  np_42   
 E  np_43   
 E  np_44   
 E  np_45   
 E  np_46   
 E  np_47   
 E  np_48   
 E  np_49   
 E  np_50   
 E  np_51   
 E  np_52   
 E  np_53   
 E  np_54   
 E  np_55   
 E  np_56   
 E  np_57   
 E  np_58   
 E  np_59   
 E  np_60   
 E  md_1    
 E  md_2    
 E  md_3    
 E  md_4    
 E  md_5    
 E  md_6    
 E  md_7    
 E  md_8    
 E  md_9    
 E  md_10   
 E  md_11   
 E  md_12   
 E  md_13   
 E  md_14   
 E  md_15   
 E  md_16   
 E  md_17   
 E  md_18   
 E  md_19   
 E  md_20   
 E  md_21   
 E  md_22   
 E  md_23   
 E  md_24   
 E  md_25   
 E  md_26   
 E  md_27   
 E  md_28   
 E  md_29   
 E  md_30   
 E  md_31   
 E  md_32   
 E  md_33   
 E  md_34   
 E  md_35   
 E  md_36   
 E  md_37   
 E  md_38   
 E  md_39   
 E  md_40   
 E  md_41   
 E  md_42   
 E  md_43   
 E  md_44   
 E  md_45   
 E  md_46   
 E  md_47   
 E  md_48   
 E  md_49   
 E  md_50   
 E  md_51   
 E  md_52   
 E  md_53   
 E  md_54   
 E  md_55   
 E  md_56   
 E  md_57   
 E  md_58   
 E  md_59   
 E  md_60   
 E  mb_1    
 E  mb_2    
 E  mb_3    
 E  mb_4    
 E  mb_5    
 E  mb_6    
 E  mb_7    
 E  mb_8    
 E  mb_9    
 E  mb_10   
 E  mb_11   
 E  mb_12   
 E  mb_13   
 E  mb_14   
 E  mb_15   
 E  mb_16   
 E  mb_17   
 E  mb_18   
 E  mb_19   
 E  mb_20   
 E  mb_21   
 E  mb_22   
 E  mb_23   
 E  mb_24   
 E  mb_25   
 E  mb_26   
 E  mb_27   
 E  mb_28   
 E  mb_29   
 E  mb_30   
 E  mb_31   
 E  mb_32   
 E  mb_33   
 E  mb_34   
 E  mb_35   
 E  mb_36   
 E  mb_37   
 E  mb_38   
 E  mb_39   
 E  mb_40   
 E  mb_41   
 E  mb_42   
 E  mb_43   
 E  mb_44   
 E  mb_45   
 E  mb_46   
 E  mb_47   
 E  mb_48   
 E  mb_49   
 E  mb_50   
 E  mb_51   
 E  mb_52   
 E  mb_53   
 E  mb_54   
 E  mb_55   
 E  mb_56   
 E  mb_57   
 E  mb_58   
 E  mb_59   
 E  mb_60   
 E  bd_1    
 E  bd_2    
 E  bd_3    
 E  bd_4    
 E  bd_5    
 E  bd_6    
 E  bd_7    
 E  bd_8    
 E  bd_9    
 E  bd_10   
 E  bd_11   
 E  bd_12   
 E  bd_13   
 E  bd_14   
 E  bd_15   
 E  bd_16   
 E  bd_17   
 E  bd_18   
 E  bd_19   
 E  bd_20   
 E  bd_21   
 E  bd_22   
 E  bd_23   
 E  bd_24   
 E  bd_25   
 E  bd_26   
 E  bd_27   
 E  bd_28   
 E  bd_29   
 E  bd_30   
 E  bd_31   
 E  bd_32   
 E  bd_33   
 E  bd_34   
 E  bd_35   
 E  bd_36   
 E  bd_37   
 E  bd_38   
 E  bd_39   
 E  bd_40   
 E  bd_41   
 E  bd_42   
 E  bd_43   
 E  bd_44   
 E  bd_45   
 E  bd_46   
 E  bd_47   
 E  bd_48   
 E  bd_49   
 E  bd_50   
 E  bd_51   
 E  bd_52   
 E  bd_53   
 E  bd_54   
 E  bd_55   
 E  bd_56   
 E  bd_57   
 E  bd_58   
 E  bd_59   
 E  bd_60   
 E  bb_1    
 E  bb_2    
 E  bb_3    
 E  bb_4    
 E  bb_5    
 E  bb_6    
 E  bb_7    
 E  bb_8    
 E  bb_9    
 E  bb_10   
 E  bb_11   
 E  bb_12   
 E  bb_13   
 E  bb_14   
 E  bb_15   
 E  bb_16   
 E  bb_17   
 E  bb_18   
 E  bb_19   
 E  bb_20   
 E  bb_21   
 E  bb_22   
 E  bb_23   
 E  bb_24   
 E  bb_25   
 E  bb_26   
 E  bb_27   
 E  bb_28   
 E  bb_29   
 E  bb_30   
 E  bb_31   
 E  bb_32   
 E  bb_33   
 E  bb_34   
 E  bb_35   
 E  bb_36   
 E  bb_37   
 E  bb_38   
 E  bb_39   
 E  bb_40   
 E  bb_41   
 E  bb_42   
 E  bb_43   
 E  bb_44   
 E  bb_45   
 E  bb_46   
 E  bb_47   
 E  bb_48   
 E  bb_49   
 E  bb_50   
 E  bb_51   
 E  bb_52   
 E  bb_53   
 E  bb_54   
 E  bb_55   
 E  bb_56   
 E  bb_57   
 E  bb_58   
 E  bb_59   
 E  bb_60   
 G  spend_1 
 L  spend_2 
 L  spend_3 
 L  spend_4 
 L  spend_5 
 L  spend_6 
 L  spend_7 
 L  spend_8 
 L  spend_9 
 L  spend_10
 L  spend_11
 L  spend_12
 L  spend_13
 L  spend_14
 L  spend_15
 L  spend_16
 L  spend_17
 L  spend_18
 L  spend_19
 L  spend_20
 L  spend_21
 L  spend_22
 L  spend_23
 L  spend_24
 L  spend_25
 L  spend_26
 L  spend_27
 L  spend_28
 L  spend_29
 L  spend_30
 L  spend_31
 L  spend_32
 L  spend_33
 L  spend_34
 L  spend_35
 L  spend_36
 L  spend_37
 L  spend_38
 L  spend_39
 L  spend_40
 L  spend_41
 L  spend_42
 L  spend_43
 L  spend_44
 L  spend_45
 L  spend_46
 L  spend_47
 L  spend_48
 L  spend_49
 L  spend_50
 L  spend_51
 L  spend_52
 L  spend_53
 L  spend_54
 L  spend_55
 L  spend_56
 L  spend_57
 L  spend_58
 L  spend_59
 L  spend_60
 E  rwa_1   
 E  rwa_2   
 E  rwa_3   
 E  rwa_4   
 E  rwa_5   
 E  rwa_6   
 E  rwa_7   
 E  rwa_8   
 E  rwa_9   
 E  rwa_10  
 E  rwa_11  
 E  rwa_12  
 E  rwa_13  
 E  rwa_14  
 E  rwa_15  
 E  rwa_16  
 E  rwa_17  
 E  rwa_18  
 E  rwa_19  
 E  rwa_20  
 E  rwa_21  
 E  rwa_22  
 E  rwa_23  
 E  rwa_24  
 E  rwa_25  
 E  rwa_26  
 E  rwa_27  
 E  rwa_28  
 E  rwa_29  
 E  rwa_30  
 E  rwa_31  
 E  rwa_32  
 E  rwa_33  
 E  rwa_34  
 E  rwa_35  
 E  rwa_36  
 E  rwa_37  
 E  rwa_38  
 E  rwa_39  
 E  rwa_40  
 E  rwa_41  
 E  rwa_42  
 E  rwa_43  
 E  rwa_44  
 E  rwa_45  
 E  rwa_46  
 E  rwa_47  
 E  rwa_48  
 E  rwa_49  
 E  rwa_50  
 E  rwa_51  
 E  rwa_52  
 E  rwa_53  
 E  rwa_54  
 E  rwa_55  
 E  rwa_56  
 E  rwa_57  
 E  rwa_58  
 E  rwa_59  
 E  rwa_60  
 E  out_1   
 E  out_2   
 E  out_3   
 E  out_4   
 E  out_5   
 E  out_6   
 E  out_7   
 E  out_8   
 E  out_9   
 E  out_10  
 E  out_11  
 E  out_12  
 E  out_13  
 E  out_14  
 E  out_15  
 E  out_16  
 E  out_17  
 E  out_18  
 E  out_19  
 E  out_20  
 E  out_21  
 E  out_22  
 E  out_23  
 E  out_24  
 E  out_25  
 E  out_26  
 E  out_27  
 E  out_28  
 E  out_29  
 E  out_30  
 E  out_31  
 E  out_32  
 E  out_33  
 E  out_34  
 E  out_35  
 E  out_36  
 E  out_37  
 E  out_38  
 E  out_39  
 E  out_40  
 E  out_41  
 E  out_42  
 E  out_43  
 E  out_44  
 E  out_45  
 E  out_46  
 E  out_47  
 E  out_48  
 E  out_49  
 E  out_50  
 E  out_51  
 E  out_52  
 E  out_53  
 E  out_54  
 E  out_55  
 E  out_56  
 E  out_57  
 E  out_58  
 E  out_59  
 E  out_60  
 E  in_1    
 E  in_2    
 E  in_3    
 E  in_4    
 E  in_5    
 E  in_6    
 E  in_7    
 E  in_8    
 E  in_9    
 E  in_10   
 E  in_11   
 E  in_12   
 E  in_13   
 E  in_14   
 E  in_15   
 E  in_16   
 E  in_17   
 E  in_18   
 E  in_19   
 E  in_20   
 E  in_21   
 E  in_22   
 E  in_23   
 E  in_24   
 E  in_25   
 E  in_26   
 E  in_27   
 E  in_28   
 E  in_29   
 E  in_30   
 E  in_31   
 E  in_32   
 E  in_33   
 E  in_34   
 E  in_35   
 E  in_36   
 E  in_37   
 E  in_38   
 E  in_39   
 E  in_40   
 E  in_41   
 E  in_42   
 E  in_43   
 E  in_44   
 E  in_45   
 E  in_46   
 E  in_47   
 E  in_48   
 E  in_49   
 E  in_50   
 E  in_51   
 E  in_52   
 E  in_53   
 E  in_54   
 E  in_55   
 E  in_56   
 E  in_57   
 E  in_58   
 E  in_59   
 E  in_60   
 E  asf_1   
 E  asf_2   
 E  asf_3   
 E  asf_4   
 E  asf_5   
 E  asf_6   
 E  asf_7   
 E  asf_8   
 E  asf_9   
 E  asf_10  
 E  asf_11  
 E  asf_12  
 E  asf_13  
 E  asf_14  
 E  asf_15  
 E  asf_16  
 E  asf_17  
 E  asf_18  
 E  asf_19  
 E  asf_20  
 E  asf_21  
 E  asf_22  
 E  asf_23  
 E  asf_24  
 E  asf_25  
 E  asf_26  
 E  asf_27  
 E  asf_28  
 E  asf_29  
 E  asf_30  
 E  asf_31  
 E  asf_32  
 E  asf_33  
 E  asf_34  
 E  asf_35  
 E  asf_36  
 E  asf_37  
 E  asf_38  
 E  asf_39  
 E  asf_40  
 E  asf_41  
 E  asf_42  
 E  asf_43  
 E  asf_44  
 E  asf_45  
 E  asf_46  
 E  asf_47  
 E  asf_48  
 E  asf_49  
 E  asf_50  
 E  asf_51  
 E  asf_52  
 E  asf_53  
 E  asf_54  
 E  asf_55  
 E  asf_56  
 E  asf_57  
 E  asf_58  
 E  asf_59  
 E  asf_60  
 E  rsf_1   
 E  rsf_2   
 E  rsf_3   
 E  rsf_4   
 E  rsf_5   
 E  rsf_6   
 E  rsf_7   
 E  rsf_8   
 E  rsf_9   
 E  rsf_10  
 E  rsf_11  
 E  rsf_12  
 E  rsf_13  
 E  rsf_14  
 E  rsf_15  
 E  rsf_16  
 E  rsf_17  
 E  rsf_18  
 E  rsf_19  
 E  rsf_20  
 E  rsf_21  
 E  rsf_22  
 E  rsf_23  
 E  rsf_24  
 E  rsf_25  
 E  rsf_26  
 E  rsf_27  
 E  rsf_28  
 E  rsf_29  
 E  rsf_30  
 E  rsf_31  
 E  rsf_32  
 E  rsf_33  
 E  rsf_34  
 E  rsf_35  
 E  rsf_36  
 E  rsf_37  
 E  rsf_38  
 E  rsf_39  
 E  rsf_40  
 E  rsf_41  
 E  rsf_42  
 E  rsf_43  
 E  rsf_44  
 E  rsf_45  
 E  rsf_46  
 E  rsf_47  
 E  rsf_48  
 E  rsf_49  
 E  rsf_50  
 E  rsf_51  
 E  rsf_52  
 E  rsf_53  
 E  rsf_54  
 E  rsf_55  
 E  rsf_56  
 E  rsf_57  
 E  rsf_58  
 E  rsf_59  
 E  rsf_60  
 G  cap_min_1
 G  cap_min_2
 G  cap_min_3
 G  cap_min_4
 G  cap_min_5
 G  cap_min_6
 G  cap_min_7
 G  cap_min_8
 G  cap_min_9
 G  cap_min_10
 G  cap_min_11
 G  cap_min_12
 G  cap_min_13
 G  cap_min_14
 G  cap_min_15
 G  cap_min_16
 G  cap_min_17
 G  cap_min_18
 G  cap_min_19
 G  cap_min_20
 G  cap_min_21
 G  cap_min_22
 G  cap_min_23
 G  cap_min_24
 G  cap_min_25
 G  cap_min_26
 G  cap_min_27
 G  cap_min_28
 G  cap_min_29
 G  cap_min_30
 G  cap_min_31
 G  cap_min_32
 G  cap_min_33
 G  cap_min_34
 G  cap_min_35
 G  cap_min_36
 G  cap_min_37
 G  cap_min_38
 G  cap_min_39
 G  cap_min_40
 G  cap_min_41
 G  cap_min_42
 G  cap_min_43
 G  cap_min_44
 G  cap_min_45
 G  cap_min_46
 G  cap_min_47
 G  cap_min_48
 G  cap_min_49
 G  cap_min_50
 G  cap_min_51
 G  cap_min_52
 G  cap_min_53
 G  cap_min_54
 G  cap_min_55
 G  cap_min_56
 G  cap_min_57
 G  cap_min_58
 G  cap_min_59
 G  cap_min_60
 G  cap_buf_1
 G  cap_buf_2
 G  cap_buf_3
 G  cap_buf_4
 G  cap_buf_5
 G  cap_buf_6
 G  cap_buf_7
 G  cap_buf_8
 G  cap_buf_9
 G  cap_buf_10
 G  cap_buf_11
 G  cap_buf_12
 G  cap_buf_13
 G  cap_buf_14
 G  cap_buf_15
 G  cap_buf_16
 G  cap_buf_17
 G  cap_buf_18
 G  cap_buf_19
 G  cap_buf_20
 G  cap_buf_21
 G  cap_buf_22
 G  cap_buf_23
 G  cap_buf_24
 G  cap_buf_25
 G  cap_buf_26
 G  cap_buf_27
 G  cap_buf_28
 G  cap_buf_29
 G  cap_buf_30
 G  cap_buf_31
 G  cap_buf_32
 G  cap_buf_33
 G  cap_buf_34
 G  cap_buf_35
 G  cap_buf_36
 G  cap_buf_37
 G  cap_buf_38
 G  cap_buf_39
 G  cap_buf_40
 G  cap_buf_41
 G  cap_buf_42
 G  cap_buf_43
 G  cap_buf_44
 G  cap_buf_45
 G  cap_buf_46
 G  cap_buf_47
 G  cap_buf_48
 G  cap_buf_49
 G  cap_buf_50
 G  cap_buf_51
 G  cap_buf_52
 G  cap_buf_53
 G  cap_buf_54
 G  cap_buf_55
 G  cap_buf_56
 G  cap_buf_57
 G  cap_buf_58
 G  cap_buf_59
 G  cap_buf_60
 G  lev_min_1
 G  lev_min_2
 G  lev_min_3
 G  lev_min_4
 G  lev_min_5
 G  lev_min_6
 G  lev_min_7
 G  lev_min_8
 G  lev_min_9
 G  lev_min_10
 G  lev_min_11
 G  lev_min_12
 G  lev_min_13
 G  lev_min_14
 G  lev_min_15
 G  lev_min_16
 G  lev_min_17
 G  lev_min_18
 G  lev_min_19
 G  lev_min_20
 G  lev_min_21
 G  lev_min_22
 G  lev_min_23
 G  lev_min_24
 G  lev_min_25
 G  lev_min_26
 G  lev_min_27
 G  lev_min_28
 G  lev_min_29
 G  lev_min_30
 G  lev_min_31
 G  lev_min_32
 G  lev_min_33
 G  lev_min_34
 G  lev_min_35
 G  lev_min_36
 G  lev_min_37
 G  lev_min_38
 G  lev_min_39
 G  lev_min_40
 G  lev_min_41
 G  lev_min_42
 G  lev_min_43
 G  lev_min_44
 G  lev_min_45
 G  lev_min_46
 G  lev_min_47
 G  lev_min_48
 G  lev_min_49
 G  lev_min_50
 G  lev_min_51
 G  lev_min_52
 G  lev_min_53
 G  lev_min_54
 G  lev_min_55
 G  lev_min_56
 G  lev_min_57
 G  lev_min_58
 G  lev_min_59
 G  lev_min_60
 G  lev_buf_1
 G  lev_buf_2
 G  lev_buf_3
 G  lev_buf_4
 G  lev_buf_5
 G  lev_buf_6
 G  lev_buf_7
 G  lev_buf_8
 G  lev_buf_9
 G  lev_buf_10
 G  lev_buf_11
 G  lev_buf_12
 G  lev_buf_13
 G  lev_buf_14
 G  lev_buf_15
 G  lev_buf_16
 G  lev_buf_17
 G  lev_buf_18
 G  lev_buf_19
 G  lev_buf_20
 G  lev_buf_21
 G  lev_buf_22
 G  lev_buf_23
 G  lev_buf_24
 G  lev_buf_25
 G  lev_buf_26
 G  lev_buf_27
 G  lev_buf_28
 G  lev_buf_29
 G  lev_buf_30
 G  lev_buf_31
 G  lev_buf_32
 G  lev_buf_33
 G  lev_buf_34
 G  lev_buf_35
 G  lev_buf_36
 G  lev_buf_37
 G  lev_buf_38
 G  lev_buf_39
 G  lev_buf_40
 G  lev_buf_41
 G  lev_buf_42
 G  lev_buf_43
 G  lev_buf_44
 G  lev_buf_45
 G  lev_buf_46
 G  lev_buf_47
 G  lev_buf_48
 G  lev_buf_49
 G  lev_buf_50
 G  lev_buf_51
 G  lev_buf_52
 G  lev_buf_53
 G  lev_buf_54
 G  lev_buf_55
 G  lev_buf_56
 G  lev_buf_57
 G  lev_buf_58
 G  lev_buf_59
 G  lev_buf_60
 G  lcr_min_1
 G  lcr_min_2
 G  lcr_min_3
 G  lcr_min_4
 G  lcr_min_5
 G  lcr_min_6
 G  lcr_min_7
 G  lcr_min_8
 G  lcr_min_9
 G  lcr_min_10
 G  lcr_min_11
 G  lcr_min_12
 G  lcr_min_13
 G  lcr_min_14
 G  lcr_min_15
 G  lcr_min_16
 G  lcr_min_17
 G  lcr_min_18
 G  lcr_min_19
 G  lcr_min_20
 G  lcr_min_21
 G  lcr_min_22
 G  lcr_min_23
 G  lcr_min_24
 G  lcr_min_25
 G  lcr_min_26
 G  lcr_min_27
 G  lcr_min_28
 G  lcr_min_29
 G  lcr_min_30
 G  lcr_min_31
 G  lcr_min_32
 G  lcr_min_33
 G  lcr_min_34
 G  lcr_min_35
 G  lcr_min_36
 G  lcr_min_37
 G  lcr_min_38
 G  lcr_min_39
 G  lcr_min_40
 G  lcr_min_41
 G  lcr_min_42
 G  lcr_min_43
 G  lcr_min_44
 G  lcr_min_45
 G  lcr_min_46
 G  lcr_min_47
 G  lcr_min_48
 G  lcr_min_49
 G  lcr_min_50
 G  lcr_min_51
 G  lcr_min_52
 G  lcr_min_53
 G  lcr_min_54
 G  lcr_min_55
 G  lcr_min_56
 G  lcr_min_57
 G  lcr_min_58
 G  lcr_min_59
 G  lcr_min_60
 G  lcr_cap_min_1
 G  lcr_cap_min_2
 G  lcr_cap_min_3
 G  lcr_cap_min_4
 G  lcr_cap_min_5
 G  lcr_cap_min_6
 G  lcr_cap_min_7
 G  lcr_cap_min_8
 G  lcr_cap_min_9
 G  lcr_cap_min_10
 G  lcr_cap_min_11
 G  lcr_cap_min_12
 G  lcr_cap_min_13
 G  lcr_cap_min_14
 G  lcr_cap_min_15
 G  lcr_cap_min_16
 G  lcr_cap_min_17
 G  lcr_cap_min_18
 G  lcr_cap_min_19
 G  lcr_cap_min_20
 G  lcr_cap_min_21
 G  lcr_cap_min_22
 G  lcr_cap_min_23
 G  lcr_cap_min_24
 G  lcr_cap_min_25
 G  lcr_cap_min_26
 G  lcr_cap_min_27
 G  lcr_cap_min_28
 G  lcr_cap_min_29
 G  lcr_cap_min_30
 G  lcr_cap_min_31
 G  lcr_cap_min_32
 G  lcr_cap_min_33
 G  lcr_cap_min_34
 G  lcr_cap_min_35
 G  lcr_cap_min_36
 G  lcr_cap_min_37
 G  lcr_cap_min_38
 G  lcr_cap_min_39
 G  lcr_cap_min_40
 G  lcr_cap_min_41
 G  lcr_cap_min_42
 G  lcr_cap_min_43
 G  lcr_cap_min_44
 G  lcr_cap_min_45
 G  lcr_cap_min_46
 G  lcr_cap_min_47
 G  lcr_cap_min_48
 G  lcr_cap_min_49
 G  lcr_cap_min_50
 G  lcr_cap_min_51
 G  lcr_cap_min_52
 G  lcr_cap_min_53
 G  lcr_cap_min_54
 G  lcr_cap_min_55
 G  lcr_cap_min_56
 G  lcr_cap_min_57
 G  lcr_cap_min_58
 G  lcr_cap_min_59
 G  lcr_cap_min_60
 G  lcr_buf_1
 G  lcr_buf_2
 G  lcr_buf_3
 G  lcr_buf_4
 G  lcr_buf_5
 G  lcr_buf_6
 G  lcr_buf_7
 G  lcr_buf_8
 G  lcr_buf_9
 G  lcr_buf_10
 G  lcr_buf_11
 G  lcr_buf_12
 G  lcr_buf_13
 G  lcr_buf_14
 G  lcr_buf_15
 G  lcr_buf_16
 G  lcr_buf_17
 G  lcr_buf_18
 G  lcr_buf_19
 G  lcr_buf_20
 G  lcr_buf_21
 G  lcr_buf_22
 G  lcr_buf_23
 G  lcr_buf_24
 G  lcr_buf_25
 G  lcr_buf_26
 G  lcr_buf_27
 G  lcr_buf_28
 G  lcr_buf_29
 G  lcr_buf_30
 G  lcr_buf_31
 G  lcr_buf_32
 G  lcr_buf_33
 G  lcr_buf_34
 G  lcr_buf_35
 G  lcr_buf_36
 G  lcr_buf_37
 G  lcr_buf_38
 G  lcr_buf_39
 G  lcr_buf_40
 G  lcr_buf_41
 G  lcr_buf_42
 G  lcr_buf_43
 G  lcr_buf_44
 G  lcr_buf_45
 G  lcr_buf_46
 G  lcr_buf_47
 G  lcr_buf_48
 G  lcr_buf_49
 G  lcr_buf_50
 G  lcr_buf_51
 G  lcr_buf_52
 G  lcr_buf_53
 G  lcr_buf_54
 G  lcr_buf_55
 G  lcr_buf_56
 G  lcr_buf_57
 G  lcr_buf_58
 G  lcr_buf_59
 G  lcr_buf_60
 G  lcr_cap_buf_1
 G  lcr_cap_buf_2
 G  lcr_cap_buf_3
 G  lcr_cap_buf_4
 G  lcr_cap_buf_5
 G  lcr_cap_buf_6
 G  lcr_cap_buf_7
 G  lcr_cap_buf_8
 G  lcr_cap_buf_9
 G  lcr_cap_buf_10
 G  lcr_cap_buf_11
 G  lcr_cap_buf_12
 G  lcr_cap_buf_13
 G  lcr_cap_buf_14
 G  lcr_cap_buf_15
 G  lcr_cap_buf_16
 G  lcr_cap_buf_17
 G  lcr_cap_buf_18
 G  lcr_cap_buf_19
 G  lcr_cap_buf_20
 G  lcr_cap_buf_21
 G  lcr_cap_buf_22
 G  lcr_cap_buf_23
 G  lcr_cap_buf_24
 G  lcr_cap_buf_25
 G  lcr_cap_buf_26
 G  lcr_cap_buf_27
 G  lcr_cap_buf_28
 G  lcr_cap_buf_29
 G  lcr_cap_buf_30
 G  lcr_cap_buf_31
 G  lcr_cap_buf_32
 G  lcr_cap_buf_33
 G  lcr_cap_buf_34
 G  lcr_cap_buf_35
 G  lcr_cap_buf_36
 G  lcr_cap_buf_37
 G  lcr_cap_buf_38
 G  lcr_cap_buf_39
 G  lcr_cap_buf_40
 G  lcr_cap_buf_41
 G  lcr_cap_buf_42
 G  lcr_cap_buf_43
 G  lcr_cap_buf_44
 G  lcr_cap_buf_45
 G  lcr_cap_buf_46
 G  lcr_cap_buf_47
 G  lcr_cap_buf_48
 G  lcr_cap_buf_49
 G  lcr_cap_buf_50
 G  lcr_cap_buf_51
 G  lcr_cap_buf_52
 G  lcr_cap_buf_53
 G  lcr_cap_buf_54
 G  lcr_cap_buf_55
 G  lcr_cap_buf_56
 G  lcr_cap_buf_57
 G  lcr_cap_buf_58
 G  lcr_cap_buf_59
 G  lcr_cap_buf_60
 G  nsfr_min_1
 G  nsfr_min_2
 G  nsfr_min_3
 G  nsfr_min_4
 G  nsfr_min_5
 G  nsfr_min_6
 G  nsfr_min_7
 G  nsfr_min_8
 G  nsfr_min_9
 G  nsfr_min_10
 G  nsfr_min_11
 G  nsfr_min_12
 G  nsfr_min_13
 G  nsfr_min_14
 G  nsfr_min_15
 G  nsfr_min_16
 G  nsfr_min_17
 G  nsfr_min_18
 G  nsfr_min_19
 G  nsfr_min_20
 G  nsfr_min_21
 G  nsfr_min_22
 G  nsfr_min_23
 G  nsfr_min_24
 G  nsfr_min_25
 G  nsfr_min_26
 G  nsfr_min_27
 G  nsfr_min_28
 G  nsfr_min_29
 G  nsfr_min_30
 G  nsfr_min_31
 G  nsfr_min_32
 G  nsfr_min_33
 G  nsfr_min_34
 G  nsfr_min_35
 G  nsfr_min_36
 G  nsfr_min_37
 G  nsfr_min_38
 G  nsfr_min_39
 G  nsfr_min_40
 G  nsfr_min_41
 G  nsfr_min_42
 G  nsfr_min_43
 G  nsfr_min_44
 G  nsfr_min_45
 G  nsfr_min_46
 G  nsfr_min_47
 G  nsfr_min_48
 G  nsfr_min_49
 G  nsfr_min_50
 G  nsfr_min_51
 G  nsfr_min_52
 G  nsfr_min_53
 G  nsfr_min_54
 G  nsfr_min_55
 G  nsfr_min_56
 G  nsfr_min_57
 G  nsfr_min_58
 G  nsfr_min_59
 G  nsfr_min_60
 G  nsfr_buf_1
 G  nsfr_buf_2
 G  nsfr_buf_3
 G  nsfr_buf_4
 G  nsfr_buf_5
 G  nsfr_buf_6
 G  nsfr_buf_7
 G  nsfr_buf_8
 G  nsfr_buf_9
 G  nsfr_buf_10
 G  nsfr_buf_11
 G  nsfr_buf_12
 G  nsfr_buf_13
 G  nsfr_buf_14
 G  nsfr_buf_15
 G  nsfr_buf_16
 G  nsfr_buf_17
 G  nsfr_buf_18
 G  nsfr_buf_19
 G  nsfr_buf_20
 G  nsfr_buf_21
 G  nsfr_buf_22
 G  nsfr_buf_23
 G  nsfr_buf_24
 G  nsfr_buf_25
 G  nsfr_buf_26
 G  nsfr_buf_27
 G  nsfr_buf_28
 G  nsfr_buf_29
 G  nsfr_buf_30
 G  nsfr_buf_31
 G  nsfr_buf_32
 G  nsfr_buf_33
 G  nsfr_buf_34
 G  nsfr_buf_35
 G  nsfr_buf_36
 G  nsfr_buf_37
 G  nsfr_buf_38
 G  nsfr_buf_39
 G  nsfr_buf_40
 G  nsfr_buf_41
 G  nsfr_buf_42
 G  nsfr_buf_43
 G  nsfr_buf_44
 G  nsfr_buf_45
 G  nsfr_buf_46
 G  nsfr_buf_47
 G  nsfr_buf_48
 G  nsfr_buf_49
 G  nsfr_buf_50
 G  nsfr_buf_51
 G  nsfr_buf_52
 G  nsfr_buf_53
 G  nsfr_buf_54
 G  nsfr_buf_55
 G  nsfr_buf_56
 G  nsfr_buf_57
 G  nsfr_buf_58
 G  nsfr_buf_59
 G  nsfr_buf_60
 G  end_capital
 G  end_loans
COLUMNS
    x_1       loan_1    1
    x_1       lf_1      -1
    x_1       lf_25     -0.78567814080721876
    x_1       lr_1      -0.052999999999999999
    x_1       lr_25     -0.041640941462782591
    x_1       lm_1      -0.002
    x_1       lm_25     -0.0015713562816144376
    x_2       loan_2    1
    x_2       lf_2      1
    x_2       lf_26     -0.78567814080721876
    x_2       lr_2      0.052915249999999997
    x_2       lr_26     -0.041574355240349178
    x_2       lm_2      0.002
    x_2       lm_26     -0.0015713562816144376
    x_3       loan_3    1
    x_3       lf_3      1
    x_3       lf_27     -0.78567814080721876
    x_3       lr_3      0.052830509999999997
    x_3       lr_27     -0.041507776874697179
    x_3       lm_3      0.002
    x_3       lm_27     -0.0015713562816144376
    x_4       loan_4    1
    x_4       lf_4      1
    x_4       lf_28     -0.78567814080721876
    x_4       lr_4      0.052745759999999996
    x_4       lr_28     -0.041441190652263767
    x_4       lm_4      0.002
    x_4       lm_28     -0.0015713562816144376
    x_5       loan_5    1
    x_5       lf_5      1
    x_5       lf_29     -0.78567814080721876
    x_5       lr_5      0.052661019999999996
    x_5       lr_29     -0.04137461228661176
    x_5       lm_5      0.002
    x_5       lm_29     -0.0015713562816144376
    x_6       loan_6    1
    x_6       lf_6      1
    x_6       lf_30     -0.78567814080721876
    x_6       lr_6      0.052576270000000001
    x_6       lr_30     -0.041308026064178355
    x_6       lm_6      0.002
    x_6       lm_30     -0.0015713562816144376
    x_7       loan_7    1
    x_7       lf_7      1
    x_7       lf_31     -0.78567814080721876
    x_7       lr_7      0.052491530000000002
    x_7       lr_31     -0.041241447698526348
    x_7       lm_7      0.002
    x_7       lm_31     -0.0015713562816144376
    x_8       loan_8    1
    x_8       lf_8      1
    x_8       lf_32     -0.78567814080721876
    x_8       lr_8      0.05240678
    x_8       lr_32     -0.041174861476092936
    x_8       lm_8      0.002
    x_8       lm_32     -0.0015713562816144376
    x_9       loan_9    1
    x_9       lf_9      1
    x_9       lf_33     -0.78567814080721876
    x_9       lr_9      0.052322029999999999
    x_9       lr_33     -0.041108275253659524
    x_9       lm_9      0.002
    x_9       lm_33     -0.0015713562816144376
    x_10      loan_10   1
    x_10      lf_10     1
    x_10      lf_34     -0.78567814080721876
    x_10      lr_10     0.052237289999999999
    x_10      lr_34     -0.041041696888007517
    x_10      lm_10     0.002
    x_10      lm_34     -0.0015713562816144376
    x_11      loan_11   1
    x_11      lf_11     1
    x_11      lf_35     -0.78567814080721876
    x_11      lr_11     0.052152539999999997
    x_11      lr_35     -0.040975110665574105
    x_11      lm_11     0.002
    x_11      lm_35     -0.0015713562816144376
    x_12      loan_12   1
    x_12      lf_12     1
    x_12      lf_36     -0.78567814080721876
    x_12      lr_12     0.052067799999999997
    x_12      lr_36     -0.040908532299922105
    x_12      lm_12     0.002
    x_12      lm_36     -0.0015713562816144376
    x_13      loan_13   1
    x_13      lf_13     1
    x_13      lf_37     -0.78567814080721876
    x_13      lr_13     0.051983049999999996
    x_13      lr_37     -0.040841946077488693
    x_13      lm_13     0.002
    x_13      lm_37     -0.0015713562816144376
    x_14      loan_14   1
    x_14      lf_14     1
    x_14      lf_38     -0.78567814080721876
    x_14      lr_14     0.051898309999999996
    x_14      lr_38     -0.040775367711836687
    x_14      lm_14     0.002
    x_14      lm_38     -0.0015713562816144376
    x_15      loan_15   1
    x_15      lf_15     1
    x_15      lf_39     -0.78567814080721876
    x_15      lr_15     0.051813560000000002
    x_15      lr_39     -0.040708781489403281
    x_15      lm_15     0.002
    x_15      lm_39     -0.0015713562816144376
    x_16      loan_16   1
    x_16      lf_16     1
    x_16      lf_40     -0.78567814080721876
    x_16      lr_16     0.05172881
    x_16      lr_40     -0.040642195266969869
    x_16      lm_16     0.002
    x_16      lm_40     -0.0015713562816144376
    x_17      loan_17   1
    x_17      lf_17     1
    x_17      lf_41     -0.78567814080721876
    x_17      lr_17     0.05164407
    x_17      lr_41     -0.040575616901317862
    x_17      lm_17     0.002
    x_17      lm_41     -0.0015713562816144376
    x_18      loan_18   1
    x_18      lf_18     1
    x_18      lf_42     -0.78567814080721876
    x_18      lr_18     0.051559319999999999
    x_18      lr_42     -0.04050903067888445
    x_18      lm_18     0.002
    x_18      lm_42     -0.0015713562816144376
    x_19      loan_19   1
    x_19      lf_19     1
    x_19      lf_43     -0.78567814080721876
    x_19      lr_19     0.051474579999999999
    x_19      lr_43     -0.040442452313232444
    x_19      lm_19     0.002
    x_19      lm_43     -0.0015713562816144376
    x_20      loan_20   1
    x_20      lf_20     1
    x_20      lf_44     -0.78567814080721876
    x_20      lr_20     0.051389829999999997
    x_20      lr_44     -0.040375866090799031
    x_20      lm_20     0.002
    x_20      lm_44     -0.0015713562816144376
    x_21      loan_21   1
    x_21      lf_21     1
    x_21      lf_45     -0.78567814080721876
    x_21      lr_21     0.051305079999999996
    x_21      lr_45     -0.040309279868365619
    x_21      lm_21     0.002
    x_21      lm_45     -0.0015713562816144376
    x_22      loan_22   1
    x_22      lf_22     1
    x_22      lf_46     -0.78567814080721876
    x_22      lr_22     0.051220339999999996
    x_22      lr_46     -0.04024270150271362
    x_22      lm_22     0.002
    x_22      lm_46     -0.0015713562816144376
    x_23      loan_23   1
    x_23      lf_23     1
    x_23      lf_47     -0.78567814080721876
    x_23      lr_23     0.051135590000000002
    x_23      lr_47     -0.040176115280280207
    x_23      lm_23     0.002
    x_23      lm_47     -0.0015713562816144376
    x_24      loan_24   1
    x_24      lf_24     1
    x_24      lf_48     -0.78567814080721876
    x_24      lr_24     0.051050849999999995
    x_24      lr_48     -0.040109536914628201
    x_24      lm_24     0.002
    x_24      lm_48     -0.0015713562816144376
    x_25      loan_25   1
    x_25      lf_25     1
    x_25      lf_49     -0.78567814080721876
    x_25      lr_25     0.0509661
    x_25      lr_49     -0.040042950692194795
    x_25      lm_25     0.002
    x_25      lm_49     -0.0015713562816144376
    x_26      loan_26   1
    x_26      lf_26     1
    x_26      lf_50     -0.78567814080721876
    x_26      lr_26     0.05088136
    x_26      lr_50     -0.039976372326542789
    x_26      lm_26     0.002
    x_26      lm_50     -0.0015713562816144376
    x_27      loan_27   1
    x_27      lf_27     1
    x_27      lf_51     -0.78567814080721876
    x_27      lr_27     0.050796609999999999
    x_27      lr_51     -0.039909786104109377
    x_27      lm_27     0.002
    x_27      lm_51     -0.0015713562816144376
    x_28      loan_28   1
    x_28      lf_28     1
    x_28      lf_52     -0.78567814080721876
    x_28      lr_28     0.050711859999999997
    x_28      lr_52     -0.039843199881675964
    x_28      lm_28     0.002
    x_28      lm_52     -0.0015713562816144376
    x_29      loan_29   1
    x_29      lf_29     1
    x_29      lf_53     -0.78567814080721876
    x_29      lr_29     0.050627119999999998
    x_29      lr_53     -0.039776621516023958
    x_29      lm_29     0.002
    x_29      lm_53     -0.0015713562816144376
    x_30      loan_30   1
    x_30      lf_30     1
    x_30      lf_54     -0.78567814080721876
    x_30      lr_30     0.050542369999999996
    x_30      lr_54     -0.039710035293590545
    x_30      lm_30     0.002
    x_30      lm_54     -0.0015713562816144376
    x_31      loan_31   1
    x_31      lf_31     1
    x_31      lf_55     -0.78567814080721876
    x_31      lr_31     0.050457629999999996
    x_31      lr_55     -0.039643456927938546
    x_31      lm_31     0.002
    x_31      lm_55     -0.0015713562816144376
    x_32      loan_32   1
    x_32      lf_32     1
    x_32      lf_56     -0.78567814080721876
    x_32      lr_32     0.050372879999999995
    x_32      lr_56     -0.039576870705505127
    x_32      lm_32     0.002
    x_32      lm_56     -0.0015713562816144376
    x_33      loan_33   1
    x_33      lf_33     1
    x_33      lf_57     -0.78567814080721876
    x_33      lr_33     0.050288139999999995
    x_33      lr_57     -0.039510292339853127
    x_33      lm_33     0.002
    x_33      lm_57     -0.0015713562816144376
    x_34      loan_34   1
    x_34      lf_34     1
    x_34      lf_58     -0.78567814080721876
    x_34      lr_34     0.050203390000000001
    x_34      lr_58     -0.039443706117419722
    x_34      lm_34     0.002
    x_34      lm_58     -0.0015713562816144376
    x_35      loan_35   1
    x_35      lf_35     1
    x_35      lf_59     -0.78567814080721876
    x_35      lr_35     0.050118639999999999
    x_35      lr_59     -0.039377119894986302
    x_35      lm_35     0.002
    x_35      lm_59     -0.0015713562816144376
    x_36      loan_36   1
    x_36      lf_36     1
    x_36      lf_60     -0.78567814080721876
    x_36      lr_36     0.050033899999999999
    x_36      lr_60     -0.039310541529334303
    x_36      lm_36     0.002
    x_36      lm_60     -0.0015713562816144376
    x_37      loan_37   1
    x_37      lf_37     1
    x_37      lr_37     0.049949149999999998
    x_37      lm_37     0.002
    x_38      loan_38   1
    x_38      lf_38     1
    x_38      lr_38     0.049864409999999998
    x_38      lm_38     0.002
    x_39      loan_39   1
    x_39      lf_39     1
    x_39      lr_39     0.049779659999999996
    x_39      lm_39     0.002
    x_40      loan_40   1
    x_40      lf_40     1
    x_40      lr_40     0.049694919999999997
    x_40      lm_40     0.002
    x_41      loan_41   1
    x_41      lf_41     1
    x_41      lr_41     0.049610169999999995
    x_41      lm_41     0.002
    x_42      loan_42   1
    x_42      lf_42     1
    x_42      lr_42     0.049525420000000001
    x_42      lm_42     0.002
    x_43      loan_43   1
    x_43      lf_43     1
    x_43      lr_43     0.049440680000000001
    x_43      lm_43     0.002
    x_44      loan_44   1
    x_44      lf_44     1
    x_44      lr_44     0.049355929999999999
    x_44      lm_44     0.002
    x_45      loan_45   1
    x_45      lf_45     1
    x_45      lr_45     0.049271189999999999
    x_45      lm_45     0.002
    x_46      loan_46   1
    x_46      lf_46     1
    x_46      lr_46     0.049186439999999998
    x_46      lm_46     0.002
    x_47      loan_47   1
    x_47      lf_47     1
    x_47      lr_47     0.049101689999999996
    x_47      lm_47     0.002
    x_48      loan_48   1
    x_48      lf_48     1
    x_48      lr_48     0.049016949999999997
    x_48      lm_48     0.002
    x_49      loan_49   1
    x_49      lf_49     1
    x_49      lr_49     0.048932199999999995
    x_49      lm_49     0.002
    x_50      loan_50   1
    x_50      lf_50     1
    x_50      lr_50     0.048847459999999995
    x_50      lm_50     0.002
    x_51      loan_51   1
    x_51      lf_51     1
    x_51      lr_51     0.048762710000000001
    x_51      lm_51     0.002
    x_52      loan_52   1
    x_52      lf_52     1
    x_52      lr_52     0.048677970000000001
    x_52      lm_52     0.002
    x_53      loan_53   1
    x_53      lf_53     1
    x_53      lr_53     0.048593219999999999
    x_53      lm_53     0.002
    x_54      loan_54   1
    x_54      lf_54     1
    x_54      lr_54     0.048508469999999998
    x_54      lm_54     0.002
    x_55      loan_55   1
    x_55      lf_55     1
    x_55      lr_55     0.048423729999999998
    x_55      lm_55     0.002
    x_56      loan_56   1
    x_56      lf_56     1
    x_56      lr_56     0.048338979999999997
    x_56      lm_56     0.002
    x_57      loan_57   1
    x_57      lf_57     1
    x_57      lr_57     0.048254239999999997
    x_57      lm_57     0.002
    x_58      loan_58   1
    x_58      lf_58     1
    x_58      lr_58     0.048169489999999995
    x_58      lm_58     0.002
    x_59      loan_59   1
    x_59      lf_59     1
    x_59      lr_59     0.048084749999999996
    x_59      lm_59     0.002
    x_60      loan_60   1
    x_60      lf_60     1
    x_60      lr_60     0.048000000000000001
    x_60      lm_60     0.002
    y_1       term_1    -1
    y_1       term_13   -1
    y_1       tr_1      -0.038000000000000006
    y_1       tr_13     -0.038000000000000006
    y_1       tm_1      -0.0030000000000000001
    y_1       tm_13     -0.0030000000000000001
    y_1       out_12    0.10000000000000001
    y_2       term_2    1
    y_2       term_14   -1
    y_2       tr_2      0.037915250000000005
    y_2       tr_14     -0.037915250000000005
    y_2       tm_2      0.0030000000000000001
    y_2       tm_14     -0.0030000000000000001
    y_2       out_13    0.10000000000000001
    y_3       term_3    1
    y_3       term_15   -1
    y_3       tr_3      0.037830510000000005
    y_3       tr_15     -0.037830510000000005
    y_3       tm_3      0.0030000000000000001
    y_3       tm_15     -0.0030000000000000001
    y_3       out_14    0.10000000000000001
    y_4       term_4    1
    y_4       term_16   -1
    y_4       tr_4      0.037745760000000003
    y_4       tr_16     -0.037745760000000003
    y_4       tm_4      0.0030000000000000001
    y_4       tm_16     -0.0030000000000000001
    y_4       out_15    0.10000000000000001
    y_5       term_5    1
    y_5       term_17   -1
    y_5       tr_5      0.037661020000000003
    y_5       tr_17     -0.037661020000000003
    y_5       tm_5      0.0030000000000000001
    y_5       tm_17     -0.0030000000000000001
    y_5       out_16    0.10000000000000001
    y_6       term_6    1
    y_6       term_18   -1
    y_6       tr_6      0.037576270000000002
    y_6       tr_18     -0.037576270000000002
    y_6       tm_6      0.0030000000000000001
    y_6       tm_18     -0.0030000000000000001
    y_6       out_17    0.10000000000000001
    y_7       term_7    1
    y_7       term_19   -1
    y_7       tr_7      0.037491530000000002
    y_7       tr_19     -0.037491530000000002
    y_7       tm_7      0.0030000000000000001
    y_7       tm_19     -0.0030000000000000001
    y_7       out_18    0.10000000000000001
    y_8       term_8    1
    y_8       term_20   -1
    y_8       tr_8      0.037406780000000001
    y_8       tr_20     -0.037406780000000001
    y_8       tm_8      0.0030000000000000001
    y_8       tm_20     -0.0030000000000000001
    y_8       out_19    0.10000000000000001
    y_9       term_9    1
    y_9       term_21   -1
    y_9       tr_9      0.037322030000000006
    y_9       tr_21     -0.037322030000000006
    y_9       tm_9      0.0030000000000000001
    y_9       tm_21     -0.0030000000000000001
    y_9       out_20    0.10000000000000001
    y_10      term_10   1
    y_10      term_22   -1
    y_10      tr_10     0.037237289999999999
    y_10      tr_22     -0.037237289999999999
    y_10      tm_10     0.0030000000000000001
    y_10      tm_22     -0.0030000000000000001
    y_10      out_21    0.10000000000000001
    y_11      term_11   1
    y_11      term_23   -1
    y_11      tr_11     0.037152540000000005
    y_11      tr_23     -0.037152540000000005
    y_11      tm_11     0.0030000000000000001
    y_11      tm_23     -0.0030000000000000001
    y_11      out_22    0.10000000000000001
    y_12      term_12   1
    y_12      term_24   -1
    y_12      tr_12     0.037067800000000005
    y_12      tr_24     -0.037067800000000005
    y_12      tm_12     0.0030000000000000001
    y_12      tm_24     -0.0030000000000000001
    y_12      out_23    0.10000000000000001
    y_13      term_13   1
    y_13      term_25   -1
    y_13      tr_13     0.036983050000000003
    y_13      tr_25     -0.036983050000000003
    y_13      tm_13     0.0030000000000000001
    y_13      tm_25     -0.0030000000000000001
    y_13      out_24    0.10000000000000001
    y_14      term_14   1
    y_14      term_26   -1
    y_14      tr_14     0.036898310000000004
    y_14      tr_26     -0.036898310000000004
    y_14      tm_14     0.0030000000000000001
    y_14      tm_26     -0.0030000000000000001
    y_14      out_25    0.10000000000000001
    y_15      term_15   1
    y_15      term_27   -1
    y_15      tr_15     0.036813560000000002
    y_15      tr_27     -0.036813560000000002
    y_15      tm_15     0.0030000000000000001
    y_15      tm_27     -0.0030000000000000001
    y_15      out_26    0.10000000000000001
    y_16      term_16   1
    y_16      term_28   -1
    y_16      tr_16     0.036728810000000001
    y_16      tr_28     -0.036728810000000001
    y_16      tm_16     0.0030000000000000001
    y_16      tm_28     -0.0030000000000000001
    y_16      out_27    0.10000000000000001
    y_17      term_17   1
    y_17      term_29   -1
    y_17      tr_17     0.036644070000000001
    y_17      tr_29     -0.036644070000000001
    y_17      tm_17     0.0030000000000000001
    y_17      tm_29     -0.0030000000000000001
    y_17      out_28    0.10000000000000001
    y_18      term_18   1
    y_18      term_30   -1
    y_18      tr_18     0.036559319999999999
    y_18      tr_30     -0.036559319999999999
    y_18      tm_18     0.0030000000000000001
    y_18      tm_30     -0.0030000000000000001
    y_18      out_29    0.10000000000000001
    y_19      term_19   1
    y_19      term_31   -1
    y_19      tr_19     0.03647458
    y_19      tr_31     -0.03647458
    y_19      tm_19     0.0030000000000000001
    y_19      tm_31     -0.0030000000000000001
    y_19      out_30    0.10000000000000001
    y_20      term_20   1
    y_20      term_32   -1
    y_20      tr_20     0.036389830000000005
    y_20      tr_32     -0.036389830000000005
    y_20      tm_20     0.0030000000000000001
    y_20      tm_32     -0.0030000000000000001
    y_20      out_31    0.10000000000000001
    y_21      term_21   1
    y_21      term_33   -1
    y_21      tr_21     0.036305080000000003
    y_21      tr_33     -0.036305080000000003
    y_21      tm_21     0.0030000000000000001
    y_21      tm_33     -0.0030000000000000001
    y_21      out_32    0.10000000000000001
    y_22      term_22   1
    y_22      term_34   -1
    y_22      tr_22     0.036220340000000004
    y_22      tr_34     -0.036220340000000004
    y_22      tm_22     0.0030000000000000001
    y_22      tm_34     -0.0030000000000000001
    y_22      out_33    0.10000000000000001
    y_23      term_23   1
    y_23      term_35   -1
    y_23      tr_23     0.036135590000000002
    y_23      tr_35     -0.036135590000000002
    y_23      tm_23     0.0030000000000000001
    y_23      tm_35     -0.0030000000000000001
    y_23      out_34    0.10000000000000001
    y_24      term_24   1
    y_24      term_36   -1
    y_24      tr_24     0.036050850000000002
    y_24      tr_36     -0.036050850000000002
    y_24      tm_24     0.0030000000000000001
    y_24      tm_36     -0.0030000000000000001
    y_24      out_35    0.10000000000000001
    y_25      term_25   1
    y_25      term_37   -1
    y_25      tr_25     0.035966100000000001
    y_25      tr_37     -0.035966100000000001
    y_25      tm_25     0.0030000000000000001
    y_25      tm_37     -0.0030000000000000001
    y_25      out_36    0.10000000000000001
    y_26      term_26   1
    y_26      term_38   -1
    y_26      tr_26     0.035881360000000001
    y_26      tr_38     -0.035881360000000001
    y_26      tm_26     0.0030000000000000001
    y_26      tm_38     -0.0030000000000000001
    y_26      out_37    0.10000000000000001
    y_27      term_27   1
    y_27      term_39   -1
    y_27      tr_27     0.03579661
    y_27      tr_39     -0.03579661
    y_27      tm_27     0.0030000000000000001
    y_27      tm_39     -0.0030000000000000001
    y_27      out_38    0.10000000000000001
    y_28      term_28   1
    y_28      term_40   -1
    y_28      tr_28     0.035711860000000005
    y_28      tr_40     -0.035711860000000005
    y_28      tm_28     0.0030000000000000001
    y_28      tm_40     -0.0030000000000000001
    y_28      out_39    0.10000000000000001
    y_29      term_29   1
    y_29      term_41   -1
    y_29      tr_29     0.035627120000000005
    y_29      tr_41     -0.035627120000000005
    y_29      tm_29     0.0030000000000000001
    y_29      tm_41     -0.0030000000000000001
    y_29      out_40    0.10000000000000001
    y_30      term_30   1
    y_30      term_42   -1
    y_30      tr_30     0.035542370000000004
    y_30      tr_42     -0.035542370000000004
    y_30      tm_30     0.0030000000000000001
    y_30      tm_42     -0.0030000000000000001
    y_30      out_41    0.10000000000000001
    y_31      term_31   1
    y_31      term_43   -1
    y_31      tr_31     0.035457630000000004
    y_31      tr_43     -0.035457630000000004
    y_31      tm_31     0.0030000000000000001
    y_31      tm_43     -0.0030000000000000001
    y_31      out_42    0.10000000000000001
    y_32      term_32   1
    y_32      term_44   -1
    y_32      tr_32     0.035372880000000002
    y_32      tr_44     -0.035372880000000002
    y_32      tm_32     0.0030000000000000001
    y_32      tm_44     -0.0030000000000000001
    y_32      out_43    0.10000000000000001
    y_33      term_33   1
    y_33      term_45   -1
    y_33      tr_33     0.035288140000000003
    y_33      tr_45     -0.035288140000000003
    y_33      tm_33     0.0030000000000000001
    y_33      tm_45     -0.0030000000000000001
    y_33      out_44    0.10000000000000001
    y_34      term_34   1
    y_34      term_46   -1
    y_34      tr_34     0.035203390000000001
    y_34      tr_46     -0.035203390000000001
    y_34      tm_34     0.0030000000000000001
    y_34      tm_46     -0.0030000000000000001
    y_34      out_45    0.10000000000000001
    y_35      term_35   1
    y_35      term_47   -1
    y_35      tr_35     0.03511864
    y_35      tr_47     -0.03511864
    y_35      tm_35     0.0030000000000000001
    y_35      tm_47     -0.0030000000000000001
    y_35      out_46    0.10000000000000001
    y_36      term_36   1
    y_36      term_48   -1
    y_36      tr_36     0.0350339
    y_36      tr_48     -0.0350339
    y_36      tm_36     0.0030000000000000001
    y_36      tm_48     -0.0030000000000000001
    y_36      out_47    0.10000000000000001
    y_37      term_37   1
    y_37      term_49   -1
    y_37      tr_37     0.034949150000000005
    y_37      tr_49     -0.034949150000000005
    y_37      tm_37     0.0030000000000000001
    y_37      tm_49     -0.0030000000000000001
    y_37      out_48    0.10000000000000001
    y_38      term_38   1
    y_38      term_50   -1
    y_38      tr_38     0.034864410000000005
    y_38      tr_50     -0.034864410000000005
    y_38      tm_38     0.0030000000000000001
    y_38      tm_50     -0.0030000000000000001
    y_38      out_49    0.10000000000000001
    y_39      term_39   1
    y_39      term_51   -1
    y_39      tr_39     0.034779660000000004
    y_39      tr_51     -0.034779660000000004
    y_39      tm_39     0.0030000000000000001
    y_39      tm_51     -0.0030000000000000001
    y_39      out_50    0.10000000000000001
    y_40      term_40   1
    y_40      term_52   -1
    y_40      tr_40     0.034694920000000004
    y_40      tr_52     -0.034694920000000004
    y_40      tm_40     0.0030000000000000001
    y_40      tm_52     -0.0030000000000000001
    y_40      out_51    0.10000000000000001
    y_41      term_41   1
    y_41      term_53   -1
    y_41      tr_41     0.034610170000000003
    y_41      tr_53     -0.034610170000000003
    y_41      tm_41     0.0030000000000000001
    y_41      tm_53     -0.0030000000000000001
    y_41      out_52    0.10000000000000001
    y_42      term_42   1
    y_42      term_54   -1
    y_42      tr_42     0.034525420000000001
    y_42      tr_54     -0.034525420000000001
    y_42      tm_42     0.0030000000000000001
    y_42      tm_54     -0.0030000000000000001
    y_42      out_53    0.10000000000000001
    y_43      term_43   1
    y_43      term_55   -1
    y_43      tr_43     0.034440680000000001
    y_43      tr_55     -0.034440680000000001
    y_43      tm_43     0.0030000000000000001
    y_43      tm_55     -0.0030000000000000001
    y_43      out_54    0.10000000000000001
    y_44      term_44   1
    y_44      term_56   -1
    y_44      tr_44     0.03435593
    y_44      tr_56     -0.03435593
    y_44      tm_44     0.0030000000000000001
    y_44      tm_56     -0.0030000000000000001
    y_44      out_55    0.10000000000000001
    y_45      term_45   1
    y_45      term_57   -1
    y_45      tr_45     0.03427119
    y_45      tr_57     -0.03427119
    y_45      tm_45     0.0030000000000000001
    y_45      tm_57     -0.0030000000000000001
    y_45      out_56    0.10000000000000001
    y_46      term_46   1
    y_46      term_58   -1
    y_46      tr_46     0.034186439999999998
    y_46      tr_58     -0.034186439999999998
    y_46      tm_46     0.0030000000000000001
    y_46      tm_58     -0.0030000000000000001
    y_46      out_57    0.10000000000000001
    y_47      term_47   1
    y_47      term_59   -1
    y_47      tr_47     0.034101690000000004
    y_47      tr_59     -0.034101690000000004
    y_47      tm_47     0.0030000000000000001
    y_47      tm_59     -0.0030000000000000001
    y_47      out_58    0.10000000000000001
    y_48      term_48   1
    y_48      term_60   -1
    y_48      tr_48     0.034016950000000004
    y_48      tr_60     -0.034016950000000004
    y_48      tm_48     0.0030000000000000001
    y_48      tm_60     -0.0030000000000000001
    y_48      out_59    0.10000000000000001
    y_49      term_49   1
    y_49      tr_49     0.033932200000000003
    y_49      tm_49     0.0030000000000000001
    y_49      out_60    0.10000000000000001
    y_50      term_50   1
    y_50      tr_50     0.033847460000000003
    y_50      tm_50     0.0030000000000000001
    y_51      term_51   1
    y_51      tr_51     0.033762710000000001
    y_51      tm_51     0.0030000000000000001
    y_52      term_52   1
    y_52      tr_52     0.033677970000000002
    y_52      tm_52     0.0030000000000000001
    y_53      term_53   1
    y_53      tr_53     0.03359322
    y_53      tm_53     0.0030000000000000001
    y_54      term_54   1
    y_54      tr_54     0.033508469999999999
    y_54      tm_54     0.0030000000000000001
    y_55      term_55   1
    y_55      tr_55     0.033423729999999999
    y_55      tm_55     0.0030000000000000001
    y_56      term_56   1
    y_56      tr_56     0.033338980000000004
    y_56      tm_56     0.0030000000000000001
    y_57      term_57   1
    y_57      tr_57     0.033254240000000004
    y_57      tm_57     0.0030000000000000001
    y_58      term_58   1
    y_58      tr_58     0.033169490000000003
    y_58      tm_58     0.0030000000000000001
    y_59      term_59   1
    y_59      tr_59     0.033084750000000003
    y_59      tm_59     0.0030000000000000001
    y_60      term_60   1
    y_60      tr_60     0.033000000000000002
    y_60      tm_60     0.0030000000000000001
    w_1       whole_1   -1
    w_1       whole_37  -1
    w_1       out_36    1
    w_1       asf_1     1
    w_1       asf_2     1
    w_1       asf_3     1
    w_1       asf_4     1
    w_1       asf_5     1
    w_1       asf_6     1
    w_1       asf_7     1
    w_1       asf_8     1
    w_1       asf_9     1
    w_1       asf_10    1
    w_1       asf_11    1
    w_1       asf_12    1
    w_1       asf_13    1
    w_1       asf_14    1
    w_1       asf_15    1
    w_1       asf_16    1
    w_1       asf_17    1
    w_1       asf_18    1
    w_1       asf_19    1
    w_1       asf_20    1
    w_1       asf_21    1
    w_1       asf_22    1
    w_1       asf_23    1
    w_1       asf_24    1
    w_1       asf_25    1
    w_1       asf_26    0.5
    w_1       asf_27    0.5
    w_1       asf_28    0.5
    w_1       asf_29    0.5
    w_1       asf_30    0.5
    w_1       asf_31    0.5
    w_2       whole_2   1
    w_2       whole_38  -1
    w_2       out_37    1
    w_2       asf_2     1
    w_2       asf_3     1
    w_2       asf_4     1
    w_2       asf_5     1
    w_2       asf_6     1
    w_2       asf_7     1
    w_2       asf_8     1
    w_2       asf_9     1
    w_2       asf_10    1
    w_2       asf_11    1
    w_2       asf_12    1
    w_2       asf_13    1
    w_2       asf_14    1
    w_2       asf_15    1
    w_2       asf_16    1
    w_2       asf_17    1
    w_2       asf_18    1
    w_2       asf_19    1
    w_2       asf_20    1
    w_2       asf_21    1
    w_2       asf_22    1
    w_2       asf_23    1
    w_2       asf_24    1
    w_2       asf_25    1
    w_2       asf_26    1
    w_2       asf_27    0.5
    w_2       asf_28    0.5
    w_2       asf_29    0.5
    w_2       asf_30    0.5
    w_2       asf_31    0.5
    w_2       asf_32    0.5
    w_3       whole_3   1
    w_3       whole_39  -1
    w_3       out_38    1
    w_3       asf_3     1
    w_3       asf_4     1
    w_3       asf_5     1
    w_3       asf_6     1
    w_3       asf_7     1
    w_3       asf_8     1
    w_3       asf_9     1
    w_3       asf_10    1
    w_3       asf_11    1
    w_3       asf_12    1
    w_3       asf_13    1
    w_3       asf_14    1
    w_3       asf_15    1
    w_3       asf_16    1
    w_3       asf_17    1
    w_3       asf_18    1
    w_3       asf_19    1
    w_3       asf_20    1
    w_3       asf_21    1
    w_3       asf_22    1
    w_3       asf_23    1
    w_3       asf_24    1
    w_3       asf_25    1
    w_3       asf_26    1
    w_3       asf_27    1
    w_3       asf_28    0.5
    w_3       asf_29    0.5
    w_3       asf_30    0.5
    w_3       asf_31    0.5
    w_3       asf_32    0.5
    w_3       asf_33    0.5
    w_4       whole_4   1
    w_4       whole_40  -1
    w_4       out_39    1
    w_4       asf_4     1
    w_4       asf_5     1
    w_4       asf_6     1
    w_4       asf_7     1
    w_4       asf_8     1
    w_4       asf_9     1
    w_4       asf_10    1
    w_4       asf_11    1
    w_4       asf_12    1
    w_4       asf_13    1
    w_4       asf_14    1
    w_4       asf_15    1
    w_4       asf_16    1
    w_4       asf_17    1
    w_4       asf_18    1
    w_4       asf_19    1
    w_4       asf_20    1
    w_4       asf_21    1
    w_4       asf_22    1
    w_4       asf_23    1
    w_4       asf_24    1
    w_4       asf_25    1
    w_4       asf_26    1
    w_4       asf_27    1
    w_4       asf_28    1
    w_4       asf_29    0.5
    w_4       asf_30    0.5
    w_4       asf_31    0.5
    w_4       asf_32    0.5
    w_4       asf_33    0.5
    w_4       asf_34    0.5
    w_5       whole_5   1
    w_5       whole_41  -1
    w_5       out_40    1
    w_5       asf_5     1
    w_5       asf_6     1
    w_5       asf_7     1
    w_5       asf_8     1
    w_5       asf_9     1
    w_5       asf_10    1
    w_5       asf_11    1
    w_5       asf_12    1
    w_5       asf_13    1
    w_5       asf_14    1
    w_5       asf_15    1
    w_5       asf_16    1
    w_5       asf_17    1
    w_5       asf_18    1
    w_5       asf_19    1
    w_5       asf_20    1
    w_5       asf_21    1
    w_5       asf_22    1
    w_5       asf_23    1
    w_5       asf_24    1
    w_5       asf_25    1
    w_5       asf_26    1
    w_5       asf_27    1
    w_5       asf_28    1
    w_5       asf_29    1
    w_5       asf_30    0.5
    w_5       asf_31    0.5
    w_5       asf_32    0.5
    w_5       asf_33    0.5
    w_5       asf_34    0.5
    w_5       asf_35    0.5
    w_6       whole_6   1
    w_6       whole_42  -1
    w_6       out_41    1
    w_6       asf_6     1
    w_6       asf_7     1
    w_6       asf_8     1
    w_6       asf_9     1
    w_6       asf_10    1
    w_6       asf_11    1
    w_6       asf_12    1
    w_6       asf_13    1
    w_6       asf_14    1
    w_6       asf_15    1
    w_6       asf_16    1
    w_6       asf_17    1
    w_6       asf_18    1
    w_6       asf_19    1
    w_6       asf_20    1
    w_6       asf_21    1
    w_6       asf_22    1
    w_6       asf_23    1
    w_6       asf_24    1
    w_6       asf_25    1
    w_6       asf_26    1
    w_6       asf_27    1
    w_6       asf_28    1
    w_6       asf_29    1
    w_6       asf_30    1
    w_6       asf_31    0.5
    w_6       asf_32    0.5
    w_6       asf_33    0.5
    w_6       asf_34    0.5
    w_6       asf_35    0.5
    w_6       asf_36    0.5
    w_7       whole_7   1
    w_7       whole_43  -1
    w_7       out_42    1
    w_7       asf_7     1
    w_7       asf_8     1
    w_7       asf_9     1
    w_7       asf_10    1
    w_7       asf_11    1
    w_7       asf_12    1
    w_7       asf_13    1
    w_7       asf_14    1
    w_7       asf_15    1
    w_7       asf_16    1
    w_7       asf_17    1
    w_7       asf_18    1
    w_7       asf_19    1
    w_7       asf_20    1
    w_7       asf_21    1
    w_7       asf_22    1
    w_7       asf_23    1
    w_7       asf_24    1
    w_7       asf_25    1
    w_7       asf_26    1
    w_7       asf_27    1
    w_7       asf_28    1
    w_7       asf_29    1
    w_7       asf_30    1
    w_7       asf_31    1
    w_7       asf_32    0.5
    w_7       asf_33    0.5
    w_7       asf_34    0.5
    w_7       asf_35    0.5
    w_7       asf_36    0.5
    w_7       asf_37    0.5
    w_8       whole_8   1
    w_8       whole_44  -1
    w_8       out_43    1
    w_8       asf_8     1
    w_8       asf_9     1
    w_8       asf_10    1
    w_8       asf_11    1
    w_8       asf_12    1
    w_8       asf_13    1
    w_8       asf_14    1
    w_8       asf_15    1
    w_8       asf_16    1
    w_8       asf_17    1
    w_8       asf_18    1
    w_8       asf_19    1
    w_8       asf_20    1
    w_8       asf_21    1
    w_8       asf_22    1
    w_8       asf_23    1
    w_8       asf_24    1
    w_8       asf_25    1
    w_8       asf_26    1
    w_8       asf_27    1
    w_8       asf_28    1
    w_8       asf_29    1
    w_8       asf_30    1
    w_8       asf_31    1
    w_8       asf_32    1
    w_8       asf_33    0.5
    w_8       asf_34    0.5
    w_8       asf_35    0.5
    w_8       asf_36    0.5
    w_8       asf_37    0.5
    w_8       asf_38    0.5
    w_9       whole_9   1
    w_9       whole_45  -1
    w_9       out_44    1
    w_9       asf_9     1
    w_9       asf_10    1
    w_9       asf_11    1
    w_9       asf_12    1
    w_9       asf_13    1
    w_9       asf_14    1
    w_9       asf_15    1
    w_9       asf_16    1
    w_9       asf_17    1
    w_9       asf_18    1
    w_9       asf_19    1
    w_9       asf_20    1
    w_9       asf_21    1
    w_9       asf_22    1
    w_9       asf_23    1
    w_9       asf_24    1
    w_9       asf_25    1
    w_9       asf_26    1
    w_9       asf_27    1
    w_9       asf_28    1
    w_9       asf_29    1
    w_9       asf_30    1
    w_9       asf_31    1
    w_9       asf_32    1
    w_9       asf_33    1
    w_9       asf_34    0.5
    w_9       asf_35    0.5
    w_9       asf_36    0.5
    w_9       asf_37    0.5
    w_9       asf_38    0.5
    w_9       asf_39    0.5
    w_10      whole_10  1
    w_10      whole_46  -1
    w_10      out_45    1
    w_10      asf_10    1
    w_10      asf_11    1
    w_10      asf_12    1
    w_10      asf_13    1
    w_10      asf_14    1
    w_10      asf_15    1
    w_10      asf_16    1
    w_10      asf_17    1
    w_10      asf_18    1
    w_10      asf_19    1
    w_10      asf_20    1
    w_10      asf_21    1
    w_10      asf_22    1
    w_10      asf_23    1
    w_10      asf_24    1
    w_10      asf_25    1
    w_10      asf_26    1
    w_10      asf_27    1
    w_10      asf_28    1
    w_10      asf_29    1
    w_10      asf_30    1
    w_10      asf_31    1
    w_10      asf_32    1
    w_10      asf_33    1
    w_10      asf_34    1
    w_10      asf_35    0.5
    w_10      asf_36    0.5
    w_10      asf_37    0.5
    w_10      asf_38    0.5
    w_10      asf_39    0.5
    w_10      asf_40    0.5
    w_11      whole_11  1
    w_11      whole_47  -1
    w_11      out_46    1
    w_11      asf_11    1
    w_11      asf_12    1
    w_11      asf_13    1
    w_11      asf_14    1
    w_11      asf_15    1
    w_11      asf_16    1
    w_11      asf_17    1
    w_11      asf_18    1
    w_11      asf_19    1
    w_11      asf_20    1
    w_11      asf_21    1
    w_11      asf_22    1
    w_11      asf_23    1
    w_11      asf_24    1
    w_11      asf_25    1
    w_11      asf_26    1
    w_11      asf_27    1
    w_11      asf_28    1
    w_11      asf_29    1
    w_11      asf_30    1
    w_11      asf_31    1
    w_11      asf_32    1
    w_11      asf_33    1
    w_11      asf_34    1
    w_11      asf_35    1
    w_11      asf_36    0.5
    w_11      asf_37    0.5
    w_11      asf_38    0.5
    w_11      asf_39    0.5
    w_11      asf_40    0.5
    w_11      asf_41    0.5
    w_12      whole_12  1
    w_12      whole_48  -1
    w_12      out_47    1
    w_12      asf_12    1
    w_12      asf_13    1
    w_12      asf_14    1
    w_12      asf_15    1
    w_12      asf_16    1
    w_12      asf_17    1
    w_12      asf_18    1
    w_12      asf_19    1
    w_12      asf_20    1
    w_12      asf_21    1
    w_12      asf_22    1
    w_12      asf_23    1
    w_12      asf_24    1
    w_12      asf_25    1
    w_12      asf_26    1
    w_12      asf_27    1
    w_12      asf_28    1
    w_12      asf_29    1
    w_12      asf_30    1
    w_12      asf_31    1
    w_12      asf_32    1
    w_12      asf_33    1
    w_12      asf_34    1
    w_12      asf_35    1
    w_12      asf_36    1
    w_12      asf_37    0.5
    w_12      asf_38    0.5
    w_12      asf_39    0.5
    w_12      asf_40    0.5
    w_12      asf_41    0.5
    w_12      asf_42    0.5
    w_13      whole_13  1
    w_13      whole_49  -1
    w_13      out_48    1
    w_13      asf_13    1
    w_13      asf_14    1
    w_13      asf_15    1
    w_13      asf_16    1
    w_13      asf_17    1
    w_13      asf_18    1
    w_13      asf_19    1
    w_13      asf_20    1
    w_13      asf_21    1
    w_13      asf_22    1
    w_13      asf_23    1
    w_13      asf_24    1
    w_13      asf_25    1
    w_13      asf_26    1
    w_13      asf_27    1
    w_13      asf_28    1
    w_13      asf_29    1
    w_13      asf_30    1
    w_13      asf_31    1
    w_13      asf_32    1
    w_13      asf_33    1
    w_13      asf_34    1
    w_13      asf_35    1
    w_13      asf_36    1
    w_13      asf_37    1
    w_13      asf_38    0.5
    w_13      asf_39    0.5
    w_13      asf_40    0.5
    w_13      asf_41    0.5
    w_13      asf_42    0.5
    w_13      asf_43    0.5
    w_14      whole_14  1
    w_14      whole_50  -1
    w_14      out_49    1
    w_14      asf_14    1
    w_14      asf_15    1
    w_14      asf_16    1
    w_14      asf_17    1
    w_14      asf_18    1
    w_14      asf_19    1
    w_14      asf_20    1
    w_14      asf_21    1
    w_14      asf_22    1
    w_14      asf_23    1
    w_14      asf_24    1
    w_14      asf_25    1
    w_14      asf_26    1
    w_14      asf_27    1
    w_14      asf_28    1
    w_14      asf_29    1
    w_14      asf_30    1
    w_14      asf_31    1
    w_14      asf_32    1
    w_14      asf_33    1
    w_14      asf_34    1
    w_14      asf_35    1
    w_14      asf_36    1
    w_14      asf_37    1
    w_14      asf_38    1
    w_14      asf_39    0.5
    w_14      asf_40    0.5
    w_14      asf_41    0.5
    w_14      asf_42    0.5
    w_14      asf_43    0.5
    w_14      asf_44    0.5
    w_15      whole_15  1
    w_15      whole_51  -1
    w_15      out_50    1
    w_15      asf_15    1
    w_15      asf_16    1
    w_15      asf_17    1
    w_15      asf_18    1
    w_15      asf_19    1
    w_15      asf_20    1
    w_15      asf_21    1
    w_15      asf_22    1
    w_15      asf_23    1
    w_15      asf_24    1
    w_15      asf_25    1
    w_15      asf_26    1
    w_15      asf_27    1
    w_15      asf_28    1
    w_15      asf_29    1
    w_15      asf_30    1
    w_15      asf_31    1
    w_15      asf_32    1
    w_15      asf_33    1
    w_15      asf_34    1
    w_15      asf_35    1
    w_15      asf_36    1
    w_15      asf_37    1
    w_15      asf_38    1
    w_15      asf_39    1
    w_15      asf_40    0.5
    w_15      asf_41    0.5
    w_15      asf_42    0.5
    w_15      asf_43    0.5
    w_15      asf_44    0.5
    w_15      asf_45    0.5
    w_16      whole_16  1
    w_16      whole_52  -1
    w_16      out_51    1
    w_16      asf_16    1
    w_16      asf_17    1
    w_16      asf_18    1
    w_16      asf_19    1
    w_16      asf_20    1
    w_16      asf_21    1
    w_16      asf_22    1
    w_16      asf_23    1
    w_16      asf_24    1
    w_16      asf_25    1
    w_16      asf_26    1
    w_16      asf_27    1
    w_16      asf_28    1
    w_16      asf_29    1
    w_16      asf_30    1
    w_16      asf_31    1
    w_16      asf_32    1
    w_16      asf_33    1
    w_16      asf_34    1
    w_16      asf_35    1
    w_16      asf_36    1
    w_16      asf_37    1
    w_16      asf_38    1
    w_16      asf_39    1
    w_16      asf_40    1
    w_16      asf_41    0.5
    w_16      asf_42    0.5
    w_16      asf_43    0.5
    w_16      asf_44    0.5
    w_16      asf_45    0.5
    w_16      asf_46    0.5
    w_17      whole_17  1
    w_17      whole_53  -1
    w_17      out_52    1
    w_17      asf_17    1
    w_17      asf_18    1
    w_17      asf_19    1
    w_17      asf_20    1
    w_17      asf_21    1
    w_17      asf_22    1
    w_17      asf_23    1
    w_17      asf_24    1
    w_17      asf_25    1
    w_17      asf_26    1
    w_17      asf_27    1
    w_17      asf_28    1
    w_17      asf_29    1
    w_17      asf_30    1
    w_17      asf_31    1
    w_17      asf_32    1
    w_17      asf_33    1
    w_17      asf_34    1
    w_17      asf_35    1
    w_17      asf_36    1
    w_17      asf_37    1
    w_17      asf_38    1
    w_17      asf_39    1
    w_17      asf_40    1
    w_17      asf_41    1
    w_17      asf_42    0.5
    w_17      asf_43    0.5
    w_17      asf_44    0.5
    w_17      asf_45    0.5
    w_17      asf_46    0.5
    w_17      asf_47    0.5
    w_18      whole_18  1
    w_18      whole_54  -1
    w_18      out_53    1
    w_18      asf_18    1
    w_18      asf_19    1
    w_18      asf_20    1
    w_18      asf_21    1
    w_18      asf_22    1
    w_18      asf_23    1
    w_18      asf_24    1
    w_18      asf_25    1
    w_18      asf_26    1
    w_18      asf_27    1
    w_18      asf_28    1
    w_18      asf_29    1
    w_18      asf_30    1
    w_18      asf_31    1
    w_18      asf_32    1
    w_18      asf_33    1
    w_18      asf_34    1
    w_18      asf_35    1
    w_18      asf_36    1
    w_18      asf_37    1
    w_18      asf_38    1
    w_18      asf_39    1
    w_18      asf_40    1
    w_18      asf_41    1
    w_18      asf_42    1
    w_18      asf_43    0.5
    w_18      asf_44    0.5
    w_18      asf_45    0.5
    w_18      asf_46    0.5
    w_18      asf_47    0.5
    w_18      asf_48    0.5
    w_19      whole_19  1
    w_19      whole_55  -1
    w_19      out_54    1
    w_19      asf_19    1
    w_19      asf_20    1
    w_19      asf_21    1
    w_19      asf_22    1
    w_19      asf_23    1
    w_19      asf_24    1
    w_19      asf_25    1
    w_19      asf_26    1
    w_19      asf_27    1
    w_19      asf_28    1
    w_19      asf_29    1
    w_19      asf_30    1
    w_19      asf_31    1
    w_19      asf_32    1
    w_19      asf_33    1
    w_19      asf_34    1
    w_19      asf_35    1
    w_19      asf_36    1
    w_19      asf_37    1
    w_19      asf_38    1
    w_19      asf_39    1
    w_19      asf_40    1
    w_19      asf_41    1
    w_19      asf_42    1
    w_19      asf_43    1
    w_19      asf_44    0.5
    w_19      asf_45    0.5
    w_19      asf_46    0.5
    w_19      asf_47    0.5
    w_19      asf_48    0.5
    w_19      asf_49    0.5
    w_20      whole_20  1
    w_20      whole_56  -1
    w_20      out_55    1
    w_20      asf_20    1
    w_20      asf_21    1
    w_20      asf_22    1
    w_20      asf_23    1
    w_20      asf_24    1
    w_20      asf_25    1
    w_20      asf_26    1
    w_20      asf_27    1
    w_20      asf_28    1
    w_20      asf_29    1
    w_20      asf_30    1
    w_20      asf_31    1
    w_20      asf_32    1
    w_20      asf_33    1
    w_20      asf_34    1
    w_20      asf_35    1
    w_20      asf_36    1
    w_20      asf_37    1
    w_20      asf_38    1
    w_20      asf_39    1
    w_20      asf_40    1
    w_20      asf_41    1
    w_20      asf_42    1
    w_20      asf_43    1
    w_20      asf_44    1
    w_20      asf_45    0.5
    w_20      asf_46    0.5
    w_20      asf_47    0.5
    w_20      asf_48    0.5
    w_20      asf_49    0.5
    w_20      asf_50    0.5
    w_21      whole_21  1
    w_21      whole_57  -1
    w_21      out_56    1
    w_21      asf_21    1
    w_21      asf_22    1
    w_21      asf_23    1
    w_21      asf_24    1
    w_21      asf_25    1
    w_21      asf_26    1
    w_21      asf_27    1
    w_21      asf_28    1
    w_21      asf_29    1
    w_21      asf_30    1
    w_21      asf_31    1
    w_21      asf_32    1
    w_21      asf_33    1
    w_21      asf_34    1
    w_21      asf_35    1
    w_21      asf_36    1
    w_21      asf_37    1
    w_21      asf_38    1
    w_21      asf_39    1
    w_21      asf_40    1
    w_21      asf_41    1
    w_21      asf_42    1
    w_21      asf_43    1
    w_21      asf_44    1
    w_21      asf_45    1
    w_21      asf_46    0.5
    w_21      asf_47    0.5
    w_21      asf_48    0.5
    w_21      asf_49    0.5
    w_21      asf_50    0.5
    w_21      asf_51    0.5
    w_22      whole_22  1
    w_22      whole_58  -1
    w_22      out_57    1
    w_22      asf_22    1
    w_22      asf_23    1
    w_22      asf_24    1
    w_22      asf_25    1
    w_22      asf_26    1
    w_22      asf_27    1
    w_22      asf_28    1
    w_22      asf_29    1
    w_22      asf_30    1
    w_22      asf_31    1
    w_22      asf_32    1
    w_22      asf_33    1
    w_22      asf_34    1
    w_22      asf_35    1
    w_22      asf_36    1
    w_22      asf_37    1
    w_22      asf_38    1
    w_22      asf_39    1
    w_22      asf_40    1
    w_22      asf_41    1
    w_22      asf_42    1
    w_22      asf_43    1
    w_22      asf_44    1
    w_22      asf_45    1
    w_22      asf_46    1
    w_22      asf_47    0.5
    w_22      asf_48    0.5
    w_22      asf_49    0.5
    w_22      asf_50    0.5
    w_22      asf_51    0.5
    w_22      asf_52    0.5
    w_23      whole_23  1
    w_23      whole_59  -1
    w_23      out_58    1
    w_23      asf_23    1
    w_23      asf_24    1
    w_23      asf_25    1
    w_23      asf_26    1
    w_23      asf_27    1
    w_23      asf_28    1
    w_23      asf_29    1
    w_23      asf_30    1
    w_23      asf_31    1
    w_23      asf_32    1
    w_23      asf_33    1
    w_23      asf_34    1
    w_23      asf_35    1
    w_23      asf_36    1
    w_23      asf_37    1
    w_23      asf_38    1
    w_23      asf_39    1
    w_23      asf_40    1
    w_23      asf_41    1
    w_23      asf_42    1
    w_23      asf_43    1
    w_23      asf_44    1
    w_23      asf_45    1
    w_23      asf_46    1
    w_23      asf_47    1
    w_23      asf_48    0.5
    w_23      asf_49    0.5
    w_23      asf_50    0.5
    w_23      asf_51    0.5
    w_23      asf_52    0.5
    w_23      asf_53    0.5
    w_24      whole_24  1
    w_24      whole_60  -1
    w_24      out_59    1
    w_24      asf_24    1
    w_24      asf_25    1
    w_24      asf_26    1
    w_24      asf_27    1
    w_24      asf_28    1
    w_24      asf_29    1
    w_24      asf_30    1
    w_24      asf_31    1
    w_24      asf_32    1
    w_24      asf_33    1
    w_24      asf_34    1
    w_24      asf_35    1
    w_24      asf_36    1
    w_24      asf_37    1
    w_24      asf_38    1
    w_24      asf_39    1
    w_24      asf_40    1
    w_24      asf_41    1
    w_24      asf_42    1
    w_24      asf_43    1
    w_24      asf_44    1
    w_24      asf_45    1
    w_24      asf_46    1
    w_24      asf_47    1
    w_24      asf_48    1
    w_24      asf_49    0.5
    w_24      asf_50    0.5
    w_24      asf_51    0.5
    w_24      asf_52    0.5
    w_24      asf_53    0.5
    w_24      asf_54    0.5
    w_25      whole_25  1
    w_25      out_60    1
    w_25      asf_25    1
    w_25      asf_26    1
    w_25      asf_27    1
    w_25      asf_28    1
    w_25      asf_29    1
    w_25      asf_30    1
    w_25      asf_31    1
    w_25      asf_32    1
    w_25      asf_33    1
    w_25      asf_34    1
    w_25      asf_35    1
    w_25      asf_36    1
    w_25      asf_37    1
    w_25      asf_38    1
    w_25      asf_39    1
    w_25      asf_40    1
    w_25      asf_41    1
    w_25      asf_42    1
    w_25      asf_43    1
    w_25      asf_44    1
    w_25      asf_45    1
    w_25      asf_46    1
    w_25      asf_47    1
    w_25      asf_48    1
    w_25      asf_49    1
    w_25      asf_50    0.5
    w_25      asf_51    0.5
    w_25      asf_52    0.5
    w_25      asf_53    0.5
    w_25      asf_54    0.5
    w_25      asf_55    0.5
    w_26      whole_26  1
    w_26      asf_26    1
    w_26      asf_27    1
    w_26      asf_28    1
    w_26      asf_29    1
    w_26      asf_30    1
    w_26      asf_31    1
    w_26      asf_32    1
    w_26      asf_33    1
    w_26      asf_34    1
    w_26      asf_35    1
    w_26      asf_36    1
    w_26      asf_37    1
    w_26      asf_38    1
    w_26      asf_39    1
    w_26      asf_40    1
    w_26      asf_41    1
    w_26      asf_42    1
    w_26      asf_43    1
    w_26      asf_44    1
    w_26      asf_45    1
    w_26      asf_46    1
    w_26      asf_47    1
    w_26      asf_48    1
    w_26      asf_49    1
    w_26      asf_50    1
    w_26      asf_51    0.5
    w_26      asf_52    0.5
    w_26      asf_53    0.5
    w_26      asf_54    0.5
    w_26      asf_55    0.5
    w_26      asf_56    0.5
    w_27      whole_27  1
    w_27      asf_27    1
    w_27      asf_28    1
    w_27      asf_29    1
    w_27      asf_30    1
    w_27      asf_31    1
    w_27      asf_32    1
    w_27      asf_33    1
    w_27      asf_34    1
    w_27      asf_35    1
    w_27      asf_36    1
    w_27      asf_37    1
    w_27      asf_38    1
    w_27      asf_39    1
    w_27      asf_40    1
    w_27      asf_41    1
    w_27      asf_42    1
    w_27      asf_43    1
    w_27      asf_44    1
    w_27      asf_45    1
    w_27      asf_46    1
    w_27      asf_47    1
    w_27      asf_48    1
    w_27      asf_49    1
    w_27      asf_50    1
    w_27      asf_51    1
    w_27      asf_52    0.5
    w_27      asf_53    0.5
    w_27      asf_54    0.5
    w_27      asf_55    0.5
    w_27      asf_56    0.5
    w_27      asf_57    0.5
    w_28      whole_28  1
    w_28      asf_28    1
    w_28      asf_29    1
    w_28      asf_30    1
    w_28      asf_31    1
    w_28      asf_32    1
    w_28      asf_33    1
    w_28      asf_34    1
    w_28      asf_35    1
    w_28      asf_36    1
    w_28      asf_37    1
    w_28      asf_38    1
    w_28      asf_39    1
    w_28      asf_40    1
    w_28      asf_41    1
    w_28      asf_42    1
    w_28      asf_43    1
    w_28      asf_44    1
    w_28      asf_45    1
    w_28      asf_46    1
    w_28      asf_47    1
    w_28      asf_48    1
    w_28      asf_49    1
    w_28      asf_50    1
    w_28      asf_51    1
    w_28      asf_52    1
    w_28      asf_53    0.5
    w_28      asf_54    0.5
    w_28      asf_55    0.5
    w_28      asf_56    0.5
    w_28      asf_57    0.5
    w_28      asf_58    0.5
    w_29      whole_29  1
    w_29      asf_29    1
    w_29      asf_30    1
    w_29      asf_31    1
    w_29      asf_32    1
    w_29      asf_33    1
    w_29      asf_34    1
    w_29      asf_35    1
    w_29      asf_36    1
    w_29      asf_37    1
    w_29      asf_38    1
    w_29      asf_39    1
    w_29      asf_40    1
    w_29      asf_41    1
    w_29      asf_42    1
    w_29      asf_43    1
    w_29      asf_44    1
    w_29      asf_45    1
    w_29      asf_46    1
    w_29      asf_47    1
    w_29      asf_48    1
    w_29      asf_49    1
    w_29      asf_50    1
    w_29      asf_51    1
    w_29      asf_52    1
    w_29      asf_53    1
    w_29      asf_54    0.5
    w_29      asf_55    0.5
    w_29      asf_56    0.5
    w_29      asf_57    0.5
    w_29      asf_58    0.5
    w_29      asf_59    0.5
    w_30      whole_30  1
    w_30      asf_30    1
    w_30      asf_31    1
    w_30      asf_32    1
    w_30      asf_33    1
    w_30      asf_34    1
    w_30      asf_35    1
    w_30      asf_36    1
    w_30      asf_37    1
    w_30      asf_38    1
    w_30      asf_39    1
    w_30      asf_40    1
    w_30      asf_41    1
    w_30      asf_42    1
    w_30      asf_43    1
    w_30      asf_44    1
    w_30      asf_45    1
    w_30      asf_46    1
    w_30      asf_47    1
    w_30      asf_48    1
    w_30      asf_49    1
    w_30      asf_50    1
    w_30      asf_51    1
    w_30      asf_52    1
    w_30      asf_53    1
    w_30      asf_54    1
    w_30      asf_55    0.5
    w_30      asf_56    0.5
    w_30      asf_57    0.5
    w_30      asf_58    0.5
    w_30      asf_59    0.5
    w_30      asf_60    0.5
    w_31      whole_31  1
    w_31      asf_31    1
    w_31      asf_32    1
    w_31      asf_33    1
    w_31      asf_34    1
    w_31      asf_35    1
    w_31      asf_36    1
    w_31      asf_37    1
    w_31      asf_38    1
    w_31      asf_39    1
    w_31      asf_40    1
    w_31      asf_41    1
    w_31      asf_42    1
    w_31      asf_43    1
    w_31      asf_44    1
    w_31      asf_45    1
    w_31      asf_46    1
    w_31      asf_47    1
    w_31      asf_48    1
    w_31      asf_49    1
    w_31      asf_50    1
    w_31      asf_51    1
    w_31      asf_52    1
    w_31      asf_53    1
    w_31      asf_54    1
    w_31      asf_55    1
    w_31      asf_56    0.5
    w_31      asf_57    0.5
    w_31      asf_58    0.5
    w_31      asf_59    0.5
    w_31      asf_60    0.5
    w_32      whole_32  1
    w_32      asf_32    1
    w_32      asf_33    1
    w_32      asf_34    1
    w_32      asf_35    1
    w_32      asf_36    1
    w_32      asf_37    1
    w_32      asf_38    1
    w_32      asf_39    1
    w_32      asf_40    1
    w_32      asf_41    1
    w_32      asf_42    1
    w_32      asf_43    1
    w_32      asf_44    1
    w_32      asf_45    1
    w_32      asf_46    1
    w_32      asf_47    1
    w_32      asf_48    1
    w_32      asf_49    1
    w_32      asf_50    1
    w_32      asf_51    1
    w_32      asf_52    1
    w_32      asf_53    1
    w_32      asf_54    1
    w_32      asf_55    1
    w_32      asf_56    1
    w_32      asf_57    0.5
    w_32      asf_58    0.5
    w_32      asf_59    0.5
    w_32      asf_60    0.5
    w_33      whole_33  1
    w_33      asf_33    1
    w_33      asf_34    1
    w_33      asf_35    1
    w_33      asf_36    1
    w_33      asf_37    1
    w_33      asf_38    1
    w_33      asf_39    1
    w_33      asf_40    1
    w_33      asf_41    1
    w_33      asf_42    1
    w_33      asf_43    1
    w_33      asf_44    1
    w_33      asf_45    1
    w_33      asf_46    1
    w_33      asf_47    1
    w_33      asf_48    1
    w_33      asf_49    1
    w_33      asf_50    1
    w_33      asf_51    1
    w_33      asf_52    1
    w_33      asf_53    1
    w_33      asf_54    1
    w_33      asf_55    1
    w_33      asf_56    1
    w_33      asf_57    1
    w_33      asf_58    0.5
    w_33      asf_59    0.5
    w_33      asf_60    0.5
    w_34      whole_34  1
    w_34      asf_34    1
    w_34      asf_35    1
    w_34      asf_36    1
    w_34      asf_37    1
    w_34      asf_38    1
    w_34      asf_39    1
    w_34      asf_40    1
    w_34      asf_41    1
    w_34      asf_42    1
    w_34      asf_43    1
    w_34      asf_44    1
    w_34      asf_45    1
    w_34      asf_46    1
    w_34      asf_47    1
    w_34      asf_48    1
    w_34      asf_49    1
    w_34      asf_50    1
    w_34      asf_51    1
    w_34      asf_52    1
    w_34      asf_53    1
    w_34      asf_54    1
    w_34      asf_55    1
    w_34      asf_56    1
    w_34      asf_57    1
    w_34      asf_58    1
    w_34      asf_59    0.5
    w_34      asf_60    0.5
    w_35      whole_35  1
    w_35      asf_35    1
    w_35      asf_36    1
    w_35      asf_37    1
    w_35      asf_38    1
    w_35      asf_39    1
    w_35      asf_40    1
    w_35      asf_41    1
    w_35      asf_42    1
    w_35      asf_43    1
    w_35      asf_44    1
    w_35      asf_45    1
    w_35      asf_46    1
    w_35      asf_47    1
    w_35      asf_48    1
    w_35      asf_49    1
    w_35      asf_50    1
    w_35      asf_51    1
    w_35      asf_52    1
    w_35      asf_53    1
    w_35      asf_54    1
    w_35      asf_55    1
    w_35      asf_56    1
    w_35      asf_57    1
    w_35      asf_58    1
    w_35      asf_59    1
    w_35      asf_60    0.5
    w_36      whole_36  1
    w_36      asf_36    1
    w_36      asf_37    1
    w_36      asf_38    1
    w_36      asf_39    1
    w_36      asf_40    1
    w_36      asf_41    1
    w_36      asf_42    1
    w_36      asf_43    1
    w_36      asf_44    1
    w_36      asf_45    1
    w_36      asf_46    1
    w_36      asf_47    1
    w_36      asf_48    1
    w_36      asf_49    1
    w_36      asf_50    1
    w_36      asf_51    1
    w_36      asf_52    1
    w_36      asf_53    1
    w_36      asf_54    1
    w_36      asf_55    1
    w_36      asf_56    1
    w_36      asf_57    1
    w_36      asf_58    1
    w_36      asf_59    1
    w_36      asf_60    1
    w_37      whole_37  1
    w_37      asf_37    1
    w_37      asf_38    1
    w_37      asf_39    1
    w_37      asf_40    1
    w_37      asf_41    1
    w_37      asf_42    1
    w_37      asf_43    1
    w_37      asf_44    1
    w_37      asf_45    1
    w_37      asf_46    1
    w_37      asf_47    1
    w_37      asf_48    1
    w_37      asf_49    1
    w_37      asf_50    1
    w_37      asf_51    1
    w_37      asf_52    1
    w_37      asf_53    1
    w_37      asf_54    1
    w_37      asf_55    1
    w_37      asf_56    1
    w_37      asf_57    1
    w_37      asf_58    1
    w_37      asf_59    1
    w_37      asf_60    1
    w_38      whole_38  1
    w_38      asf_38    1
    w_38      asf_39    1
    w_38      asf_40    1
    w_38      asf_41    1
    w_38      asf_42    1
    w_38      asf_43    1
    w_38      asf_44    1
    w_38      asf_45    1
    w_38      asf_46    1
    w_38      asf_47    1
    w_38      asf_48    1
    w_38      asf_49    1
    w_38      asf_50    1
    w_38      asf_51    1
    w_38      asf_52    1
    w_38      asf_53    1
    w_38      asf_54    1
    w_38      asf_55    1
    w_38      asf_56    1
    w_38      asf_57    1
    w_38      asf_58    1
    w_38      asf_59    1
    w_38      asf_60    1
    w_39      whole_39  1
    w_39      asf_39    1
    w_39      asf_40    1
    w_39      asf_41    1
    w_39      asf_42    1
    w_39      asf_43    1
    w_39      asf_44    1
    w_39      asf_45    1
    w_39      asf_46    1
    w_39      asf_47    1
    w_39      asf_48    1
    w_39      asf_49    1
    w_39      asf_50    1
    w_39      asf_51    1
    w_39      asf_52    1
    w_39      asf_53    1
    w_39      asf_54    1
    w_39      asf_55    1
    w_39      asf_56    1
    w_39      asf_57    1
    w_39      asf_58    1
    w_39      asf_59    1
    w_39      asf_60    1
    w_40      whole_40  1
    w_40      asf_40    1
    w_40      asf_41    1
    w_40      asf_42    1
    w_40      asf_43    1
    w_40      asf_44    1
    w_40      asf_45    1
    w_40      asf_46    1
    w_40      asf_47    1
    w_40      asf_48    1
    w_40      asf_49    1
    w_40      asf_50    1
    w_40      asf_51    1
    w_40      asf_52    1
    w_40      asf_53    1
    w_40      asf_54    1
    w_40      asf_55    1
    w_40      asf_56    1
    w_40      asf_57    1
    w_40      asf_58    1
    w_40      asf_59    1
    w_40      asf_60    1
    w_41      whole_41  1
    w_41      asf_41    1
    w_41      asf_42    1
    w_41      asf_43    1
    w_41      asf_44    1
    w_41      asf_45    1
    w_41      asf_46    1
    w_41      asf_47    1
    w_41      asf_48    1
    w_41      asf_49    1
    w_41      asf_50    1
    w_41      asf_51    1
    w_41      asf_52    1
    w_41      asf_53    1
    w_41      asf_54    1
    w_41      asf_55    1
    w_41      asf_56    1
    w_41      asf_57    1
    w_41      asf_58    1
    w_41      asf_59    1
    w_41      asf_60    1
    w_42      whole_42  1
    w_42      asf_42    1
    w_42      asf_43    1
    w_42      asf_44    1
    w_42      asf_45    1
    w_42      asf_46    1
    w_42      asf_47    1
    w_42      asf_48    1
    w_42      asf_49    1
    w_42      asf_50    1
    w_42      asf_51    1
    w_42      asf_52    1
    w_42      asf_53    1
    w_42      asf_54    1
    w_42      asf_55    1
    w_42      asf_56    1
    w_42      asf_57    1
    w_42      asf_58    1
    w_42      asf_59    1
    w_42      asf_60    1
    w_43      whole_43  1
    w_43      asf_43    1
    w_43      asf_44    1
    w_43      asf_45    1
    w_43      asf_46    1
    w_43      asf_47    1
    w_43      asf_48    1
    w_43      asf_49    1
    w_43      asf_50    1
    w_43      asf_51    1
    w_43      asf_52    1
    w_43      asf_53    1
    w_43      asf_54    1
    w_43      asf_55    1
    w_43      asf_56    1
    w_43      asf_57    1
    w_43      asf_58    1
    w_43      asf_59    1
    w_43      asf_60    1
    w_44      whole_44  1
    w_44      asf_44    1
    w_44      asf_45    1
    w_44      asf_46    1
    w_44      asf_47    1
    w_44      asf_48    1
    w_44      asf_49    1
    w_44      asf_50    1
    w_44      asf_51    1
    w_44      asf_52    1
    w_44      asf_53    1
    w_44      asf_54    1
    w_44      asf_55    1
    w_44      asf_56    1
    w_44      asf_57    1
    w_44      asf_58    1
    w_44      asf_59    1
    w_44      asf_60    1
    w_45      whole_45  1
    w_45      asf_45    1
    w_45      asf_46    1
    w_45      asf_47    1
    w_45      asf_48    1
    w_45      asf_49    1
    w_45      asf_50    1
    w_45      asf_51    1
    w_45      asf_52    1
    w_45      asf_53    1
    w_45      asf_54    1
    w_45      asf_55    1
    w_45      asf_56    1
    w_45      asf_57    1
    w_45      asf_58    1
    w_45      asf_59    1
    w_45      asf_60    1
    w_46      whole_46  1
    w_46      asf_46    1
    w_46      asf_47    1
    w_46      asf_48    1
    w_46      asf_49    1
    w_46      asf_50    1
    w_46      asf_51    1
    w_46      asf_52    1
    w_46      asf_53    1
    w_46      asf_54    1
    w_46      asf_55    1
    w_46      asf_56    1
    w_46      asf_57    1
    w_46      asf_58    1
    w_46      asf_59    1
    w_46      asf_60    1
    w_47      whole_47  1
    w_47      asf_47    1
    w_47      asf_48    1
    w_47      asf_49    1
    w_47      asf_50    1
    w_47      asf_51    1
    w_47      asf_52    1
    w_47      asf_53    1
    w_47      asf_54    1
    w_47      asf_55    1
    w_47      asf_56    1
    w_47      asf_57    1
    w_47      asf_58    1
    w_47      asf_59    1
    w_47      asf_60    1
    w_48      whole_48  1
    w_48      asf_48    1
    w_48      asf_49    1
    w_48      asf_50    1
    w_48      asf_51    1
    w_48      asf_52    1
    w_48      asf_53    1
    w_48      asf_54    1
    w_48      asf_55    1
    w_48      asf_56    1
    w_48      asf_57    1
    w_48      asf_58    1
    w_48      asf_59    1
    w_48      asf_60    1
    w_49      whole_49  1
    w_49      asf_49    1
    w_49      asf_50    1
    w_49      asf_51    1
    w_49      asf_52    1
    w_49      asf_53    1
    w_49      asf_54    1
    w_49      asf_55    1
    w_49      asf_56    1
    w_49      asf_57    1
    w_49      asf_58    1
    w_49      asf_59    1
    w_49      asf_60    1
    w_50      whole_50  1
    w_50      asf_50    1
    w_50      asf_51    1
    w_50      asf_52    1
    w_50      asf_53    1
    w_50      asf_54    1
    w_50      asf_55    1
    w_50      asf_56    1
    w_50      asf_57    1
    w_50      asf_58    1
    w_50      asf_59    1
    w_50      asf_60    1
    w_51      whole_51  1
    w_51      asf_51    1
    w_51      asf_52    1
    w_51      asf_53    1
    w_51      asf_54    1
    w_51      asf_55    1
    w_51      asf_56    1
    w_51      asf_57    1
    w_51      asf_58    1
    w_51      asf_59    1
    w_51      asf_60    1
    w_52      whole_52  1
    w_52      asf_52    1
    w_52      asf_53    1
    w_52      asf_54    1
    w_52      asf_55    1
    w_52      asf_56    1
    w_52      asf_57    1
    w_52      asf_58    1
    w_52      asf_59    1
    w_52      asf_60    1
    w_53      whole_53  1
    w_53      asf_53    1
    w_53      asf_54    1
    w_53      asf_55    1
    w_53      asf_56    1
    w_53      asf_57    1
    w_53      asf_58    1
    w_53      asf_59    1
    w_53      asf_60    1
    w_54      whole_54  1
    w_54      asf_54    1
    w_54      asf_55    1
    w_54      asf_56    1
    w_54      asf_57    1
    w_54      asf_58    1
    w_54      asf_59    1
    w_54      asf_60    1
    w_55      whole_55  1
    w_55      asf_55    1
    w_55      asf_56    1
    w_55      asf_57    1
    w_55      asf_58    1
    w_55      asf_59    1
    w_55      asf_60    1
    w_56      whole_56  1
    w_56      asf_56    1
    w_56      asf_57    1
    w_56      asf_58    1
    w_56      asf_59    1
    w_56      asf_60    1
    w_57      whole_57  1
    w_57      asf_57    1
    w_57      asf_58    1
    w_57      asf_59    1
    w_57      asf_60    1
    w_58      whole_58  1
    w_58      asf_58    1
    w_58      asf_59    1
    w_58      asf_60    1
    w_59      whole_59  1
    w_59      asf_59    1
    w_59      asf_60    1
    w_60      whole_60  1
    w_60      asf_60    1
    S_1       balance_1  -1
    S_1       ie_2      0.0027429374999999997
    S_1       bd_2      0.00025000000000000001
    S_1       out_1     0.050000000000000003
    S_1       asf_1     0.94999999999999996
    S_2       balance_2  -1
    S_2       ie_3      0.0027358758333333334
    S_2       bd_3      0.00025000000000000001
    S_2       out_2     0.050000000000000003
    S_2       asf_2     0.94999999999999996
    S_3       balance_3  -1
    S_3       ie_4      0.0027288133333333332
    S_3       bd_4      0.00025000000000000001
    S_3       out_3     0.050000000000000003
    S_3       asf_3     0.94999999999999996
    S_4       balance_4  -1
    S_4       ie_5      0.0027217516666666664
    S_4       bd_5      0.00025000000000000001
    S_4       out_4     0.050000000000000003
    S_4       asf_4     0.94999999999999996
    S_5       balance_5  -1
    S_5       ie_6      0.0027146891666666667
    S_5       bd_6      0.00025000000000000001
    S_5       out_5     0.050000000000000003
    S_5       asf_5     0.94999999999999996
    S_6       balance_6  -1
    S_6       ie_7      0.0027076274999999995
    S_6       bd_7      0.00025000000000000001
    S_6       out_6     0.050000000000000003
    S_6       asf_6     0.94999999999999996
    S_7       balance_7  -1
    S_7       ie_8      0.0027005650000000003
    S_7       bd_8      0.00025000000000000001
    S_7       out_7     0.050000000000000003
    S_7       asf_7     0.94999999999999996
    S_8       balance_8  -1
    S_8       ie_9      0.0026935025000000001
    S_8       bd_9      0.00025000000000000001
    S_8       out_8     0.050000000000000003
    S_8       asf_8     0.94999999999999996
    S_9       balance_9  -1
    S_9       ie_10     0.0026864408333333333
    S_9       bd_10     0.00025000000000000001
    S_9       out_9     0.050000000000000003
    S_9       asf_9     0.94999999999999996
    S_10      balance_10  -1
    S_10      ie_11     0.0026793783333333332
    S_10      bd_11     0.00025000000000000001
    S_10      out_10    0.050000000000000003
    S_10      asf_10    0.94999999999999996
    S_11      balance_11  -1
    S_11      ie_12     0.0026723166666666664
    S_11      bd_12     0.00025000000000000001
    S_11      out_11    0.050000000000000003
    S_11      asf_11    0.94999999999999996
    S_12      balance_12  -1
    S_12      ie_13     0.0026652541666666663
    S_12      bd_13     0.00025000000000000001
    S_12      out_12    0.050000000000000003
    S_12      asf_12    0.94999999999999996
    S_13      balance_13  -1
    S_13      ie_14     0.0026581924999999999
    S_13      bd_14     0.00025000000000000001
    S_13      out_13    0.050000000000000003
    S_13      asf_13    0.94999999999999996
    S_14      balance_14  -1
    S_14      ie_15     0.0026511299999999998
    S_14      bd_15     0.00025000000000000001
    S_14      out_14    0.050000000000000003
    S_14      asf_14    0.94999999999999996
    S_15      balance_15  -1
    S_15      ie_16     0.0026440675000000001
    S_15      bd_16     0.00025000000000000001
    S_15      out_15    0.050000000000000003
    S_15      asf_15    0.94999999999999996
    S_16      balance_16  -1
    S_16      ie_17     0.0026370058333333333
    S_16      bd_17     0.00025000000000000001
    S_16      out_16    0.050000000000000003
    S_16      asf_16    0.94999999999999996
    S_17      balance_17  -1
    S_17      ie_18     0.0026299433333333332
    S_17      bd_18     0.00025000000000000001
    S_17      out_17    0.050000000000000003
    S_17      asf_17    0.94999999999999996
    S_18      balance_18  -1
    S_18      ie_19     0.0026228816666666668
    S_18      bd_19     0.00025000000000000001
    S_18      out_18    0.050000000000000003
    S_18      asf_18    0.94999999999999996
    S_19      balance_19  -1
    S_19      ie_20     0.0026158191666666667
    S_19      bd_20     0.00025000000000000001
    S_19      out_19    0.050000000000000003
    S_19      asf_19    0.94999999999999996
    S_20      balance_20  -1
    S_20      ie_21     0.0026087566666666666
    S_20      bd_21     0.00025000000000000001
    S_20      out_20    0.050000000000000003
    S_20      asf_20    0.94999999999999996
    S_21      balance_21  -1
    S_21      ie_22     0.0026016949999999998
    S_21      bd_22     0.00025000000000000001
    S_21      out_21    0.050000000000000003
    S_21      asf_21    0.94999999999999996
    S_22      balance_22  -1
    S_22      ie_23     0.0025946324999999997
    S_22      bd_23     0.00025000000000000001
    S_22      out_22    0.050000000000000003
    S_22      asf_22    0.94999999999999996
    S_23      balance_23  -1
    S_23      ie_24     0.0025875708333333329
    S_23      bd_24     0.00025000000000000001
    S_23      out_23    0.050000000000000003
    S_23      asf_23    0.94999999999999996
    S_24      balance_24  -1
    S_24      ie_25     0.0025805083333333332
    S_24      bd_25     0.00025000000000000001
    S_24      out_24    0.050000000000000003
    S_24      asf_24    0.94999999999999996
    S_25      balance_25  -1
    S_25      ie_26     0.0025734466666666664
    S_25      bd_26     0.00025000000000000001
    S_25      out_25    0.050000000000000003
    S_25      asf_25    0.94999999999999996
    S_26      balance_26  -1
    S_26      ie_27     0.0025663841666666663
    S_26      bd_27     0.00025000000000000001
    S_26      out_26    0.050000000000000003
    S_26      asf_26    0.94999999999999996
    S_27      balance_27  -1
    S_27      ie_28     0.0025593216666666666
    S_27      bd_28     0.00025000000000000001
    S_27      out_27    0.050000000000000003
    S_27      asf_27    0.94999999999999996
    S_28      balance_28  -1
    S_28      ie_29     0.0025522599999999998
    S_28      bd_29     0.00025000000000000001
    S_28      out_28    0.050000000000000003
    S_28      asf_28    0.94999999999999996
    S_29      balance_29  -1
    S_29      ie_30     0.0025451974999999996
    S_29      bd_30     0.00025000000000000001
    S_29      out_29    0.050000000000000003
    S_29      asf_29    0.94999999999999996
    S_30      balance_30  -1
    S_30      ie_31     0.0025381358333333333
    S_30      bd_31     0.00025000000000000001
    S_30      out_30    0.050000000000000003
    S_30      asf_30    0.94999999999999996
    S_31      balance_31  -1
    S_31      ie_32     0.0025310733333333332
    S_31      bd_32     0.00025000000000000001
    S_31      out_31    0.050000000000000003
    S_31      asf_31    0.94999999999999996
    S_32      balance_32  -1
    S_32      ie_33     0.0025240116666666664
    S_32      bd_33     0.00025000000000000001
    S_32      out_32    0.050000000000000003
    S_32      asf_32    0.94999999999999996
    S_33      balance_33  -1
    S_33      ie_34     0.0025169491666666667
    S_33      bd_34     0.00025000000000000001
    S_33      out_33    0.050000000000000003
    S_33      asf_33    0.94999999999999996
    S_34      balance_34  -1
    S_34      ie_35     0.0025098866666666666
    S_34      bd_35     0.00025000000000000001
    S_34      out_34    0.050000000000000003
    S_34      asf_34    0.94999999999999996
    S_35      balance_35  -1
    S_35      ie_36     0.0025028249999999998
    S_35      bd_36     0.00025000000000000001
    S_35      out_35    0.050000000000000003
    S_35      asf_35    0.94999999999999996
    S_36      balance_36  -1
    S_36      ie_37     0.0024957625000000001
    S_36      bd_37     0.00025000000000000001
    S_36      out_36    0.050000000000000003
    S_36      asf_36    0.94999999999999996
    S_37      balance_37  -1
    S_37      ie_38     0.0024887008333333328
    S_37      bd_38     0.00025000000000000001
    S_37      out_37    0.050000000000000003
    S_37      asf_37    0.94999999999999996
    S_38      balance_38  -1
    S_38      ie_39     0.0024816383333333331
    S_38      bd_39     0.00025000000000000001
    S_38      out_38    0.050000000000000003
    S_38      asf_38    0.94999999999999996
    S_39      balance_39  -1
    S_39      ie_40     0.0024745766666666663
    S_39      bd_40     0.00025000000000000001
    S_39      out_39    0.050000000000000003
    S_39      asf_39    0.94999999999999996
    S_40      balance_40  -1
    S_40      ie_41     0.0024675141666666662
    S_40      bd_41     0.00025000000000000001
    S_40      out_40    0.050000000000000003
    S_40      asf_40    0.94999999999999996
    S_41      balance_41  -1
    S_41      ie_42     0.0024604516666666665
    S_41      bd_42     0.00025000000000000001
    S_41      out_41    0.050000000000000003
    S_41      asf_41    0.94999999999999996
    S_42      balance_42  -1
    S_42      ie_43     0.0024533899999999997
    S_42      bd_43     0.00025000000000000001
    S_42      out_42    0.050000000000000003
    S_42      asf_42    0.94999999999999996
    S_43      balance_43  -1
    S_43      ie_44     0.0024463274999999996
    S_43      bd_44     0.00025000000000000001
    S_43      out_43    0.050000000000000003
    S_43      asf_43    0.94999999999999996
    S_44      balance_44  -1
    S_44      ie_45     0.0024392658333333333
    S_44      bd_45     0.00025000000000000001
    S_44      out_44    0.050000000000000003
    S_44      asf_44    0.94999999999999996
    S_45      balance_45  -1
    S_45      ie_46     0.0024322033333333331
    S_45      bd_46     0.00025000000000000001
    S_45      out_45    0.050000000000000003
    S_45      asf_45    0.94999999999999996
    S_46      balance_46  -1
    S_46      ie_47     0.002425140833333333
    S_46      bd_47     0.00025000000000000001
    S_46      out_46    0.050000000000000003
    S_46      asf_46    0.94999999999999996
    S_47      balance_47  -1
    S_47      ie_48     0.0024180791666666666
    S_47      bd_48     0.00025000000000000001
    S_47      out_47    0.050000000000000003
    S_47      asf_47    0.94999999999999996
    S_48      balance_48  -1
    S_48      ie_49     0.0024110166666666665
    S_48      bd_49     0.00025000000000000001
    S_48      out_48    0.050000000000000003
    S_48      asf_48    0.94999999999999996
    S_49      balance_49  -1
    S_49      ie_50     0.0024039549999999997
    S_49      bd_50     0.00025000000000000001
    S_49      out_49    0.050000000000000003
    S_49      asf_49    0.94999999999999996
    S_50      balance_50  -1
    S_50      ie_51     0.0023968925
    S_50      bd_51     0.00025000000000000001
    S_50      out_50    0.050000000000000003
    S_50      asf_50    0.94999999999999996
    S_51      balance_51  -1
    S_51      ie_52     0.0023898308333333332
    S_51      bd_52     0.00025000000000000001
    S_51      out_51    0.050000000000000003
    S_51      asf_51    0.94999999999999996
    S_52      balance_52  -1
    S_52      ie_53     0.0023827683333333331
    S_52      bd_53     0.00025000000000000001
    S_52      out_52    0.050000000000000003
    S_52      asf_52    0.94999999999999996
    S_53      balance_53  -1
    S_53      ie_54     0.002375705833333333
    S_53      bd_54     0.00025000000000000001
    S_53      out_53    0.050000000000000003
    S_53      asf_53    0.94999999999999996
    S_54      balance_54  -1
    S_54      ie_55     0.0023686441666666662
    S_54      bd_55     0.00025000000000000001
    S_54      out_54    0.050000000000000003
    S_54      asf_54    0.94999999999999996
    S_55      balance_55  -1
    S_55      ie_56     0.0023615816666666665
    S_55      bd_56     0.00025000000000000001
    S_55      out_55    0.050000000000000003
    S_55      asf_55    0.94999999999999996
    S_56      balance_56  -1
    S_56      ie_57     0.0023545199999999997
    S_56      bd_57     0.00025000000000000001
    S_56      out_56    0.050000000000000003
    S_56      asf_56    0.94999999999999996
    S_57      balance_57  -1
    S_57      ie_58     0.0023474574999999996
    S_57      bd_58     0.00025000000000000001
    S_57      out_57    0.050000000000000003
    S_57      asf_57    0.94999999999999996
    S_58      balance_58  -1
    S_58      ie_59     0.0023403958333333332
    S_58      bd_59     0.00025000000000000001
    S_58      out_58    0.050000000000000003
    S_58      asf_58    0.94999999999999996
    S_59      balance_59  -1
    S_59      ie_60     0.0023333333333333331
    S_59      bd_60     0.00025000000000000001
    S_59      out_59    0.050000000000000003
    S_59      asf_59    0.94999999999999996
    S_60      Obj       -0.0023333333333333331
    S_60      balance_60  -1
    S_60      out_60    0.050000000000000003
    S_60      asf_60    0.94999999999999996
    U_1       balance_1  -1
    U_1       ie_2      0.002326270833333333
    U_1       bd_2      0.00025000000000000001
    U_1       out_1     0.10000000000000001
    U_1       asf_1     0.90000000000000002
    U_2       balance_2  -1
    U_2       ie_3      0.0023192091666666666
    U_2       bd_3      0.00025000000000000001
    U_2       out_2     0.10000000000000001
    U_2       asf_2     0.90000000000000002
    U_3       balance_3  -1
    U_3       ie_4      0.0023121466666666665
    U_3       bd_4      0.00025000000000000001
    U_3       out_3     0.10000000000000001
    U_3       asf_3     0.90000000000000002
    U_4       balance_4  -1
    U_4       ie_5      0.0023050849999999997
    U_4       bd_5      0.00025000000000000001
    U_4       out_4     0.10000000000000001
    U_4       asf_4     0.90000000000000002
    U_5       balance_5  -1
    U_5       ie_6      0.0022980225
    U_5       bd_6      0.00025000000000000001
    U_5       out_5     0.10000000000000001
    U_5       asf_5     0.90000000000000002
    U_6       balance_6  -1
    U_6       ie_7      0.0022909608333333332
    U_6       bd_7      0.00025000000000000001
    U_6       out_6     0.10000000000000001
    U_6       asf_6     0.90000000000000002
    U_7       balance_7  -1
    U_7       ie_8      0.0022838983333333331
    U_7       bd_8      0.00025000000000000001
    U_7       out_7     0.10000000000000001
    U_7       asf_7     0.90000000000000002
    U_8       balance_8  -1
    U_8       ie_9      0.0022768358333333334
    U_8       bd_9      0.00025000000000000001
    U_8       out_8     0.10000000000000001
    U_8       asf_8     0.90000000000000002
    U_9       balance_9  -1
    U_9       ie_10     0.0022697741666666666
    U_9       bd_10     0.00025000000000000001
    U_9       out_9     0.10000000000000001
    U_9       asf_9     0.90000000000000002
    U_10      balance_10  -1
    U_10      ie_11     0.0022627116666666665
    U_10      bd_11     0.00025000000000000001
    U_10      out_10    0.10000000000000001
    U_10      asf_10    0.90000000000000002
    U_11      balance_11  -1
    U_11      ie_12     0.0022556499999999997
    U_11      bd_12     0.00025000000000000001
    U_11      out_11    0.10000000000000001
    U_11      asf_11    0.90000000000000002
    U_12      balance_12  -1
    U_12      ie_13     0.0022485874999999995
    U_12      bd_13     0.00025000000000000001
    U_12      out_12    0.10000000000000001
    U_12      asf_12    0.90000000000000002
    U_13      balance_13  -1
    U_13      ie_14     0.0022415258333333332
    U_13      bd_14     0.00025000000000000001
    U_13      out_13    0.10000000000000001
    U_13      asf_13    0.90000000000000002
    U_14      balance_14  -1
    U_14      ie_15     0.0022344633333333331
    U_14      bd_15     0.00025000000000000001
    U_14      out_14    0.10000000000000001
    U_14      asf_14    0.90000000000000002
    U_15      balance_15  -1
    U_15      ie_16     0.0022274008333333329
    U_15      bd_16     0.00025000000000000001
    U_15      out_15    0.10000000000000001
    U_15      asf_15    0.90000000000000002
    U_16      balance_16  -1
    U_16      ie_17     0.0022203391666666666
    U_16      bd_17     0.00025000000000000001
    U_16      out_16    0.10000000000000001
    U_16      asf_16    0.90000000000000002
    U_17      balance_17  -1
    U_17      ie_18     0.0022132766666666664
    U_17      bd_18     0.00025000000000000001
    U_17      out_17    0.10000000000000001
    U_17      asf_17    0.90000000000000002
    U_18      balance_18  -1
    U_18      ie_19     0.0022062149999999997
    U_18      bd_19     0.00025000000000000001
    U_18      out_18    0.10000000000000001
    U_18      asf_18    0.90000000000000002
    U_19      balance_19  -1
    U_19      ie_20     0.0021991525
    U_19      bd_20     0.00025000000000000001
    U_19      out_19    0.10000000000000001
    U_19      asf_19    0.90000000000000002
    U_20      balance_20  -1
    U_20      ie_21     0.0021920899999999998
    U_20      bd_21     0.00025000000000000001
    U_20      out_20    0.10000000000000001
    U_20      asf_20    0.90000000000000002
    U_21      balance_21  -1
    U_21      ie_22     0.002185028333333333
    U_21      bd_22     0.00025000000000000001
    U_21      out_21    0.10000000000000001
    U_21      asf_21    0.90000000000000002
    U_22      balance_22  -1
    U_22      ie_23     0.0021779658333333334
    U_22      bd_23     0.00025000000000000001
    U_22      out_22    0.10000000000000001
    U_22      asf_22    0.90000000000000002
    U_23      balance_23  -1
    U_23      ie_24     0.0021709041666666666
    U_23      bd_24     0.00025000000000000001
    U_23      out_23    0.10000000000000001
    U_23      asf_23    0.90000000000000002
    U_24      balance_24  -1
    U_24      ie_25     0.0021638416666666664
    U_24      bd_25     0.00025000000000000001
    U_24      out_24    0.10000000000000001
    U_24      asf_24    0.90000000000000002
    U_25      balance_25  -1
    U_25      ie_26     0.0021567799999999996
    U_25      bd_26     0.00025000000000000001
    U_25      out_25    0.10000000000000001
    U_25      asf_25    0.90000000000000002
    U_26      balance_26  -1
    U_26      ie_27     0.0021497174999999995
    U_26      bd_27     0.00025000000000000001
    U_26      out_26    0.10000000000000001
    U_26      asf_26    0.90000000000000002
    U_27      balance_27  -1
    U_27      ie_28     0.0021426549999999998
    U_27      bd_28     0.00025000000000000001
    U_27      out_27    0.10000000000000001
    U_27      asf_27    0.90000000000000002
    U_28      balance_28  -1
    U_28      ie_29     0.002135593333333333
    U_28      bd_29     0.00025000000000000001
    U_28      out_28    0.10000000000000001
    U_28      asf_28    0.90000000000000002
    U_29      balance_29  -1
    U_29      ie_30     0.0021285308333333329
    U_29      bd_30     0.00025000000000000001
    U_29      out_29    0.10000000000000001
    U_29      asf_29    0.90000000000000002
    U_30      balance_30  -1
    U_30      ie_31     0.0021214691666666665
    U_30      bd_31     0.00025000000000000001
    U_30      out_30    0.10000000000000001
    U_30      asf_30    0.90000000000000002
    U_31      balance_31  -1
    U_31      ie_32     0.0021144066666666664
    U_31      bd_32     0.00025000000000000001
    U_31      out_31    0.10000000000000001
    U_31      asf_31    0.90000000000000002
    U_32      balance_32  -1
    U_32      ie_33     0.0021073450000000001
    U_32      bd_33     0.00025000000000000001
    U_32      out_32    0.10000000000000001
    U_32      asf_32    0.90000000000000002
    U_33      balance_33  -1
    U_33      ie_34     0.0021002824999999999
    U_33      bd_34     0.00025000000000000001
    U_33      out_33    0.10000000000000001
    U_33      asf_33    0.90000000000000002
    U_34      balance_34  -1
    U_34      ie_35     0.0020932199999999998
    U_34      bd_35     0.00025000000000000001
    U_34      out_34    0.10000000000000001
    U_34      asf_34    0.90000000000000002
    U_35      balance_35  -1
    U_35      ie_36     0.002086158333333333
    U_35      bd_36     0.00025000000000000001
    U_35      out_35    0.10000000000000001
    U_35      asf_35    0.90000000000000002
    U_36      balance_36  -1
    U_36      ie_37     0.0020790958333333333
    U_36      bd_37     0.00025000000000000001
    U_36      out_36    0.10000000000000001
    U_36      asf_36    0.90000000000000002
    U_37      balance_37  -1
    U_37      ie_38     0.0020720341666666665
    U_37      bd_38     0.00025000000000000001
    U_37      out_37    0.10000000000000001
    U_37      asf_37    0.90000000000000002
    U_38      balance_38  -1
    U_38      ie_39     0.0020649716666666664
    U_38      bd_39     0.00025000000000000001
    U_38      out_38    0.10000000000000001
    U_38      asf_38    0.90000000000000002
    U_39      balance_39  -1
    U_39      ie_40     0.0020579099999999996
    U_39      bd_40     0.00025000000000000001
    U_39      out_39    0.10000000000000001
    U_39      asf_39    0.90000000000000002
    U_40      balance_40  -1
    U_40      ie_41     0.0020508474999999999
    U_40      bd_41     0.00025000000000000001
    U_40      out_40    0.10000000000000001
    U_40      asf_40    0.90000000000000002
    U_41      balance_41  -1
    U_41      ie_42     0.0020437849999999998
    U_41      bd_42     0.00025000000000000001
    U_41      out_41    0.10000000000000001
    U_41      asf_41    0.90000000000000002
    U_42      balance_42  -1
    U_42      ie_43     0.002036723333333333
    U_42      bd_43     0.00025000000000000001
    U_42      out_42    0.10000000000000001
    U_42      asf_42    0.90000000000000002
    U_43      balance_43  -1
    U_43      ie_44     0.0020296608333333329
    U_43      bd_44     0.00025000000000000001
    U_43      out_43    0.10000000000000001
    U_43      asf_43    0.90000000000000002
    U_44      balance_44  -1
    U_44      ie_45     0.0020225991666666665
    U_44      bd_45     0.00025000000000000001
    U_44      out_44    0.10000000000000001
    U_44      asf_44    0.90000000000000002
    U_45      balance_45  -1
    U_45      ie_46     0.0020155366666666664
    U_45      bd_46     0.00025000000000000001
    U_45      out_45    0.10000000000000001
    U_45      asf_45    0.90000000000000002
    U_46      balance_46  -1
    U_46      ie_47     0.0020084741666666663
    U_46      bd_47     0.00025000000000000001
    U_46      out_46    0.10000000000000001
    U_46      asf_46    0.90000000000000002
    U_47      balance_47  -1
    U_47      ie_48     0.0020014124999999999
    U_47      bd_48     0.00025000000000000001
    U_47      out_47    0.10000000000000001
    U_47      asf_47    0.90000000000000002
    U_48      balance_48  -1
    U_48      ie_49     0.0019943499999999998
    U_48      bd_49     0.00025000000000000001
    U_48      out_48    0.10000000000000001
    U_48      asf_48    0.90000000000000002
    U_49      balance_49  -1
    U_49      ie_50     0.0019872883333333334
    U_49      bd_50     0.00025000000000000001
    U_49      out_49    0.10000000000000001
    U_49      asf_49    0.90000000000000002
    U_50      balance_50  -1
    U_50      ie_51     0.0019802258333333333
    U_50      bd_51     0.00025000000000000001
    U_50      out_50    0.10000000000000001
    U_50      asf_50    0.90000000000000002
    U_51      balance_51  -1
    U_51      ie_52     0.0019731641666666665
    U_51      bd_52     0.00025000000000000001
    U_51      out_51    0.10000000000000001
    U_51      asf_51    0.90000000000000002
    U_52      balance_52  -1
    U_52      ie_53     0.0019661016666666664
    U_52      bd_53     0.00025000000000000001
    U_52      out_52    0.10000000000000001
    U_52      asf_52    0.90000000000000002
    U_53      balance_53  -1
    U_53      ie_54     0.0019590391666666667
    U_53      bd_54     0.00025000000000000001
    U_53      out_53    0.10000000000000001
    U_53      asf_53    0.90000000000000002
    U_54      balance_54  -1
    U_54      ie_55     0.0019519774999999999
    U_54      bd_55     0.00025000000000000001
    U_54      out_54    0.10000000000000001
    U_54      asf_54    0.90000000000000002
    U_55      balance_55  -1
    U_55      ie_56     0.0019449149999999998
    U_55      bd_56     0.00025000000000000001
    U_55      out_55    0.10000000000000001
    U_55      asf_55    0.90000000000000002
    U_56      balance_56  -1
    U_56      ie_57     0.0019378533333333332
    U_56      bd_57     0.00025000000000000001
    U_56      out_56    0.10000000000000001
    U_56      asf_56    0.90000000000000002
    U_57      balance_57  -1
    U_57      ie_58     0.0019307908333333333
    U_57      bd_58     0.00025000000000000001
    U_57      out_57    0.10000000000000001
    U_57      asf_57    0.90000000000000002
    U_58      balance_58  -1
    U_58      ie_59     0.0019237291666666665
    U_58      bd_59     0.00025000000000000001
    U_58      out_58    0.10000000000000001
    U_58      asf_58    0.90000000000000002
    U_59      balance_59  -1
    U_59      ie_60     0.0019166666666666666
    U_59      bd_60     0.00025000000000000001
    U_59      out_59    0.10000000000000001
    U_59      asf_59    0.90000000000000002
    U_60      Obj       -0.0019166666666666666
    U_60      balance_60  -1
    U_60      out_60    0.10000000000000001
    U_60      asf_60    0.90000000000000002
    H_1       balance_1  1
    H_1       liquid_1  -1
    H_1       lev_min_1  -0.032500000000000001
    H_1       lev_buf_1  -0.037499999999999999
    H_2       balance_2  1
    H_2       liquid_2  -1
    H_2       lev_min_2  -0.032500000000000001
    H_2       lev_buf_2  -0.037499999999999999
    H_3       balance_3  1
    H_3       liquid_3  -1
    H_3       lev_min_3  -0.032500000000000001
    H_3       lev_buf_3  -0.037499999999999999
    H_4       balance_4  1
    H_4       liquid_4  -1
    H_4       lev_min_4  -0.032500000000000001
    H_4       lev_buf_4  -0.037499999999999999
    H_5       balance_5  1
    H_5       liquid_5  -1
    H_5       lev_min_5  -0.032500000000000001
    H_5       lev_buf_5  -0.037499999999999999
    H_6       balance_6  1
    H_6       liquid_6  -1
    H_6       lev_min_6  -0.032500000000000001
    H_6       lev_buf_6  -0.037499999999999999
    H_7       balance_7  1
    H_7       liquid_7  -1
    H_7       lev_min_7  -0.032500000000000001
    H_7       lev_buf_7  -0.037499999999999999
    H_8       balance_8  1
    H_8       liquid_8  -1
    H_8       lev_min_8  -0.032500000000000001
    H_8       lev_buf_8  -0.037499999999999999
    H_9       balance_9  1
    H_9       liquid_9  -1
    H_9       lev_min_9  -0.032500000000000001
    H_9       lev_buf_9  -0.037499999999999999
    H_10      balance_10  1
    H_10      liquid_10  -1
    H_10      lev_min_10  -0.032500000000000001
    H_10      lev_buf_10  -0.037499999999999999
    H_11      balance_11  1
    H_11      liquid_11  -1
    H_11      lev_min_11  -0.032500000000000001
    H_11      lev_buf_11  -0.037499999999999999
    H_12      balance_12  1
    H_12      liquid_12  -1
    H_12      lev_min_12  -0.032500000000000001
    H_12      lev_buf_12  -0.037499999999999999
    H_13      balance_13  1
    H_13      liquid_13  -1
    H_13      lev_min_13  -0.032500000000000001
    H_13      lev_buf_13  -0.037499999999999999
    H_14      balance_14  1
    H_14      liquid_14  -1
    H_14      lev_min_14  -0.032500000000000001
    H_14      lev_buf_14  -0.037499999999999999
    H_15      balance_15  1
    H_15      liquid_15  -1
    H_15      lev_min_15  -0.032500000000000001
    H_15      lev_buf_15  -0.037499999999999999
    H_16      balance_16  1
    H_16      liquid_16  -1
    H_16      lev_min_16  -0.032500000000000001
    H_16      lev_buf_16  -0.037499999999999999
    H_17      balance_17  1
    H_17      liquid_17  -1
    H_17      lev_min_17  -0.032500000000000001
    H_17      lev_buf_17  -0.037499999999999999
    H_18      balance_18  1
    H_18      liquid_18  -1
    H_18      lev_min_18  -0.032500000000000001
    H_18      lev_buf_18  -0.037499999999999999
    H_19      balance_19  1
    H_19      liquid_19  -1
    H_19      lev_min_19  -0.032500000000000001
    H_19      lev_buf_19  -0.037499999999999999
    H_20      balance_20  1
    H_20      liquid_20  -1
    H_20      lev_min_20  -0.032500000000000001
    H_20      lev_buf_20  -0.037499999999999999
    H_21      balance_21  1
    H_21      liquid_21  -1
    H_21      lev_min_21  -0.032500000000000001
    H_21      lev_buf_21  -0.037499999999999999
    H_22      balance_22  1
    H_22      liquid_22  -1
    H_22      lev_min_22  -0.032500000000000001
    H_22      lev_buf_22  -0.037499999999999999
    H_23      balance_23  1
    H_23      liquid_23  -1
    H_23      lev_min_23  -0.032500000000000001
    H_23      lev_buf_23  -0.037499999999999999
    H_24      balance_24  1
    H_24      liquid_24  -1
    H_24      lev_min_24  -0.032500000000000001
    H_24      lev_buf_24  -0.037499999999999999
    H_25      balance_25  1
    H_25      liquid_25  -1
    H_25      lev_min_25  -0.032500000000000001
    H_25      lev_buf_25  -0.037499999999999999
    H_26      balance_26  1
    H_26      liquid_26  -1
    H_26      lev_min_26  -0.032500000000000001
    H_26      lev_buf_26  -0.037499999999999999
    H_27      balance_27  1
    H_27      liquid_27  -1
    H_27      lev_min_27  -0.032500000000000001
    H_27      lev_buf_27  -0.037499999999999999
    H_28      balance_28  1
    H_28      liquid_28  -1
    H_28      lev_min_28  -0.032500000000000001
    H_28      lev_buf_28  -0.037499999999999999
    H_29      balance_29  1
    H_29      liquid_29  -1
    H_29      lev_min_29  -0.032500000000000001
    H_29      lev_buf_29  -0.037499999999999999
    H_30      balance_30  1
    H_30      liquid_30  -1
    H_30      lev_min_30  -0.032500000000000001
    H_30      lev_buf_30  -0.037499999999999999
    H_31      balance_31  1
    H_31      liquid_31  -1
    H_31      lev_min_31  -0.032500000000000001
    H_31      lev_buf_31  -0.037499999999999999
    H_32      balance_32  1
    H_32      liquid_32  -1
    H_32      lev_min_32  -0.032500000000000001
    H_32      lev_buf_32  -0.037499999999999999
    H_33      balance_33  1
    H_33      liquid_33  -1
    H_33      lev_min_33  -0.032500000000000001
    H_33      lev_buf_33  -0.037499999999999999
    H_34      balance_34  1
    H_34      liquid_34  -1
    H_34      lev_min_34  -0.032500000000000001
    H_34      lev_buf_34  -0.037499999999999999
    H_35      balance_35  1
    H_35      liquid_35  -1
    H_35      lev_min_35  -0.032500000000000001
    H_35      lev_buf_35  -0.037499999999999999
    H_36      balance_36  1
    H_36      liquid_36  -1
    H_36      lev_min_36  -0.032500000000000001
    H_36      lev_buf_36  -0.037499999999999999
    H_37      balance_37  1
    H_37      liquid_37  -1
    H_37      lev_min_37  -0.032500000000000001
    H_37      lev_buf_37  -0.037499999999999999
    H_38      balance_38  1
    H_38      liquid_38  -1
    H_38      lev_min_38  -0.032500000000000001
    H_38      lev_buf_38  -0.037499999999999999
    H_39      balance_39  1
    H_39      liquid_39  -1
    H_39      lev_min_39  -0.032500000000000001
    H_39      lev_buf_39  -0.037499999999999999
    H_40      balance_40  1
    H_40      liquid_40  -1
    H_40      lev_min_40  -0.032500000000000001
    H_40      lev_buf_40  -0.037499999999999999
    H_41      balance_41  1
    H_41      liquid_41  -1
    H_41      lev_min_41  -0.032500000000000001
    H_41      lev_buf_41  -0.037499999999999999
    H_42      balance_42  1
    H_42      liquid_42  -1
    H_42      lev_min_42  -0.032500000000000001
    H_42      lev_buf_42  -0.037499999999999999
    H_43      balance_43  1
    H_43      liquid_43  -1
    H_43      lev_min_43  -0.032500000000000001
    H_43      lev_buf_43  -0.037499999999999999
    H_44      balance_44  1
    H_44      liquid_44  -1
    H_44      lev_min_44  -0.032500000000000001
    H_44      lev_buf_44  -0.037499999999999999
    H_45      balance_45  1
    H_45      liquid_45  -1
    H_45      lev_min_45  -0.032500000000000001
    H_45      lev_buf_45  -0.037499999999999999
    H_46      balance_46  1
    H_46      liquid_46  -1
    H_46      lev_min_46  -0.032500000000000001
    H_46      lev_buf_46  -0.037499999999999999
    H_47      balance_47  1
    H_47      liquid_47  -1
    H_47      lev_min_47  -0.032500000000000001
    H_47      lev_buf_47  -0.037499999999999999
    H_48      balance_48  1
    H_48      liquid_48  -1
    H_48      lev_min_48  -0.032500000000000001
    H_48      lev_buf_48  -0.037499999999999999
    H_49      balance_49  1
    H_49      liquid_49  -1
    H_49      lev_min_49  -0.032500000000000001
    H_49      lev_buf_49  -0.037499999999999999
    H_50      balance_50  1
    H_50      liquid_50  -1
    H_50      lev_min_50  -0.032500000000000001
    H_50      lev_buf_50  -0.037499999999999999
    H_51      balance_51  1
    H_51      liquid_51  -1
    H_51      lev_min_51  -0.032500000000000001
    H_51      lev_buf_51  -0.037499999999999999
    H_52      balance_52  1
    H_52      liquid_52  -1
    H_52      lev_min_52  -0.032500000000000001
    H_52      lev_buf_52  -0.037499999999999999
    H_53      balance_53  1
    H_53      liquid_53  -1
    H_53      lev_min_53  -0.032500000000000001
    H_53      lev_buf_53  -0.037499999999999999
    H_54      balance_54  1
    H_54      liquid_54  -1
    H_54      lev_min_54  -0.032500000000000001
    H_54      lev_buf_54  -0.037499999999999999
    H_55      balance_55  1
    H_55      liquid_55  -1
    H_55      lev_min_55  -0.032500000000000001
    H_55      lev_buf_55  -0.037499999999999999
    H_56      balance_56  1
    H_56      liquid_56  -1
    H_56      lev_min_56  -0.032500000000000001
    H_56      lev_buf_56  -0.037499999999999999
    H_57      balance_57  1
    H_57      liquid_57  -1
    H_57      lev_min_57  -0.032500000000000001
    H_57      lev_buf_57  -0.037499999999999999
    H_58      balance_58  1
    H_58      liquid_58  -1
    H_58      lev_min_58  -0.032500000000000001
    H_58      lev_buf_58  -0.037499999999999999
    H_59      balance_59  1
    H_59      liquid_59  -1
    H_59      lev_min_59  -0.032500000000000001
    H_59      lev_buf_59  -0.037499999999999999
    H_60      balance_60  1
    H_60      liquid_60  -1
    H_60      lev_min_60  -0.032500000000000001
    H_60      lev_buf_60  -0.037499999999999999
    M_1       md_1      0.5
    M_1       mb_1      0.5
    M_1       spend_1   1
    M_1       spend_2   1
    M_2       md_2      0.5
    M_2       mb_2      0.5
    M_2       spend_2   -1
    M_2       spend_3   1
    M_3       md_3      0.5
    M_3       mb_3      0.5
    M_3       spend_3   -1
    M_3       spend_4   1
    M_4       md_4      0.5
    M_4       mb_4      0.5
    M_4       spend_4   -1
    M_4       spend_5   1
    M_5       md_5      0.5
    M_5       mb_5      0.5
    M_5       spend_5   -1
    M_5       spend_6   1
    M_6       md_6      0.5
    M_6       mb_6      0.5
    M_6       spend_6   -1
    M_6       spend_7   1
    M_7       md_7      0.5
    M_7       mb_7      0.5
    M_7       spend_7   -1
    M_7       spend_8   1
    M_8       md_8      0.5
    M_8       mb_8      0.5
    M_8       spend_8   -1
    M_8       spend_9   1
    M_9       md_9      0.5
    M_9       mb_9      0.5
    M_9       spend_9   -1
    M_9       spend_10  1
    M_10      md_10     0.5
    M_10      mb_10     0.5
    M_10      spend_10  -1
    M_10      spend_11  1
    M_11      md_11     0.5
    M_11      mb_11     0.5
    M_11      spend_11  -1
    M_11      spend_12  1
    M_12      md_12     0.5
    M_12      mb_12     0.5
    M_12      spend_12  -1
    M_12      spend_13  1
    M_13      md_13     0.5
    M_13      mb_13     0.5
    M_13      spend_13  -1
    M_13      spend_14  1
    M_14      md_14     0.5
    M_14      mb_14     0.5
    M_14      spend_14  -1
    M_14      spend_15  1
    M_15      md_15     0.5
    M_15      mb_15     0.5
    M_15      spend_15  -1
    M_15      spend_16  1
    M_16      md_16     0.5
    M_16      mb_16     0.5
    M_16      spend_16  -1
    M_16      spend_17  1
    M_17      md_17     0.5
    M_17      mb_17     0.5
    M_17      spend_17  -1
    M_17      spend_18  1
    M_18      md_18     0.5
    M_18      mb_18     0.5
    M_18      spend_18  -1
    M_18      spend_19  1
    M_19      md_19     0.5
    M_19      mb_19     0.5
    M_19      spend_19  -1
    M_19      spend_20  1
    M_20      md_20     0.5
    M_20      mb_20     0.5
    M_20      spend_20  -1
    M_20      spend_21  1
    M_21      md_21     0.5
    M_21      mb_21     0.5
    M_21      spend_21  -1
    M_21      spend_22  1
    M_22      md_22     0.5
    M_22      mb_22     0.5
    M_22      spend_22  -1
    M_22      spend_23  1
    M_23      md_23     0.5
    M_23      mb_23     0.5
    M_23      spend_23  -1
    M_23      spend_24  1
    M_24      md_24     0.5
    M_24      mb_24     0.5
    M_24      spend_24  -1
    M_24      spend_25  1
    M_25      md_25     0.5
    M_25      mb_25     0.5
    M_25      spend_25  -1
    M_25      spend_26  1
    M_26      md_26     0.5
    M_26      mb_26     0.5
    M_26      spend_26  -1
    M_26      spend_27  1
    M_27      md_27     0.5
    M_27      mb_27     0.5
    M_27      spend_27  -1
    M_27      spend_28  1
    M_28      md_28     0.5
    M_28      mb_28     0.5
    M_28      spend_28  -1
    M_28      spend_29  1
    M_29      md_29     0.5
    M_29      mb_29     0.5
    M_29      spend_29  -1
    M_29      spend_30  1
    M_30      md_30     0.5
    M_30      mb_30     0.5
    M_30      spend_30  -1
    M_30      spend_31  1
    M_31      md_31     0.5
    M_31      mb_31     0.5
    M_31      spend_31  -1
    M_31      spend_32  1
    M_32      md_32     0.5
    M_32      mb_32     0.5
    M_32      spend_32  -1
    M_32      spend_33  1
    M_33      md_33     0.5
    M_33      mb_33     0.5
    M_33      spend_33  -1
    M_33      spend_34  1
    M_34      md_34     0.5
    M_34      mb_34     0.5
    M_34      spend_34  -1
    M_34      spend_35  1
    M_35      md_35     0.5
    M_35      mb_35     0.5
    M_35      spend_35  -1
    M_35      spend_36  1
    M_36      md_36     0.5
    M_36      mb_36     0.5
    M_36      spend_36  -1
    M_36      spend_37  1
    M_37      md_37     0.5
    M_37      mb_37     0.5
    M_37      spend_37  -1
    M_37      spend_38  1
    M_38      md_38     0.5
    M_38      mb_38     0.5
    M_38      spend_38  -1
    M_38      spend_39  1
    M_39      md_39     0.5
    M_39      mb_39     0.5
    M_39      spend_39  -1
    M_39      spend_40  1
    M_40      md_40     0.5
    M_40      mb_40     0.5
    M_40      spend_40  -1
    M_40      spend_41  1
    M_41      md_41     0.5
    M_41      mb_41     0.5
    M_41      spend_41  -1
    M_41      spend_42  1
    M_42      md_42     0.5
    M_42      mb_42     0.5
    M_42      spend_42  -1
    M_42      spend_43  1
    M_43      md_43     0.5
    M_43      mb_43     0.5
    M_43      spend_43  -1
    M_43      spend_44  1
    M_44      md_44     0.5
    M_44      mb_44     0.5
    M_44      spend_44  -1
    M_44      spend_45  1
    M_45      md_45     0.5
    M_45      mb_45     0.5
    M_45      spend_45  -1
    M_45      spend_46  1
    M_46      md_46     0.5
    M_46      mb_46     0.5
    M_46      spend_46  -1
    M_46      spend_47  1
    M_47      md_47     0.5
    M_47      mb_47     0.5
    M_47      spend_47  -1
    M_47      spend_48  1
    M_48      md_48     0.5
    M_48      mb_48     0.5
    M_48      spend_48  -1
    M_48      spend_49  1
    M_49      md_49     0.5
    M_49      mb_49     0.5
    M_49      spend_49  -1
    M_49      spend_50  1
    M_50      md_50     0.5
    M_50      mb_50     0.5
    M_50      spend_50  -1
    M_50      spend_51  1
    M_51      md_51     0.5
    M_51      mb_51     0.5
    M_51      spend_51  -1
    M_51      spend_52  1
    M_52      md_52     0.5
    M_52      mb_52     0.5
    M_52      spend_52  -1
    M_52      spend_53  1
    M_53      md_53     0.5
    M_53      mb_53     0.5
    M_53      spend_53  -1
    M_53      spend_54  1
    M_54      md_54     0.5
    M_54      mb_54     0.5
    M_54      spend_54  -1
    M_54      spend_55  1
    M_55      md_55     0.5
    M_55      mb_55     0.5
    M_55      spend_55  -1
    M_55      spend_56  1
    M_56      md_56     0.5
    M_56      mb_56     0.5
    M_56      spend_56  -1
    M_56      spend_57  1
    M_57      md_57     0.5
    M_57      mb_57     0.5
    M_57      spend_57  -1
    M_57      spend_58  1
    M_58      md_58     0.5
    M_58      mb_58     0.5
    M_58      spend_58  -1
    M_58      spend_59  1
    M_59      md_59     0.5
    M_59      mb_59     0.5
    M_59      spend_59  -1
    M_59      spend_60  1
    M_60      md_60     0.5
    M_60      mb_60     0.5
    M_60      spend_60  -1
    L_1       stage2_2  0.0050000000000000001
    L_1       stage3_2  5.0000000000000002e-05
    L_1       provision_1  0.002
    L_1       loan_1    -1
    L_1       loan_2    0.98999999999999999
    L_1       balance_1  1
    L_1       ii_2      0.0044096041666666658
    L_1       bb_2      0.00016666666666666666
    L_1       rwa_1     -0.34999999999999998
    L_1       in_1      0.0050000000000000001
    L_1       rsf_1     0.65000000000000002
    L_1       lev_min_1  -0.032500000000000001
    L_1       lev_buf_1  -0.037499999999999999
    L_2       stage2_3  0.0050000000000000001
    L_2       stage3_3  5.0000000000000002e-05
    L_2       provision_2  0.002
    L_2       loan_2    -1
    L_2       loan_3    0.98999999999999999
    L_2       balance_2  1
    L_2       ii_3      0.0044025424999999995
    L_2       bb_3      0.00016666666666666666
    L_2       rwa_2     -0.34999999999999998
    L_2       in_2      0.0050000000000000001
    L_2       rsf_2     0.65000000000000002
    L_2       lev_min_2  -0.032500000000000001
    L_2       lev_buf_2  -0.037499999999999999
    L_3       stage2_4  0.0050000000000000001
    L_3       stage3_4  5.0000000000000002e-05
    L_3       provision_3  0.002
    L_3       loan_3    -1
    L_3       loan_4    0.98999999999999999
    L_3       balance_3  1
    L_3       ii_4      0.0043954799999999994
    L_3       bb_4      0.00016666666666666666
    L_3       rwa_3     -0.34999999999999998
    L_3       in_3      0.0050000000000000001
    L_3       rsf_3     0.65000000000000002
    L_3       lev_min_3  -0.032500000000000001
    L_3       lev_buf_3  -0.037499999999999999
    L_4       stage2_5  0.0050000000000000001
    L_4       stage3_5  5.0000000000000002e-05
    L_4       provision_4  0.002
    L_4       loan_4    -1
    L_4       loan_5    0.98999999999999999
    L_4       balance_4  1
    L_4       ii_5      0.004388418333333333
    L_4       bb_5      0.00016666666666666666
    L_4       rwa_4     -0.34999999999999998
    L_4       in_4      0.0050000000000000001
    L_4       rsf_4     0.65000000000000002
    L_4       lev_min_4  -0.032500000000000001
    L_4       lev_buf_4  -0.037499999999999999
    L_5       stage2_6  0.0050000000000000001
    L_5       stage3_6  5.0000000000000002e-05
    L_5       provision_5  0.002
    L_5       loan_5    -1
    L_5       loan_6    0.98999999999999999
    L_5       balance_5  1
    L_5       ii_6      0.0043813558333333329
    L_5       bb_6      0.00016666666666666666
    L_5       rwa_5     -0.34999999999999998
    L_5       in_5      0.0050000000000000001
    L_5       rsf_5     0.65000000000000002
    L_5       lev_min_5  -0.032500000000000001
    L_5       lev_buf_5  -0.037499999999999999
    L_6       stage2_7  0.0050000000000000001
    L_6       stage3_7  5.0000000000000002e-05
    L_6       provision_6  0.002
    L_6       loan_6    -1
    L_6       loan_7    0.98999999999999999
    L_6       balance_6  1
    L_6       ii_7      0.0043742941666666665
    L_6       bb_7      0.00016666666666666666
    L_6       rwa_6     -0.34999999999999998
    L_6       in_6      0.0050000000000000001
    L_6       rsf_6     0.65000000000000002
    L_6       lev_min_6  -0.032500000000000001
    L_6       lev_buf_6  -0.037499999999999999
    L_7       stage2_8  0.0050000000000000001
    L_7       stage3_8  5.0000000000000002e-05
    L_7       provision_7  0.002
    L_7       loan_7    -1
    L_7       loan_8    0.98999999999999999
    L_7       balance_7  1
    L_7       ii_8      0.0043672316666666664
    L_7       bb_8      0.00016666666666666666
    L_7       rwa_7     -0.34999999999999998
    L_7       in_7      0.0050000000000000001
    L_7       rsf_7     0.65000000000000002
    L_7       lev_min_7  -0.032500000000000001
    L_7       lev_buf_7  -0.037499999999999999
    L_8       stage2_9  0.0050000000000000001
    L_8       stage3_9  5.0000000000000002e-05
    L_8       provision_8  0.002
    L_8       loan_8    -1
    L_8       loan_9    0.98999999999999999
    L_8       balance_8  1
    L_8       ii_9      0.0043601691666666663
    L_8       bb_9      0.00016666666666666666
    L_8       rwa_8     -0.34999999999999998
    L_8       in_8      0.0050000000000000001
    L_8       rsf_8     0.65000000000000002
    L_8       lev_min_8  -0.032500000000000001
    L_8       lev_buf_8  -0.037499999999999999
    L_9       stage2_10  0.0050000000000000001
    L_9       stage3_10  5.0000000000000002e-05
    L_9       provision_9  0.002
    L_9       loan_9    -1
    L_9       loan_10   0.98999999999999999
    L_9       balance_9  1
    L_9       ii_10     0.0043531074999999999
    L_9       bb_10     0.00016666666666666666
    L_9       rwa_9     -0.34999999999999998
    L_9       in_9      0.0050000000000000001
    L_9       rsf_9     0.65000000000000002
    L_9       lev_min_9  -0.032500000000000001
    L_9       lev_buf_9  -0.037499999999999999
    L_10      stage2_11  0.0050000000000000001
    L_10      stage3_11  5.0000000000000002e-05
    L_10      provision_10  0.002
    L_10      loan_10   -1
    L_10      loan_11   0.98999999999999999
    L_10      balance_10  1
    L_10      ii_11     0.0043460449999999998
    L_10      bb_11     0.00016666666666666666
    L_10      rwa_10    -0.34999999999999998
    L_10      in_10     0.0050000000000000001
    L_10      rsf_10    0.65000000000000002
    L_10      lev_min_10  -0.032500000000000001
    L_10      lev_buf_10  -0.037499999999999999
    L_11      stage2_12  0.0050000000000000001
    L_11      stage3_12  5.0000000000000002e-05
    L_11      provision_11  0.002
    L_11      loan_11   -1
    L_11      loan_12   0.98999999999999999
    L_11      balance_11  1
    L_11      ii_12     0.0043389833333333325
    L_11      bb_12     0.00016666666666666666
    L_11      rwa_11    -0.34999999999999998
    L_11      in_11     0.0050000000000000001
    L_11      rsf_11    0.65000000000000002
    L_11      lev_min_11  -0.032500000000000001
    L_11      lev_buf_11  -0.037499999999999999
    L_12      stage2_13  0.0050000000000000001
    L_12      stage3_13  5.0000000000000002e-05
    L_12      provision_12  0.002
    L_12      loan_12   -1
    L_12      loan_13   0.98999999999999999
    L_12      balance_12  1
    L_12      ii_13     0.0043319208333333324
    L_12      bb_13     0.00016666666666666666
    L_12      rwa_12    -0.34999999999999998
    L_12      in_12     0.0050000000000000001
    L_12      rsf_12    0.65000000000000002
    L_12      lev_min_12  -0.032500000000000001
    L_12      lev_buf_12  -0.037499999999999999
    L_13      stage2_14  0.0050000000000000001
    L_13      stage3_14  5.0000000000000002e-05
    L_13      provision_13  0.002
    L_13      loan_13   -1
    L_13      loan_14   0.98999999999999999
    L_13      balance_13  1
    L_13      ii_14     0.0043248591666666661
    L_13      bb_14     0.00016666666666666666
    L_13      rwa_13    -0.34999999999999998
    L_13      in_13     0.0050000000000000001
    L_13      rsf_13    0.65000000000000002
    L_13      lev_min_13  -0.032500000000000001
    L_13      lev_buf_13  -0.037499999999999999
    L_14      stage2_15  0.0050000000000000001
    L_14      stage3_15  5.0000000000000002e-05
    L_14      provision_14  0.002
    L_14      loan_14   -1
    L_14      loan_15   0.98999999999999999
    L_14      balance_14  1
    L_14      ii_15     0.0043177966666666668
    L_14      bb_15     0.00016666666666666666
    L_14      rwa_14    -0.34999999999999998
    L_14      in_14     0.0050000000000000001
    L_14      rsf_14    0.65000000000000002
    L_14      lev_min_14  -0.032500000000000001
    L_14      lev_buf_14  -0.037499999999999999
    L_15      stage2_16  0.0050000000000000001
    L_15      stage3_16  5.0000000000000002e-05
    L_15      provision_15  0.002
    L_15      loan_15   -1
    L_15      loan_16   0.98999999999999999
    L_15      balance_15  1
    L_15      ii_16     0.0043107341666666667
    L_15      bb_16     0.00016666666666666666
    L_15      rwa_15    -0.34999999999999998
    L_15      in_15     0.0050000000000000001
    L_15      rsf_15    0.65000000000000002
    L_15      lev_min_15  -0.032500000000000001
    L_15      lev_buf_15  -0.037499999999999999
    L_16      stage2_17  0.0050000000000000001
    L_16      stage3_17  5.0000000000000002e-05
    L_16      provision_16  0.002
    L_16      loan_16   -1
    L_16      loan_17   0.98999999999999999
    L_16      balance_16  1
    L_16      ii_17     0.0043036724999999994
    L_16      bb_17     0.00016666666666666666
    L_16      rwa_16    -0.34999999999999998
    L_16      in_16     0.0050000000000000001
    L_16      rsf_16    0.65000000000000002
    L_16      lev_min_16  -0.032500000000000001
    L_16      lev_buf_16  -0.037499999999999999
    L_17      stage2_18  0.0050000000000000001
    L_17      stage3_18  5.0000000000000002e-05
    L_17      provision_17  0.002
    L_17      loan_17   -1
    L_17      loan_18   0.98999999999999999
    L_17      balance_17  1
    L_17      ii_18     0.0042966099999999993
    L_17      bb_18     0.00016666666666666666
    L_17      rwa_17    -0.34999999999999998
    L_17      in_17     0.0050000000000000001
    L_17      rsf_17    0.65000000000000002
    L_17      lev_min_17  -0.032500000000000001
    L_17      lev_buf_17  -0.037499999999999999
    L_18      stage2_19  0.0050000000000000001
    L_18      stage3_19  5.0000000000000002e-05
    L_18      provision_18  0.002
    L_18      loan_18   -1
    L_18      loan_19   0.98999999999999999
    L_18      balance_18  1
    L_18      ii_19     0.004289548333333333
    L_18      bb_19     0.00016666666666666666
    L_18      rwa_18    -0.34999999999999998
    L_18      in_18     0.0050000000000000001
    L_18      rsf_18    0.65000000000000002
    L_18      lev_min_18  -0.032500000000000001
    L_18      lev_buf_18  -0.037499999999999999
    L_19      stage2_20  0.0050000000000000001
    L_19      stage3_20  5.0000000000000002e-05
    L_19      provision_19  0.002
    L_19      loan_19   -1
    L_19      loan_20   0.98999999999999999
    L_19      balance_19  1
    L_19      ii_20     0.0042824858333333328
    L_19      bb_20     0.00016666666666666666
    L_19      rwa_19    -0.34999999999999998
    L_19      in_19     0.0050000000000000001
    L_19      rsf_19    0.65000000000000002
    L_19      lev_min_19  -0.032500000000000001
    L_19      lev_buf_19  -0.037499999999999999
    L_20      stage2_21  0.0050000000000000001
    L_20      stage3_21  5.0000000000000002e-05
    L_20      provision_20  0.002
    L_20      loan_20   -1
    L_20      loan_21   0.98999999999999999
    L_20      balance_20  1
    L_20      ii_21     0.0042754233333333327
    L_20      bb_21     0.00016666666666666666
    L_20      rwa_20    -0.34999999999999998
    L_20      in_20     0.0050000000000000001
    L_20      rsf_20    0.65000000000000002
    L_20      lev_min_20  -0.032500000000000001
    L_20      lev_buf_20  -0.037499999999999999
    L_21      stage2_22  0.0050000000000000001
    L_21      stage3_22  5.0000000000000002e-05
    L_21      provision_21  0.002
    L_21      loan_21   -1
    L_21      loan_22   0.98999999999999999
    L_21      balance_21  1
    L_21      ii_22     0.0042683616666666663
    L_21      bb_22     0.00016666666666666666
    L_21      rwa_21    -0.34999999999999998
    L_21      in_21     0.0050000000000000001
    L_21      rsf_21    0.65000000000000002
    L_21      lev_min_21  -0.032500000000000001
    L_21      lev_buf_21  -0.037499999999999999
    L_22      stage2_23  0.0050000000000000001
    L_22      stage3_23  5.0000000000000002e-05
    L_22      provision_22  0.002
    L_22      loan_22   -1
    L_22      loan_23   0.98999999999999999
    L_22      balance_22  1
    L_22      ii_23     0.0042612991666666662
    L_22      bb_23     0.00016666666666666666
    L_22      rwa_22    -0.34999999999999998
    L_22      in_22     0.0050000000000000001
    L_22      rsf_22    0.65000000000000002
    L_22      lev_min_22  -0.032500000000000001
    L_22      lev_buf_22  -0.037499999999999999
    L_23      stage2_24  0.0050000000000000001
    L_23      stage3_24  5.0000000000000002e-05
    L_23      provision_23  0.002
    L_23      loan_23   -1
    L_23      loan_24   0.98999999999999999
    L_23      balance_23  1
    L_23      ii_24     0.004254237499999999
    L_23      bb_24     0.00016666666666666666
    L_23      rwa_23    -0.34999999999999998
    L_23      in_23     0.0050000000000000001
    L_23      rsf_23    0.65000000000000002
    L_23      lev_min_23  -0.032500000000000001
    L_23      lev_buf_23  -0.037499999999999999
    L_24      stage2_25  0.0050000000000000001
    L_24      stage3_25  5.0000000000000002e-05
    L_24      provision_24  0.002
    L_24      loan_24   -1
    L_24      loan_25   0.98999999999999999
    L_24      balance_24  1
    L_24      ii_25     0.0042471749999999997
    L_24      bb_25     0.00016666666666666666
    L_24      rwa_24    -0.34999999999999998
    L_24      in_24     0.0050000000000000001
    L_24      rsf_24    0.65000000000000002
    L_24      lev_min_24  -0.032500000000000001
    L_24      lev_buf_24  -0.037499999999999999
    L_25      stage2_26  0.0050000000000000001
    L_25      stage3_26  5.0000000000000002e-05
    L_25      provision_25  0.002
    L_25      loan_25   -1
    L_25      loan_26   0.98999999999999999
    L_25      balance_25  1
    L_25      ii_26     0.0042401133333333334
    L_25      bb_26     0.00016666666666666666
    L_25      rwa_25    -0.34999999999999998
    L_25      in_25     0.0050000000000000001
    L_25      rsf_25    0.65000000000000002
    L_25      lev_min_25  -0.032500000000000001
    L_25      lev_buf_25  -0.037499999999999999
    L_26      stage2_27  0.0050000000000000001
    L_26      stage3_27  5.0000000000000002e-05
    L_26      provision_26  0.002
    L_26      loan_26   -1
    L_26      loan_27   0.98999999999999999
    L_26      balance_26  1
    L_26      ii_27     0.0042330508333333332
    L_26      bb_27     0.00016666666666666666
    L_26      rwa_26    -0.34999999999999998
    L_26      in_26     0.0050000000000000001
    L_26      rsf_26    0.65000000000000002
    L_26      lev_min_26  -0.032500000000000001
    L_26      lev_buf_26  -0.037499999999999999
    L_27      stage2_28  0.0050000000000000001
    L_27      stage3_28  5.0000000000000002e-05
    L_27      provision_27  0.002
    L_27      loan_27   -1
    L_27      loan_28   0.98999999999999999
    L_27      balance_27  1
    L_27      ii_28     0.0042259883333333331
    L_27      bb_28     0.00016666666666666666
    L_27      rwa_27    -0.34999999999999998
    L_27      in_27     0.0050000000000000001
    L_27      rsf_27    0.65000000000000002
    L_27      lev_min_27  -0.032500000000000001
    L_27      lev_buf_27  -0.037499999999999999
    L_28      stage2_29  0.0050000000000000001
    L_28      stage3_29  5.0000000000000002e-05
    L_28      provision_28  0.002
    L_28      loan_28   -1
    L_28      loan_29   0.98999999999999999
    L_28      balance_28  1
    L_28      ii_29     0.0042189266666666659
    L_28      bb_29     0.00016666666666666666
    L_28      rwa_28    -0.34999999999999998
    L_28      in_28     0.0050000000000000001
    L_28      rsf_28    0.65000000000000002
    L_28      lev_min_28  -0.032500000000000001
    L_28      lev_buf_28  -0.037499999999999999
    L_29      stage2_30  0.0050000000000000001
    L_29      stage3_30  5.0000000000000002e-05
    L_29      provision_29  0.002
    L_29      loan_29   -1
    L_29      loan_30   0.98999999999999999
    L_29      balance_29  1
    L_29      ii_30     0.0042118641666666658
    L_29      bb_30     0.00016666666666666666
    L_29      rwa_29    -0.34999999999999998
    L_29      in_29     0.0050000000000000001
    L_29      rsf_29    0.65000000000000002
    L_29      lev_min_29  -0.032500000000000001
    L_29      lev_buf_29  -0.037499999999999999
    L_30      stage2_31  0.0050000000000000001
    L_30      stage3_31  5.0000000000000002e-05
    L_30      provision_30  0.002
    L_30      loan_30   -1
    L_30      loan_31   0.98999999999999999
    L_30      balance_30  1
    L_30      ii_31     0.0042048024999999994
    L_30      bb_31     0.00016666666666666666
    L_30      rwa_30    -0.34999999999999998
    L_30      in_30     0.0050000000000000001
    L_30      rsf_30    0.65000000000000002
    L_30      lev_min_30  -0.032500000000000001
    L_30      lev_buf_30  -0.037499999999999999
    L_31      stage2_32  0.0050000000000000001
    L_31      stage3_32  5.0000000000000002e-05
    L_31      provision_31  0.002
    L_31      loan_31   -1
    L_31      loan_32   0.98999999999999999
    L_31      balance_31  1
    L_31      ii_32     0.0041977399999999993
    L_31      bb_32     0.00016666666666666666
    L_31      rwa_31    -0.34999999999999998
    L_31      in_31     0.0050000000000000001
    L_31      rsf_31    0.65000000000000002
    L_31      lev_min_31  -0.032500000000000001
    L_31      lev_buf_31  -0.037499999999999999
    L_32      stage2_33  0.0050000000000000001
    L_32      stage3_33  5.0000000000000002e-05
    L_32      provision_32  0.002
    L_32      loan_32   -1
    L_32      loan_33   0.98999999999999999
    L_32      balance_32  1
    L_32      ii_33     0.0041906783333333329
    L_32      bb_33     0.00016666666666666666
    L_32      rwa_32    -0.34999999999999998
    L_32      in_32     0.0050000000000000001
    L_32      rsf_32    0.65000000000000002
    L_32      lev_min_32  -0.032500000000000001
    L_32      lev_buf_32  -0.037499999999999999
    L_33      stage2_34  0.0050000000000000001
    L_33      stage3_34  5.0000000000000002e-05
    L_33      provision_33  0.002
    L_33      loan_33   -1
    L_33      loan_34   0.98999999999999999
    L_33      balance_33  1
    L_33      ii_34     0.0041836158333333328
    L_33      bb_34     0.00016666666666666666
    L_33      rwa_33    -0.34999999999999998
    L_33      in_33     0.0050000000000000001
    L_33      rsf_33    0.65000000000000002
    L_33      lev_min_33  -0.032500000000000001
    L_33      lev_buf_33  -0.037499999999999999
    L_34      stage2_35  0.0050000000000000001
    L_34      stage3_35  5.0000000000000002e-05
    L_34      provision_34  0.002
    L_34      loan_34   -1
    L_34      loan_35   0.98999999999999999
    L_34      balance_34  1
    L_34      ii_35     0.0041765533333333327
    L_34      bb_35     0.00016666666666666666
    L_34      rwa_34    -0.34999999999999998
    L_34      in_34     0.0050000000000000001
    L_34      rsf_34    0.65000000000000002
    L_34      lev_min_34  -0.032500000000000001
    L_34      lev_buf_34  -0.037499999999999999
    L_35      stage2_36  0.0050000000000000001
    L_35      stage3_36  5.0000000000000002e-05
    L_35      provision_35  0.002
    L_35      loan_35   -1
    L_35      loan_36   0.98999999999999999
    L_35      balance_35  1
    L_35      ii_36     0.0041694916666666663
    L_35      bb_36     0.00016666666666666666
    L_35      rwa_35    -0.34999999999999998
    L_35      in_35     0.0050000000000000001
    L_35      rsf_35    0.65000000000000002
    L_35      lev_min_35  -0.032500000000000001
    L_35      lev_buf_35  -0.037499999999999999
    L_36      stage2_37  0.0050000000000000001
    L_36      stage3_37  5.0000000000000002e-05
    L_36      provision_36  0.002
    L_36      loan_36   -1
    L_36      loan_37   0.98999999999999999
    L_36      balance_36  1
    L_36      ii_37     0.0041624291666666662
    L_36      bb_37     0.00016666666666666666
    L_36      rwa_36    -0.34999999999999998
    L_36      in_36     0.0050000000000000001
    L_36      rsf_36    0.65000000000000002
    L_36      lev_min_36  -0.032500000000000001
    L_36      lev_buf_36  -0.037499999999999999
    L_37      stage2_38  0.0050000000000000001
    L_37      stage3_38  5.0000000000000002e-05
    L_37      provision_37  0.002
    L_37      loan_37   -1
    L_37      loan_38   0.98999999999999999
    L_37      balance_37  1
    L_37      ii_38     0.0041553674999999998
    L_37      bb_38     0.00016666666666666666
    L_37      rwa_37    -0.34999999999999998
    L_37      in_37     0.0050000000000000001
    L_37      rsf_37    0.65000000000000002
    L_37      lev_min_37  -0.032500000000000001
    L_37      lev_buf_37  -0.037499999999999999
    L_38      stage2_39  0.0050000000000000001
    L_38      stage3_39  5.0000000000000002e-05
    L_38      provision_38  0.002
    L_38      loan_38   -1
    L_38      loan_39   0.98999999999999999
    L_38      balance_38  1
    L_38      ii_39     0.0041483049999999997
    L_38      bb_39     0.00016666666666666666
    L_38      rwa_38    -0.34999999999999998
    L_38      in_38     0.0050000000000000001
    L_38      rsf_38    0.65000000000000002
    L_38      lev_min_38  -0.032500000000000001
    L_38      lev_buf_38  -0.037499999999999999
    L_39      stage2_40  0.0050000000000000001
    L_39      stage3_40  5.0000000000000002e-05
    L_39      provision_39  0.002
    L_39      loan_39   -1
    L_39      loan_40   0.98999999999999999
    L_39      balance_39  1
    L_39      ii_40     0.0041412433333333325
    L_39      bb_40     0.00016666666666666666
    L_39      rwa_39    -0.34999999999999998
    L_39      in_39     0.0050000000000000001
    L_39      rsf_39    0.65000000000000002
    L_39      lev_min_39  -0.032500000000000001
    L_39      lev_buf_39  -0.037499999999999999
    L_40      stage2_41  0.0050000000000000001
    L_40      stage3_41  5.0000000000000002e-05
    L_40      provision_40  0.002
    L_40      loan_40   -1
    L_40      loan_41   0.98999999999999999
    L_40      balance_40  1
    L_40      ii_41     0.0041341808333333323
    L_40      bb_41     0.00016666666666666666
    L_40      rwa_40    -0.34999999999999998
    L_40      in_40     0.0050000000000000001
    L_40      rsf_40    0.65000000000000002
    L_40      lev_min_40  -0.032500000000000001
    L_40      lev_buf_40  -0.037499999999999999
    L_41      stage2_42  0.0050000000000000001
    L_41      stage3_42  5.0000000000000002e-05
    L_41      provision_41  0.002
    L_41      loan_41   -1
    L_41      loan_42   0.98999999999999999
    L_41      balance_41  1
    L_41      ii_42     0.0041271183333333331
    L_41      bb_42     0.00016666666666666666
    L_41      rwa_41    -0.34999999999999998
    L_41      in_41     0.0050000000000000001
    L_41      rsf_41    0.65000000000000002
    L_41      lev_min_41  -0.032500000000000001
    L_41      lev_buf_41  -0.037499999999999999
    L_42      stage2_43  0.0050000000000000001
    L_42      stage3_43  5.0000000000000002e-05
    L_42      provision_42  0.002
    L_42      loan_42   -1
    L_42      loan_43   0.98999999999999999
    L_42      balance_42  1
    L_42      ii_43     0.0041200566666666667
    L_42      bb_43     0.00016666666666666666
    L_42      rwa_42    -0.34999999999999998
    L_42      in_42     0.0050000000000000001
    L_42      rsf_42    0.65000000000000002
    L_42      lev_min_42  -0.032500000000000001
    L_42      lev_buf_42  -0.037499999999999999
    L_43      stage2_44  0.0050000000000000001
    L_43      stage3_44  5.0000000000000002e-05
    L_43      provision_43  0.002
    L_43      loan_43   -1
    L_43      loan_44   0.98999999999999999
    L_43      balance_43  1
    L_43      ii_44     0.0041129941666666666
    L_43      bb_44     0.00016666666666666666
    L_43      rwa_43    -0.34999999999999998
    L_43      in_43     0.0050000000000000001
    L_43      rsf_43    0.65000000000000002
    L_43      lev_min_43  -0.032500000000000001
    L_43      lev_buf_43  -0.037499999999999999
    L_44      stage2_45  0.0050000000000000001
    L_44      stage3_45  5.0000000000000002e-05
    L_44      provision_44  0.002
    L_44      loan_44   -1
    L_44      loan_45   0.98999999999999999
    L_44      balance_44  1
    L_44      ii_45     0.0041059324999999994
    L_44      bb_45     0.00016666666666666666
    L_44      rwa_44    -0.34999999999999998
    L_44      in_44     0.0050000000000000001
    L_44      rsf_44    0.65000000000000002
    L_44      lev_min_44  -0.032500000000000001
    L_44      lev_buf_44  -0.037499999999999999
    L_45      stage2_46  0.0050000000000000001
    L_45      stage3_46  5.0000000000000002e-05
    L_45      provision_45  0.002
    L_45      loan_45   -1
    L_45      loan_46   0.98999999999999999
    L_45      balance_45  1
    L_45      ii_46     0.0040988699999999993
    L_45      bb_46     0.00016666666666666666
    L_45      rwa_45    -0.34999999999999998
    L_45      in_45     0.0050000000000000001
    L_45      rsf_45    0.65000000000000002
    L_45      lev_min_45  -0.032500000000000001
    L_45      lev_buf_45  -0.037499999999999999
    L_46      stage2_47  0.0050000000000000001
    L_46      stage3_47  5.0000000000000002e-05
    L_46      provision_46  0.002
    L_46      loan_46   -1
    L_46      loan_47   0.98999999999999999
    L_46      balance_46  1
    L_46      ii_47     0.0040918074999999991
    L_46      bb_47     0.00016666666666666666
    L_46      rwa_46    -0.34999999999999998
    L_46      in_46     0.0050000000000000001
    L_46      rsf_46    0.65000000000000002
    L_46      lev_min_46  -0.032500000000000001
    L_46      lev_buf_46  -0.037499999999999999
    L_47      stage2_48  0.0050000000000000001
    L_47      stage3_48  5.0000000000000002e-05
    L_47      provision_47  0.002
    L_47      loan_47   -1
    L_47      loan_48   0.98999999999999999
    L_47      balance_47  1
    L_47      ii_48     0.0040847458333333328
    L_47      bb_48     0.00016666666666666666
    L_47      rwa_47    -0.34999999999999998
    L_47      in_47     0.0050000000000000001
    L_47      rsf_47    0.65000000000000002
    L_47      lev_min_47  -0.032500000000000001
    L_47      lev_buf_47  -0.037499999999999999
    L_48      stage2_49  0.0050000000000000001
    L_48      stage3_49  5.0000000000000002e-05
    L_48      provision_48  0.002
    L_48      loan_48   -1
    L_48      loan_49   0.98999999999999999
    L_48      balance_48  1
    L_48      ii_49     0.0040776833333333326
    L_48      bb_49     0.00016666666666666666
    L_48      rwa_48    -0.34999999999999998
    L_48      in_48     0.0050000000000000001
    L_48      rsf_48    0.65000000000000002
    L_48      lev_min_48  -0.032500000000000001
    L_48      lev_buf_48  -0.037499999999999999
    L_49      stage2_50  0.0050000000000000001
    L_49      stage3_50  5.0000000000000002e-05
    L_49      provision_49  0.002
    L_49      loan_49   -1
    L_49      loan_50   0.98999999999999999
    L_49      balance_49  1
    L_49      ii_50     0.0040706216666666663
    L_49      bb_50     0.00016666666666666666
    L_49      rwa_49    -0.34999999999999998
    L_49      in_49     0.0050000000000000001
    L_49      rsf_49    0.65000000000000002
    L_49      lev_min_49  -0.032500000000000001
    L_49      lev_buf_49  -0.037499999999999999
    L_50      stage2_51  0.0050000000000000001
    L_50      stage3_51  5.0000000000000002e-05
    L_50      provision_50  0.002
    L_50      loan_50   -1
    L_50      loan_51   0.98999999999999999
    L_50      balance_50  1
    L_50      ii_51     0.0040635591666666662
    L_50      bb_51     0.00016666666666666666
    L_50      rwa_50    -0.34999999999999998
    L_50      in_50     0.0050000000000000001
    L_50      rsf_50    0.65000000000000002
    L_50      lev_min_50  -0.032500000000000001
    L_50      lev_buf_50  -0.037499999999999999
    L_51      stage2_52  0.0050000000000000001
    L_51      stage3_52  5.0000000000000002e-05
    L_51      provision_51  0.002
    L_51      loan_51   -1
    L_51      loan_52   0.98999999999999999
    L_51      balance_51  1
    L_51      ii_52     0.0040564974999999998
    L_51      bb_52     0.00016666666666666666
    L_51      rwa_51    -0.34999999999999998
    L_51      in_51     0.0050000000000000001
    L_51      rsf_51    0.65000000000000002
    L_51      lev_min_51  -0.032500000000000001
    L_51      lev_buf_51  -0.037499999999999999
    L_52      stage2_53  0.0050000000000000001
    L_52      stage3_53  5.0000000000000002e-05
    L_52      provision_52  0.002
    L_52      loan_52   -1
    L_52      loan_53   0.98999999999999999
    L_52      balance_52  1
    L_52      ii_53     0.0040494349999999997
    L_52      bb_53     0.00016666666666666666
    L_52      rwa_52    -0.34999999999999998
    L_52      in_52     0.0050000000000000001
    L_52      rsf_52    0.65000000000000002
    L_52      lev_min_52  -0.032500000000000001
    L_52      lev_buf_52  -0.037499999999999999
    L_53      stage2_54  0.0050000000000000001
    L_53      stage3_54  5.0000000000000002e-05
    L_53      provision_53  0.002
    L_53      loan_53   -1
    L_53      loan_54   0.98999999999999999
    L_53      balance_53  1
    L_53      ii_54     0.0040423724999999995
    L_53      bb_54     0.00016666666666666666
    L_53      rwa_53    -0.34999999999999998
    L_53      in_53     0.0050000000000000001
    L_53      rsf_53    0.65000000000000002
    L_53      lev_min_53  -0.032500000000000001
    L_53      lev_buf_53  -0.037499999999999999
    L_54      stage2_55  0.0050000000000000001
    L_54      stage3_55  5.0000000000000002e-05
    L_54      provision_54  0.002
    L_54      loan_54   -1
    L_54      loan_55   0.98999999999999999
    L_54      balance_54  1
    L_54      ii_55     0.0040353108333333332
    L_54      bb_55     0.00016666666666666666
    L_54      rwa_54    -0.34999999999999998
    L_54      in_54     0.0050000000000000001
    L_54      rsf_54    0.65000000000000002
    L_54      lev_min_54  -0.032500000000000001
    L_54      lev_buf_54  -0.037499999999999999
    L_55      stage2_56  0.0050000000000000001
    L_55      stage3_56  5.0000000000000002e-05
    L_55      provision_55  0.002
    L_55      loan_55   -1
    L_55      loan_56   0.98999999999999999
    L_55      balance_55  1
    L_55      ii_56     0.0040282483333333331
    L_55      bb_56     0.00016666666666666666
    L_55      rwa_55    -0.34999999999999998
    L_55      in_55     0.0050000000000000001
    L_55      rsf_55    0.65000000000000002
    L_55      lev_min_55  -0.032500000000000001
    L_55      lev_buf_55  -0.037499999999999999
    L_56      stage2_57  0.0050000000000000001
    L_56      stage3_57  5.0000000000000002e-05
    L_56      provision_56  0.002
    L_56      loan_56   -1
    L_56      loan_57   0.98999999999999999
    L_56      balance_56  1
    L_56      ii_57     0.0040211866666666658
    L_56      bb_57     0.00016666666666666666
    L_56      rwa_56    -0.34999999999999998
    L_56      in_56     0.0050000000000000001
    L_56      rsf_56    0.65000000000000002
    L_56      lev_min_56  -0.032500000000000001
    L_56      lev_buf_56  -0.037499999999999999
    L_57      stage2_58  0.0050000000000000001
    L_57      stage3_58  5.0000000000000002e-05
    L_57      provision_57  0.002
    L_57      loan_57   -1
    L_57      loan_58   0.98999999999999999
    L_57      balance_57  1
    L_57      ii_58     0.0040141241666666657
    L_57      bb_58     0.00016666666666666666
    L_57      rwa_57    -0.34999999999999998
    L_57      in_57     0.0050000000000000001
    L_57      rsf_57    0.65000000000000002
    L_57      lev_min_57  -0.032500000000000001
    L_57      lev_buf_57  -0.037499999999999999
    L_58      stage2_59  0.0050000000000000001
    L_58      stage3_59  5.0000000000000002e-05
    L_58      provision_58  0.002
    L_58      loan_58   -1
    L_58      loan_59   0.98999999999999999
    L_58      balance_58  1
    L_58      ii_59     0.0040070624999999993
    L_58      bb_59     0.00016666666666666666
    L_58      rwa_58    -0.34999999999999998
    L_58      in_58     0.0050000000000000001
    L_58      rsf_58    0.65000000000000002
    L_58      lev_min_58  -0.032500000000000001
    L_58      lev_buf_58  -0.037499999999999999
    L_59      stage2_60  0.0050000000000000001
    L_59      stage3_60  5.0000000000000002e-05
    L_59      provision_59  0.002
    L_59      loan_59   -1
    L_59      loan_60   0.98999999999999999
    L_59      balance_59  1
    L_59      ii_60     0.0040000000000000001
    L_59      bb_60     0.00016666666666666666
    L_59      rwa_59    -0.34999999999999998
    L_59      in_59     0.0050000000000000001
    L_59      rsf_59    0.65000000000000002
    L_59      lev_min_59  -0.032500000000000001
    L_59      lev_buf_59  -0.037499999999999999
    L_60      Obj       0.0040000000000000001
    L_60      provision_60  0.002
    L_60      loan_60   -1
    L_60      balance_60  1
    L_60      rwa_60    -0.34999999999999998
    L_60      in_60     0.0050000000000000001
    L_60      rsf_60    0.65000000000000002
    L_60      lev_min_60  -0.032500000000000001
    L_60      lev_buf_60  -0.037499999999999999
    L_60      end_loans  1
    T_1       term_1    1
    T_1       term_2    1
    T_1       balance_1  -1
    T_1       asf_1     0.90000000000000002
    T_2       term_2    -1
    T_2       term_3    1
    T_2       balance_2  -1
    T_2       asf_2     0.90000000000000002
    T_3       term_3    -1
    T_3       term_4    1
    T_3       balance_3  -1
    T_3       asf_3     0.90000000000000002
    T_4       term_4    -1
    T_4       term_5    1
    T_4       balance_4  -1
    T_4       asf_4     0.90000000000000002
    T_5       term_5    -1
    T_5       term_6    1
    T_5       balance_5  -1
    T_5       asf_5     0.90000000000000002
    T_6       term_6    -1
    T_6       term_7    1
    T_6       balance_6  -1
    T_6       asf_6     0.90000000000000002
    T_7       term_7    -1
    T_7       term_8    1
    T_7       balance_7  -1
    T_7       asf_7     0.90000000000000002
    T_8       term_8    -1
    T_8       term_9    1
    T_8       balance_8  -1
    T_8       asf_8     0.90000000000000002
    T_9       term_9    -1
    T_9       term_10   1
    T_9       balance_9  -1
    T_9       asf_9     0.90000000000000002
    T_10      term_10   -1
    T_10      term_11   1
    T_10      balance_10  -1
    T_10      asf_10    0.90000000000000002
    T_11      term_11   -1
    T_11      term_12   1
    T_11      balance_11  -1
    T_11      asf_11    0.90000000000000002
    T_12      term_12   -1
    T_12      term_13   1
    T_12      balance_12  -1
    T_12      asf_12    0.90000000000000002
    T_13      term_13   -1
    T_13      term_14   1
    T_13      balance_13  -1
    T_13      asf_13    0.90000000000000002
    T_14      term_14   -1
    T_14      term_15   1
    T_14      balance_14  -1
    T_14      asf_14    0.90000000000000002
    T_15      term_15   -1
    T_15      term_16   1
    T_15      balance_15  -1
    T_15      asf_15    0.90000000000000002
    T_16      term_16   -1
    T_16      term_17   1
    T_16      balance_16  -1
    T_16      asf_16    0.90000000000000002
    T_17      term_17   -1
    T_17      term_18   1
    T_17      balance_17  -1
    T_17      asf_17    0.90000000000000002
    T_18      term_18   -1
    T_18      term_19   1
    T_18      balance_18  -1
    T_18      asf_18    0.90000000000000002
    T_19      term_19   -1
    T_19      term_20   1
    T_19      balance_19  -1
    T_19      asf_19    0.90000000000000002
    T_20      term_20   -1
    T_20      term_21   1
    T_20      balance_20  -1
    T_20      asf_20    0.90000000000000002
    T_21      term_21   -1
    T_21      term_22   1
    T_21      balance_21  -1
    T_21      asf_21    0.90000000000000002
    T_22      term_22   -1
    T_22      term_23   1
    T_22      balance_22  -1
    T_22      asf_22    0.90000000000000002
    T_23      term_23   -1
    T_23      term_24   1
    T_23      balance_23  -1
    T_23      asf_23    0.90000000000000002
    T_24      term_24   -1
    T_24      term_25   1
    T_24      balance_24  -1
    T_24      asf_24    0.90000000000000002
    T_25      term_25   -1
    T_25      term_26   1
    T_25      balance_25  -1
    T_25      asf_25    0.90000000000000002
    T_26      term_26   -1
    T_26      term_27   1
    T_26      balance_26  -1
    T_26      asf_26    0.90000000000000002
    T_27      term_27   -1
    T_27      term_28   1
    T_27      balance_27  -1
    T_27      asf_27    0.90000000000000002
    T_28      term_28   -1
    T_28      term_29   1
    T_28      balance_28  -1
    T_28      asf_28    0.90000000000000002
    T_29      term_29   -1
    T_29      term_30   1
    T_29      balance_29  -1
    T_29      asf_29    0.90000000000000002
    T_30      term_30   -1
    T_30      term_31   1
    T_30      balance_30  -1
    T_30      asf_30    0.90000000000000002
    T_31      term_31   -1
    T_31      term_32   1
    T_31      balance_31  -1
    T_31      asf_31    0.90000000000000002
    T_32      term_32   -1
    T_32      term_33   1
    T_32      balance_32  -1
    T_32      asf_32    0.90000000000000002
    T_33      term_33   -1
    T_33      term_34   1
    T_33      balance_33  -1
    T_33      asf_33    0.90000000000000002
    T_34      term_34   -1
    T_34      term_35   1
    T_34      balance_34  -1
    T_34      asf_34    0.90000000000000002
    T_35      term_35   -1
    T_35      term_36   1
    T_35      balance_35  -1
    T_35      asf_35    0.90000000000000002
    T_36      term_36   -1
    T_36      term_37   1
    T_36      balance_36  -1
    T_36      asf_36    0.90000000000000002
    T_37      term_37   -1
    T_37      term_38   1
    T_37      balance_37  -1
    T_37      asf_37    0.90000000000000002
    T_38      term_38   -1
    T_38      term_39   1
    T_38      balance_38  -1
    T_38      asf_38    0.90000000000000002
    T_39      term_39   -1
    T_39      term_40   1
    T_39      balance_39  -1
    T_39      asf_39    0.90000000000000002
    T_40      term_40   -1
    T_40      term_41   1
    T_40      balance_40  -1
    T_40      asf_40    0.90000000000000002
    T_41      term_41   -1
    T_41      term_42   1
    T_41      balance_41  -1
    T_41      asf_41    0.90000000000000002
    T_42      term_42   -1
    T_42      term_43   1
    T_42      balance_42  -1
    T_42      asf_42    0.90000000000000002
    T_43      term_43   -1
    T_43      term_44   1
    T_43      balance_43  -1
    T_43      asf_43    0.90000000000000002
    T_44      term_44   -1
    T_44      term_45   1
    T_44      balance_44  -1
    T_44      asf_44    0.90000000000000002
    T_45      term_45   -1
    T_45      term_46   1
    T_45      balance_45  -1
    T_45      asf_45    0.90000000000000002
    T_46      term_46   -1
    T_46      term_47   1
    T_46      balance_46  -1
    T_46      asf_46    0.90000000000000002
    T_47      term_47   -1
    T_47      term_48   1
    T_47      balance_47  -1
    T_47      asf_47    0.90000000000000002
    T_48      term_48   -1
    T_48      term_49   1
    T_48      balance_48  -1
    T_48      asf_48    0.90000000000000002
    T_49      term_49   -1
    T_49      term_50   1
    T_49      balance_49  -1
    T_49      asf_49    0.90000000000000002
    T_50      term_50   -1
    T_50      term_51   1
    T_50      balance_50  -1
    T_50      asf_50    0.90000000000000002
    T_51      term_51   -1
    T_51      term_52   1
    T_51      balance_51  -1
    T_51      asf_51    0.90000000000000002
    T_52      term_52   -1
    T_52      term_53   1
    T_52      balance_52  -1
    T_52      asf_52    0.90000000000000002
    T_53      term_53   -1
    T_53      term_54   1
    T_53      balance_53  -1
    T_53      asf_53    0.90000000000000002
    T_54      term_54   -1
    T_54      term_55   1
    T_54      balance_54  -1
    T_54      asf_54    0.90000000000000002
    T_55      term_55   -1
    T_55      term_56   1
    T_55      balance_55  -1
    T_55      asf_55    0.90000000000000002
    T_56      term_56   -1
    T_56      term_57   1
    T_56      balance_56  -1
    T_56      asf_56    0.90000000000000002
    T_57      term_57   -1
    T_57      term_58   1
    T_57      balance_57  -1
    T_57      asf_57    0.90000000000000002
    T_58      term_58   -1
    T_58      term_59   1
    T_58      balance_58  -1
    T_58      asf_58    0.90000000000000002
    T_59      term_59   -1
    T_59      term_60   1
    T_59      balance_59  -1
    T_59      asf_59    0.90000000000000002
    T_60      term_60   -1
    T_60      balance_60  -1
    T_60      asf_60    0.90000000000000002
    W_1       whole_1   1
    W_1       whole_2   1
    W_1       balance_1  -1
    W_1       ie_2      0.0035762708333333332
    W_2       whole_2   -1
    W_2       whole_3   1
    W_2       balance_2  -1
    W_2       ie_3      0.0035692091666666668
    W_3       whole_3   -1
    W_3       whole_4   1
    W_3       balance_3  -1
    W_3       ie_4      0.0035621466666666667
    W_4       whole_4   -1
    W_4       whole_5   1
    W_4       balance_4  -1
    W_4       ie_5      0.0035550849999999999
    W_5       whole_5   -1
    W_5       whole_6   1
    W_5       balance_5  -1
    W_5       ie_6      0.0035480224999999998
    W_6       whole_6   -1
    W_6       whole_7   1
    W_6       balance_6  -1
    W_6       ie_7      0.003540960833333333
    W_7       whole_7   -1
    W_7       whole_8   1
    W_7       balance_7  -1
    W_7       ie_8      0.0035338983333333329
    W_8       whole_8   -1
    W_8       whole_9   1
    W_8       balance_8  -1
    W_8       ie_9      0.0035268358333333328
    W_9       whole_9   -1
    W_9       whole_10  1
    W_9       balance_9  -1
    W_9       ie_10     0.0035197741666666664
    W_10      whole_10  -1
    W_10      whole_11  1
    W_10      balance_10  -1
    W_10      ie_11     0.0035127116666666667
    W_11      whole_11  -1
    W_11      whole_12  1
    W_11      balance_11  -1
    W_11      ie_12     0.0035056499999999999
    W_12      whole_12  -1
    W_12      whole_13  1
    W_12      balance_12  -1
    W_12      ie_13     0.0034985874999999998
    W_13      whole_13  -1
    W_13      whole_14  1
    W_13      balance_13  -1
    W_13      ie_14     0.0034915258333333334
    W_14      whole_14  -1
    W_14      whole_15  1
    W_14      balance_14  -1
    W_14      ie_15     0.0034844633333333333
    W_15      whole_15  -1
    W_15      whole_16  1
    W_15      balance_15  -1
    W_15      ie_16     0.0034774008333333332
    W_16      whole_16  -1
    W_16      whole_17  1
    W_16      balance_16  -1
    W_16      ie_17     0.0034703391666666664
    W_17      whole_17  -1
    W_17      whole_18  1
    W_17      balance_17  -1
    W_17      ie_18     0.0034632766666666663
    W_18      whole_18  -1
    W_18      whole_19  1
    W_18      balance_18  -1
    W_18      ie_19     0.0034562149999999995
    W_19      whole_19  -1
    W_19      whole_20  1
    W_19      balance_19  -1
    W_19      ie_20     0.0034491525000000002
    W_20      whole_20  -1
    W_20      whole_21  1
    W_20      balance_20  -1
    W_20      ie_21     0.0034420900000000001
    W_21      whole_21  -1
    W_21      whole_22  1
    W_21      balance_21  -1
    W_21      ie_22     0.0034350283333333333
    W_22      whole_22  -1
    W_22      whole_23  1
    W_22      balance_22  -1
    W_22      ie_23     0.0034279658333333332
    W_23      whole_23  -1
    W_23      whole_24  1
    W_23      balance_23  -1
    W_23      ie_24     0.0034209041666666664
    W_24      whole_24  -1
    W_24      whole_25  1
    W_24      balance_24  -1
    W_24      ie_25     0.0034138416666666662
    W_25      whole_25  -1
    W_25      whole_26  1
    W_25      balance_25  -1
    W_25      ie_26     0.0034067799999999999
    W_26      whole_26  -1
    W_26      whole_27  1
    W_26      balance_26  -1
    W_26      ie_27     0.0033997174999999998
    W_27      whole_27  -1
    W_27      whole_28  1
    W_27      balance_27  -1
    W_27      ie_28     0.0033926550000000001
    W_28      whole_28  -1
    W_28      whole_29  1
    W_28      balance_28  -1
    W_28      ie_29     0.0033855933333333333
    W_29      whole_29  -1
    W_29      whole_30  1
    W_29      balance_29  -1
    W_29      ie_30     0.0033785308333333331
    W_30      whole_30  -1
    W_30      whole_31  1
    W_30      balance_30  -1
    W_30      ie_31     0.0033714691666666668
    W_31      whole_31  -1
    W_31      whole_32  1
    W_31      balance_31  -1
    W_31      ie_32     0.0033644066666666667
    W_32      whole_32  -1
    W_32      whole_33  1
    W_32      balance_32  -1
    W_32      ie_33     0.0033573449999999999
    W_33      whole_33  -1
    W_33      whole_34  1
    W_33      balance_33  -1
    W_33      ie_34     0.0033502824999999997
    W_34      whole_34  -1
    W_34      whole_35  1
    W_34      balance_34  -1
    W_34      ie_35     0.0033432199999999996
    W_35      whole_35  -1
    W_35      whole_36  1
    W_35      balance_35  -1
    W_35      ie_36     0.0033361583333333328
    W_36      whole_36  -1
    W_36      whole_37  1
    W_36      balance_36  -1
    W_36      ie_37     0.0033290958333333336
    W_37      whole_37  -1
    W_37      whole_38  1
    W_37      balance_37  -1
    W_37      ie_38     0.0033220341666666668
    W_38      whole_38  -1
    W_38      whole_39  1
    W_38      balance_38  -1
    W_38      ie_39     0.0033149716666666666
    W_39      whole_39  -1
    W_39      whole_40  1
    W_39      balance_39  -1
    W_39      ie_40     0.0033079099999999998
    W_40      whole_40  -1
    W_40      whole_41  1
    W_40      balance_40  -1
    W_40      ie_41     0.0033008474999999997
    W_41      whole_41  -1
    W_41      whole_42  1
    W_41      balance_41  -1
    W_41      ie_42     0.0032937849999999996
    W_42      whole_42  -1
    W_42      whole_43  1
    W_42      balance_42  -1
    W_42      ie_43     0.0032867233333333332
    W_43      whole_43  -1
    W_43      whole_44  1
    W_43      balance_43  -1
    W_43      ie_44     0.0032796608333333331
    W_44      whole_44  -1
    W_44      whole_45  1
    W_44      balance_44  -1
    W_44      ie_45     0.0032725991666666663
    W_45      whole_45  -1
    W_45      whole_46  1
    W_45      balance_45  -1
    W_45      ie_46     0.0032655366666666666
    W_46      whole_46  -1
    W_46      whole_47  1
    W_46      balance_46  -1
    W_46      ie_47     0.0032584741666666665
    W_47      whole_47  -1
    W_47      whole_48  1
    W_47      balance_47  -1
    W_47      ie_48     0.0032514125000000001
    W_48      whole_48  -1
    W_48      whole_49  1
    W_48      balance_48  -1
    W_48      ie_49     0.00324435
    W_49      whole_49  -1
    W_49      whole_50  1
    W_49      balance_49  -1
    W_49      ie_50     0.0032372883333333332
    W_50      whole_50  -1
    W_50      whole_51  1
    W_50      balance_50  -1
    W_50      ie_51     0.0032302258333333331
    W_51      whole_51  -1
    W_51      whole_52  1
    W_51      balance_51  -1
    W_51      ie_52     0.0032231641666666663
    W_52      whole_52  -1
    W_52      whole_53  1
    W_52      balance_52  -1
    W_52      ie_53     0.0032161016666666662
    W_53      whole_53  -1
    W_53      whole_54  1
    W_53      balance_53  -1
    W_53      ie_54     0.0032090391666666669
    W_54      whole_54  -1
    W_54      whole_55  1
    W_54      balance_54  -1
    W_54      ie_55     0.0032019775000000001
    W_55      whole_55  -1
    W_55      whole_56  1
    W_55      balance_55  -1
    W_55      ie_56     0.003194915
    W_56      whole_56  -1
    W_56      whole_57  1
    W_56      balance_56  -1
    W_56      ie_57     0.0031878533333333332
    W_57      whole_57  -1
    W_57      whole_58  1
    W_57      balance_57  -1
    W_57      ie_58     0.0031807908333333331
    W_58      whole_58  -1
    W_58      whole_59  1
    W_58      balance_58  -1
    W_58      ie_59     0.0031737291666666667
    W_59      whole_59  -1
    W_59      whole_60  1
    W_59      balance_59  -1
    W_59      ie_60     0.0031666666666666666
    W_60      Obj       -0.0031666666666666666
    W_60      whole_60  -1
    W_60      balance_60  -1
    K_1       capital_1  1
    K_1       capital_2  1
    K_1       balance_1  -1
    K_1       asf_1     1
    K_1       cap_min_1  1
    K_1       cap_buf_1  1
    K_1       lev_min_1  1
    K_1       lev_buf_1  1
    K_2       capital_2  -1
    K_2       capital_3  1
    K_2       balance_2  -1
    K_2       asf_2     1
    K_2       cap_min_2  1
    K_2       cap_buf_2  1
    K_2       lev_min_2  1
    K_2       lev_buf_2  1
    K_3       capital_3  -1
    K_3       capital_4  1
    K_3       balance_3  -1
    K_3       asf_3     1
    K_3       cap_min_3  1
    K_3       cap_buf_3  1
    K_3       lev_min_3  1
    K_3       lev_buf_3  1
    K_4       capital_4  -1
    K_4       capital_5  1
    K_4       balance_4  -1
    K_4       asf_4     1
    K_4       cap_min_4  1
    K_4       cap_buf_4  1
    K_4       lev_min_4  1
    K_4       lev_buf_4  1
    K_5       capital_5  -1
    K_5       capital_6  1
    K_5       balance_5  -1
    K_5       asf_5     1
    K_5       cap_min_5  1
    K_5       cap_buf_5  1
    K_5       lev_min_5  1
    K_5       lev_buf_5  1
    K_6       capital_6  -1
    K_6       capital_7  1
    K_6       balance_6  -1
    K_6       asf_6     1
    K_6       cap_min_6  1
    K_6       cap_buf_6  1
    K_6       lev_min_6  1
    K_6       lev_buf_6  1
    K_7       capital_7  -1
    K_7       capital_8  1
    K_7       balance_7  -1
    K_7       asf_7     1
    K_7       cap_min_7  1
    K_7       cap_buf_7  1
    K_7       lev_min_7  1
    K_7       lev_buf_7  1
    K_8       capital_8  -1
    K_8       capital_9  1
    K_8       balance_8  -1
    K_8       asf_8     1
    K_8       cap_min_8  1
    K_8       cap_buf_8  1
    K_8       lev_min_8  1
    K_8       lev_buf_8  1
    K_9       capital_9  -1
    K_9       capital_10  1
    K_9       balance_9  -1
    K_9       asf_9     1
    K_9       cap_min_9  1
    K_9       cap_buf_9  1
    K_9       lev_min_9  1
    K_9       lev_buf_9  1
    K_10      capital_10  -1
    K_10      capital_11  1
    K_10      balance_10  -1
    K_10      asf_10    1
    K_10      cap_min_10  1
    K_10      cap_buf_10  1
    K_10      lev_min_10  1
    K_10      lev_buf_10  1
    K_11      capital_11  -1
    K_11      capital_12  1
    K_11      balance_11  -1
    K_11      asf_11    1
    K_11      cap_min_11  1
    K_11      cap_buf_11  1
    K_11      lev_min_11  1
    K_11      lev_buf_11  1
    K_12      capital_12  -1
    K_12      capital_13  1
    K_12      balance_12  -1
    K_12      asf_12    1
    K_12      cap_min_12  1
    K_12      cap_buf_12  1
    K_12      lev_min_12  1
    K_12      lev_buf_12  1
    K_13      capital_13  -1
    K_13      capital_14  1
    K_13      balance_13  -1
    K_13      asf_13    1
    K_13      cap_min_13  1
    K_13      cap_buf_13  1
    K_13      lev_min_13  1
    K_13      lev_buf_13  1
    K_14      capital_14  -1
    K_14      capital_15  1
    K_14      balance_14  -1
    K_14      asf_14    1
    K_14      cap_min_14  1
    K_14      cap_buf_14  1
    K_14      lev_min_14  1
    K_14      lev_buf_14  1
    K_15      capital_15  -1
    K_15      capital_16  1
    K_15      balance_15  -1
    K_15      asf_15    1
    K_15      cap_min_15  1
    K_15      cap_buf_15  1
    K_15      lev_min_15  1
    K_15      lev_buf_15  1
    K_16      capital_16  -1
    K_16      capital_17  1
    K_16      balance_16  -1
    K_16      asf_16    1
    K_16      cap_min_16  1
    K_16      cap_buf_16  1
    K_16      lev_min_16  1
    K_16      lev_buf_16  1
    K_17      capital_17  -1
    K_17      capital_18  1
    K_17      balance_17  -1
    K_17      asf_17    1
    K_17      cap_min_17  1
    K_17      cap_buf_17  1
    K_17      lev_min_17  1
    K_17      lev_buf_17  1
    K_18      capital_18  -1
    K_18      capital_19  1
    K_18      balance_18  -1
    K_18      asf_18    1
    K_18      cap_min_18  1
    K_18      cap_buf_18  1
    K_18      lev_min_18  1
    K_18      lev_buf_18  1
    K_19      capital_19  -1
    K_19      capital_20  1
    K_19      balance_19  -1
    K_19      asf_19    1
    K_19      cap_min_19  1
    K_19      cap_buf_19  1
    K_19      lev_min_19  1
    K_19      lev_buf_19  1
    K_20      capital_20  -1
    K_20      capital_21  1
    K_20      balance_20  -1
    K_20      asf_20    1
    K_20      cap_min_20  1
    K_20      cap_buf_20  1
    K_20      lev_min_20  1
    K_20      lev_buf_20  1
    K_21      capital_21  -1
    K_21      capital_22  1
    K_21      balance_21  -1
    K_21      asf_21    1
    K_21      cap_min_21  1
    K_21      cap_buf_21  1
    K_21      lev_min_21  1
    K_21      lev_buf_21  1
    K_22      capital_22  -1
    K_22      capital_23  1
    K_22      balance_22  -1
    K_22      asf_22    1
    K_22      cap_min_22  1
    K_22      cap_buf_22  1
    K_22      lev_min_22  1
    K_22      lev_buf_22  1
    K_23      capital_23  -1
    K_23      capital_24  1
    K_23      balance_23  -1
    K_23      asf_23    1
    K_23      cap_min_23  1
    K_23      cap_buf_23  1
    K_23      lev_min_23  1
    K_23      lev_buf_23  1
    K_24      capital_24  -1
    K_24      capital_25  1
    K_24      balance_24  -1
    K_24      asf_24    1
    K_24      cap_min_24  1
    K_24      cap_buf_24  1
    K_24      lev_min_24  1
    K_24      lev_buf_24  1
    K_25      capital_25  -1
    K_25      capital_26  1
    K_25      balance_25  -1
    K_25      asf_25    1
    K_25      cap_min_25  1
    K_25      cap_buf_25  1
    K_25      lev_min_25  1
    K_25      lev_buf_25  1
    K_26      capital_26  -1
    K_26      capital_27  1
    K_26      balance_26  -1
    K_26      asf_26    1
    K_26      cap_min_26  1
    K_26      cap_buf_26  1
    K_26      lev_min_26  1
    K_26      lev_buf_26  1
    K_27      capital_27  -1
    K_27      capital_28  1
    K_27      balance_27  -1
    K_27      asf_27    1
    K_27      cap_min_27  1
    K_27      cap_buf_27  1
    K_27      lev_min_27  1
    K_27      lev_buf_27  1
    K_28      capital_28  -1
    K_28      capital_29  1
    K_28      balance_28  -1
    K_28      asf_28    1
    K_28      cap_min_28  1
    K_28      cap_buf_28  1
    K_28      lev_min_28  1
    K_28      lev_buf_28  1
    K_29      capital_29  -1
    K_29      capital_30  1
    K_29      balance_29  -1
    K_29      asf_29    1
    K_29      cap_min_29  1
    K_29      cap_buf_29  1
    K_29      lev_min_29  1
    K_29      lev_buf_29  1
    K_30      capital_30  -1
    K_30      capital_31  1
    K_30      balance_30  -1
    K_30      asf_30    1
    K_30      cap_min_30  1
    K_30      cap_buf_30  1
    K_30      lev_min_30  1
    K_30      lev_buf_30  1
    K_31      capital_31  -1
    K_31      capital_32  1
    K_31      balance_31  -1
    K_31      asf_31    1
    K_31      cap_min_31  1
    K_31      cap_buf_31  1
    K_31      lev_min_31  1
    K_31      lev_buf_31  1
    K_32      capital_32  -1
    K_32      capital_33  1
    K_32      balance_32  -1
    K_32      asf_32    1
    K_32      cap_min_32  1
    K_32      cap_buf_32  1
    K_32      lev_min_32  1
    K_32      lev_buf_32  1
    K_33      capital_33  -1
    K_33      capital_34  1
    K_33      balance_33  -1
    K_33      asf_33    1
    K_33      cap_min_33  1
    K_33      cap_buf_33  1
    K_33      lev_min_33  1
    K_33      lev_buf_33  1
    K_34      capital_34  -1
    K_34      capital_35  1
    K_34      balance_34  -1
    K_34      asf_34    1
    K_34      cap_min_34  1
    K_34      cap_buf_34  1
    K_34      lev_min_34  1
    K_34      lev_buf_34  1
    K_35      capital_35  -1
    K_35      capital_36  1
    K_35      balance_35  -1
    K_35      asf_35    1
    K_35      cap_min_35  1
    K_35      cap_buf_35  1
    K_35      lev_min_35  1
    K_35      lev_buf_35  1
    K_36      capital_36  -1
    K_36      capital_37  1
    K_36      balance_36  -1
    K_36      asf_36    1
    K_36      cap_min_36  1
    K_36      cap_buf_36  1
    K_36      lev_min_36  1
    K_36      lev_buf_36  1
    K_37      capital_37  -1
    K_37      capital_38  1
    K_37      balance_37  -1
    K_37      asf_37    1
    K_37      cap_min_37  1
    K_37      cap_buf_37  1
    K_37      lev_min_37  1
    K_37      lev_buf_37  1
    K_38      capital_38  -1
    K_38      capital_39  1
    K_38      balance_38  -1
    K_38      asf_38    1
    K_38      cap_min_38  1
    K_38      cap_buf_38  1
    K_38      lev_min_38  1
    K_38      lev_buf_38  1
    K_39      capital_39  -1
    K_39      capital_40  1
    K_39      balance_39  -1
    K_39      asf_39    1
    K_39      cap_min_39  1
    K_39      cap_buf_39  1
    K_39      lev_min_39  1
    K_39      lev_buf_39  1
    K_40      capital_40  -1
    K_40      capital_41  1
    K_40      balance_40  -1
    K_40      asf_40    1
    K_40      cap_min_40  1
    K_40      cap_buf_40  1
    K_40      lev_min_40  1
    K_40      lev_buf_40  1
    K_41      capital_41  -1
    K_41      capital_42  1
    K_41      balance_41  -1
    K_41      asf_41    1
    K_41      cap_min_41  1
    K_41      cap_buf_41  1
    K_41      lev_min_41  1
    K_41      lev_buf_41  1
    K_42      capital_42  -1
    K_42      capital_43  1
    K_42      balance_42  -1
    K_42      asf_42    1
    K_42      cap_min_42  1
    K_42      cap_buf_42  1
    K_42      lev_min_42  1
    K_42      lev_buf_42  1
    K_43      capital_43  -1
    K_43      capital_44  1
    K_43      balance_43  -1
    K_43      asf_43    1
    K_43      cap_min_43  1
    K_43      cap_buf_43  1
    K_43      lev_min_43  1
    K_43      lev_buf_43  1
    K_44      capital_44  -1
    K_44      capital_45  1
    K_44      balance_44  -1
    K_44      asf_44    1
    K_44      cap_min_44  1
    K_44      cap_buf_44  1
    K_44      lev_min_44  1
    K_44      lev_buf_44  1
    K_45      capital_45  -1
    K_45      capital_46  1
    K_45      balance_45  -1
    K_45      asf_45    1
    K_45      cap_min_45  1
    K_45      cap_buf_45  1
    K_45      lev_min_45  1
    K_45      lev_buf_45  1
    K_46      capital_46  -1
    K_46      capital_47  1
    K_46      balance_46  -1
    K_46      asf_46    1
    K_46      cap_min_46  1
    K_46      cap_buf_46  1
    K_46      lev_min_46  1
    K_46      lev_buf_46  1
    K_47      capital_47  -1
    K_47      capital_48  1
    K_47      balance_47  -1
    K_47      asf_47    1
    K_47      cap_min_47  1
    K_47      cap_buf_47  1
    K_47      lev_min_47  1
    K_47      lev_buf_47  1
    K_48      capital_48  -1
    K_48      capital_49  1
    K_48      balance_48  -1
    K_48      asf_48    1
    K_48      cap_min_48  1
    K_48      cap_buf_48  1
    K_48      lev_min_48  1
    K_48      lev_buf_48  1
    K_49      capital_49  -1
    K_49      capital_50  1
    K_49      balance_49  -1
    K_49      asf_49    1
    K_49      cap_min_49  1
    K_49      cap_buf_49  1
    K_49      lev_min_49  1
    K_49      lev_buf_49  1
    K_50      capital_50  -1
    K_50      capital_51  1
    K_50      balance_50  -1
    K_50      asf_50    1
    K_50      cap_min_50  1
    K_50      cap_buf_50  1
    K_50      lev_min_50  1
    K_50      lev_buf_50  1
    K_51      capital_51  -1
    K_51      capital_52  1
    K_51      balance_51  -1
    K_51      asf_51    1
    K_51      cap_min_51  1
    K_51      cap_buf_51  1
    K_51      lev_min_51  1
    K_51      lev_buf_51  1
    K_52      capital_52  -1
    K_52      capital_53  1
    K_52      balance_52  -1
    K_52      asf_52    1
    K_52      cap_min_52  1
    K_52      cap_buf_52  1
    K_52      lev_min_52  1
    K_52      lev_buf_52  1
    K_53      capital_53  -1
    K_53      capital_54  1
    K_53      balance_53  -1
    K_53      asf_53    1
    K_53      cap_min_53  1
    K_53      cap_buf_53  1
    K_53      lev_min_53  1
    K_53      lev_buf_53  1
    K_54      capital_54  -1
    K_54      capital_55  1
    K_54      balance_54  -1
    K_54      asf_54    1
    K_54      cap_min_54  1
    K_54      cap_buf_54  1
    K_54      lev_min_54  1
    K_54      lev_buf_54  1
    K_55      capital_55  -1
    K_55      capital_56  1
    K_55      balance_55  -1
    K_55      asf_55    1
    K_55      cap_min_55  1
    K_55      cap_buf_55  1
    K_55      lev_min_55  1
    K_55      lev_buf_55  1
    K_56      capital_56  -1
    K_56      capital_57  1
    K_56      balance_56  -1
    K_56      asf_56    1
    K_56      cap_min_56  1
    K_56      cap_buf_56  1
    K_56      lev_min_56  1
    K_56      lev_buf_56  1
    K_57      capital_57  -1
    K_57      capital_58  1
    K_57      balance_57  -1
    K_57      asf_57    1
    K_57      cap_min_57  1
    K_57      cap_buf_57  1
    K_57      lev_min_57  1
    K_57      lev_buf_57  1
    K_58      capital_58  -1
    K_58      capital_59  1
    K_58      balance_58  -1
    K_58      asf_58    1
    K_58      cap_min_58  1
    K_58      cap_buf_58  1
    K_58      lev_min_58  1
    K_58      lev_buf_58  1
    K_59      capital_59  -1
    K_59      capital_60  1
    K_59      balance_59  -1
    K_59      asf_59    1
    K_59      cap_min_59  1
    K_59      cap_buf_59  1
    K_59      lev_min_59  1
    K_59      lev_buf_59  1
    K_60      capital_60  -1
    K_60      balance_60  -1
    K_60      asf_60    1
    K_60      cap_min_60  1
    K_60      cap_buf_60  1
    K_60      lev_min_60  1
    K_60      lev_buf_60  1
    K_60      end_capital  1
    MD_1      pbt_1     -1
    MD_1      md_1      -1
    MD_1      bd_1      -1
    MD_2      pbt_2     -1
    MD_2      md_2      -1
    MD_2      bd_2      1
    MD_3      pbt_3     -1
    MD_3      md_3      -1
    MD_3      bd_3      1
    MD_4      pbt_4     -1
    MD_4      md_4      -1
    MD_4      bd_4      1
    MD_5      pbt_5     -1
    MD_5      md_5      -1
    MD_5      bd_5      1
    MD_6      pbt_6     -1
    MD_6      md_6      -1
    MD_6      bd_6      1
    MD_7      pbt_7     -1
    MD_7      md_7      -1
    MD_7      bd_7      1
    MD_8      pbt_8     -1
    MD_8      md_8      -1
    MD_8      bd_8      1
    MD_9      pbt_9     -1
    MD_9      md_9      -1
    MD_9      bd_9      1
    MD_10     pbt_10    -1
    MD_10     md_10     -1
    MD_10     bd_10     1
    MD_11     pbt_11    -1
    MD_11     md_11     -1
    MD_11     bd_11     1
    MD_12     pbt_12    -1
    MD_12     md_12     -1
    MD_12     bd_12     1
    MD_13     pbt_13    -1
    MD_13     md_13     -1
    MD_13     bd_13     1
    MD_14     pbt_14    -1
    MD_14     md_14     -1
    MD_14     bd_14     1
    MD_15     pbt_15    -1
    MD_15     md_15     -1
    MD_15     bd_15     1
    MD_16     pbt_16    -1
    MD_16     md_16     -1
    MD_16     bd_16     1
    MD_17     pbt_17    -1
    MD_17     md_17     -1
    MD_17     bd_17     1
    MD_18     pbt_18    -1
    MD_18     md_18     -1
    MD_18     bd_18     1
    MD_19     pbt_19    -1
    MD_19     md_19     -1
    MD_19     bd_19     1
    MD_20     pbt_20    -1
    MD_20     md_20     -1
    MD_20     bd_20     1
    MD_21     pbt_21    -1
    MD_21     md_21     -1
    MD_21     bd_21     1
    MD_22     pbt_22    -1
    MD_22     md_22     -1
    MD_22     bd_22     1
    MD_23     pbt_23    -1
    MD_23     md_23     -1
    MD_23     bd_23     1
    MD_24     pbt_24    -1
    MD_24     md_24     -1
    MD_24     bd_24     1
    MD_25     pbt_25    -1
    MD_25     md_25     -1
    MD_25     bd_25     1
    MD_26     pbt_26    -1
    MD_26     md_26     -1
    MD_26     bd_26     1
    MD_27     pbt_27    -1
    MD_27     md_27     -1
    MD_27     bd_27     1
    MD_28     pbt_28    -1
    MD_28     md_28     -1
    MD_28     bd_28     1
    MD_29     pbt_29    -1
    MD_29     md_29     -1
    MD_29     bd_29     1
    MD_30     pbt_30    -1
    MD_30     md_30     -1
    MD_30     bd_30     1
    MD_31     pbt_31    -1
    MD_31     md_31     -1
    MD_31     bd_31     1
    MD_32     pbt_32    -1
    MD_32     md_32     -1
    MD_32     bd_32     1
    MD_33     pbt_33    -1
    MD_33     md_33     -1
    MD_33     bd_33     1
    MD_34     pbt_34    -1
    MD_34     md_34     -1
    MD_34     bd_34     1
    MD_35     pbt_35    -1
    MD_35     md_35     -1
    MD_35     bd_35     1
    MD_36     pbt_36    -1
    MD_36     md_36     -1
    MD_36     bd_36     1
    MD_37     pbt_37    -1
    MD_37     md_37     -1
    MD_37     bd_37     1
    MD_38     pbt_38    -1
    MD_38     md_38     -1
    MD_38     bd_38     1
    MD_39     pbt_39    -1
    MD_39     md_39     -1
    MD_39     bd_39     1
    MD_40     pbt_40    -1
    MD_40     md_40     -1
    MD_40     bd_40     1
    MD_41     pbt_41    -1
    MD_41     md_41     -1
    MD_41     bd_41     1
    MD_42     pbt_42    -1
    MD_42     md_42     -1
    MD_42     bd_42     1
    MD_43     pbt_43    -1
    MD_43     md_43     -1
    MD_43     bd_43     1
    MD_44     pbt_44    -1
    MD_44     md_44     -1
    MD_44     bd_44     1
    MD_45     pbt_45    -1
    MD_45     md_45     -1
    MD_45     bd_45     1
    MD_46     pbt_46    -1
    MD_46     md_46     -1
    MD_46     bd_46     1
    MD_47     pbt_47    -1
    MD_47     md_47     -1
    MD_47     bd_47     1
    MD_48     pbt_48    -1
    MD_48     md_48     -1
    MD_48     bd_48     1
    MD_49     pbt_49    -1
    MD_49     md_49     -1
    MD_49     bd_49     1
    MD_50     pbt_50    -1
    MD_50     md_50     -1
    MD_50     bd_50     1
    MD_51     pbt_51    -1
    MD_51     md_51     -1
    MD_51     bd_51     1
    MD_52     pbt_52    -1
    MD_52     md_52     -1
    MD_52     bd_52     1
    MD_53     pbt_53    -1
    MD_53     md_53     -1
    MD_53     bd_53     1
    MD_54     pbt_54    -1
    MD_54     md_54     -1
    MD_54     bd_54     1
    MD_55     pbt_55    -1
    MD_55     md_55     -1
    MD_55     bd_55     1
    MD_56     pbt_56    -1
    MD_56     md_56     -1
    MD_56     bd_56     1
    MD_57     pbt_57    -1
    MD_57     md_57     -1
    MD_57     bd_57     1
    MD_58     pbt_58    -1
    MD_58     md_58     -1
    MD_58     bd_58     1
    MD_59     pbt_59    -1
    MD_59     md_59     -1
    MD_59     bd_59     1
    MD_60     pbt_60    -1
    MD_60     md_60     -1
    MD_60     bd_60     1
    MB_1      pbt_1     -1
    MB_1      mb_1      -1
    MB_1      bb_1      -1
    MB_2      pbt_2     -1
    MB_2      mb_2      -1
    MB_2      bb_2      1
    MB_3      pbt_3     -1
    MB_3      mb_3      -1
    MB_3      bb_3      1
    MB_4      pbt_4     -1
    MB_4      mb_4      -1
    MB_4      bb_4      1
    MB_5      pbt_5     -1
    MB_5      mb_5      -1
    MB_5      bb_5      1
    MB_6      pbt_6     -1
    MB_6      mb_6      -1
    MB_6      bb_6      1
    MB_7      pbt_7     -1
    MB_7      mb_7      -1
    MB_7      bb_7      1
    MB_8      pbt_8     -1
    MB_8      mb_8      -1
    MB_8      bb_8      1
    MB_9      pbt_9     -1
    MB_9      mb_9      -1
    MB_9      bb_9      1
    MB_10     pbt_10    -1
    MB_10     mb_10     -1
    MB_10     bb_10     1
    MB_11     pbt_11    -1
    MB_11     mb_11     -1
    MB_11     bb_11     1
    MB_12     pbt_12    -1
    MB_12     mb_12     -1
    MB_12     bb_12     1
    MB_13     pbt_13    -1
    MB_13     mb_13     -1
    MB_13     bb_13     1
    MB_14     pbt_14    -1
    MB_14     mb_14     -1
    MB_14     bb_14     1
    MB_15     pbt_15    -1
    MB_15     mb_15     -1
    MB_15     bb_15     1
    MB_16     pbt_16    -1
    MB_16     mb_16     -1
    MB_16     bb_16     1
    MB_17     pbt_17    -1
    MB_17     mb_17     -1
    MB_17     bb_17     1
    MB_18     pbt_18    -1
    MB_18     mb_18     -1
    MB_18     bb_18     1
    MB_19     pbt_19    -1
    MB_19     mb_19     -1
    MB_19     bb_19     1
    MB_20     pbt_20    -1
    MB_20     mb_20     -1
    MB_20     bb_20     1
    MB_21     pbt_21    -1
    MB_21     mb_21     -1
    MB_21     bb_21     1
    MB_22     pbt_22    -1
    MB_22     mb_22     -1
    MB_22     bb_22     1
    MB_23     pbt_23    -1
    MB_23     mb_23     -1
    MB_23     bb_23     1
    MB_24     pbt_24    -1
    MB_24     mb_24     -1
    MB_24     bb_24     1
    MB_25     pbt_25    -1
    MB_25     mb_25     -1
    MB_25     bb_25     1
    MB_26     pbt_26    -1
    MB_26     mb_26     -1
    MB_26     bb_26     1
    MB_27     pbt_27    -1
    MB_27     mb_27     -1
    MB_27     bb_27     1
    MB_28     pbt_28    -1
    MB_28     mb_28     -1
    MB_28     bb_28     1
    MB_29     pbt_29    -1
    MB_29     mb_29     -1
    MB_29     bb_29     1
    MB_30     pbt_30    -1
    MB_30     mb_30     -1
    MB_30     bb_30     1
    MB_31     pbt_31    -1
    MB_31     mb_31     -1
    MB_31     bb_31     1
    MB_32     pbt_32    -1
    MB_32     mb_32     -1
    MB_32     bb_32     1
    MB_33     pbt_33    -1
    MB_33     mb_33     -1
    MB_33     bb_33     1
    MB_34     pbt_34    -1
    MB_34     mb_34     -1
    MB_34     bb_34     1
    MB_35     pbt_35    -1
    MB_35     mb_35     -1
    MB_35     bb_35     1
    MB_36     pbt_36    -1
    MB_36     mb_36     -1
    MB_36     bb_36     1
    MB_37     pbt_37    -1
    MB_37     mb_37     -1
    MB_37     bb_37     1
    MB_38     pbt_38    -1
    MB_38     mb_38     -1
    MB_38     bb_38     1
    MB_39     pbt_39    -1
    MB_39     mb_39     -1
    MB_39     bb_39     1
    MB_40     pbt_40    -1
    MB_40     mb_40     -1
    MB_40     bb_40     1
    MB_41     pbt_41    -1
    MB_41     mb_41     -1
    MB_41     bb_41     1
    MB_42     pbt_42    -1
    MB_42     mb_42     -1
    MB_42     bb_42     1
    MB_43     pbt_43    -1
    MB_43     mb_43     -1
    MB_43     bb_43     1
    MB_44     pbt_44    -1
    MB_44     mb_44     -1
    MB_44     bb_44     1
    MB_45     pbt_45    -1
    MB_45     mb_45     -1
    MB_45     bb_45     1
    MB_46     pbt_46    -1
    MB_46     mb_46     -1
    MB_46     bb_46     1
    MB_47     pbt_47    -1
    MB_47     mb_47     -1
    MB_47     bb_47     1
    MB_48     pbt_48    -1
    MB_48     mb_48     -1
    MB_48     bb_48     1
    MB_49     pbt_49    -1
    MB_49     mb_49     -1
    MB_49     bb_49     1
    MB_50     pbt_50    -1
    MB_50     mb_50     -1
    MB_50     bb_50     1
    MB_51     pbt_51    -1
    MB_51     mb_51     -1
    MB_51     bb_51     1
    MB_52     pbt_52    -1
    MB_52     mb_52     -1
    MB_52     bb_52     1
    MB_53     pbt_53    -1
    MB_53     mb_53     -1
    MB_53     bb_53     1
    MB_54     pbt_54    -1
    MB_54     mb_54     -1
    MB_54     bb_54     1
    MB_55     pbt_55    -1
    MB_55     mb_55     -1
    MB_55     bb_55     1
    MB_56     pbt_56    -1
    MB_56     mb_56     -1
    MB_56     bb_56     1
    MB_57     pbt_57    -1
    MB_57     mb_57     -1
    MB_57     bb_57     1
    MB_58     pbt_58    -1
    MB_58     mb_58     -1
    MB_58     bb_58     1
    MB_59     pbt_59    -1
    MB_59     mb_59     -1
    MB_59     bb_59     1
    MB_60     pbt_60    -1
    MB_60     mb_60     -1
    MB_60     bb_60     1
    BD_1      Obj       1
    BD_1      bd_1      1
    BD_2      Obj       1
    BD_2      bd_2      -1
    BD_3      Obj       1
    BD_3      bd_3      -1
    BD_4      Obj       1
    BD_4      bd_4      -1
    BD_5      Obj       1
    BD_5      bd_5      -1
    BD_6      Obj       1
    BD_6      bd_6      -1
    BD_7      Obj       1
    BD_7      bd_7      -1
    BD_8      Obj       1
    BD_8      bd_8      -1
    BD_9      Obj       1
    BD_9      bd_9      -1
    BD_10     Obj       1
    BD_10     bd_10     -1
    BD_11     Obj       1
    BD_11     bd_11     -1
    BD_12     Obj       1
    BD_12     bd_12     -1
    BD_13     Obj       1
    BD_13     bd_13     -1
    BD_14     Obj       1
    BD_14     bd_14     -1
    BD_15     Obj       1
    BD_15     bd_15     -1
    BD_16     Obj       1
    BD_16     bd_16     -1
    BD_17     Obj       1
    BD_17     bd_17     -1
    BD_18     Obj       1
    BD_18     bd_18     -1
    BD_19     Obj       1
    BD_19     bd_19     -1
    BD_20     Obj       1
    BD_20     bd_20     -1
    BD_21     Obj       1
    BD_21     bd_21     -1
    BD_22     Obj       1
    BD_22     bd_22     -1
    BD_23     Obj       1
    BD_23     bd_23     -1
    BD_24     Obj       1
    BD_24     bd_24     -1
    BD_25     Obj       1
    BD_25     bd_25     -1
    BD_26     Obj       1
    BD_26     bd_26     -1
    BD_27     Obj       1
    BD_27     bd_27     -1
    BD_28     Obj       1
    BD_28     bd_28     -1
    BD_29     Obj       1
    BD_29     bd_29     -1
    BD_30     Obj       1
    BD_30     bd_30     -1
    BD_31     Obj       1
    BD_31     bd_31     -1
    BD_32     Obj       1
    BD_32     bd_32     -1
    BD_33     Obj       1
    BD_33     bd_33     -1
    BD_34     Obj       1
    BD_34     bd_34     -1
    BD_35     Obj       1
    BD_35     bd_35     -1
    BD_36     Obj       1
    BD_36     bd_36     -1
    BD_37     Obj       1
    BD_37     bd_37     -1
    BD_38     Obj       1
    BD_38     bd_38     -1
    BD_39     Obj       1
    BD_39     bd_39     -1
    BD_40     Obj       1
    BD_40     bd_40     -1
    BD_41     Obj       1
    BD_41     bd_41     -1
    BD_42     Obj       1
    BD_42     bd_42     -1
    BD_43     Obj       1
    BD_43     bd_43     -1
    BD_44     Obj       1
    BD_44     bd_44     -1
    BD_45     Obj       1
    BD_45     bd_45     -1
    BD_46     Obj       1
    BD_46     bd_46     -1
    BD_47     Obj       1
    BD_47     bd_47     -1
    BD_48     Obj       1
    BD_48     bd_48     -1
    BD_49     Obj       1
    BD_49     bd_49     -1
    BD_50     Obj       1
    BD_50     bd_50     -1
    BD_51     Obj       1
    BD_51     bd_51     -1
    BD_52     Obj       1
    BD_52     bd_52     -1
    BD_53     Obj       1
    BD_53     bd_53     -1
    BD_54     Obj       1
    BD_54     bd_54     -1
    BD_55     Obj       1
    BD_55     bd_55     -1
    BD_56     Obj       1
    BD_56     bd_56     -1
    BD_57     Obj       1
    BD_57     bd_57     -1
    BD_58     Obj       1
    BD_58     bd_58     -1
    BD_59     Obj       1
    BD_59     bd_59     -1
    BD_60     Obj       1
    BD_60     bd_60     -1
    BB_1      Obj       1
    BB_1      bb_1      1
    BB_2      Obj       1
    BB_2      bb_2      -1
    BB_3      Obj       1
    BB_3      bb_3      -1
    BB_4      Obj       1
    BB_4      bb_4      -1
    BB_5      Obj       1
    BB_5      bb_5      -1
    BB_6      Obj       1
    BB_6      bb_6      -1
    BB_7      Obj       1
    BB_7      bb_7      -1
    BB_8      Obj       1
    BB_8      bb_8      -1
    BB_9      Obj       1
    BB_9      bb_9      -1
    BB_10     Obj       1
    BB_10     bb_10     -1
    BB_11     Obj       1
    BB_11     bb_11     -1
    BB_12     Obj       1
    BB_12     bb_12     -1
    BB_13     Obj       1
    BB_13     bb_13     -1
    BB_14     Obj       1
    BB_14     bb_14     -1
    BB_15     Obj       1
    BB_15     bb_15     -1
    BB_16     Obj       1
    BB_16     bb_16     -1
    BB_17     Obj       1
    BB_17     bb_17     -1
    BB_18     Obj       1
    BB_18     bb_18     -1
    BB_19     Obj       1
    BB_19     bb_19     -1
    BB_20     Obj       1
    BB_20     bb_20     -1
    BB_21     Obj       1
    BB_21     bb_21     -1
    BB_22     Obj       1
    BB_22     bb_22     -1
    BB_23     Obj       1
    BB_23     bb_23     -1
    BB_24     Obj       1
    BB_24     bb_24     -1
    BB_25     Obj       1
    BB_25     bb_25     -1
    BB_26     Obj       1
    BB_26     bb_26     -1
    BB_27     Obj       1
    BB_27     bb_27     -1
    BB_28     Obj       1
    BB_28     bb_28     -1
    BB_29     Obj       1
    BB_29     bb_29     -1
    BB_30     Obj       1
    BB_30     bb_30     -1
    BB_31     Obj       1
    BB_31     bb_31     -1
    BB_32     Obj       1
    BB_32     bb_32     -1
    BB_33     Obj       1
    BB_33     bb_33     -1
    BB_34     Obj       1
    BB_34     bb_34     -1
    BB_35     Obj       1
    BB_35     bb_35     -1
    BB_36     Obj       1
    BB_36     bb_36     -1
    BB_37     Obj       1
    BB_37     bb_37     -1
    BB_38     Obj       1
    BB_38     bb_38     -1
    BB_39     Obj       1
    BB_39     bb_39     -1
    BB_40     Obj       1
    BB_40     bb_40     -1
    BB_41     Obj       1
    BB_41     bb_41     -1
    BB_42     Obj       1
    BB_42     bb_42     -1
    BB_43     Obj       1
    BB_43     bb_43     -1
    BB_44     Obj       1
    BB_44     bb_44     -1
    BB_45     Obj       1
    BB_45     bb_45     -1
    BB_46     Obj       1
    BB_46     bb_46     -1
    BB_47     Obj       1
    BB_47     bb_47     -1
    BB_48     Obj       1
    BB_48     bb_48     -1
    BB_49     Obj       1
    BB_49     bb_49     -1
    BB_50     Obj       1
    BB_50     bb_50     -1
    BB_51     Obj       1
    BB_51     bb_51     -1
    BB_52     Obj       1
    BB_52     bb_52     -1
    BB_53     Obj       1
    BB_53     bb_53     -1
    BB_54     Obj       1
    BB_54     bb_54     -1
    BB_55     Obj       1
    BB_55     bb_55     -1
    BB_56     Obj       1
    BB_56     bb_56     -1
    BB_57     Obj       1
    BB_57     bb_57     -1
    BB_58     Obj       1
    BB_58     bb_58     -1
    BB_59     Obj       1
    BB_59     bb_59     -1
    BB_60     Obj       1
    BB_60     bb_60     -1
    II_1      ii_1      1
    II_1      pbt_1     1
    II_2      ii_2      -1
    II_2      pbt_2     1
    II_3      ii_3      -1
    II_3      pbt_3     1
    II_4      ii_4      -1
    II_4      pbt_4     1
    II_5      ii_5      -1
    II_5      pbt_5     1
    II_6      ii_6      -1
    II_6      pbt_6     1
    II_7      ii_7      -1
    II_7      pbt_7     1
    II_8      ii_8      -1
    II_8      pbt_8     1
    II_9      ii_9      -1
    II_9      pbt_9     1
    II_10     ii_10     -1
    II_10     pbt_10    1
    II_11     ii_11     -1
    II_11     pbt_11    1
    II_12     ii_12     -1
    II_12     pbt_12    1
    II_13     ii_13     -1
    II_13     pbt_13    1
    II_14     ii_14     -1
    II_14     pbt_14    1
    II_15     ii_15     -1
    II_15     pbt_15    1
    II_16     ii_16     -1
    II_16     pbt_16    1
    II_17     ii_17     -1
    II_17     pbt_17    1
    II_18     ii_18     -1
    II_18     pbt_18    1
    II_19     ii_19     -1
    II_19     pbt_19    1
    II_20     ii_20     -1
    II_20     pbt_20    1
    II_21     ii_21     -1
    II_21     pbt_21    1
    II_22     ii_22     -1
    II_22     pbt_22    1
    II_23     ii_23     -1
    II_23     pbt_23    1
    II_24     ii_24     -1
    II_24     pbt_24    1
    II_25     ii_25     -1
    II_25     pbt_25    1
    II_26     ii_26     -1
    II_26     pbt_26    1
    II_27     ii_27     -1
    II_27     pbt_27    1
    II_28     ii_28     -1
    II_28     pbt_28    1
    II_29     ii_29     -1
    II_29     pbt_29    1
    II_30     ii_30     -1
    II_30     pbt_30    1
    II_31     ii_31     -1
    II_31     pbt_31    1
    II_32     ii_32     -1
    II_32     pbt_32    1
    II_33     ii_33     -1
    II_33     pbt_33    1
    II_34     ii_34     -1
    II_34     pbt_34    1
    II_35     ii_35     -1
    II_35     pbt_35    1
    II_36     ii_36     -1
    II_36     pbt_36    1
    II_37     ii_37     -1
    II_37     pbt_37    1
    II_38     ii_38     -1
    II_38     pbt_38    1
    II_39     ii_39     -1
    II_39     pbt_39    1
    II_40     ii_40     -1
    II_40     pbt_40    1
    II_41     ii_41     -1
    II_41     pbt_41    1
    II_42     ii_42     -1
    II_42     pbt_42    1
    II_43     ii_43     -1
    II_43     pbt_43    1
    II_44     ii_44     -1
    II_44     pbt_44    1
    II_45     ii_45     -1
    II_45     pbt_45    1
    II_46     ii_46     -1
    II_46     pbt_46    1
    II_47     ii_47     -1
    II_47     pbt_47    1
    II_48     ii_48     -1
    II_48     pbt_48    1
    II_49     ii_49     -1
    II_49     pbt_49    1
    II_50     ii_50     -1
    II_50     pbt_50    1
    II_51     ii_51     -1
    II_51     pbt_51    1
    II_52     ii_52     -1
    II_52     pbt_52    1
    II_53     ii_53     -1
    II_53     pbt_53    1
    II_54     ii_54     -1
    II_54     pbt_54    1
    II_55     ii_55     -1
    II_55     pbt_55    1
    II_56     ii_56     -1
    II_56     pbt_56    1
    II_57     ii_57     -1
    II_57     pbt_57    1
    II_58     ii_58     -1
    II_58     pbt_58    1
    II_59     ii_59     -1
    II_59     pbt_59    1
    II_60     ii_60     -1
    II_60     pbt_60    1
    IE_1      ie_1      1
    IE_1      pbt_1     -1
    IE_2      ie_2      -1
    IE_2      pbt_2     -1
    IE_3      ie_3      -1
    IE_3      pbt_3     -1
    IE_4      ie_4      -1
    IE_4      pbt_4     -1
    IE_5      ie_5      -1
    IE_5      pbt_5     -1
    IE_6      ie_6      -1
    IE_6      pbt_6     -1
    IE_7      ie_7      -1
    IE_7      pbt_7     -1
    IE_8      ie_8      -1
    IE_8      pbt_8     -1
    IE_9      ie_9      -1
    IE_9      pbt_9     -1
    IE_10     ie_10     -1
    IE_10     pbt_10    -1
    IE_11     ie_11     -1
    IE_11     pbt_11    -1
    IE_12     ie_12     -1
    IE_12     pbt_12    -1
    IE_13     ie_13     -1
    IE_13     pbt_13    -1
    IE_14     ie_14     -1
    IE_14     pbt_14    -1
    IE_15     ie_15     -1
    IE_15     pbt_15    -1
    IE_16     ie_16     -1
    IE_16     pbt_16    -1
    IE_17     ie_17     -1
    IE_17     pbt_17    -1
    IE_18     ie_18     -1
    IE_18     pbt_18    -1
    IE_19     ie_19     -1
    IE_19     pbt_19    -1
    IE_20     ie_20     -1
    IE_20     pbt_20    -1
    IE_21     ie_21     -1
    IE_21     pbt_21    -1
    IE_22     ie_22     -1
    IE_22     pbt_22    -1
    IE_23     ie_23     -1
    IE_23     pbt_23    -1
    IE_24     ie_24     -1
    IE_24     pbt_24    -1
    IE_25     ie_25     -1
    IE_25     pbt_25    -1
    IE_26     ie_26     -1
    IE_26     pbt_26    -1
    IE_27     ie_27     -1
    IE_27     pbt_27    -1
    IE_28     ie_28     -1
    IE_28     pbt_28    -1
    IE_29     ie_29     -1
    IE_29     pbt_29    -1
    IE_30     ie_30     -1
    IE_30     pbt_30    -1
    IE_31     ie_31     -1
    IE_31     pbt_31    -1
    IE_32     ie_32     -1
    IE_32     pbt_32    -1
    IE_33     ie_33     -1
    IE_33     pbt_33    -1
    IE_34     ie_34     -1
    IE_34     pbt_34    -1
    IE_35     ie_35     -1
    IE_35     pbt_35    -1
    IE_36     ie_36     -1
    IE_36     pbt_36    -1
    IE_37     ie_37     -1
    IE_37     pbt_37    -1
    IE_38     ie_38     -1
    IE_38     pbt_38    -1
    IE_39     ie_39     -1
    IE_39     pbt_39    -1
    IE_40     ie_40     -1
    IE_40     pbt_40    -1
    IE_41     ie_41     -1
    IE_41     pbt_41    -1
    IE_42     ie_42     -1
    IE_42     pbt_42    -1
    IE_43     ie_43     -1
    IE_43     pbt_43    -1
    IE_44     ie_44     -1
    IE_44     pbt_44    -1
    IE_45     ie_45     -1
    IE_45     pbt_45    -1
    IE_46     ie_46     -1
    IE_46     pbt_46    -1
    IE_47     ie_47     -1
    IE_47     pbt_47    -1
    IE_48     ie_48     -1
    IE_48     pbt_48    -1
    IE_49     ie_49     -1
    IE_49     pbt_49    -1
    IE_50     ie_50     -1
    IE_50     pbt_50    -1
    IE_51     ie_51     -1
    IE_51     pbt_51    -1
    IE_52     ie_52     -1
    IE_52     pbt_52    -1
    IE_53     ie_53     -1
    IE_53     pbt_53    -1
    IE_54     ie_54     -1
    IE_54     pbt_54    -1
    IE_55     ie_55     -1
    IE_55     pbt_55    -1
    IE_56     ie_56     -1
    IE_56     pbt_56    -1
    IE_57     ie_57     -1
    IE_57     pbt_57    -1
    IE_58     ie_58     -1
    IE_58     pbt_58    -1
    IE_59     ie_59     -1
    IE_59     pbt_59    -1
    IE_60     ie_60     -1
    IE_60     pbt_60    -1
    IMP_1     imp_1     -1
    IMP_1     pbt_1     -1
    IMP_2     imp_2     -1
    IMP_2     pbt_2     -1
    IMP_3     imp_3     -1
    IMP_3     pbt_3     -1
    IMP_4     imp_4     -1
    IMP_4     pbt_4     -1
    IMP_5     imp_5     -1
    IMP_5     pbt_5     -1
    IMP_6     imp_6     -1
    IMP_6     pbt_6     -1
    IMP_7     imp_7     -1
    IMP_7     pbt_7     -1
    IMP_8     imp_8     -1
    IMP_8     pbt_8     -1
    IMP_9     imp_9     -1
    IMP_9     pbt_9     -1
    IMP_10    imp_10    -1
    IMP_10    pbt_10    -1
    IMP_11    imp_11    -1
    IMP_11    pbt_11    -1
    IMP_12    imp_12    -1
    IMP_12    pbt_12    -1
    IMP_13    imp_13    -1
    IMP_13    pbt_13    -1
    IMP_14    imp_14    -1
    IMP_14    pbt_14    -1
    IMP_15    imp_15    -1
    IMP_15    pbt_15    -1
    IMP_16    imp_16    -1
    IMP_16    pbt_16    -1
    IMP_17    imp_17    -1
    IMP_17    pbt_17    -1
    IMP_18    imp_18    -1
    IMP_18    pbt_18    -1
    IMP_19    imp_19    -1
    IMP_19    pbt_19    -1
    IMP_20    imp_20    -1
    IMP_20    pbt_20    -1
    IMP_21    imp_21    -1
    IMP_21    pbt_21    -1
    IMP_22    imp_22    -1
    IMP_22    pbt_22    -1
    IMP_23    imp_23    -1
    IMP_23    pbt_23    -1
    IMP_24    imp_24    -1
    IMP_24    pbt_24    -1
    IMP_25    imp_25    -1
    IMP_25    pbt_25    -1
    IMP_26    imp_26    -1
    IMP_26    pbt_26    -1
    IMP_27    imp_27    -1
    IMP_27    pbt_27    -1
    IMP_28    imp_28    -1
    IMP_28    pbt_28    -1
    IMP_29    imp_29    -1
    IMP_29    pbt_29    -1
    IMP_30    imp_30    -1
    IMP_30    pbt_30    -1
    IMP_31    imp_31    -1
    IMP_31    pbt_31    -1
    IMP_32    imp_32    -1
    IMP_32    pbt_32    -1
    IMP_33    imp_33    -1
    IMP_33    pbt_33    -1
    IMP_34    imp_34    -1
    IMP_34    pbt_34    -1
    IMP_35    imp_35    -1
    IMP_35    pbt_35    -1
    IMP_36    imp_36    -1
    IMP_36    pbt_36    -1
    IMP_37    imp_37    -1
    IMP_37    pbt_37    -1
    IMP_38    imp_38    -1
    IMP_38    pbt_38    -1
    IMP_39    imp_39    -1
    IMP_39    pbt_39    -1
    IMP_40    imp_40    -1
    IMP_40    pbt_40    -1
    IMP_41    imp_41    -1
    IMP_41    pbt_41    -1
    IMP_42    imp_42    -1
    IMP_42    pbt_42    -1
    IMP_43    imp_43    -1
    IMP_43    pbt_43    -1
    IMP_44    imp_44    -1
    IMP_44    pbt_44    -1
    IMP_45    imp_45    -1
    IMP_45    pbt_45    -1
    IMP_46    imp_46    -1
    IMP_46    pbt_46    -1
    IMP_47    imp_47    -1
    IMP_47    pbt_47    -1
    IMP_48    imp_48    -1
    IMP_48    pbt_48    -1
    IMP_49    imp_49    -1
    IMP_49    pbt_49    -1
    IMP_50    imp_50    -1
    IMP_50    pbt_50    -1
    IMP_51    imp_51    -1
    IMP_51    pbt_51    -1
    IMP_52    imp_52    -1
    IMP_52    pbt_52    -1
    IMP_53    imp_53    -1
    IMP_53    pbt_53    -1
    IMP_54    imp_54    -1
    IMP_54    pbt_54    -1
    IMP_55    imp_55    -1
    IMP_55    pbt_55    -1
    IMP_56    imp_56    -1
    IMP_56    pbt_56    -1
    IMP_57    imp_57    -1
    IMP_57    pbt_57    -1
    IMP_58    imp_58    -1
    IMP_58    pbt_58    -1
    IMP_59    imp_59    -1
    IMP_59    pbt_59    -1
    IMP_60    imp_60    -1
    IMP_60    pbt_60    -1
    PBT_1     pbt_1     -1
    PBT_1     loss_1    -1
    PBT_1     np_1      1
    PBT_2     pbt_2     -1
    PBT_2     loss_2    -1
    PBT_2     np_2      1
    PBT_3     pbt_3     -1
    PBT_3     loss_3    -1
    PBT_3     np_3      1
    PBT_4     pbt_4     -1
    PBT_4     loss_4    -1
    PBT_4     np_4      1
    PBT_5     pbt_5     -1
    PBT_5     loss_5    -1
    PBT_5     np_5      1
    PBT_6     pbt_6     -1
    PBT_6     loss_6    -1
    PBT_6     np_6      1
    PBT_7     pbt_7     -1
    PBT_7     loss_7    -1
    PBT_7     np_7      1
    PBT_8     pbt_8     -1
    PBT_8     loss_8    -1
    PBT_8     np_8      1
    PBT_9     pbt_9     -1
    PBT_9     loss_9    -1
    PBT_9     np_9      1
    PBT_10    pbt_10    -1
    PBT_10    loss_10   -1
    PBT_10    np_10     1
    PBT_11    pbt_11    -1
    PBT_11    loss_11   -1
    PBT_11    np_11     1
    PBT_12    pbt_12    -1
    PBT_12    loss_12   -1
    PBT_12    np_12     1
    PBT_13    pbt_13    -1
    PBT_13    loss_13   -1
    PBT_13    np_13     1
    PBT_14    pbt_14    -1
    PBT_14    loss_14   -1
    PBT_14    np_14     1
    PBT_15    pbt_15    -1
    PBT_15    loss_15   -1
    PBT_15    np_15     1
    PBT_16    pbt_16    -1
    PBT_16    loss_16   -1
    PBT_16    np_16     1
    PBT_17    pbt_17    -1
    PBT_17    loss_17   -1
    PBT_17    np_17     1
    PBT_18    pbt_18    -1
    PBT_18    loss_18   -1
    PBT_18    np_18     1
    PBT_19    pbt_19    -1
    PBT_19    loss_19   -1
    PBT_19    np_19     1
    PBT_20    pbt_20    -1
    PBT_20    loss_20   -1
    PBT_20    np_20     1
    PBT_21    pbt_21    -1
    PBT_21    loss_21   -1
    PBT_21    np_21     1
    PBT_22    pbt_22    -1
    PBT_22    loss_22   -1
    PBT_22    np_22     1
    PBT_23    pbt_23    -1
    PBT_23    loss_23   -1
    PBT_23    np_23     1
    PBT_24    pbt_24    -1
    PBT_24    loss_24   -1
    PBT_24    np_24     1
    PBT_25    pbt_25    -1
    PBT_25    loss_25   -1
    PBT_25    np_25     1
    PBT_26    pbt_26    -1
    PBT_26    loss_26   -1
    PBT_26    np_26     1
    PBT_27    pbt_27    -1
    PBT_27    loss_27   -1
    PBT_27    np_27     1
    PBT_28    pbt_28    -1
    PBT_28    loss_28   -1
    PBT_28    np_28     1
    PBT_29    pbt_29    -1
    PBT_29    loss_29   -1
    PBT_29    np_29     1
    PBT_30    pbt_30    -1
    PBT_30    loss_30   -1
    PBT_30    np_30     1
    PBT_31    pbt_31    -1
    PBT_31    loss_31   -1
    PBT_31    np_31     1
    PBT_32    pbt_32    -1
    PBT_32    loss_32   -1
    PBT_32    np_32     1
    PBT_33    pbt_33    -1
    PBT_33    loss_33   -1
    PBT_33    np_33     1
    PBT_34    pbt_34    -1
    PBT_34    loss_34   -1
    PBT_34    np_34     1
    PBT_35    pbt_35    -1
    PBT_35    loss_35   -1
    PBT_35    np_35     1
    PBT_36    pbt_36    -1
    PBT_36    loss_36   -1
    PBT_36    np_36     1
    PBT_37    pbt_37    -1
    PBT_37    loss_37   -1
    PBT_37    np_37     1
    PBT_38    pbt_38    -1
    PBT_38    loss_38   -1
    PBT_38    np_38     1
    PBT_39    pbt_39    -1
    PBT_39    loss_39   -1
    PBT_39    np_39     1
    PBT_40    pbt_40    -1
    PBT_40    loss_40   -1
    PBT_40    np_40     1
    PBT_41    pbt_41    -1
    PBT_41    loss_41   -1
    PBT_41    np_41     1
    PBT_42    pbt_42    -1
    PBT_42    loss_42   -1
    PBT_42    np_42     1
    PBT_43    pbt_43    -1
    PBT_43    loss_43   -1
    PBT_43    np_43     1
    PBT_44    pbt_44    -1
    PBT_44    loss_44   -1
    PBT_44    np_44     1
    PBT_45    pbt_45    -1
    PBT_45    loss_45   -1
    PBT_45    np_45     1
    PBT_46    pbt_46    -1
    PBT_46    loss_46   -1
    PBT_46    np_46     1
    PBT_47    pbt_47    -1
    PBT_47    loss_47   -1
    PBT_47    np_47     1
    PBT_48    pbt_48    -1
    PBT_48    loss_48   -1
    PBT_48    np_48     1
    PBT_49    pbt_49    -1
    PBT_49    loss_49   -1
    PBT_49    np_49     1
    PBT_50    pbt_50    -1
    PBT_50    loss_50   -1
    PBT_50    np_50     1
    PBT_51    pbt_51    -1
    PBT_51    loss_51   -1
    PBT_51    np_51     1
    PBT_52    pbt_52    -1
    PBT_52    loss_52   -1
    PBT_52    np_52     1
    PBT_53    pbt_53    -1
    PBT_53    loss_53   -1
    PBT_53    np_53     1
    PBT_54    pbt_54    -1
    PBT_54    loss_54   -1
    PBT_54    np_54     1
    PBT_55    pbt_55    -1
    PBT_55    loss_55   -1
    PBT_55    np_55     1
    PBT_56    pbt_56    -1
    PBT_56    loss_56   -1
    PBT_56    np_56     1
    PBT_57    pbt_57    -1
    PBT_57    loss_57   -1
    PBT_57    np_57     1
    PBT_58    pbt_58    -1
    PBT_58    loss_58   -1
    PBT_58    np_58     1
    PBT_59    pbt_59    -1
    PBT_59    loss_59   -1
    PBT_59    np_59     1
    PBT_60    pbt_60    -1
    PBT_60    loss_60   -1
    PBT_60    np_60     1
    PP_1      loss_1    1
    PP_1      tl_use_1  -1
    PP_1      tax_1     0.25
    PP_2      loss_2    1
    PP_2      tl_use_2  -1
    PP_2      tax_2     0.25
    PP_3      loss_3    1
    PP_3      tl_use_3  -1
    PP_3      tax_3     0.25
    PP_4      loss_4    1
    PP_4      tl_use_4  -1
    PP_4      tax_4     0.25
    PP_5      loss_5    1
    PP_5      tl_use_5  -1
    PP_5      tax_5     0.25
    PP_6      loss_6    1
    PP_6      tl_use_6  -1
    PP_6      tax_6     0.25
    PP_7      loss_7    1
    PP_7      tl_use_7  -1
    PP_7      tax_7     0.25
    PP_8      loss_8    1
    PP_8      tl_use_8  -1
    PP_8      tax_8     0.25
    PP_9      loss_9    1
    PP_9      tl_use_9  -1
    PP_9      tax_9     0.25
    PP_10     loss_10   1
    PP_10     tl_use_10  -1
    PP_10     tax_10    0.25
    PP_11     loss_11   1
    PP_11     tl_use_11  -1
    PP_11     tax_11    0.25
    PP_12     loss_12   1
    PP_12     tl_use_12  -1
    PP_12     tax_12    0.25
    PP_13     loss_13   1
    PP_13     tl_use_13  -1
    PP_13     tax_13    0.25
    PP_14     loss_14   1
    PP_14     tl_use_14  -1
    PP_14     tax_14    0.25
    PP_15     loss_15   1
    PP_15     tl_use_15  -1
    PP_15     tax_15    0.25
    PP_16     loss_16   1
    PP_16     tl_use_16  -1
    PP_16     tax_16    0.25
    PP_17     loss_17   1
    PP_17     tl_use_17  -1
    PP_17     tax_17    0.25
    PP_18     loss_18   1
    PP_18     tl_use_18  -1
    PP_18     tax_18    0.25
    PP_19     loss_19   1
    PP_19     tl_use_19  -1
    PP_19     tax_19    0.25
    PP_20     loss_20   1
    PP_20     tl_use_20  -1
    PP_20     tax_20    0.25
    PP_21     loss_21   1
    PP_21     tl_use_21  -1
    PP_21     tax_21    0.25
    PP_22     loss_22   1
    PP_22     tl_use_22  -1
    PP_22     tax_22    0.25
    PP_23     loss_23   1
    PP_23     tl_use_23  -1
    PP_23     tax_23    0.25
    PP_24     loss_24   1
    PP_24     tl_use_24  -1
    PP_24     tax_24    0.25
    PP_25     loss_25   1
    PP_25     tl_use_25  -1
    PP_25     tax_25    0.25
    PP_26     loss_26   1
    PP_26     tl_use_26  -1
    PP_26     tax_26    0.25
    PP_27     loss_27   1
    PP_27     tl_use_27  -1
    PP_27     tax_27    0.25
    PP_28     loss_28   1
    PP_28     tl_use_28  -1
    PP_28     tax_28    0.25
    PP_29     loss_29   1
    PP_29     tl_use_29  -1
    PP_29     tax_29    0.25
    PP_30     loss_30   1
    PP_30     tl_use_30  -1
    PP_30     tax_30    0.25
    PP_31     loss_31   1
    PP_31     tl_use_31  -1
    PP_31     tax_31    0.25
    PP_32     loss_32   1
    PP_32     tl_use_32  -1
    PP_32     tax_32    0.25
    PP_33     loss_33   1
    PP_33     tl_use_33  -1
    PP_33     tax_33    0.25
    PP_34     loss_34   1
    PP_34     tl_use_34  -1
    PP_34     tax_34    0.25
    PP_35     loss_35   1
    PP_35     tl_use_35  -1
    PP_35     tax_35    0.25
    PP_36     loss_36   1
    PP_36     tl_use_36  -1
    PP_36     tax_36    0.25
    PP_37     loss_37   1
    PP_37     tl_use_37  -1
    PP_37     tax_37    0.25
    PP_38     loss_38   1
    PP_38     tl_use_38  -1
    PP_38     tax_38    0.25
    PP_39     loss_39   1
    PP_39     tl_use_39  -1
    PP_39     tax_39    0.25
    PP_40     loss_40   1
    PP_40     tl_use_40  -1
    PP_40     tax_40    0.25
    PP_41     loss_41   1
    PP_41     tl_use_41  -1
    PP_41     tax_41    0.25
    PP_42     loss_42   1
    PP_42     tl_use_42  -1
    PP_42     tax_42    0.25
    PP_43     loss_43   1
    PP_43     tl_use_43  -1
    PP_43     tax_43    0.25
    PP_44     loss_44   1
    PP_44     tl_use_44  -1
    PP_44     tax_44    0.25
    PP_45     loss_45   1
    PP_45     tl_use_45  -1
    PP_45     tax_45    0.25
    PP_46     loss_46   1
    PP_46     tl_use_46  -1
    PP_46     tax_46    0.25
    PP_47     loss_47   1
    PP_47     tl_use_47  -1
    PP_47     tax_47    0.25
    PP_48     loss_48   1
    PP_48     tl_use_48  -1
    PP_48     tax_48    0.25
    PP_49     loss_49   1
    PP_49     tl_use_49  -1
    PP_49     tax_49    0.25
    PP_50     loss_50   1
    PP_50     tl_use_50  -1
    PP_50     tax_50    0.25
    PP_51     loss_51   1
    PP_51     tl_use_51  -1
    PP_51     tax_51    0.25
    PP_52     loss_52   1
    PP_52     tl_use_52  -1
    PP_52     tax_52    0.25
    PP_53     loss_53   1
    PP_53     tl_use_53  -1
    PP_53     tax_53    0.25
    PP_54     loss_54   1
    PP_54     tl_use_54  -1
    PP_54     tax_54    0.25
    PP_55     loss_55   1
    PP_55     tl_use_55  -1
    PP_55     tax_55    0.25
    PP_56     loss_56   1
    PP_56     tl_use_56  -1
    PP_56     tax_56    0.25
    PP_57     loss_57   1
    PP_57     tl_use_57  -1
    PP_57     tax_57    0.25
    PP_58     loss_58   1
    PP_58     tl_use_58  -1
    PP_58     tax_58    0.25
    PP_59     loss_59   1
    PP_59     tl_use_59  -1
    PP_59     tax_59    0.25
    PP_60     loss_60   1
    PP_60     tl_use_60  -1
    PP_60     tax_60    0.25
    TAX_1     tax_1     -1
    TAX_1     np_1      -1
    TAX_2     tax_2     -1
    TAX_2     np_2      -1
    TAX_3     tax_3     -1
    TAX_3     np_3      -1
    TAX_4     tax_4     -1
    TAX_4     np_4      -1
    TAX_5     tax_5     -1
    TAX_5     np_5      -1
    TAX_6     tax_6     -1
    TAX_6     np_6      -1
    TAX_7     tax_7     -1
    TAX_7     np_7      -1
    TAX_8     tax_8     -1
    TAX_8     np_8      -1
    TAX_9     tax_9     -1
    TAX_9     np_9      -1
    TAX_10    tax_10    -1
    TAX_10    np_10     -1
    TAX_11    tax_11    -1
    TAX_11    np_11     -1
    TAX_12    tax_12    -1
    TAX_12    np_12     -1
    TAX_13    tax_13    -1
    TAX_13    np_13     -1
    TAX_14    tax_14    -1
    TAX_14    np_14     -1
    TAX_15    tax_15    -1
    TAX_15    np_15     -1
    TAX_16    tax_16    -1
    TAX_16    np_16     -1
    TAX_17    tax_17    -1
    TAX_17    np_17     -1
    TAX_18    tax_18    -1
    TAX_18    np_18     -1
    TAX_19    tax_19    -1
    TAX_19    np_19     -1
    TAX_20    tax_20    -1
    TAX_20    np_20     -1
    TAX_21    tax_21    -1
    TAX_21    np_21     -1
    TAX_22    tax_22    -1
    TAX_22    np_22     -1
    TAX_23    tax_23    -1
    TAX_23    np_23     -1
    TAX_24    tax_24    -1
    TAX_24    np_24     -1
    TAX_25    tax_25    -1
    TAX_25    np_25     -1
    TAX_26    tax_26    -1
    TAX_26    np_26     -1
    TAX_27    tax_27    -1
    TAX_27    np_27     -1
    TAX_28    tax_28    -1
    TAX_28    np_28     -1
    TAX_29    tax_29    -1
    TAX_29    np_29     -1
    TAX_30    tax_30    -1
    TAX_30    np_30     -1
    TAX_31    tax_31    -1
    TAX_31    np_31     -1
    TAX_32    tax_32    -1
    TAX_32    np_32     -1
    TAX_33    tax_33    -1
    TAX_33    np_33     -1
    TAX_34    tax_34    -1
    TAX_34    np_34     -1
    TAX_35    tax_35    -1
    TAX_35    np_35     -1
    TAX_36    tax_36    -1
    TAX_36    np_36     -1
    TAX_37    tax_37    -1
    TAX_37    np_37     -1
    TAX_38    tax_38    -1
    TAX_38    np_38     -1
    TAX_39    tax_39    -1
    TAX_39    np_39     -1
    TAX_40    tax_40    -1
    TAX_40    np_40     -1
    TAX_41    tax_41    -1
    TAX_41    np_41     -1
    TAX_42    tax_42    -1
    TAX_42    np_42     -1
    TAX_43    tax_43    -1
    TAX_43    np_43     -1
    TAX_44    tax_44    -1
    TAX_44    np_44     -1
    TAX_45    tax_45    -1
    TAX_45    np_45     -1
    TAX_46    tax_46    -1
    TAX_46    np_46     -1
    TAX_47    tax_47    -1
    TAX_47    np_47     -1
    TAX_48    tax_48    -1
    TAX_48    np_48     -1
    TAX_49    tax_49    -1
    TAX_49    np_49     -1
    TAX_50    tax_50    -1
    TAX_50    np_50     -1
    TAX_51    tax_51    -1
    TAX_51    np_51     -1
    TAX_52    tax_52    -1
    TAX_52    np_52     -1
    TAX_53    tax_53    -1
    TAX_53    np_53     -1
    TAX_54    tax_54    -1
    TAX_54    np_54     -1
    TAX_55    tax_55    -1
    TAX_55    np_55     -1
    TAX_56    tax_56    -1
    TAX_56    np_56     -1
    TAX_57    tax_57    -1
    TAX_57    np_57     -1
    TAX_58    tax_58    -1
    TAX_58    np_58     -1
    TAX_59    tax_59    -1
    TAX_59    np_59     -1
    TAX_60    tax_60    -1
    TAX_60    np_60     -1
    NP_1      capital_1  -1
    NP_1      np_1      -1
    NP_2      capital_2  1
    NP_2      np_2      -1
    NP_3      capital_3  1
    NP_3      np_3      -1
    NP_4      capital_4  1
    NP_4      np_4      -1
    NP_5      capital_5  1
    NP_5      np_5      -1
    NP_6      capital_6  1
    NP_6      np_6      -1
    NP_7      capital_7  1
    NP_7      np_7      -1
    NP_8      capital_8  1
    NP_8      np_8      -1
    NP_9      capital_9  1
    NP_9      np_9      -1
    NP_10     capital_10  1
    NP_10     np_10     -1
    NP_11     capital_11  1
    NP_11     np_11     -1
    NP_12     capital_12  1
    NP_12     np_12     -1
    NP_13     capital_13  1
    NP_13     np_13     -1
    NP_14     capital_14  1
    NP_14     np_14     -1
    NP_15     capital_15  1
    NP_15     np_15     -1
    NP_16     capital_16  1
    NP_16     np_16     -1
    NP_17     capital_17  1
    NP_17     np_17     -1
    NP_18     capital_18  1
    NP_18     np_18     -1
    NP_19     capital_19  1
    NP_19     np_19     -1
    NP_20     capital_20  1
    NP_20     np_20     -1
    NP_21     capital_21  1
    NP_21     np_21     -1
    NP_22     capital_22  1
    NP_22     np_22     -1
    NP_23     capital_23  1
    NP_23     np_23     -1
    NP_24     capital_24  1
    NP_24     np_24     -1
    NP_25     capital_25  1
    NP_25     np_25     -1
    NP_26     capital_26  1
    NP_26     np_26     -1
    NP_27     capital_27  1
    NP_27     np_27     -1
    NP_28     capital_28  1
    NP_28     np_28     -1
    NP_29     capital_29  1
    NP_29     np_29     -1
    NP_30     capital_30  1
    NP_30     np_30     -1
    NP_31     capital_31  1
    NP_31     np_31     -1
    NP_32     capital_32  1
    NP_32     np_32     -1
    NP_33     capital_33  1
    NP_33     np_33     -1
    NP_34     capital_34  1
    NP_34     np_34     -1
    NP_35     capital_35  1
    NP_35     np_35     -1
    NP_36     capital_36  1
    NP_36     np_36     -1
    NP_37     capital_37  1
    NP_37     np_37     -1
    NP_38     capital_38  1
    NP_38     np_38     -1
    NP_39     capital_39  1
    NP_39     np_39     -1
    NP_40     capital_40  1
    NP_40     np_40     -1
    NP_41     capital_41  1
    NP_41     np_41     -1
    NP_42     capital_42  1
    NP_42     np_42     -1
    NP_43     capital_43  1
    NP_43     np_43     -1
    NP_44     capital_44  1
    NP_44     np_44     -1
    NP_45     capital_45  1
    NP_45     np_45     -1
    NP_46     capital_46  1
    NP_46     np_46     -1
    NP_47     capital_47  1
    NP_47     np_47     -1
    NP_48     capital_48  1
    NP_48     np_48     -1
    NP_49     capital_49  1
    NP_49     np_49     -1
    NP_50     capital_50  1
    NP_50     np_50     -1
    NP_51     capital_51  1
    NP_51     np_51     -1
    NP_52     capital_52  1
    NP_52     np_52     -1
    NP_53     capital_53  1
    NP_53     np_53     -1
    NP_54     capital_54  1
    NP_54     np_54     -1
    NP_55     capital_55  1
    NP_55     np_55     -1
    NP_56     capital_56  1
    NP_56     np_56     -1
    NP_57     capital_57  1
    NP_57     np_57     -1
    NP_58     capital_58  1
    NP_58     np_58     -1
    NP_59     capital_59  1
    NP_59     np_59     -1
    NP_60     capital_60  1
    NP_60     np_60     -1
    RWA_1     rwa_1     1
    RWA_1     cap_min_1  -0.105
    RWA_1     cap_buf_1  -0.125
    RWA_2     rwa_2     1
    RWA_2     cap_min_2  -0.105
    RWA_2     cap_buf_2  -0.125
    RWA_3     rwa_3     1
    RWA_3     cap_min_3  -0.105
    RWA_3     cap_buf_3  -0.125
    RWA_4     rwa_4     1
    RWA_4     cap_min_4  -0.105
    RWA_4     cap_buf_4  -0.125
    RWA_5     rwa_5     1
    RWA_5     cap_min_5  -0.105
    RWA_5     cap_buf_5  -0.125
    RWA_6     rwa_6     1
    RWA_6     cap_min_6  -0.105
    RWA_6     cap_buf_6  -0.125
    RWA_7     rwa_7     1
    RWA_7     cap_min_7  -0.105
    RWA_7     cap_buf_7  -0.125
    RWA_8     rwa_8     1
    RWA_8     cap_min_8  -0.105
    RWA_8     cap_buf_8  -0.125
    RWA_9     rwa_9     1
    RWA_9     cap_min_9  -0.105
    RWA_9     cap_buf_9  -0.125
    RWA_10    rwa_10    1
    RWA_10    cap_min_10  -0.105
    RWA_10    cap_buf_10  -0.125
    RWA_11    rwa_11    1
    RWA_11    cap_min_11  -0.105
    RWA_11    cap_buf_11  -0.125
    RWA_12    rwa_12    1
    RWA_12    cap_min_12  -0.105
    RWA_12    cap_buf_12  -0.125
    RWA_13    rwa_13    1
    RWA_13    cap_min_13  -0.105
    RWA_13    cap_buf_13  -0.125
    RWA_14    rwa_14    1
    RWA_14    cap_min_14  -0.105
    RWA_14    cap_buf_14  -0.125
    RWA_15    rwa_15    1
    RWA_15    cap_min_15  -0.105
    RWA_15    cap_buf_15  -0.125
    RWA_16    rwa_16    1
    RWA_16    cap_min_16  -0.105
    RWA_16    cap_buf_16  -0.125
    RWA_17    rwa_17    1
    RWA_17    cap_min_17  -0.105
    RWA_17    cap_buf_17  -0.125
    RWA_18    rwa_18    1
    RWA_18    cap_min_18  -0.105
    RWA_18    cap_buf_18  -0.125
    RWA_19    rwa_19    1
    RWA_19    cap_min_19  -0.105
    RWA_19    cap_buf_19  -0.125
    RWA_20    rwa_20    1
    RWA_20    cap_min_20  -0.105
    RWA_20    cap_buf_20  -0.125
    RWA_21    rwa_21    1
    RWA_21    cap_min_21  -0.105
    RWA_21    cap_buf_21  -0.125
    RWA_22    rwa_22    1
    RWA_22    cap_min_22  -0.105
    RWA_22    cap_buf_22  -0.125
    RWA_23    rwa_23    1
    RWA_23    cap_min_23  -0.105
    RWA_23    cap_buf_23  -0.125
    RWA_24    rwa_24    1
    RWA_24    cap_min_24  -0.105
    RWA_24    cap_buf_24  -0.125
    RWA_25    rwa_25    1
    RWA_25    cap_min_25  -0.105
    RWA_25    cap_buf_25  -0.125
    RWA_26    rwa_26    1
    RWA_26    cap_min_26  -0.105
    RWA_26    cap_buf_26  -0.125
    RWA_27    rwa_27    1
    RWA_27    cap_min_27  -0.105
    RWA_27    cap_buf_27  -0.125
    RWA_28    rwa_28    1
    RWA_28    cap_min_28  -0.105
    RWA_28    cap_buf_28  -0.125
    RWA_29    rwa_29    1
    RWA_29    cap_min_29  -0.105
    RWA_29    cap_buf_29  -0.125
    RWA_30    rwa_30    1
    RWA_30    cap_min_30  -0.105
    RWA_30    cap_buf_30  -0.125
    RWA_31    rwa_31    1
    RWA_31    cap_min_31  -0.105
    RWA_31    cap_buf_31  -0.125
    RWA_32    rwa_32    1
    RWA_32    cap_min_32  -0.105
    RWA_32    cap_buf_32  -0.125
    RWA_33    rwa_33    1
    RWA_33    cap_min_33  -0.105
    RWA_33    cap_buf_33  -0.125
    RWA_34    rwa_34    1
    RWA_34    cap_min_34  -0.105
    RWA_34    cap_buf_34  -0.125
    RWA_35    rwa_35    1
    RWA_35    cap_min_35  -0.105
    RWA_35    cap_buf_35  -0.125
    RWA_36    rwa_36    1
    RWA_36    cap_min_36  -0.105
    RWA_36    cap_buf_36  -0.125
    RWA_37    rwa_37    1
    RWA_37    cap_min_37  -0.105
    RWA_37    cap_buf_37  -0.125
    RWA_38    rwa_38    1
    RWA_38    cap_min_38  -0.105
    RWA_38    cap_buf_38  -0.125
    RWA_39    rwa_39    1
    RWA_39    cap_min_39  -0.105
    RWA_39    cap_buf_39  -0.125
    RWA_40    rwa_40    1
    RWA_40    cap_min_40  -0.105
    RWA_40    cap_buf_40  -0.125
    RWA_41    rwa_41    1
    RWA_41    cap_min_41  -0.105
    RWA_41    cap_buf_41  -0.125
    RWA_42    rwa_42    1
    RWA_42    cap_min_42  -0.105
    RWA_42    cap_buf_42  -0.125
    RWA_43    rwa_43    1
    RWA_43    cap_min_43  -0.105
    RWA_43    cap_buf_43  -0.125
    RWA_44    rwa_44    1
    RWA_44    cap_min_44  -0.105
    RWA_44    cap_buf_44  -0.125
    RWA_45    rwa_45    1
    RWA_45    cap_min_45  -0.105
    RWA_45    cap_buf_45  -0.125
    RWA_46    rwa_46    1
    RWA_46    cap_min_46  -0.105
    RWA_46    cap_buf_46  -0.125
    RWA_47    rwa_47    1
    RWA_47    cap_min_47  -0.105
    RWA_47    cap_buf_47  -0.125
    RWA_48    rwa_48    1
    RWA_48    cap_min_48  -0.105
    RWA_48    cap_buf_48  -0.125
    RWA_49    rwa_49    1
    RWA_49    cap_min_49  -0.105
    RWA_49    cap_buf_49  -0.125
    RWA_50    rwa_50    1
    RWA_50    cap_min_50  -0.105
    RWA_50    cap_buf_50  -0.125
    RWA_51    rwa_51    1
    RWA_51    cap_min_51  -0.105
    RWA_51    cap_buf_51  -0.125
    RWA_52    rwa_52    1
    RWA_52    cap_min_52  -0.105
    RWA_52    cap_buf_52  -0.125
    RWA_53    rwa_53    1
    RWA_53    cap_min_53  -0.105
    RWA_53    cap_buf_53  -0.125
    RWA_54    rwa_54    1
    RWA_54    cap_min_54  -0.105
    RWA_54    cap_buf_54  -0.125
    RWA_55    rwa_55    1
    RWA_55    cap_min_55  -0.105
    RWA_55    cap_buf_55  -0.125
    RWA_56    rwa_56    1
    RWA_56    cap_min_56  -0.105
    RWA_56    cap_buf_56  -0.125
    RWA_57    rwa_57    1
    RWA_57    cap_min_57  -0.105
    RWA_57    cap_buf_57  -0.125
    RWA_58    rwa_58    1
    RWA_58    cap_min_58  -0.105
    RWA_58    cap_buf_58  -0.125
    RWA_59    rwa_59    1
    RWA_59    cap_min_59  -0.105
    RWA_59    cap_buf_59  -0.125
    RWA_60    rwa_60    1
    RWA_60    cap_min_60  -0.105
    RWA_60    cap_buf_60  -0.125
    RWA_60    end_capital  -0.13500000000000001
    OUT_1     out_1     -1
    OUT_1     lcr_min_1  -1
    OUT_1     lcr_cap_min_1  -0.25
    OUT_1     lcr_buf_1  -1.2
    OUT_1     lcr_cap_buf_1  -0.29999999999999999
    OUT_2     out_2     -1
    OUT_2     lcr_min_2  -1
    OUT_2     lcr_cap_min_2  -0.25
    OUT_2     lcr_buf_2  -1.2
    OUT_2     lcr_cap_buf_2  -0.29999999999999999
    OUT_3     out_3     -1
    OUT_3     lcr_min_3  -1
    OUT_3     lcr_cap_min_3  -0.25
    OUT_3     lcr_buf_3  -1.2
    OUT_3     lcr_cap_buf_3  -0.29999999999999999
    OUT_4     out_4     -1
    OUT_4     lcr_min_4  -1
    OUT_4     lcr_cap_min_4  -0.25
    OUT_4     lcr_buf_4  -1.2
    OUT_4     lcr_cap_buf_4  -0.29999999999999999
    OUT_5     out_5     -1
    OUT_5     lcr_min_5  -1
    OUT_5     lcr_cap_min_5  -0.25
    OUT_5     lcr_buf_5  -1.2
    OUT_5     lcr_cap_buf_5  -0.29999999999999999
    OUT_6     out_6     -1
    OUT_6     lcr_min_6  -1
    OUT_6     lcr_cap_min_6  -0.25
    OUT_6     lcr_buf_6  -1.2
    OUT_6     lcr_cap_buf_6  -0.29999999999999999
    OUT_7     out_7     -1
    OUT_7     lcr_min_7  -1
    OUT_7     lcr_cap_min_7  -0.25
    OUT_7     lcr_buf_7  -1.2
    OUT_7     lcr_cap_buf_7  -0.29999999999999999
    OUT_8     out_8     -1
    OUT_8     lcr_min_8  -1
    OUT_8     lcr_cap_min_8  -0.25
    OUT_8     lcr_buf_8  -1.2
    OUT_8     lcr_cap_buf_8  -0.29999999999999999
    OUT_9     out_9     -1
    OUT_9     lcr_min_9  -1
    OUT_9     lcr_cap_min_9  -0.25
    OUT_9     lcr_buf_9  -1.2
    OUT_9     lcr_cap_buf_9  -0.29999999999999999
    OUT_10    out_10    -1
    OUT_10    lcr_min_10  -1
    OUT_10    lcr_cap_min_10  -0.25
    OUT_10    lcr_buf_10  -1.2
    OUT_10    lcr_cap_buf_10  -0.29999999999999999
    OUT_11    out_11    -1
    OUT_11    lcr_min_11  -1
    OUT_11    lcr_cap_min_11  -0.25
    OUT_11    lcr_buf_11  -1.2
    OUT_11    lcr_cap_buf_11  -0.29999999999999999
    OUT_12    out_12    -1
    OUT_12    lcr_min_12  -1
    OUT_12    lcr_cap_min_12  -0.25
    OUT_12    lcr_buf_12  -1.2
    OUT_12    lcr_cap_buf_12  -0.29999999999999999
    OUT_13    out_13    -1
    OUT_13    lcr_min_13  -1
    OUT_13    lcr_cap_min_13  -0.25
    OUT_13    lcr_buf_13  -1.2
    OUT_13    lcr_cap_buf_13  -0.29999999999999999
    OUT_14    out_14    -1
    OUT_14    lcr_min_14  -1
    OUT_14    lcr_cap_min_14  -0.25
    OUT_14    lcr_buf_14  -1.2
    OUT_14    lcr_cap_buf_14  -0.29999999999999999
    OUT_15    out_15    -1
    OUT_15    lcr_min_15  -1
    OUT_15    lcr_cap_min_15  -0.25
    OUT_15    lcr_buf_15  -1.2
    OUT_15    lcr_cap_buf_15  -0.29999999999999999
    OUT_16    out_16    -1
    OUT_16    lcr_min_16  -1
    OUT_16    lcr_cap_min_16  -0.25
    OUT_16    lcr_buf_16  -1.2
    OUT_16    lcr_cap_buf_16  -0.29999999999999999
    OUT_17    out_17    -1
    OUT_17    lcr_min_17  -1
    OUT_17    lcr_cap_min_17  -0.25
    OUT_17    lcr_buf_17  -1.2
    OUT_17    lcr_cap_buf_17  -0.29999999999999999
    OUT_18    out_18    -1
    OUT_18    lcr_min_18  -1
    OUT_18    lcr_cap_min_18  -0.25
    OUT_18    lcr_buf_18  -1.2
    OUT_18    lcr_cap_buf_18  -0.29999999999999999
    OUT_19    out_19    -1
    OUT_19    lcr_min_19  -1
    OUT_19    lcr_cap_min_19  -0.25
    OUT_19    lcr_buf_19  -1.2
    OUT_19    lcr_cap_buf_19  -0.29999999999999999
    OUT_20    out_20    -1
    OUT_20    lcr_min_20  -1
    OUT_20    lcr_cap_min_20  -0.25
    OUT_20    lcr_buf_20  -1.2
    OUT_20    lcr_cap_buf_20  -0.29999999999999999
    OUT_21    out_21    -1
    OUT_21    lcr_min_21  -1
    OUT_21    lcr_cap_min_21  -0.25
    OUT_21    lcr_buf_21  -1.2
    OUT_21    lcr_cap_buf_21  -0.29999999999999999
    OUT_22    out_22    -1
    OUT_22    lcr_min_22  -1
    OUT_22    lcr_cap_min_22  -0.25
    OUT_22    lcr_buf_22  -1.2
    OUT_22    lcr_cap_buf_22  -0.29999999999999999
    OUT_23    out_23    -1
    OUT_23    lcr_min_23  -1
    OUT_23    lcr_cap_min_23  -0.25
    OUT_23    lcr_buf_23  -1.2
    OUT_23    lcr_cap_buf_23  -0.29999999999999999
    OUT_24    out_24    -1
    OUT_24    lcr_min_24  -1
    OUT_24    lcr_cap_min_24  -0.25
    OUT_24    lcr_buf_24  -1.2
    OUT_24    lcr_cap_buf_24  -0.29999999999999999
    OUT_25    out_25    -1
    OUT_25    lcr_min_25  -1
    OUT_25    lcr_cap_min_25  -0.25
    OUT_25    lcr_buf_25  -1.2
    OUT_25    lcr_cap_buf_25  -0.29999999999999999
    OUT_26    out_26    -1
    OUT_26    lcr_min_26  -1
    OUT_26    lcr_cap_min_26  -0.25
    OUT_26    lcr_buf_26  -1.2
    OUT_26    lcr_cap_buf_26  -0.29999999999999999
    OUT_27    out_27    -1
    OUT_27    lcr_min_27  -1
    OUT_27    lcr_cap_min_27  -0.25
    OUT_27    lcr_buf_27  -1.2
    OUT_27    lcr_cap_buf_27  -0.29999999999999999
    OUT_28    out_28    -1
    OUT_28    lcr_min_28  -1
    OUT_28    lcr_cap_min_28  -0.25
    OUT_28    lcr_buf_28  -1.2
    OUT_28    lcr_cap_buf_28  -0.29999999999999999
    OUT_29    out_29    -1
    OUT_29    lcr_min_29  -1
    OUT_29    lcr_cap_min_29  -0.25
    OUT_29    lcr_buf_29  -1.2
    OUT_29    lcr_cap_buf_29  -0.29999999999999999
    OUT_30    out_30    -1
    OUT_30    lcr_min_30  -1
    OUT_30    lcr_cap_min_30  -0.25
    OUT_30    lcr_buf_30  -1.2
    OUT_30    lcr_cap_buf_30  -0.29999999999999999
    OUT_31    out_31    -1
    OUT_31    lcr_min_31  -1
    OUT_31    lcr_cap_min_31  -0.25
    OUT_31    lcr_buf_31  -1.2
    OUT_31    lcr_cap_buf_31  -0.29999999999999999
    OUT_32    out_32    -1
    OUT_32    lcr_min_32  -1
    OUT_32    lcr_cap_min_32  -0.25
    OUT_32    lcr_buf_32  -1.2
    OUT_32    lcr_cap_buf_32  -0.29999999999999999
    OUT_33    out_33    -1
    OUT_33    lcr_min_33  -1
    OUT_33    lcr_cap_min_33  -0.25
    OUT_33    lcr_buf_33  -1.2
    OUT_33    lcr_cap_buf_33  -0.29999999999999999
    OUT_34    out_34    -1
    OUT_34    lcr_min_34  -1
    OUT_34    lcr_cap_min_34  -0.25
    OUT_34    lcr_buf_34  -1.2
    OUT_34    lcr_cap_buf_34  -0.29999999999999999
    OUT_35    out_35    -1
    OUT_35    lcr_min_35  -1
    OUT_35    lcr_cap_min_35  -0.25
    OUT_35    lcr_buf_35  -1.2
    OUT_35    lcr_cap_buf_35  -0.29999999999999999
    OUT_36    out_36    -1
    OUT_36    lcr_min_36  -1
    OUT_36    lcr_cap_min_36  -0.25
    OUT_36    lcr_buf_36  -1.2
    OUT_36    lcr_cap_buf_36  -0.29999999999999999
    OUT_37    out_37    -1
    OUT_37    lcr_min_37  -1
    OUT_37    lcr_cap_min_37  -0.25
    OUT_37    lcr_buf_37  -1.2
    OUT_37    lcr_cap_buf_37  -0.29999999999999999
    OUT_38    out_38    -1
    OUT_38    lcr_min_38  -1
    OUT_38    lcr_cap_min_38  -0.25
    OUT_38    lcr_buf_38  -1.2
    OUT_38    lcr_cap_buf_38  -0.29999999999999999
    OUT_39    out_39    -1
    OUT_39    lcr_min_39  -1
    OUT_39    lcr_cap_min_39  -0.25
    OUT_39    lcr_buf_39  -1.2
    OUT_39    lcr_cap_buf_39  -0.29999999999999999
    OUT_40    out_40    -1
    OUT_40    lcr_min_40  -1
    OUT_40    lcr_cap_min_40  -0.25
    OUT_40    lcr_buf_40  -1.2
    OUT_40    lcr_cap_buf_40  -0.29999999999999999
    OUT_41    out_41    -1
    OUT_41    lcr_min_41  -1
    OUT_41    lcr_cap_min_41  -0.25
    OUT_41    lcr_buf_41  -1.2
    OUT_41    lcr_cap_buf_41  -0.29999999999999999
    OUT_42    out_42    -1
    OUT_42    lcr_min_42  -1
    OUT_42    lcr_cap_min_42  -0.25
    OUT_42    lcr_buf_42  -1.2
    OUT_42    lcr_cap_buf_42  -0.29999999999999999
    OUT_43    out_43    -1
    OUT_43    lcr_min_43  -1
    OUT_43    lcr_cap_min_43  -0.25
    OUT_43    lcr_buf_43  -1.2
    OUT_43    lcr_cap_buf_43  -0.29999999999999999
    OUT_44    out_44    -1
    OUT_44    lcr_min_44  -1
    OUT_44    lcr_cap_min_44  -0.25
    OUT_44    lcr_buf_44  -1.2
    OUT_44    lcr_cap_buf_44  -0.29999999999999999
    OUT_45    out_45    -1
    OUT_45    lcr_min_45  -1
    OUT_45    lcr_cap_min_45  -0.25
    OUT_45    lcr_buf_45  -1.2
    OUT_45    lcr_cap_buf_45  -0.29999999999999999
    OUT_46    out_46    -1
    OUT_46    lcr_min_46  -1
    OUT_46    lcr_cap_min_46  -0.25
    OUT_46    lcr_buf_46  -1.2
    OUT_46    lcr_cap_buf_46  -0.29999999999999999
    OUT_47    out_47    -1
    OUT_47    lcr_min_47  -1
    OUT_47    lcr_cap_min_47  -0.25
    OUT_47    lcr_buf_47  -1.2
    OUT_47    lcr_cap_buf_47  -0.29999999999999999
    OUT_48    out_48    -1
    OUT_48    lcr_min_48  -1
    OUT_48    lcr_cap_min_48  -0.25
    OUT_48    lcr_buf_48  -1.2
    OUT_48    lcr_cap_buf_48  -0.29999999999999999
    OUT_49    out_49    -1
    OUT_49    lcr_min_49  -1
    OUT_49    lcr_cap_min_49  -0.25
    OUT_49    lcr_buf_49  -1.2
    OUT_49    lcr_cap_buf_49  -0.29999999999999999
    OUT_50    out_50    -1
    OUT_50    lcr_min_50  -1
    OUT_50    lcr_cap_min_50  -0.25
    OUT_50    lcr_buf_50  -1.2
    OUT_50    lcr_cap_buf_50  -0.29999999999999999
    OUT_51    out_51    -1
    OUT_51    lcr_min_51  -1
    OUT_51    lcr_cap_min_51  -0.25
    OUT_51    lcr_buf_51  -1.2
    OUT_51    lcr_cap_buf_51  -0.29999999999999999
    OUT_52    out_52    -1
    OUT_52    lcr_min_52  -1
    OUT_52    lcr_cap_min_52  -0.25
    OUT_52    lcr_buf_52  -1.2
    OUT_52    lcr_cap_buf_52  -0.29999999999999999
    OUT_53    out_53    -1
    OUT_53    lcr_min_53  -1
    OUT_53    lcr_cap_min_53  -0.25
    OUT_53    lcr_buf_53  -1.2
    OUT_53    lcr_cap_buf_53  -0.29999999999999999
    OUT_54    out_54    -1
    OUT_54    lcr_min_54  -1
    OUT_54    lcr_cap_min_54  -0.25
    OUT_54    lcr_buf_54  -1.2
    OUT_54    lcr_cap_buf_54  -0.29999999999999999
    OUT_55    out_55    -1
    OUT_55    lcr_min_55  -1
    OUT_55    lcr_cap_min_55  -0.25
    OUT_55    lcr_buf_55  -1.2
    OUT_55    lcr_cap_buf_55  -0.29999999999999999
    OUT_56    out_56    -1
    OUT_56    lcr_min_56  -1
    OUT_56    lcr_cap_min_56  -0.25
    OUT_56    lcr_buf_56  -1.2
    OUT_56    lcr_cap_buf_56  -0.29999999999999999
    OUT_57    out_57    -1
    OUT_57    lcr_min_57  -1
    OUT_57    lcr_cap_min_57  -0.25
    OUT_57    lcr_buf_57  -1.2
    OUT_57    lcr_cap_buf_57  -0.29999999999999999
    OUT_58    out_58    -1
    OUT_58    lcr_min_58  -1
    OUT_58    lcr_cap_min_58  -0.25
    OUT_58    lcr_buf_58  -1.2
    OUT_58    lcr_cap_buf_58  -0.29999999999999999
    OUT_59    out_59    -1
    OUT_59    lcr_min_59  -1
    OUT_59    lcr_cap_min_59  -0.25
    OUT_59    lcr_buf_59  -1.2
    OUT_59    lcr_cap_buf_59  -0.29999999999999999
    OUT_60    out_60    -1
    OUT_60    lcr_min_60  -1
    OUT_60    lcr_cap_min_60  -0.25
    OUT_60    lcr_buf_60  -1.2
    OUT_60    lcr_cap_buf_60  -0.29999999999999999
    IN_1      in_1      -1
    IN_1      lcr_min_1  1
    IN_1      lcr_buf_1  1.2
    IN_2      in_2      -1
    IN_2      lcr_min_2  1
    IN_2      lcr_buf_2  1.2
    IN_3      in_3      -1
    IN_3      lcr_min_3  1
    IN_3      lcr_buf_3  1.2
    IN_4      in_4      -1
    IN_4      lcr_min_4  1
    IN_4      lcr_buf_4  1.2
    IN_5      in_5      -1
    IN_5      lcr_min_5  1
    IN_5      lcr_buf_5  1.2
    IN_6      in_6      -1
    IN_6      lcr_min_6  1
    IN_6      lcr_buf_6  1.2
    IN_7      in_7      -1
    IN_7      lcr_min_7  1
    IN_7      lcr_buf_7  1.2
    IN_8      in_8      -1
    IN_8      lcr_min_8  1
    IN_8      lcr_buf_8  1.2
    IN_9      in_9      -1
    IN_9      lcr_min_9  1
    IN_9      lcr_buf_9  1.2
    IN_10     in_10     -1
    IN_10     lcr_min_10  1
    IN_10     lcr_buf_10  1.2
    IN_11     in_11     -1
    IN_11     lcr_min_11  1
    IN_11     lcr_buf_11  1.2
    IN_12     in_12     -1
    IN_12     lcr_min_12  1
    IN_12     lcr_buf_12  1.2
    IN_13     in_13     -1
    IN_13     lcr_min_13  1
    IN_13     lcr_buf_13  1.2
    IN_14     in_14     -1
    IN_14     lcr_min_14  1
    IN_14     lcr_buf_14  1.2
    IN_15     in_15     -1
    IN_15     lcr_min_15  1
    IN_15     lcr_buf_15  1.2
    IN_16     in_16     -1
    IN_16     lcr_min_16  1
    IN_16     lcr_buf_16  1.2
    IN_17     in_17     -1
    IN_17     lcr_min_17  1
    IN_17     lcr_buf_17  1.2
    IN_18     in_18     -1
    IN_18     lcr_min_18  1
    IN_18     lcr_buf_18  1.2
    IN_19     in_19     -1
    IN_19     lcr_min_19  1
    IN_19     lcr_buf_19  1.2
    IN_20     in_20     -1
    IN_20     lcr_min_20  1
    IN_20     lcr_buf_20  1.2
    IN_21     in_21     -1
    IN_21     lcr_min_21  1
    IN_21     lcr_buf_21  1.2
    IN_22     in_22     -1
    IN_22     lcr_min_22  1
    IN_22     lcr_buf_22  1.2
    IN_23     in_23     -1
    IN_23     lcr_min_23  1
    IN_23     lcr_buf_23  1.2
    IN_24     in_24     -1
    IN_24     lcr_min_24  1
    IN_24     lcr_buf_24  1.2
    IN_25     in_25     -1
    IN_25     lcr_min_25  1
    IN_25     lcr_buf_25  1.2
    IN_26     in_26     -1
    IN_26     lcr_min_26  1
    IN_26     lcr_buf_26  1.2
    IN_27     in_27     -1
    IN_27     lcr_min_27  1
    IN_27     lcr_buf_27  1.2
    IN_28     in_28     -1
    IN_28     lcr_min_28  1
    IN_28     lcr_buf_28  1.2
    IN_29     in_29     -1
    IN_29     lcr_min_29  1
    IN_29     lcr_buf_29  1.2
    IN_30     in_30     -1
    IN_30     lcr_min_30  1
    IN_30     lcr_buf_30  1.2
    IN_31     in_31     -1
    IN_31     lcr_min_31  1
    IN_31     lcr_buf_31  1.2
    IN_32     in_32     -1
    IN_32     lcr_min_32  1
    IN_32     lcr_buf_32  1.2
    IN_33     in_33     -1
    IN_33     lcr_min_33  1
    IN_33     lcr_buf_33  1.2
    IN_34     in_34     -1
    IN_34     lcr_min_34  1
    IN_34     lcr_buf_34  1.2
    IN_35     in_35     -1
    IN_35     lcr_min_35  1
    IN_35     lcr_buf_35  1.2
    IN_36     in_36     -1
    IN_36     lcr_min_36  1
    IN_36     lcr_buf_36  1.2
    IN_37     in_37     -1
    IN_37     lcr_min_37  1
    IN_37     lcr_buf_37  1.2
    IN_38     in_38     -1
    IN_38     lcr_min_38  1
    IN_38     lcr_buf_38  1.2
    IN_39     in_39     -1
    IN_39     lcr_min_39  1
    IN_39     lcr_buf_39  1.2
    IN_40     in_40     -1
    IN_40     lcr_min_40  1
    IN_40     lcr_buf_40  1.2
    IN_41     in_41     -1
    IN_41     lcr_min_41  1
    IN_41     lcr_buf_41  1.2
    IN_42     in_42     -1
    IN_42     lcr_min_42  1
    IN_42     lcr_buf_42  1.2
    IN_43     in_43     -1
    IN_43     lcr_min_43  1
    IN_43     lcr_buf_43  1.2
    IN_44     in_44     -1
    IN_44     lcr_min_44  1
    IN_44     lcr_buf_44  1.2
    IN_45     in_45     -1
    IN_45     lcr_min_45  1
    IN_45     lcr_buf_45  1.2
    IN_46     in_46     -1
    IN_46     lcr_min_46  1
    IN_46     lcr_buf_46  1.2
    IN_47     in_47     -1
    IN_47     lcr_min_47  1
    IN_47     lcr_buf_47  1.2
    IN_48     in_48     -1
    IN_48     lcr_min_48  1
    IN_48     lcr_buf_48  1.2
    IN_49     in_49     -1
    IN_49     lcr_min_49  1
    IN_49     lcr_buf_49  1.2
    IN_50     in_50     -1
    IN_50     lcr_min_50  1
    IN_50     lcr_buf_50  1.2
    IN_51     in_51     -1
    IN_51     lcr_min_51  1
    IN_51     lcr_buf_51  1.2
    IN_52     in_52     -1
    IN_52     lcr_min_52  1
    IN_52     lcr_buf_52  1.2
    IN_53     in_53     -1
    IN_53     lcr_min_53  1
    IN_53     lcr_buf_53  1.2
    IN_54     in_54     -1
    IN_54     lcr_min_54  1
    IN_54     lcr_buf_54  1.2
    IN_55     in_55     -1
    IN_55     lcr_min_55  1
    IN_55     lcr_buf_55  1.2
    IN_56     in_56     -1
    IN_56     lcr_min_56  1
    IN_56     lcr_buf_56  1.2
    IN_57     in_57     -1
    IN_57     lcr_min_57  1
    IN_57     lcr_buf_57  1.2
    IN_58     in_58     -1
    IN_58     lcr_min_58  1
    IN_58     lcr_buf_58  1.2
    IN_59     in_59     -1
    IN_59     lcr_min_59  1
    IN_59     lcr_buf_59  1.2
    IN_60     in_60     -1
    IN_60     lcr_min_60  1
    IN_60     lcr_buf_60  1.2
    ASF_1     asf_1     -1
    ASF_1     nsfr_min_1  1
    ASF_1     nsfr_buf_1  1
    ASF_2     asf_2     -1
    ASF_2     nsfr_min_2  1
    ASF_2     nsfr_buf_2  1
    ASF_3     asf_3     -1
    ASF_3     nsfr_min_3  1
    ASF_3     nsfr_buf_3  1
    ASF_4     asf_4     -1
    ASF_4     nsfr_min_4  1
    ASF_4     nsfr_buf_4  1
    ASF_5     asf_5     -1
    ASF_5     nsfr_min_5  1
    ASF_5     nsfr_buf_5  1
    ASF_6     asf_6     -1
    ASF_6     nsfr_min_6  1
    ASF_6     nsfr_buf_6  1
    ASF_7     asf_7     -1
    ASF_7     nsfr_min_7  1
    ASF_7     nsfr_buf_7  1
    ASF_8     asf_8     -1
    ASF_8     nsfr_min_8  1
    ASF_8     nsfr_buf_8  1
    ASF_9     asf_9     -1
    ASF_9     nsfr_min_9  1
    ASF_9     nsfr_buf_9  1
    ASF_10    asf_10    -1
    ASF_10    nsfr_min_10  1
    ASF_10    nsfr_buf_10  1
    ASF_11    asf_11    -1
    ASF_11    nsfr_min_11  1
    ASF_11    nsfr_buf_11  1
    ASF_12    asf_12    -1
    ASF_12    nsfr_min_12  1
    ASF_12    nsfr_buf_12  1
    ASF_13    asf_13    -1
    ASF_13    nsfr_min_13  1
    ASF_13    nsfr_buf_13  1
    ASF_14    asf_14    -1
    ASF_14    nsfr_min_14  1
    ASF_14    nsfr_buf_14  1
    ASF_15    asf_15    -1
    ASF_15    nsfr_min_15  1
    ASF_15    nsfr_buf_15  1
    ASF_16    asf_16    -1
    ASF_16    nsfr_min_16  1
    ASF_16    nsfr_buf_16  1
    ASF_17    asf_17    -1
    ASF_17    nsfr_min_17  1
    ASF_17    nsfr_buf_17  1
    ASF_18    asf_18    -1
    ASF_18    nsfr_min_18  1
    ASF_18    nsfr_buf_18  1
    ASF_19    asf_19    -1
    ASF_19    nsfr_min_19  1
    ASF_19    nsfr_buf_19  1
    ASF_20    asf_20    -1
    ASF_20    nsfr_min_20  1
    ASF_20    nsfr_buf_20  1
    ASF_21    asf_21    -1
    ASF_21    nsfr_min_21  1
    ASF_21    nsfr_buf_21  1
    ASF_22    asf_22    -1
    ASF_22    nsfr_min_22  1
    ASF_22    nsfr_buf_22  1
    ASF_23    asf_23    -1
    ASF_23    nsfr_min_23  1
    ASF_23    nsfr_buf_23  1
    ASF_24    asf_24    -1
    ASF_24    nsfr_min_24  1
    ASF_24    nsfr_buf_24  1
    ASF_25    asf_25    -1
    ASF_25    nsfr_min_25  1
    ASF_25    nsfr_buf_25  1
    ASF_26    asf_26    -1
    ASF_26    nsfr_min_26  1
    ASF_26    nsfr_buf_26  1
    ASF_27    asf_27    -1
    ASF_27    nsfr_min_27  1
    ASF_27    nsfr_buf_27  1
    ASF_28    asf_28    -1
    ASF_28    nsfr_min_28  1
    ASF_28    nsfr_buf_28  1
    ASF_29    asf_29    -1
    ASF_29    nsfr_min_29  1
    ASF_29    nsfr_buf_29  1
    ASF_30    asf_30    -1
    ASF_30    nsfr_min_30  1
    ASF_30    nsfr_buf_30  1
    ASF_31    asf_31    -1
    ASF_31    nsfr_min_31  1
    ASF_31    nsfr_buf_31  1
    ASF_32    asf_32    -1
    ASF_32    nsfr_min_32  1
    ASF_32    nsfr_buf_32  1
    ASF_33    asf_33    -1
    ASF_33    nsfr_min_33  1
    ASF_33    nsfr_buf_33  1
    ASF_34    asf_34    -1
    ASF_34    nsfr_min_34  1
    ASF_34    nsfr_buf_34  1
    ASF_35    asf_35    -1
    ASF_35    nsfr_min_35  1
    ASF_35    nsfr_buf_35  1
    ASF_36    asf_36    -1
    ASF_36    nsfr_min_36  1
    ASF_36    nsfr_buf_36  1
    ASF_37    asf_37    -1
    ASF_37    nsfr_min_37  1
    ASF_37    nsfr_buf_37  1
    ASF_38    asf_38    -1
    ASF_38    nsfr_min_38  1
    ASF_38    nsfr_buf_38  1
    ASF_39    asf_39    -1
    ASF_39    nsfr_min_39  1
    ASF_39    nsfr_buf_39  1
    ASF_40    asf_40    -1
    ASF_40    nsfr_min_40  1
    ASF_40    nsfr_buf_40  1
    ASF_41    asf_41    -1
    ASF_41    nsfr_min_41  1
    ASF_41    nsfr_buf_41  1
    ASF_42    asf_42    -1
    ASF_42    nsfr_min_42  1
    ASF_42    nsfr_buf_42  1
    ASF_43    asf_43    -1
    ASF_43    nsfr_min_43  1
    ASF_43    nsfr_buf_43  1
    ASF_44    asf_44    -1
    ASF_44    nsfr_min_44  1
    ASF_44    nsfr_buf_44  1
    ASF_45    asf_45    -1
    ASF_45    nsfr_min_45  1
    ASF_45    nsfr_buf_45  1
    ASF_46    asf_46    -1
    ASF_46    nsfr_min_46  1
    ASF_46    nsfr_buf_46  1
    ASF_47    asf_47    -1
    ASF_47    nsfr_min_47  1
    ASF_47    nsfr_buf_47  1
    ASF_48    asf_48    -1
    ASF_48    nsfr_min_48  1
    ASF_48    nsfr_buf_48  1
    ASF_49    asf_49    -1
    ASF_49    nsfr_min_49  1
    ASF_49    nsfr_buf_49  1
    ASF_50    asf_50    -1
    ASF_50    nsfr_min_50  1
    ASF_50    nsfr_buf_50  1
    ASF_51    asf_51    -1
    ASF_51    nsfr_min_51  1
    ASF_51    nsfr_buf_51  1
    ASF_52    asf_52    -1
    ASF_52    nsfr_min_52  1
    ASF_52    nsfr_buf_52  1
    ASF_53    asf_53    -1
    ASF_53    nsfr_min_53  1
    ASF_53    nsfr_buf_53  1
    ASF_54    asf_54    -1
    ASF_54    nsfr_min_54  1
    ASF_54    nsfr_buf_54  1
    ASF_55    asf_55    -1
    ASF_55    nsfr_min_55  1
    ASF_55    nsfr_buf_55  1
    ASF_56    asf_56    -1
    ASF_56    nsfr_min_56  1
    ASF_56    nsfr_buf_56  1
    ASF_57    asf_57    -1
    ASF_57    nsfr_min_57  1
    ASF_57    nsfr_buf_57  1
    ASF_58    asf_58    -1
    ASF_58    nsfr_min_58  1
    ASF_58    nsfr_buf_58  1
    ASF_59    asf_59    -1
    ASF_59    nsfr_min_59  1
    ASF_59    nsfr_buf_59  1
    ASF_60    asf_60    -1
    ASF_60    nsfr_min_60  1
    ASF_60    nsfr_buf_60  1
    RSF_1     rsf_1     -1
    RSF_1     nsfr_min_1  -1
    RSF_1     nsfr_buf_1  -1.1000000000000001
    RSF_2     rsf_2     -1
    RSF_2     nsfr_min_2  -1
    RSF_2     nsfr_buf_2  -1.1000000000000001
    RSF_3     rsf_3     -1
    RSF_3     nsfr_min_3  -1
    RSF_3     nsfr_buf_3  -1.1000000000000001
    RSF_4     rsf_4     -1
    RSF_4     nsfr_min_4  -1
    RSF_4     nsfr_buf_4  -1.1000000000000001
    RSF_5     rsf_5     -1
    RSF_5     nsfr_min_5  -1
    RSF_5     nsfr_buf_5  -1.1000000000000001
    RSF_6     rsf_6     -1
    RSF_6     nsfr_min_6  -1
    RSF_6     nsfr_buf_6  -1.1000000000000001
    RSF_7     rsf_7     -1
    RSF_7     nsfr_min_7  -1
    RSF_7     nsfr_buf_7  -1.1000000000000001
    RSF_8     rsf_8     -1
    RSF_8     nsfr_min_8  -1
    RSF_8     nsfr_buf_8  -1.1000000000000001
    RSF_9     rsf_9     -1
    RSF_9     nsfr_min_9  -1
    RSF_9     nsfr_buf_9  -1.1000000000000001
    RSF_10    rsf_10    -1
    RSF_10    nsfr_min_10  -1
    RSF_10    nsfr_buf_10  -1.1000000000000001
    RSF_11    rsf_11    -1
    RSF_11    nsfr_min_11  -1
    RSF_11    nsfr_buf_11  -1.1000000000000001
    RSF_12    rsf_12    -1
    RSF_12    nsfr_min_12  -1
    RSF_12    nsfr_buf_12  -1.1000000000000001
    RSF_13    rsf_13    -1
    RSF_13    nsfr_min_13  -1
    RSF_13    nsfr_buf_13  -1.1000000000000001
    RSF_14    rsf_14    -1
    RSF_14    nsfr_min_14  -1
    RSF_14    nsfr_buf_14  -1.1000000000000001
    RSF_15    rsf_15    -1
    RSF_15    nsfr_min_15  -1
    RSF_15    nsfr_buf_15  -1.1000000000000001
    RSF_16    rsf_16    -1
    RSF_16    nsfr_min_16  -1
    RSF_16    nsfr_buf_16  -1.1000000000000001
    RSF_17    rsf_17    -1
    RSF_17    nsfr_min_17  -1
    RSF_17    nsfr_buf_17  -1.1000000000000001
    RSF_18    rsf_18    -1
    RSF_18    nsfr_min_18  -1
    RSF_18    nsfr_buf_18  -1.1000000000000001
    RSF_19    rsf_19    -1
    RSF_19    nsfr_min_19  -1
    RSF_19    nsfr_buf_19  -1.1000000000000001
    RSF_20    rsf_20    -1
    RSF_20    nsfr_min_20  -1
    RSF_20    nsfr_buf_20  -1.1000000000000001
    RSF_21    rsf_21    -1
    RSF_21    nsfr_min_21  -1
    RSF_21    nsfr_buf_21  -1.1000000000000001
    RSF_22    rsf_22    -1
    RSF_22    nsfr_min_22  -1
    RSF_22    nsfr_buf_22  -1.1000000000000001
    RSF_23    rsf_23    -1
    RSF_23    nsfr_min_23  -1
    RSF_23    nsfr_buf_23  -1.1000000000000001
    RSF_24    rsf_24    -1
    RSF_24    nsfr_min_24  -1
    RSF_24    nsfr_buf_24  -1.1000000000000001
    RSF_25    rsf_25    -1
    RSF_25    nsfr_min_25  -1
    RSF_25    nsfr_buf_25  -1.1000000000000001
    RSF_26    rsf_26    -1
    RSF_26    nsfr_min_26  -1
    RSF_26    nsfr_buf_26  -1.1000000000000001
    RSF_27    rsf_27    -1
    RSF_27    nsfr_min_27  -1
    RSF_27    nsfr_buf_27  -1.1000000000000001
    RSF_28    rsf_28    -1
    RSF_28    nsfr_min_28  -1
    RSF_28    nsfr_buf_28  -1.1000000000000001
    RSF_29    rsf_29    -1
    RSF_29    nsfr_min_29  -1
    RSF_29    nsfr_buf_29  -1.1000000000000001
    RSF_30    rsf_30    -1
    RSF_30    nsfr_min_30  -1
    RSF_30    nsfr_buf_30  -1.1000000000000001
    RSF_31    rsf_31    -1
    RSF_31    nsfr_min_31  -1
    RSF_31    nsfr_buf_31  -1.1000000000000001
    RSF_32    rsf_32    -1
    RSF_32    nsfr_min_32  -1
    RSF_32    nsfr_buf_32  -1.1000000000000001
    RSF_33    rsf_33    -1
    RSF_33    nsfr_min_33  -1
    RSF_33    nsfr_buf_33  -1.1000000000000001
    RSF_34    rsf_34    -1
    RSF_34    nsfr_min_34  -1
    RSF_34    nsfr_buf_34  -1.1000000000000001
    RSF_35    rsf_35    -1
    RSF_35    nsfr_min_35  -1
    RSF_35    nsfr_buf_35  -1.1000000000000001
    RSF_36    rsf_36    -1
    RSF_36    nsfr_min_36  -1
    RSF_36    nsfr_buf_36  -1.1000000000000001
    RSF_37    rsf_37    -1
    RSF_37    nsfr_min_37  -1
    RSF_37    nsfr_buf_37  -1.1000000000000001
    RSF_38    rsf_38    -1
    RSF_38    nsfr_min_38  -1
    RSF_38    nsfr_buf_38  -1.1000000000000001
    RSF_39    rsf_39    -1
    RSF_39    nsfr_min_39  -1
    RSF_39    nsfr_buf_39  -1.1000000000000001
    RSF_40    rsf_40    -1
    RSF_40    nsfr_min_40  -1
    RSF_40    nsfr_buf_40  -1.1000000000000001
    RSF_41    rsf_41    -1
    RSF_41    nsfr_min_41  -1
    RSF_41    nsfr_buf_41  -1.1000000000000001
    RSF_42    rsf_42    -1
    RSF_42    nsfr_min_42  -1
    RSF_42    nsfr_buf_42  -1.1000000000000001
    RSF_43    rsf_43    -1
    RSF_43    nsfr_min_43  -1
    RSF_43    nsfr_buf_43  -1.1000000000000001
    RSF_44    rsf_44    -1
    RSF_44    nsfr_min_44  -1
    RSF_44    nsfr_buf_44  -1.1000000000000001
    RSF_45    rsf_45    -1
    RSF_45    nsfr_min_45  -1
    RSF_45    nsfr_buf_45  -1.1000000000000001
    RSF_46    rsf_46    -1
    RSF_46    nsfr_min_46  -1
    RSF_46    nsfr_buf_46  -1.1000000000000001
    RSF_47    rsf_47    -1
    RSF_47    nsfr_min_47  -1
    RSF_47    nsfr_buf_47  -1.1000000000000001
    RSF_48    rsf_48    -1
    RSF_48    nsfr_min_48  -1
    RSF_48    nsfr_buf_48  -1.1000000000000001
    RSF_49    rsf_49    -1
    RSF_49    nsfr_min_49  -1
    RSF_49    nsfr_buf_49  -1.1000000000000001
    RSF_50    rsf_50    -1
    RSF_50    nsfr_min_50  -1
    RSF_50    nsfr_buf_50  -1.1000000000000001
    RSF_51    rsf_51    -1
    RSF_51    nsfr_min_51  -1
    RSF_51    nsfr_buf_51  -1.1000000000000001
    RSF_52    rsf_52    -1
    RSF_52    nsfr_min_52  -1
    RSF_52    nsfr_buf_52  -1.1000000000000001
    RSF_53    rsf_53    -1
    RSF_53    nsfr_min_53  -1
    RSF_53    nsfr_buf_53  -1.1000000000000001
    RSF_54    rsf_54    -1
    RSF_54    nsfr_min_54  -1
    RSF_54    nsfr_buf_54  -1.1000000000000001
    RSF_55    rsf_55    -1
    RSF_55    nsfr_min_55  -1
    RSF_55    nsfr_buf_55  -1.1000000000000001
    RSF_56    rsf_56    -1
    RSF_56    nsfr_min_56  -1
    RSF_56    nsfr_buf_56  -1.1000000000000001
    RSF_57    rsf_57    -1
    RSF_57    nsfr_min_57  -1
    RSF_57    nsfr_buf_57  -1.1000000000000001
    RSF_58    rsf_58    -1
    RSF_58    nsfr_min_58  -1
    RSF_58    nsfr_buf_58  -1.1000000000000001
    RSF_59    rsf_59    -1
    RSF_59    nsfr_min_59  -1
    RSF_59    nsfr_buf_59  -1.1000000000000001
    RSF_60    rsf_60    -1
    RSF_60    nsfr_min_60  -1
    RSF_60    nsfr_buf_60  -1.1000000000000001
    sP_1      Obj       -1000
    sP_1      loss_1    -1
    sP_1      tl_1      1
    sP_2      Obj       -1000
    sP_2      loss_2    -1
    sP_2      tl_2      1
    sP_3      Obj       -1000
    sP_3      loss_3    -1
    sP_3      tl_3      1
    sP_4      Obj       -1000
    sP_4      loss_4    -1
    sP_4      tl_4      1
    sP_5      Obj       -1000
    sP_5      loss_5    -1
    sP_5      tl_5      1
    sP_6      Obj       -1000
    sP_6      loss_6    -1
    sP_6      tl_6      1
    sP_7      Obj       -1000
    sP_7      loss_7    -1
    sP_7      tl_7      1
    sP_8      Obj       -1000
    sP_8      loss_8    -1
    sP_8      tl_8      1
    sP_9      Obj       -1000
    sP_9      loss_9    -1
    sP_9      tl_9      1
    sP_10     Obj       -1000
    sP_10     loss_10   -1
    sP_10     tl_10     1
    sP_11     Obj       -1000
    sP_11     loss_11   -1
    sP_11     tl_11     1
    sP_12     Obj       -1000
    sP_12     loss_12   -1
    sP_12     tl_12     1
    sP_13     Obj       -1000
    sP_13     loss_13   -1
    sP_13     tl_13     1
    sP_14     Obj       -1000
    sP_14     loss_14   -1
    sP_14     tl_14     1
    sP_15     Obj       -1000
    sP_15     loss_15   -1
    sP_15     tl_15     1
    sP_16     Obj       -1000
    sP_16     loss_16   -1
    sP_16     tl_16     1
    sP_17     Obj       -1000
    sP_17     loss_17   -1
    sP_17     tl_17     1
    sP_18     Obj       -1000
    sP_18     loss_18   -1
    sP_18     tl_18     1
    sP_19     Obj       -1000
    sP_19     loss_19   -1
    sP_19     tl_19     1
    sP_20     Obj       -1000
    sP_20     loss_20   -1
    sP_20     tl_20     1
    sP_21     Obj       -1000
    sP_21     loss_21   -1
    sP_21     tl_21     1
    sP_22     Obj       -1000
    sP_22     loss_22   -1
    sP_22     tl_22     1
    sP_23     Obj       -1000
    sP_23     loss_23   -1
    sP_23     tl_23     1
    sP_24     Obj       -1000
    sP_24     loss_24   -1
    sP_24     tl_24     1
    sP_25     Obj       -1000
    sP_25     loss_25   -1
    sP_25     tl_25     1
    sP_26     Obj       -1000
    sP_26     loss_26   -1
    sP_26     tl_26     1
    sP_27     Obj       -1000
    sP_27     loss_27   -1
    sP_27     tl_27     1
    sP_28     Obj       -1000
    sP_28     loss_28   -1
    sP_28     tl_28     1
    sP_29     Obj       -1000
    sP_29     loss_29   -1
    sP_29     tl_29     1
    sP_30     Obj       -1000
    sP_30     loss_30   -1
    sP_30     tl_30     1
    sP_31     Obj       -1000
    sP_31     loss_31   -1
    sP_31     tl_31     1
    sP_32     Obj       -1000
    sP_32     loss_32   -1
    sP_32     tl_32     1
    sP_33     Obj       -1000
    sP_33     loss_33   -1
    sP_33     tl_33     1
    sP_34     Obj       -1000
    sP_34     loss_34   -1
    sP_34     tl_34     1
    sP_35     Obj       -1000
    sP_35     loss_35   -1
    sP_35     tl_35     1
    sP_36     Obj       -1000
    sP_36     loss_36   -1
    sP_36     tl_36     1
    sP_37     Obj       -1000
    sP_37     loss_37   -1
    sP_37     tl_37     1
    sP_38     Obj       -1000
    sP_38     loss_38   -1
    sP_38     tl_38     1
    sP_39     Obj       -1000
    sP_39     loss_39   -1
    sP_39     tl_39     1
    sP_40     Obj       -1000
    sP_40     loss_40   -1
    sP_40     tl_40     1
    sP_41     Obj       -1000
    sP_41     loss_41   -1
    sP_41     tl_41     1
    sP_42     Obj       -1000
    sP_42     loss_42   -1
    sP_42     tl_42     1
    sP_43     Obj       -1000
    sP_43     loss_43   -1
    sP_43     tl_43     1
    sP_44     Obj       -1000
    sP_44     loss_44   -1
    sP_44     tl_44     1
    sP_45     Obj       -1000
    sP_45     loss_45   -1
    sP_45     tl_45     1
    sP_46     Obj       -1000
    sP_46     loss_46   -1
    sP_46     tl_46     1
    sP_47     Obj       -1000
    sP_47     loss_47   -1
    sP_47     tl_47     1
    sP_48     Obj       -1000
    sP_48     loss_48   -1
    sP_48     tl_48     1
    sP_49     Obj       -1000
    sP_49     loss_49   -1
    sP_49     tl_49     1
    sP_50     Obj       -1000
    sP_50     loss_50   -1
    sP_50     tl_50     1
    sP_51     Obj       -1000
    sP_51     loss_51   -1
    sP_51     tl_51     1
    sP_52     Obj       -1000
    sP_52     loss_52   -1
    sP_52     tl_52     1
    sP_53     Obj       -1000
    sP_53     loss_53   -1
    sP_53     tl_53     1
    sP_54     Obj       -1000
    sP_54     loss_54   -1
    sP_54     tl_54     1
    sP_55     Obj       -1000
    sP_55     loss_55   -1
    sP_55     tl_55     1
    sP_56     Obj       -1000
    sP_56     loss_56   -1
    sP_56     tl_56     1
    sP_57     Obj       -1000
    sP_57     loss_57   -1
    sP_57     tl_57     1
    sP_58     Obj       -1000
    sP_58     loss_58   -1
    sP_58     tl_58     1
    sP_59     Obj       -1000
    sP_59     loss_59   -1
    sP_59     tl_59     1
    sP_60     Obj       -1000
    sP_60     loss_60   -1
    sP_60     tl_60     1
    sK_1      Obj       -100
    sK_1      cap_min_1  1
    sK_1      cap_buf_1  1
    sK_2      Obj       -100
    sK_2      cap_min_2  1
    sK_2      cap_buf_2  1
    sK_3      Obj       -100
    sK_3      cap_min_3  1
    sK_3      cap_buf_3  1
    sK_4      Obj       -100
    sK_4      cap_min_4  1
    sK_4      cap_buf_4  1
    sK_5      Obj       -100
    sK_5      cap_min_5  1
    sK_5      cap_buf_5  1
    sK_6      Obj       -100
    sK_6      cap_min_6  1
    sK_6      cap_buf_6  1
    sK_7      Obj       -100
    sK_7      cap_min_7  1
    sK_7      cap_buf_7  1
    sK_8      Obj       -100
    sK_8      cap_min_8  1
    sK_8      cap_buf_8  1
    sK_9      Obj       -100
    sK_9      cap_min_9  1
    sK_9      cap_buf_9  1
    sK_10     Obj       -100
    sK_10     cap_min_10  1
    sK_10     cap_buf_10  1
    sK_11     Obj       -100
    sK_11     cap_min_11  1
    sK_11     cap_buf_11  1
    sK_12     Obj       -100
    sK_12     cap_min_12  1
    sK_12     cap_buf_12  1
    sK_13     Obj       -100
    sK_13     cap_min_13  1
    sK_13     cap_buf_13  1
    sK_14     Obj       -100
    sK_14     cap_min_14  1
    sK_14     cap_buf_14  1
    sK_15     Obj       -100
    sK_15     cap_min_15  1
    sK_15     cap_buf_15  1
    sK_16     Obj       -100
    sK_16     cap_min_16  1
    sK_16     cap_buf_16  1
    sK_17     Obj       -100
    sK_17     cap_min_17  1
    sK_17     cap_buf_17  1
    sK_18     Obj       -100
    sK_18     cap_min_18  1
    sK_18     cap_buf_18  1
    sK_19     Obj       -100
    sK_19     cap_min_19  1
    sK_19     cap_buf_19  1
    sK_20     Obj       -100
    sK_20     cap_min_20  1
    sK_20     cap_buf_20  1
    sK_21     Obj       -100
    sK_21     cap_min_21  1
    sK_21     cap_buf_21  1
    sK_22     Obj       -100
    sK_22     cap_min_22  1
    sK_22     cap_buf_22  1
    sK_23     Obj       -100
    sK_23     cap_min_23  1
    sK_23     cap_buf_23  1
    sK_24     Obj       -100
    sK_24     cap_min_24  1
    sK_24     cap_buf_24  1
    sK_25     Obj       -100
    sK_25     cap_min_25  1
    sK_25     cap_buf_25  1
    sK_26     Obj       -100
    sK_26     cap_min_26  1
    sK_26     cap_buf_26  1
    sK_27     Obj       -100
    sK_27     cap_min_27  1
    sK_27     cap_buf_27  1
    sK_28     Obj       -100
    sK_28     cap_min_28  1
    sK_28     cap_buf_28  1
    sK_29     Obj       -100
    sK_29     cap_min_29  1
    sK_29     cap_buf_29  1
    sK_30     Obj       -100
    sK_30     cap_min_30  1
    sK_30     cap_buf_30  1
    sK_31     Obj       -100
    sK_31     cap_min_31  1
    sK_31     cap_buf_31  1
    sK_32     Obj       -100
    sK_32     cap_min_32  1
    sK_32     cap_buf_32  1
    sK_33     Obj       -100
    sK_33     cap_min_33  1
    sK_33     cap_buf_33  1
    sK_34     Obj       -100
    sK_34     cap_min_34  1
    sK_34     cap_buf_34  1
    sK_35     Obj       -100
    sK_35     cap_min_35  1
    sK_35     cap_buf_35  1
    sK_36     Obj       -100
    sK_36     cap_min_36  1
    sK_36     cap_buf_36  1
    sK_37     Obj       -100
    sK_37     cap_min_37  1
    sK_37     cap_buf_37  1
    sK_38     Obj       -100
    sK_38     cap_min_38  1
    sK_38     cap_buf_38  1
    sK_39     Obj       -100
    sK_39     cap_min_39  1
    sK_39     cap_buf_39  1
    sK_40     Obj       -100
    sK_40     cap_min_40  1
    sK_40     cap_buf_40  1
    sK_41     Obj       -100
    sK_41     cap_min_41  1
    sK_41     cap_buf_41  1
    sK_42     Obj       -100
    sK_42     cap_min_42  1
    sK_42     cap_buf_42  1
    sK_43     Obj       -100
    sK_43     cap_min_43  1
    sK_43     cap_buf_43  1
    sK_44     Obj       -100
    sK_44     cap_min_44  1
    sK_44     cap_buf_44  1
    sK_45     Obj       -100
    sK_45     cap_min_45  1
    sK_45     cap_buf_45  1
    sK_46     Obj       -100
    sK_46     cap_min_46  1
    sK_46     cap_buf_46  1
    sK_47     Obj       -100
    sK_47     cap_min_47  1
    sK_47     cap_buf_47  1
    sK_48     Obj       -100
    sK_48     cap_min_48  1
    sK_48     cap_buf_48  1
    sK_49     Obj       -100
    sK_49     cap_min_49  1
    sK_49     cap_buf_49  1
    sK_50     Obj       -100
    sK_50     cap_min_50  1
    sK_50     cap_buf_50  1
    sK_51     Obj       -100
    sK_51     cap_min_51  1
    sK_51     cap_buf_51  1
    sK_52     Obj       -100
    sK_52     cap_min_52  1
    sK_52     cap_buf_52  1
    sK_53     Obj       -100
    sK_53     cap_min_53  1
    sK_53     cap_buf_53  1
    sK_54     Obj       -100
    sK_54     cap_min_54  1
    sK_54     cap_buf_54  1
    sK_55     Obj       -100
    sK_55     cap_min_55  1
    sK_55     cap_buf_55  1
    sK_56     Obj       -100
    sK_56     cap_min_56  1
    sK_56     cap_buf_56  1
    sK_57     Obj       -100
    sK_57     cap_min_57  1
    sK_57     cap_buf_57  1
    sK_58     Obj       -100
    sK_58     cap_min_58  1
    sK_58     cap_buf_58  1
    sK_59     Obj       -100
    sK_59     cap_min_59  1
    sK_59     cap_buf_59  1
    sK_60     Obj       -100
    sK_60     cap_min_60  1
    sK_60     cap_buf_60  1
    sLev_1    Obj       -100
    sLev_1    lev_min_1  1
    sLev_1    lev_buf_1  1
    sLev_2    Obj       -100
    sLev_2    lev_min_2  1
    sLev_2    lev_buf_2  1
    sLev_3    Obj       -100
    sLev_3    lev_min_3  1
    sLev_3    lev_buf_3  1
    sLev_4    Obj       -100
    sLev_4    lev_min_4  1
    sLev_4    lev_buf_4  1
    sLev_5    Obj       -100
    sLev_5    lev_min_5  1
    sLev_5    lev_buf_5  1
    sLev_6    Obj       -100
    sLev_6    lev_min_6  1
    sLev_6    lev_buf_6  1
    sLev_7    Obj       -100
    sLev_7    lev_min_7  1
    sLev_7    lev_buf_7  1
    sLev_8    Obj       -100
    sLev_8    lev_min_8  1
    sLev_8    lev_buf_8  1
    sLev_9    Obj       -100
    sLev_9    lev_min_9  1
    sLev_9    lev_buf_9  1
    sLev_10   Obj       -100
    sLev_10   lev_min_10  1
    sLev_10   lev_buf_10  1
    sLev_11   Obj       -100
    sLev_11   lev_min_11  1
    sLev_11   lev_buf_11  1
    sLev_12   Obj       -100
    sLev_12   lev_min_12  1
    sLev_12   lev_buf_12  1
    sLev_13   Obj       -100
    sLev_13   lev_min_13  1
    sLev_13   lev_buf_13  1
    sLev_14   Obj       -100
    sLev_14   lev_min_14  1
    sLev_14   lev_buf_14  1
    sLev_15   Obj       -100
    sLev_15   lev_min_15  1
    sLev_15   lev_buf_15  1
    sLev_16   Obj       -100
    sLev_16   lev_min_16  1
    sLev_16   lev_buf_16  1
    sLev_17   Obj       -100
    sLev_17   lev_min_17  1
    sLev_17   lev_buf_17  1
    sLev_18   Obj       -100
    sLev_18   lev_min_18  1
    sLev_18   lev_buf_18  1
    sLev_19   Obj       -100
    sLev_19   lev_min_19  1
    sLev_19   lev_buf_19  1
    sLev_20   Obj       -100
    sLev_20   lev_min_20  1
    sLev_20   lev_buf_20  1
    sLev_21   Obj       -100
    sLev_21   lev_min_21  1
    sLev_21   lev_buf_21  1
    sLev_22   Obj       -100
    sLev_22   lev_min_22  1
    sLev_22   lev_buf_22  1
    sLev_23   Obj       -100
    sLev_23   lev_min_23  1
    sLev_23   lev_buf_23  1
    sLev_24   Obj       -100
    sLev_24   lev_min_24  1
    sLev_24   lev_buf_24  1
    sLev_25   Obj       -100
    sLev_25   lev_min_25  1
    sLev_25   lev_buf_25  1
    sLev_26   Obj       -100
    sLev_26   lev_min_26  1
    sLev_26   lev_buf_26  1
    sLev_27   Obj       -100
    sLev_27   lev_min_27  1
    sLev_27   lev_buf_27  1
    sLev_28   Obj       -100
    sLev_28   lev_min_28  1
    sLev_28   lev_buf_28  1
    sLev_29   Obj       -100
    sLev_29   lev_min_29  1
    sLev_29   lev_buf_29  1
    sLev_30   Obj       -100
    sLev_30   lev_min_30  1
    sLev_30   lev_buf_30  1
    sLev_31   Obj       -100
    sLev_31   lev_min_31  1
    sLev_31   lev_buf_31  1
    sLev_32   Obj       -100
    sLev_32   lev_min_32  1
    sLev_32   lev_buf_32  1
    sLev_33   Obj       -100
    sLev_33   lev_min_33  1
    sLev_33   lev_buf_33  1
    sLev_34   Obj       -100
    sLev_34   lev_min_34  1
    sLev_34   lev_buf_34  1
    sLev_35   Obj       -100
    sLev_35   lev_min_35  1
    sLev_35   lev_buf_35  1
    sLev_36   Obj       -100
    sLev_36   lev_min_36  1
    sLev_36   lev_buf_36  1
    sLev_37   Obj       -100
    sLev_37   lev_min_37  1
    sLev_37   lev_buf_37  1
    sLev_38   Obj       -100
    sLev_38   lev_min_38  1
    sLev_38   lev_buf_38  1
    sLev_39   Obj       -100
    sLev_39   lev_min_39  1
    sLev_39   lev_buf_39  1
    sLev_40   Obj       -100
    sLev_40   lev_min_40  1
    sLev_40   lev_buf_40  1
    sLev_41   Obj       -100
    sLev_41   lev_min_41  1
    sLev_41   lev_buf_41  1
    sLev_42   Obj       -100
    sLev_42   lev_min_42  1
    sLev_42   lev_buf_42  1
    sLev_43   Obj       -100
    sLev_43   lev_min_43  1
    sLev_43   lev_buf_43  1
    sLev_44   Obj       -100
    sLev_44   lev_min_44  1
    sLev_44   lev_buf_44  1
    sLev_45   Obj       -100
    sLev_45   lev_min_45  1
    sLev_45   lev_buf_45  1
    sLev_46   Obj       -100
    sLev_46   lev_min_46  1
    sLev_46   lev_buf_46  1
    sLev_47   Obj       -100
    sLev_47   lev_min_47  1
    sLev_47   lev_buf_47  1
    sLev_48   Obj       -100
    sLev_48   lev_min_48  1
    sLev_48   lev_buf_48  1
    sLev_49   Obj       -100
    sLev_49   lev_min_49  1
    sLev_49   lev_buf_49  1
    sLev_50   Obj       -100
    sLev_50   lev_min_50  1
    sLev_50   lev_buf_50  1
    sLev_51   Obj       -100
    sLev_51   lev_min_51  1
    sLev_51   lev_buf_51  1
    sLev_52   Obj       -100
    sLev_52   lev_min_52  1
    sLev_52   lev_buf_52  1
    sLev_53   Obj       -100
    sLev_53   lev_min_53  1
    sLev_53   lev_buf_53  1
    sLev_54   Obj       -100
    sLev_54   lev_min_54  1
    sLev_54   lev_buf_54  1
    sLev_55   Obj       -100
    sLev_55   lev_min_55  1
    sLev_55   lev_buf_55  1
    sLev_56   Obj       -100
    sLev_56   lev_min_56  1
    sLev_56   lev_buf_56  1
    sLev_57   Obj       -100
    sLev_57   lev_min_57  1
    sLev_57   lev_buf_57  1
    sLev_58   Obj       -100
    sLev_58   lev_min_58  1
    sLev_58   lev_buf_58  1
    sLev_59   Obj       -100
    sLev_59   lev_min_59  1
    sLev_59   lev_buf_59  1
    sLev_60   Obj       -100
    sLev_60   lev_min_60  1
    sLev_60   lev_buf_60  1
    sH_1      Obj       -100
    sH_1      lcr_min_1  1
    sH_1      lcr_cap_min_1  1
    sH_1      lcr_buf_1  1
    sH_1      lcr_cap_buf_1  1
    sH_2      Obj       -100
    sH_2      lcr_min_2  1
    sH_2      lcr_cap_min_2  1
    sH_2      lcr_buf_2  1
    sH_2      lcr_cap_buf_2  1
    sH_3      Obj       -100
    sH_3      lcr_min_3  1
    sH_3      lcr_cap_min_3  1
    sH_3      lcr_buf_3  1
    sH_3      lcr_cap_buf_3  1
    sH_4      Obj       -100
    sH_4      lcr_min_4  1
    sH_4      lcr_cap_min_4  1
    sH_4      lcr_buf_4  1
    sH_4      lcr_cap_buf_4  1
    sH_5      Obj       -100
    sH_5      lcr_min_5  1
    sH_5      lcr_cap_min_5  1
    sH_5      lcr_buf_5  1
    sH_5      lcr_cap_buf_5  1
    sH_6      Obj       -100
    sH_6      lcr_min_6  1
    sH_6      lcr_cap_min_6  1
    sH_6      lcr_buf_6  1
    sH_6      lcr_cap_buf_6  1
    sH_7      Obj       -100
    sH_7      lcr_min_7  1
    sH_7      lcr_cap_min_7  1
    sH_7      lcr_buf_7  1
    sH_7      lcr_cap_buf_7  1
    sH_8      Obj       -100
    sH_8      lcr_min_8  1
    sH_8      lcr_cap_min_8  1
    sH_8      lcr_buf_8  1
    sH_8      lcr_cap_buf_8  1
    sH_9      Obj       -100
    sH_9      lcr_min_9  1
    sH_9      lcr_cap_min_9  1
    sH_9      lcr_buf_9  1
    sH_9      lcr_cap_buf_9  1
    sH_10     Obj       -100
    sH_10     lcr_min_10  1
    sH_10     lcr_cap_min_10  1
    sH_10     lcr_buf_10  1
    sH_10     lcr_cap_buf_10  1
    sH_11     Obj       -100
    sH_11     lcr_min_11  1
    sH_11     lcr_cap_min_11  1
    sH_11     lcr_buf_11  1
    sH_11     lcr_cap_buf_11  1
    sH_12     Obj       -100
    sH_12     lcr_min_12  1
    sH_12     lcr_cap_min_12  1
    sH_12     lcr_buf_12  1
    sH_12     lcr_cap_buf_12  1
    sH_13     Obj       -100
    sH_13     lcr_min_13  1
    sH_13     lcr_cap_min_13  1
    sH_13     lcr_buf_13  1
    sH_13     lcr_cap_buf_13  1
    sH_14     Obj       -100
    sH_14     lcr_min_14  1
    sH_14     lcr_cap_min_14  1
    sH_14     lcr_buf_14  1
    sH_14     lcr_cap_buf_14  1
    sH_15     Obj       -100
    sH_15     lcr_min_15  1
    sH_15     lcr_cap_min_15  1
    sH_15     lcr_buf_15  1
    sH_15     lcr_cap_buf_15  1
    sH_16     Obj       -100
    sH_16     lcr_min_16  1
    sH_16     lcr_cap_min_16  1
    sH_16     lcr_buf_16  1
    sH_16     lcr_cap_buf_16  1
    sH_17     Obj       -100
    sH_17     lcr_min_17  1
    sH_17     lcr_cap_min_17  1
    sH_17     lcr_buf_17  1
    sH_17     lcr_cap_buf_17  1
    sH_18     Obj       -100
    sH_18     lcr_min_18  1
    sH_18     lcr_cap_min_18  1
    sH_18     lcr_buf_18  1
    sH_18     lcr_cap_buf_18  1
    sH_19     Obj       -100
    sH_19     lcr_min_19  1
    sH_19     lcr_cap_min_19  1
    sH_19     lcr_buf_19  1
    sH_19     lcr_cap_buf_19  1
    sH_20     Obj       -100
    sH_20     lcr_min_20  1
    sH_20     lcr_cap_min_20  1
    sH_20     lcr_buf_20  1
    sH_20     lcr_cap_buf_20  1
    sH_21     Obj       -100
    sH_21     lcr_min_21  1
    sH_21     lcr_cap_min_21  1
    sH_21     lcr_buf_21  1
    sH_21     lcr_cap_buf_21  1
    sH_22     Obj       -100
    sH_22     lcr_min_22  1
    sH_22     lcr_cap_min_22  1
    sH_22     lcr_buf_22  1
    sH_22     lcr_cap_buf_22  1
    sH_23     Obj       -100
    sH_23     lcr_min_23  1
    sH_23     lcr_cap_min_23  1
    sH_23     lcr_buf_23  1
    sH_23     lcr_cap_buf_23  1
    sH_24     Obj       -100
    sH_24     lcr_min_24  1
    sH_24     lcr_cap_min_24  1
    sH_24     lcr_buf_24  1
    sH_24     lcr_cap_buf_24  1
    sH_25     Obj       -100
    sH_25     lcr_min_25  1
    sH_25     lcr_cap_min_25  1
    sH_25     lcr_buf_25  1
    sH_25     lcr_cap_buf_25  1
    sH_26     Obj       -100
    sH_26     lcr_min_26  1
    sH_26     lcr_cap_min_26  1
    sH_26     lcr_buf_26  1
    sH_26     lcr_cap_buf_26  1
    sH_27     Obj       -100
    sH_27     lcr_min_27  1
    sH_27     lcr_cap_min_27  1
    sH_27     lcr_buf_27  1
    sH_27     lcr_cap_buf_27  1
    sH_28     Obj       -100
    sH_28     lcr_min_28  1
    sH_28     lcr_cap_min_28  1
    sH_28     lcr_buf_28  1
    sH_28     lcr_cap_buf_28  1
    sH_29     Obj       -100
    sH_29     lcr_min_29  1
    sH_29     lcr_cap_min_29  1
    sH_29     lcr_buf_29  1
    sH_29     lcr_cap_buf_29  1
    sH_30     Obj       -100
    sH_30     lcr_min_30  1
    sH_30     lcr_cap_min_30  1
    sH_30     lcr_buf_30  1
    sH_30     lcr_cap_buf_30  1
    sH_31     Obj       -100
    sH_31     lcr_min_31  1
    sH_31     lcr_cap_min_31  1
    sH_31     lcr_buf_31  1
    sH_31     lcr_cap_buf_31  1
    sH_32     Obj       -100
    sH_32     lcr_min_32  1
    sH_32     lcr_cap_min_32  1
    sH_32     lcr_buf_32  1
    sH_32     lcr_cap_buf_32  1
    sH_33     Obj       -100
    sH_33     lcr_min_33  1
    sH_33     lcr_cap_min_33  1
    sH_33     lcr_buf_33  1
    sH_33     lcr_cap_buf_33  1
    sH_34     Obj       -100
    sH_34     lcr_min_34  1
    sH_34     lcr_cap_min_34  1
    sH_34     lcr_buf_34  1
    sH_34     lcr_cap_buf_34  1
    sH_35     Obj       -100
    sH_35     lcr_min_35  1
    sH_35     lcr_cap_min_35  1
    sH_35     lcr_buf_35  1
    sH_35     lcr_cap_buf_35  1
    sH_36     Obj       -100
    sH_36     lcr_min_36  1
    sH_36     lcr_cap_min_36  1
    sH_36     lcr_buf_36  1
    sH_36     lcr_cap_buf_36  1
    sH_37     Obj       -100
    sH_37     lcr_min_37  1
    sH_37     lcr_cap_min_37  1
    sH_37     lcr_buf_37  1
    sH_37     lcr_cap_buf_37  1
    sH_38     Obj       -100
    sH_38     lcr_min_38  1
    sH_38     lcr_cap_min_38  1
    sH_38     lcr_buf_38  1
    sH_38     lcr_cap_buf_38  1
    sH_39     Obj       -100
    sH_39     lcr_min_39  1
    sH_39     lcr_cap_min_39  1
    sH_39     lcr_buf_39  1
    sH_39     lcr_cap_buf_39  1
    sH_40     Obj       -100
    sH_40     lcr_min_40  1
    sH_40     lcr_cap_min_40  1
    sH_40     lcr_buf_40  1
    sH_40     lcr_cap_buf_40  1
    sH_41     Obj       -100
    sH_41     lcr_min_41  1
    sH_41     lcr_cap_min_41  1
    sH_41     lcr_buf_41  1
    sH_41     lcr_cap_buf_41  1
    sH_42     Obj       -100
    sH_42     lcr_min_42  1
    sH_42     lcr_cap_min_42  1
    sH_42     lcr_buf_42  1
    sH_42     lcr_cap_buf_42  1
    sH_43     Obj       -100
    sH_43     lcr_min_43  1
    sH_43     lcr_cap_min_43  1
    sH_43     lcr_buf_43  1
    sH_43     lcr_cap_buf_43  1
    sH_44     Obj       -100
    sH_44     lcr_min_44  1
    sH_44     lcr_cap_min_44  1
    sH_44     lcr_buf_44  1
    sH_44     lcr_cap_buf_44  1
    sH_45     Obj       -100
    sH_45     lcr_min_45  1
    sH_45     lcr_cap_min_45  1
    sH_45     lcr_buf_45  1
    sH_45     lcr_cap_buf_45  1
    sH_46     Obj       -100
    sH_46     lcr_min_46  1
    sH_46     lcr_cap_min_46  1
    sH_46     lcr_buf_46  1
    sH_46     lcr_cap_buf_46  1
    sH_47     Obj       -100
    sH_47     lcr_min_47  1
    sH_47     lcr_cap_min_47  1
    sH_47     lcr_buf_47  1
    sH_47     lcr_cap_buf_47  1
    sH_48     Obj       -100
    sH_48     lcr_min_48  1
    sH_48     lcr_cap_min_48  1
    sH_48     lcr_buf_48  1
    sH_48     lcr_cap_buf_48  1
    sH_49     Obj       -100
    sH_49     lcr_min_49  1
    sH_49     lcr_cap_min_49  1
    sH_49     lcr_buf_49  1
    sH_49     lcr_cap_buf_49  1
    sH_50     Obj       -100
    sH_50     lcr_min_50  1
    sH_50     lcr_cap_min_50  1
    sH_50     lcr_buf_50  1
    sH_50     lcr_cap_buf_50  1
    sH_51     Obj       -100
    sH_51     lcr_min_51  1
    sH_51     lcr_cap_min_51  1
    sH_51     lcr_buf_51  1
    sH_51     lcr_cap_buf_51  1
    sH_52     Obj       -100
    sH_52     lcr_min_52  1
    sH_52     lcr_cap_min_52  1
    sH_52     lcr_buf_52  1
    sH_52     lcr_cap_buf_52  1
    sH_53     Obj       -100
    sH_53     lcr_min_53  1
    sH_53     lcr_cap_min_53  1
    sH_53     lcr_buf_53  1
    sH_53     lcr_cap_buf_53  1
    sH_54     Obj       -100
    sH_54     lcr_min_54  1
    sH_54     lcr_cap_min_54  1
    sH_54     lcr_buf_54  1
    sH_54     lcr_cap_buf_54  1
    sH_55     Obj       -100
    sH_55     lcr_min_55  1
    sH_55     lcr_cap_min_55  1
    sH_55     lcr_buf_55  1
    sH_55     lcr_cap_buf_55  1
    sH_56     Obj       -100
    sH_56     lcr_min_56  1
    sH_56     lcr_cap_min_56  1
    sH_56     lcr_buf_56  1
    sH_56     lcr_cap_buf_56  1
    sH_57     Obj       -100
    sH_57     lcr_min_57  1
    sH_57     lcr_cap_min_57  1
    sH_57     lcr_buf_57  1
    sH_57     lcr_cap_buf_57  1
    sH_58     Obj       -100
    sH_58     lcr_min_58  1
    sH_58     lcr_cap_min_58  1
    sH_58     lcr_buf_58  1
    sH_58     lcr_cap_buf_58  1
    sH_59     Obj       -100
    sH_59     lcr_min_59  1
    sH_59     lcr_cap_min_59  1
    sH_59     lcr_buf_59  1
    sH_59     lcr_cap_buf_59  1
    sH_60     Obj       -100
    sH_60     lcr_min_60  1
    sH_60     lcr_cap_min_60  1
    sH_60     lcr_buf_60  1
    sH_60     lcr_cap_buf_60  1
    sN_1      Obj       -100
    sN_1      nsfr_min_1  1
    sN_1      nsfr_buf_1  1
    sN_2      Obj       -100
    sN_2      nsfr_min_2  1
    sN_2      nsfr_buf_2  1
    sN_3      Obj       -100
    sN_3      nsfr_min_3  1
    sN_3      nsfr_buf_3  1
    sN_4      Obj       -100
    sN_4      nsfr_min_4  1
    sN_4      nsfr_buf_4  1
    sN_5      Obj       -100
    sN_5      nsfr_min_5  1
    sN_5      nsfr_buf_5  1
    sN_6      Obj       -100
    sN_6      nsfr_min_6  1
    sN_6      nsfr_buf_6  1
    sN_7      Obj       -100
    sN_7      nsfr_min_7  1
    sN_7      nsfr_buf_7  1
    sN_8      Obj       -100
    sN_8      nsfr_min_8  1
    sN_8      nsfr_buf_8  1
    sN_9      Obj       -100
    sN_9      nsfr_min_9  1
    sN_9      nsfr_buf_9  1
    sN_10     Obj       -100
    sN_10     nsfr_min_10  1
    sN_10     nsfr_buf_10  1
    sN_11     Obj       -100
    sN_11     nsfr_min_11  1
    sN_11     nsfr_buf_11  1
    sN_12     Obj       -100
    sN_12     nsfr_min_12  1
    sN_12     nsfr_buf_12  1
    sN_13     Obj       -100
    sN_13     nsfr_min_13  1
    sN_13     nsfr_buf_13  1
    sN_14     Obj       -100
    sN_14     nsfr_min_14  1
    sN_14     nsfr_buf_14  1
    sN_15     Obj       -100
    sN_15     nsfr_min_15  1
    sN_15     nsfr_buf_15  1
    sN_16     Obj       -100
    sN_16     nsfr_min_16  1
    sN_16     nsfr_buf_16  1
    sN_17     Obj       -100
    sN_17     nsfr_min_17  1
    sN_17     nsfr_buf_17  1
    sN_18     Obj       -100
    sN_18     nsfr_min_18  1
    sN_18     nsfr_buf_18  1
    sN_19     Obj       -100
    sN_19     nsfr_min_19  1
    sN_19     nsfr_buf_19  1
    sN_20     Obj       -100
    sN_20     nsfr_min_20  1
    sN_20     nsfr_buf_20  1
    sN_21     Obj       -100
    sN_21     nsfr_min_21  1
    sN_21     nsfr_buf_21  1
    sN_22     Obj       -100
    sN_22     nsfr_min_22  1
    sN_22     nsfr_buf_22  1
    sN_23     Obj       -100
    sN_23     nsfr_min_23  1
    sN_23     nsfr_buf_23  1
    sN_24     Obj       -100
    sN_24     nsfr_min_24  1
    sN_24     nsfr_buf_24  1
    sN_25     Obj       -100
    sN_25     nsfr_min_25  1
    sN_25     nsfr_buf_25  1
    sN_26     Obj       -100
    sN_26     nsfr_min_26  1
    sN_26     nsfr_buf_26  1
    sN_27     Obj       -100
    sN_27     nsfr_min_27  1
    sN_27     nsfr_buf_27  1
    sN_28     Obj       -100
    sN_28     nsfr_min_28  1
    sN_28     nsfr_buf_28  1
    sN_29     Obj       -100
    sN_29     nsfr_min_29  1
    sN_29     nsfr_buf_29  1
    sN_30     Obj       -100
    sN_30     nsfr_min_30  1
    sN_30     nsfr_buf_30  1
    sN_31     Obj       -100
    sN_31     nsfr_min_31  1
    sN_31     nsfr_buf_31  1
    sN_32     Obj       -100
    sN_32     nsfr_min_32  1
    sN_32     nsfr_buf_32  1
    sN_33     Obj       -100
    sN_33     nsfr_min_33  1
    sN_33     nsfr_buf_33  1
    sN_34     Obj       -100
    sN_34     nsfr_min_34  1
    sN_34     nsfr_buf_34  1
    sN_35     Obj       -100
    sN_35     nsfr_min_35  1
    sN_35     nsfr_buf_35  1
    sN_36     Obj       -100
    sN_36     nsfr_min_36  1
    sN_36     nsfr_buf_36  1
    sN_37     Obj       -100
    sN_37     nsfr_min_37  1
    sN_37     nsfr_buf_37  1
    sN_38     Obj       -100
    sN_38     nsfr_min_38  1
    sN_38     nsfr_buf_38  1
    sN_39     Obj       -100
    sN_39     nsfr_min_39  1
    sN_39     nsfr_buf_39  1
    sN_40     Obj       -100
    sN_40     nsfr_min_40  1
    sN_40     nsfr_buf_40  1
    sN_41     Obj       -100
    sN_41     nsfr_min_41  1
    sN_41     nsfr_buf_41  1
    sN_42     Obj       -100
    sN_42     nsfr_min_42  1
    sN_42     nsfr_buf_42  1
    sN_43     Obj       -100
    sN_43     nsfr_min_43  1
    sN_43     nsfr_buf_43  1
    sN_44     Obj       -100
    sN_44     nsfr_min_44  1
    sN_44     nsfr_buf_44  1
    sN_45     Obj       -100
    sN_45     nsfr_min_45  1
    sN_45     nsfr_buf_45  1
    sN_46     Obj       -100
    sN_46     nsfr_min_46  1
    sN_46     nsfr_buf_46  1
    sN_47     Obj       -100
    sN_47     nsfr_min_47  1
    sN_47     nsfr_buf_47  1
    sN_48     Obj       -100
    sN_48     nsfr_min_48  1
    sN_48     nsfr_buf_48  1
    sN_49     Obj       -100
    sN_49     nsfr_min_49  1
    sN_49     nsfr_buf_49  1
    sN_50     Obj       -100
    sN_50     nsfr_min_50  1
    sN_50     nsfr_buf_50  1
    sN_51     Obj       -100
    sN_51     nsfr_min_51  1
    sN_51     nsfr_buf_51  1
    sN_52     Obj       -100
    sN_52     nsfr_min_52  1
    sN_52     nsfr_buf_52  1
    sN_53     Obj       -100
    sN_53     nsfr_min_53  1
    sN_53     nsfr_buf_53  1
    sN_54     Obj       -100
    sN_54     nsfr_min_54  1
    sN_54     nsfr_buf_54  1
    sN_55     Obj       -100
    sN_55     nsfr_min_55  1
    sN_55     nsfr_buf_55  1
    sN_56     Obj       -100
    sN_56     nsfr_min_56  1
    sN_56     nsfr_buf_56  1
    sN_57     Obj       -100
    sN_57     nsfr_min_57  1
    sN_57     nsfr_buf_57  1
    sN_58     Obj       -100
    sN_58     nsfr_min_58  1
    sN_58     nsfr_buf_58  1
    sN_59     Obj       -100
    sN_59     nsfr_min_59  1
    sN_59     nsfr_buf_59  1
    sN_60     Obj       -100
    sN_60     nsfr_min_60  1
    sN_60     nsfr_buf_60  1
    uK_1      Obj       -10
    uK_1      cap_buf_1  1
    uK_2      Obj       -10
    uK_2      cap_buf_2  1
    uK_3      Obj       -10
    uK_3      cap_buf_3  1
    uK_4      Obj       -10
    uK_4      cap_buf_4  1
    uK_5      Obj       -10
    uK_5      cap_buf_5  1
    uK_6      Obj       -10
    uK_6      cap_buf_6  1
    uK_7      Obj       -10
    uK_7      cap_buf_7  1
    uK_8      Obj       -10
    uK_8      cap_buf_8  1
    uK_9      Obj       -10
    uK_9      cap_buf_9  1
    uK_10     Obj       -10
    uK_10     cap_buf_10  1
    uK_11     Obj       -10
    uK_11     cap_buf_11  1
    uK_12     Obj       -10
    uK_12     cap_buf_12  1
    uK_13     Obj       -10
    uK_13     cap_buf_13  1
    uK_14     Obj       -10
    uK_14     cap_buf_14  1
    uK_15     Obj       -10
    uK_15     cap_buf_15  1
    uK_16     Obj       -10
    uK_16     cap_buf_16  1
    uK_17     Obj       -10
    uK_17     cap_buf_17  1
    uK_18     Obj       -10
    uK_18     cap_buf_18  1
    uK_19     Obj       -10
    uK_19     cap_buf_19  1
    uK_20     Obj       -10
    uK_20     cap_buf_20  1
    uK_21     Obj       -10
    uK_21     cap_buf_21  1
    uK_22     Obj       -10
    uK_22     cap_buf_22  1
    uK_23     Obj       -10
    uK_23     cap_buf_23  1
    uK_24     Obj       -10
    uK_24     cap_buf_24  1
    uK_25     Obj       -10
    uK_25     cap_buf_25  1
    uK_26     Obj       -10
    uK_26     cap_buf_26  1
    uK_27     Obj       -10
    uK_27     cap_buf_27  1
    uK_28     Obj       -10
    uK_28     cap_buf_28  1
    uK_29     Obj       -10
    uK_29     cap_buf_29  1
    uK_30     Obj       -10
    uK_30     cap_buf_30  1
    uK_31     Obj       -10
    uK_31     cap_buf_31  1
    uK_32     Obj       -10
    uK_32     cap_buf_32  1
    uK_33     Obj       -10
    uK_33     cap_buf_33  1
    uK_34     Obj       -10
    uK_34     cap_buf_34  1
    uK_35     Obj       -10
    uK_35     cap_buf_35  1
    uK_36     Obj       -10
    uK_36     cap_buf_36  1
    uK_37     Obj       -10
    uK_37     cap_buf_37  1
    uK_38     Obj       -10
    uK_38     cap_buf_38  1
    uK_39     Obj       -10
    uK_39     cap_buf_39  1
    uK_40     Obj       -10
    uK_40     cap_buf_40  1
    uK_41     Obj       -10
    uK_41     cap_buf_41  1
    uK_42     Obj       -10
    uK_42     cap_buf_42  1
    uK_43     Obj       -10
    uK_43     cap_buf_43  1
    uK_44     Obj       -10
    uK_44     cap_buf_44  1
    uK_45     Obj       -10
    uK_45     cap_buf_45  1
    uK_46     Obj       -10
    uK_46     cap_buf_46  1
    uK_47     Obj       -10
    uK_47     cap_buf_47  1
    uK_48     Obj       -10
    uK_48     cap_buf_48  1
    uK_49     Obj       -10
    uK_49     cap_buf_49  1
    uK_50     Obj       -10
    uK_50     cap_buf_50  1
    uK_51     Obj       -10
    uK_51     cap_buf_51  1
    uK_52     Obj       -10
    uK_52     cap_buf_52  1
    uK_53     Obj       -10
    uK_53     cap_buf_53  1
    uK_54     Obj       -10
    uK_54     cap_buf_54  1
    uK_55     Obj       -10
    uK_55     cap_buf_55  1
    uK_56     Obj       -10
    uK_56     cap_buf_56  1
    uK_57     Obj       -10
    uK_57     cap_buf_57  1
    uK_58     Obj       -10
    uK_58     cap_buf_58  1
    uK_59     Obj       -10
    uK_59     cap_buf_59  1
    uK_60     Obj       -10
    uK_60     cap_buf_60  1
    uLev_1    Obj       -10
    uLev_1    lev_buf_1  1
    uLev_2    Obj       -10
    uLev_2    lev_buf_2  1
    uLev_3    Obj       -10
    uLev_3    lev_buf_3  1
    uLev_4    Obj       -10
    uLev_4    lev_buf_4  1
    uLev_5    Obj       -10
    uLev_5    lev_buf_5  1
    uLev_6    Obj       -10
    uLev_6    lev_buf_6  1
    uLev_7    Obj       -10
    uLev_7    lev_buf_7  1
    uLev_8    Obj       -10
    uLev_8    lev_buf_8  1
    uLev_9    Obj       -10
    uLev_9    lev_buf_9  1
    uLev_10   Obj       -10
    uLev_10   lev_buf_10  1
    uLev_11   Obj       -10
    uLev_11   lev_buf_11  1
    uLev_12   Obj       -10
    uLev_12   lev_buf_12  1
    uLev_13   Obj       -10
    uLev_13   lev_buf_13  1
    uLev_14   Obj       -10
    uLev_14   lev_buf_14  1
    uLev_15   Obj       -10
    uLev_15   lev_buf_15  1
    uLev_16   Obj       -10
    uLev_16   lev_buf_16  1
    uLev_17   Obj       -10
    uLev_17   lev_buf_17  1
    uLev_18   Obj       -10
    uLev_18   lev_buf_18  1
    uLev_19   Obj       -10
    uLev_19   lev_buf_19  1
    uLev_20   Obj       -10
    uLev_20   lev_buf_20  1
    uLev_21   Obj       -10
    uLev_21   lev_buf_21  1
    uLev_22   Obj       -10
    uLev_22   lev_buf_22  1
    uLev_23   Obj       -10
    uLev_23   lev_buf_23  1
    uLev_24   Obj       -10
    uLev_24   lev_buf_24  1
    uLev_25   Obj       -10
    uLev_25   lev_buf_25  1
    uLev_26   Obj       -10
    uLev_26   lev_buf_26  1
    uLev_27   Obj       -10
    uLev_27   lev_buf_27  1
    uLev_28   Obj       -10
    uLev_28   lev_buf_28  1
    uLev_29   Obj       -10
    uLev_29   lev_buf_29  1
    uLev_30   Obj       -10
    uLev_30   lev_buf_30  1
    uLev_31   Obj       -10
    uLev_31   lev_buf_31  1
    uLev_32   Obj       -10
    uLev_32   lev_buf_32  1
    uLev_33   Obj       -10
    uLev_33   lev_buf_33  1
    uLev_34   Obj       -10
    uLev_34   lev_buf_34  1
    uLev_35   Obj       -10
    uLev_35   lev_buf_35  1
    uLev_36   Obj       -10
    uLev_36   lev_buf_36  1
    uLev_37   Obj       -10
    uLev_37   lev_buf_37  1
    uLev_38   Obj       -10
    uLev_38   lev_buf_38  1
    uLev_39   Obj       -10
    uLev_39   lev_buf_39  1
    uLev_40   Obj       -10
    uLev_40   lev_buf_40  1
    uLev_41   Obj       -10
    uLev_41   lev_buf_41  1
    uLev_42   Obj       -10
    uLev_42   lev_buf_42  1
    uLev_43   Obj       -10
    uLev_43   lev_buf_43  1
    uLev_44   Obj       -10
    uLev_44   lev_buf_44  1
    uLev_45   Obj       -10
    uLev_45   lev_buf_45  1
    uLev_46   Obj       -10
    uLev_46   lev_buf_46  1
    uLev_47   Obj       -10
    uLev_47   lev_buf_47  1
    uLev_48   Obj       -10
    uLev_48   lev_buf_48  1
    uLev_49   Obj       -10
    uLev_49   lev_buf_49  1
    uLev_50   Obj       -10
    uLev_50   lev_buf_50  1
    uLev_51   Obj       -10
    uLev_51   lev_buf_51  1
    uLev_52   Obj       -10
    uLev_52   lev_buf_52  1
    uLev_53   Obj       -10
    uLev_53   lev_buf_53  1
    uLev_54   Obj       -10
    uLev_54   lev_buf_54  1
    uLev_55   Obj       -10
    uLev_55   lev_buf_55  1
    uLev_56   Obj       -10
    uLev_56   lev_buf_56  1
    uLev_57   Obj       -10
    uLev_57   lev_buf_57  1
    uLev_58   Obj       -10
    uLev_58   lev_buf_58  1
    uLev_59   Obj       -10
    uLev_59   lev_buf_59  1
    uLev_60   Obj       -10
    uLev_60   lev_buf_60  1
    uH_1      Obj       -5
    uH_1      lcr_buf_1  1
    uH_1      lcr_cap_buf_1  1
    uH_2      Obj       -5
    uH_2      lcr_buf_2  1
    uH_2      lcr_cap_buf_2  1
    uH_3      Obj       -5
    uH_3      lcr_buf_3  1
    uH_3      lcr_cap_buf_3  1
    uH_4      Obj       -5
    uH_4      lcr_buf_4  1
    uH_4      lcr_cap_buf_4  1
    uH_5      Obj       -5
    uH_5      lcr_buf_5  1
    uH_5      lcr_cap_buf_5  1
    uH_6      Obj       -5
    uH_6      lcr_buf_6  1
    uH_6      lcr_cap_buf_6  1
    uH_7      Obj       -5
    uH_7      lcr_buf_7  1
    uH_7      lcr_cap_buf_7  1
    uH_8      Obj       -5
    uH_8      lcr_buf_8  1
    uH_8      lcr_cap_buf_8  1
    uH_9      Obj       -5
    uH_9      lcr_buf_9  1
    uH_9      lcr_cap_buf_9  1
    uH_10     Obj       -5
    uH_10     lcr_buf_10  1
    uH_10     lcr_cap_buf_10  1
    uH_11     Obj       -5
    uH_11     lcr_buf_11  1
    uH_11     lcr_cap_buf_11  1
    uH_12     Obj       -5
    uH_12     lcr_buf_12  1
    uH_12     lcr_cap_buf_12  1
    uH_13     Obj       -5
    uH_13     lcr_buf_13  1
    uH_13     lcr_cap_buf_13  1
    uH_14     Obj       -5
    uH_14     lcr_buf_14  1
    uH_14     lcr_cap_buf_14  1
    uH_15     Obj       -5
    uH_15     lcr_buf_15  1
    uH_15     lcr_cap_buf_15  1
    uH_16     Obj       -5
    uH_16     lcr_buf_16  1
    uH_16     lcr_cap_buf_16  1
    uH_17     Obj       -5
    uH_17     lcr_buf_17  1
    uH_17     lcr_cap_buf_17  1
    uH_18     Obj       -5
    uH_18     lcr_buf_18  1
    uH_18     lcr_cap_buf_18  1
    uH_19     Obj       -5
    uH_19     lcr_buf_19  1
    uH_19     lcr_cap_buf_19  1
    uH_20     Obj       -5
    uH_20     lcr_buf_20  1
    uH_20     lcr_cap_buf_20  1
    uH_21     Obj       -5
    uH_21     lcr_buf_21  1
    uH_21     lcr_cap_buf_21  1
    uH_22     Obj       -5
    uH_22     lcr_buf_22  1
    uH_22     lcr_cap_buf_22  1
    uH_23     Obj       -5
    uH_23     lcr_buf_23  1
    uH_23     lcr_cap_buf_23  1
    uH_24     Obj       -5
    uH_24     lcr_buf_24  1
    uH_24     lcr_cap_buf_24  1
    uH_25     Obj       -5
    uH_25     lcr_buf_25  1
    uH_25     lcr_cap_buf_25  1
    uH_26     Obj       -5
    uH_26     lcr_buf_26  1
    uH_26     lcr_cap_buf_26  1
    uH_27     Obj       -5
    uH_27     lcr_buf_27  1
    uH_27     lcr_cap_buf_27  1
    uH_28     Obj       -5
    uH_28     lcr_buf_28  1
    uH_28     lcr_cap_buf_28  1
    uH_29     Obj       -5
    uH_29     lcr_buf_29  1
    uH_29     lcr_cap_buf_29  1
    uH_30     Obj       -5
    uH_30     lcr_buf_30  1
    uH_30     lcr_cap_buf_30  1
    uH_31     Obj       -5
    uH_31     lcr_buf_31  1
    uH_31     lcr_cap_buf_31  1
    uH_32     Obj       -5
    uH_32     lcr_buf_32  1
    uH_32     lcr_cap_buf_32  1
    uH_33     Obj       -5
    uH_33     lcr_buf_33  1
    uH_33     lcr_cap_buf_33  1
    uH_34     Obj       -5
    uH_34     lcr_buf_34  1
    uH_34     lcr_cap_buf_34  1
    uH_35     Obj       -5
    uH_35     lcr_buf_35  1
    uH_35     lcr_cap_buf_35  1
    uH_36     Obj       -5
    uH_36     lcr_buf_36  1
    uH_36     lcr_cap_buf_36  1
    uH_37     Obj       -5
    uH_37     lcr_buf_37  1
    uH_37     lcr_cap_buf_37  1
    uH_38     Obj       -5
    uH_38     lcr_buf_38  1
    uH_38     lcr_cap_buf_38  1
    uH_39     Obj       -5
    uH_39     lcr_buf_39  1
    uH_39     lcr_cap_buf_39  1
    uH_40     Obj       -5
    uH_40     lcr_buf_40  1
    uH_40     lcr_cap_buf_40  1
    uH_41     Obj       -5
    uH_41     lcr_buf_41  1
    uH_41     lcr_cap_buf_41  1
    uH_42     Obj       -5
    uH_42     lcr_buf_42  1
    uH_42     lcr_cap_buf_42  1
    uH_43     Obj       -5
    uH_43     lcr_buf_43  1
    uH_43     lcr_cap_buf_43  1
    uH_44     Obj       -5
    uH_44     lcr_buf_44  1
    uH_44     lcr_cap_buf_44  1
    uH_45     Obj       -5
    uH_45     lcr_buf_45  1
    uH_45     lcr_cap_buf_45  1
    uH_46     Obj       -5
    uH_46     lcr_buf_46  1
    uH_46     lcr_cap_buf_46  1
    uH_47     Obj       -5
    uH_47     lcr_buf_47  1
    uH_47     lcr_cap_buf_47  1
    uH_48     Obj       -5
    uH_48     lcr_buf_48  1
    uH_48     lcr_cap_buf_48  1
    uH_49     Obj       -5
    uH_49     lcr_buf_49  1
    uH_49     lcr_cap_buf_49  1
    uH_50     Obj       -5
    uH_50     lcr_buf_50  1
    uH_50     lcr_cap_buf_50  1
    uH_51     Obj       -5
    uH_51     lcr_buf_51  1
    uH_51     lcr_cap_buf_51  1
    uH_52     Obj       -5
    uH_52     lcr_buf_52  1
    uH_52     lcr_cap_buf_52  1
    uH_53     Obj       -5
    uH_53     lcr_buf_53  1
    uH_53     lcr_cap_buf_53  1
    uH_54     Obj       -5
    uH_54     lcr_buf_54  1
    uH_54     lcr_cap_buf_54  1
    uH_55     Obj       -5
    uH_55     lcr_buf_55  1
    uH_55     lcr_cap_buf_55  1
    uH_56     Obj       -5
    uH_56     lcr_buf_56  1
    uH_56     lcr_cap_buf_56  1
    uH_57     Obj       -5
    uH_57     lcr_buf_57  1
    uH_57     lcr_cap_buf_57  1
    uH_58     Obj       -5
    uH_58     lcr_buf_58  1
    uH_58     lcr_cap_buf_58  1
    uH_59     Obj       -5
    uH_59     lcr_buf_59  1
    uH_59     lcr_cap_buf_59  1
    uH_60     Obj       -5
    uH_60     lcr_buf_60  1
    uH_60     lcr_cap_buf_60  1
    uN_1      Obj       -5
    uN_1      nsfr_buf_1  1
    uN_2      Obj       -5
    uN_2      nsfr_buf_2  1
    uN_3      Obj       -5
    uN_3      nsfr_buf_3  1
    uN_4      Obj       -5
    uN_4      nsfr_buf_4  1
    uN_5      Obj       -5
    uN_5      nsfr_buf_5  1
    uN_6      Obj       -5
    uN_6      nsfr_buf_6  1
    uN_7      Obj       -5
    uN_7      nsfr_buf_7  1
    uN_8      Obj       -5
    uN_8      nsfr_buf_8  1
    uN_9      Obj       -5
    uN_9      nsfr_buf_9  1
    uN_10     Obj       -5
    uN_10     nsfr_buf_10  1
    uN_11     Obj       -5
    uN_11     nsfr_buf_11  1
    uN_12     Obj       -5
    uN_12     nsfr_buf_12  1
    uN_13     Obj       -5
    uN_13     nsfr_buf_13  1
    uN_14     Obj       -5
    uN_14     nsfr_buf_14  1
    uN_15     Obj       -5
    uN_15     nsfr_buf_15  1
    uN_16     Obj       -5
    uN_16     nsfr_buf_16  1
    uN_17     Obj       -5
    uN_17     nsfr_buf_17  1
    uN_18     Obj       -5
    uN_18     nsfr_buf_18  1
    uN_19     Obj       -5
    uN_19     nsfr_buf_19  1
    uN_20     Obj       -5
    uN_20     nsfr_buf_20  1
    uN_21     Obj       -5
    uN_21     nsfr_buf_21  1
    uN_22     Obj       -5
    uN_22     nsfr_buf_22  1
    uN_23     Obj       -5
    uN_23     nsfr_buf_23  1
    uN_24     Obj       -5
    uN_24     nsfr_buf_24  1
    uN_25     Obj       -5
    uN_25     nsfr_buf_25  1
    uN_26     Obj       -5
    uN_26     nsfr_buf_26  1
    uN_27     Obj       -5
    uN_27     nsfr_buf_27  1
    uN_28     Obj       -5
    uN_28     nsfr_buf_28  1
    uN_29     Obj       -5
    uN_29     nsfr_buf_29  1
    uN_30     Obj       -5
    uN_30     nsfr_buf_30  1
    uN_31     Obj       -5
    uN_31     nsfr_buf_31  1
    uN_32     Obj       -5
    uN_32     nsfr_buf_32  1
    uN_33     Obj       -5
    uN_33     nsfr_buf_33  1
    uN_34     Obj       -5
    uN_34     nsfr_buf_34  1
    uN_35     Obj       -5
    uN_35     nsfr_buf_35  1
    uN_36     Obj       -5
    uN_36     nsfr_buf_36  1
    uN_37     Obj       -5
    uN_37     nsfr_buf_37  1
    uN_38     Obj       -5
    uN_38     nsfr_buf_38  1
    uN_39     Obj       -5
    uN_39     nsfr_buf_39  1
    uN_40     Obj       -5
    uN_40     nsfr_buf_40  1
    uN_41     Obj       -5
    uN_41     nsfr_buf_41  1
    uN_42     Obj       -5
    uN_42     nsfr_buf_42  1
    uN_43     Obj       -5
    uN_43     nsfr_buf_43  1
    uN_44     Obj       -5
    uN_44     nsfr_buf_44  1
    uN_45     Obj       -5
    uN_45     nsfr_buf_45  1
    uN_46     Obj       -5
    uN_46     nsfr_buf_46  1
    uN_47     Obj       -5
    uN_47     nsfr_buf_47  1
    uN_48     Obj       -5
    uN_48     nsfr_buf_48  1
    uN_49     Obj       -5
    uN_49     nsfr_buf_49  1
    uN_50     Obj       -5
    uN_50     nsfr_buf_50  1
    uN_51     Obj       -5
    uN_51     nsfr_buf_51  1
    uN_52     Obj       -5
    uN_52     nsfr_buf_52  1
    uN_53     Obj       -5
    uN_53     nsfr_buf_53  1
    uN_54     Obj       -5
    uN_54     nsfr_buf_54  1
    uN_55     Obj       -5
    uN_55     nsfr_buf_55  1
    uN_56     Obj       -5
    uN_56     nsfr_buf_56  1
    uN_57     Obj       -5
    uN_57     nsfr_buf_57  1
    uN_58     Obj       -5
    uN_58     nsfr_buf_58  1
    uN_59     Obj       -5
    uN_59     nsfr_buf_59  1
    uN_60     Obj       -5
    uN_60     nsfr_buf_60  1
    sEndK     Obj       -50
    sEndK     end_capital  1
    sEndL     Obj       -50
    sEndL     end_loans  1
    L2_1      stage2_1  1
    L2_1      stage2_2  0.94299999999999995
    L2_1      stage3_2  0.0019500000000000001
    L2_1      provision_1  0.023
    L2_2      stage2_2  -1
    L2_2      stage2_3  0.94299999999999995
    L2_2      stage3_3  0.0019500000000000001
    L2_2      provision_2  0.023
    L2_3      stage2_3  -1
    L2_3      stage2_4  0.94299999999999995
    L2_3      stage3_4  0.0019500000000000001
    L2_3      provision_3  0.023
    L2_4      stage2_4  -1
    L2_4      stage2_5  0.94299999999999995
    L2_4      stage3_5  0.0019500000000000001
    L2_4      provision_4  0.023
    L2_5      stage2_5  -1
    L2_5      stage2_6  0.94299999999999995
    L2_5      stage3_6  0.0019500000000000001
    L2_5      provision_5  0.023
    L2_6      stage2_6  -1
    L2_6      stage2_7  0.94299999999999995
    L2_6      stage3_7  0.0019500000000000001
    L2_6      provision_6  0.023
    L2_7      stage2_7  -1
    L2_7      stage2_8  0.94299999999999995
    L2_7      stage3_8  0.0019500000000000001
    L2_7      provision_7  0.023
    L2_8      stage2_8  -1
    L2_8      stage2_9  0.94299999999999995
    L2_8      stage3_9  0.0019500000000000001
    L2_8      provision_8  0.023
    L2_9      stage2_9  -1
    L2_9      stage2_10  0.94299999999999995
    L2_9      stage3_10  0.0019500000000000001
    L2_9      provision_9  0.023
    L2_10     stage2_10  -1
    L2_10     stage2_11  0.94299999999999995
    L2_10     stage3_11  0.0019500000000000001
    L2_10     provision_10  0.023
    L2_11     stage2_11  -1
    L2_11     stage2_12  0.94299999999999995
    L2_11     stage3_12  0.0019500000000000001
    L2_11     provision_11  0.023
    L2_12     stage2_12  -1
    L2_12     stage2_13  0.94299999999999995
    L2_12     stage3_13  0.0019500000000000001
    L2_12     provision_12  0.023
    L2_13     stage2_13  -1
    L2_13     stage2_14  0.94299999999999995
    L2_13     stage3_14  0.0019500000000000001
    L2_13     provision_13  0.023
    L2_14     stage2_14  -1
    L2_14     stage2_15  0.94299999999999995
    L2_14     stage3_15  0.0019500000000000001
    L2_14     provision_14  0.023
    L2_15     stage2_15  -1
    L2_15     stage2_16  0.94299999999999995
    L2_15     stage3_16  0.0019500000000000001
    L2_15     provision_15  0.023
    L2_16     stage2_16  -1
    L2_16     stage2_17  0.94299999999999995
    L2_16     stage3_17  0.0019500000000000001
    L2_16     provision_16  0.023
    L2_17     stage2_17  -1
    L2_17     stage2_18  0.94299999999999995
    L2_17     stage3_18  0.0019500000000000001
    L2_17     provision_17  0.023
    L2_18     stage2_18  -1
    L2_18     stage2_19  0.94299999999999995
    L2_18     stage3_19  0.0019500000000000001
    L2_18     provision_18  0.023
    L2_19     stage2_19  -1
    L2_19     stage2_20  0.94299999999999995
    L2_19     stage3_20  0.0019500000000000001
    L2_19     provision_19  0.023
    L2_20     stage2_20  -1
    L2_20     stage2_21  0.94299999999999995
    L2_20     stage3_21  0.0019500000000000001
    L2_20     provision_20  0.023
    L2_21     stage2_21  -1
    L2_21     stage2_22  0.94299999999999995
    L2_21     stage3_22  0.0019500000000000001
    L2_21     provision_21  0.023
    L2_22     stage2_22  -1
    L2_22     stage2_23  0.94299999999999995
    L2_22     stage3_23  0.0019500000000000001
    L2_22     provision_22  0.023
    L2_23     stage2_23  -1
    L2_23     stage2_24  0.94299999999999995
    L2_23     stage3_24  0.0019500000000000001
    L2_23     provision_23  0.023
    L2_24     stage2_24  -1
    L2_24     stage2_25  0.94299999999999995
    L2_24     stage3_25  0.0019500000000000001
    L2_24     provision_24  0.023
    L2_25     stage2_25  -1
    L2_25     stage2_26  0.94299999999999995
    L2_25     stage3_26  0.0019500000000000001
    L2_25     provision_25  0.023
    L2_26     stage2_26  -1
    L2_26     stage2_27  0.94299999999999995
    L2_26     stage3_27  0.0019500000000000001
    L2_26     provision_26  0.023
    L2_27     stage2_27  -1
    L2_27     stage2_28  0.94299999999999995
    L2_27     stage3_28  0.0019500000000000001
    L2_27     provision_27  0.023
    L2_28     stage2_28  -1
    L2_28     stage2_29  0.94299999999999995
    L2_28     stage3_29  0.0019500000000000001
    L2_28     provision_28  0.023
    L2_29     stage2_29  -1
    L2_29     stage2_30  0.94299999999999995
    L2_29     stage3_30  0.0019500000000000001
    L2_29     provision_29  0.023
    L2_30     stage2_30  -1
    L2_30     stage2_31  0.94299999999999995
    L2_30     stage3_31  0.0019500000000000001
    L2_30     provision_30  0.023
    L2_31     stage2_31  -1
    L2_31     stage2_32  0.94299999999999995
    L2_31     stage3_32  0.0019500000000000001
    L2_31     provision_31  0.023
    L2_32     stage2_32  -1
    L2_32     stage2_33  0.94299999999999995
    L2_32     stage3_33  0.0019500000000000001
    L2_32     provision_32  0.023
    L2_33     stage2_33  -1
    L2_33     stage2_34  0.94299999999999995
    L2_33     stage3_34  0.0019500000000000001
    L2_33     provision_33  0.023
    L2_34     stage2_34  -1
    L2_34     stage2_35  0.94299999999999995
    L2_34     stage3_35  0.0019500000000000001
    L2_34     provision_34  0.023
    L2_35     stage2_35  -1
    L2_35     stage2_36  0.94299999999999995
    L2_35     stage3_36  0.0019500000000000001
    L2_35     provision_35  0.023
    L2_36     stage2_36  -1
    L2_36     stage2_37  0.94299999999999995
    L2_36     stage3_37  0.0019500000000000001
    L2_36     provision_36  0.023
    L2_37     stage2_37  -1
    L2_37     stage2_38  0.94299999999999995
    L2_37     stage3_38  0.0019500000000000001
    L2_37     provision_37  0.023
    L2_38     stage2_38  -1
    L2_38     stage2_39  0.94299999999999995
    L2_38     stage3_39  0.0019500000000000001
    L2_38     provision_38  0.023
    L2_39     stage2_39  -1
    L2_39     stage2_40  0.94299999999999995
    L2_39     stage3_40  0.0019500000000000001
    L2_39     provision_39  0.023
    L2_40     stage2_40  -1
    L2_40     stage2_41  0.94299999999999995
    L2_40     stage3_41  0.0019500000000000001
    L2_40     provision_40  0.023
    L2_41     stage2_41  -1
    L2_41     stage2_42  0.94299999999999995
    L2_41     stage3_42  0.0019500000000000001
    L2_41     provision_41  0.023
    L2_42     stage2_42  -1
    L2_42     stage2_43  0.94299999999999995
    L2_42     stage3_43  0.0019500000000000001
    L2_42     provision_42  0.023
    L2_43     stage2_43  -1
    L2_43     stage2_44  0.94299999999999995
    L2_43     stage3_44  0.0019500000000000001
    L2_43     provision_43  0.023
    L2_44     stage2_44  -1
    L2_44     stage2_45  0.94299999999999995
    L2_44     stage3_45  0.0019500000000000001
    L2_44     provision_44  0.023
    L2_45     stage2_45  -1
    L2_45     stage2_46  0.94299999999999995
    L2_45     stage3_46  0.0019500000000000001
    L2_45     provision_45  0.023
    L2_46     stage2_46  -1
    L2_46     stage2_47  0.94299999999999995
    L2_46     stage3_47  0.0019500000000000001
    L2_46     provision_46  0.023
    L2_47     stage2_47  -1
    L2_47     stage2_48  0.94299999999999995
    L2_47     stage3_48  0.0019500000000000001
    L2_47     provision_47  0.023
    L2_48     stage2_48  -1
    L2_48     stage2_49  0.94299999999999995
    L2_48     stage3_49  0.0019500000000000001
    L2_48     provision_48  0.023
    L2_49     stage2_49  -1
    L2_49     stage2_50  0.94299999999999995
    L2_49     stage3_50  0.0019500000000000001
    L2_49     provision_49  0.023
    L2_50     stage2_50  -1
    L2_50     stage2_51  0.94299999999999995
    L2_50     stage3_51  0.0019500000000000001
    L2_50     provision_50  0.023
    L2_51     stage2_51  -1
    L2_51     stage2_52  0.94299999999999995
    L2_51     stage3_52  0.0019500000000000001
    L2_51     provision_51  0.023
    L2_52     stage2_52  -1
    L2_52     stage2_53  0.94299999999999995
    L2_52     stage3_53  0.0019500000000000001
    L2_52     provision_52  0.023
    L2_53     stage2_53  -1
    L2_53     stage2_54  0.94299999999999995
    L2_53     stage3_54  0.0019500000000000001
    L2_53     provision_53  0.023
    L2_54     stage2_54  -1
    L2_54     stage2_55  0.94299999999999995
    L2_54     stage3_55  0.0019500000000000001
    L2_54     provision_54  0.023
    L2_55     stage2_55  -1
    L2_55     stage2_56  0.94299999999999995
    L2_55     stage3_56  0.0019500000000000001
    L2_55     provision_55  0.023
    L2_56     stage2_56  -1
    L2_56     stage2_57  0.94299999999999995
    L2_56     stage3_57  0.0019500000000000001
    L2_56     provision_56  0.023
    L2_57     stage2_57  -1
    L2_57     stage2_58  0.94299999999999995
    L2_57     stage3_58  0.0019500000000000001
    L2_57     provision_57  0.023
    L2_58     stage2_58  -1
    L2_58     stage2_59  0.94299999999999995
    L2_58     stage3_59  0.0019500000000000001
    L2_58     provision_58  0.023
    L2_59     stage2_59  -1
    L2_59     stage2_60  0.94299999999999995
    L2_59     stage3_60  0.0019500000000000001
    L2_59     provision_59  0.023
    L2_60     stage2_60  -1
    L2_60     provision_60  0.023
    L3_1      writeoff_2  0.02
    L3_1      stage2_2  -0.0049999999999999975
    L3_1      stage3_1  1
    L3_1      stage3_2  0.98995
    L3_1      provision_1  0.24800000000000003
    L3_1      in_1      -0.0050000000000000001
    L3_2      writeoff_3  0.02
    L3_2      stage2_3  -0.0049999999999999975
    L3_2      stage3_2  -1
    L3_2      stage3_3  0.98995
    L3_2      provision_2  0.24800000000000003
    L3_2      in_2      -0.0050000000000000001
    L3_3      writeoff_4  0.02
    L3_3      stage2_4  -0.0049999999999999975
    L3_3      stage3_3  -1
    L3_3      stage3_4  0.98995
    L3_3      provision_3  0.24800000000000003
    L3_3      in_3      -0.0050000000000000001
    L3_4      writeoff_5  0.02
    L3_4      stage2_5  -0.0049999999999999975
    L3_4      stage3_4  -1
    L3_4      stage3_5  0.98995
    L3_4      provision_4  0.24800000000000003
    L3_4      in_4      -0.0050000000000000001
    L3_5      writeoff_6  0.02
    L3_5      stage2_6  -0.0049999999999999975
    L3_5      stage3_5  -1
    L3_5      stage3_6  0.98995
    L3_5      provision_5  0.24800000000000003
    L3_5      in_5      -0.0050000000000000001
    L3_6      writeoff_7  0.02
    L3_6      stage2_7  -0.0049999999999999975
    L3_6      stage3_6  -1
    L3_6      stage3_7  0.98995
    L3_6      provision_6  0.24800000000000003
    L3_6      in_6      -0.0050000000000000001
    L3_7      writeoff_8  0.02
    L3_7      stage2_8  -0.0049999999999999975
    L3_7      stage3_7  -1
    L3_7      stage3_8  0.98995
    L3_7      provision_7  0.24800000000000003
    L3_7      in_7      -0.0050000000000000001
    L3_8      writeoff_9  0.02
    L3_8      stage2_9  -0.0049999999999999975
    L3_8      stage3_8  -1
    L3_8      stage3_9  0.98995
    L3_8      provision_8  0.24800000000000003
    L3_8      in_8      -0.0050000000000000001
    L3_9      writeoff_10  0.02
    L3_9      stage2_10  -0.0049999999999999975
    L3_9      stage3_9  -1
    L3_9      stage3_10  0.98995
    L3_9      provision_9  0.24800000000000003
    L3_9      in_9      -0.0050000000000000001
    L3_10     writeoff_11  0.02
    L3_10     stage2_11  -0.0049999999999999975
    L3_10     stage3_10  -1
    L3_10     stage3_11  0.98995
    L3_10     provision_10  0.24800000000000003
    L3_10     in_10     -0.0050000000000000001
    L3_11     writeoff_12  0.02
    L3_11     stage2_12  -0.0049999999999999975
    L3_11     stage3_11  -1
    L3_11     stage3_12  0.98995
    L3_11     provision_11  0.24800000000000003
    L3_11     in_11     -0.0050000000000000001
    L3_12     writeoff_13  0.02
    L3_12     stage2_13  -0.0049999999999999975
    L3_12     stage3_12  -1
    L3_12     stage3_13  0.98995
    L3_12     provision_12  0.24800000000000003
    L3_12     in_12     -0.0050000000000000001
    L3_13     writeoff_14  0.02
    L3_13     stage2_14  -0.0049999999999999975
    L3_13     stage3_13  -1
    L3_13     stage3_14  0.98995
    L3_13     provision_13  0.24800000000000003
    L3_13     in_13     -0.0050000000000000001
    L3_14     writeoff_15  0.02
    L3_14     stage2_15  -0.0049999999999999975
    L3_14     stage3_14  -1
    L3_14     stage3_15  0.98995
    L3_14     provision_14  0.24800000000000003
    L3_14     in_14     -0.0050000000000000001
    L3_15     writeoff_16  0.02
    L3_15     stage2_16  -0.0049999999999999975
    L3_15     stage3_15  -1
    L3_15     stage3_16  0.98995
    L3_15     provision_15  0.24800000000000003
    L3_15     in_15     -0.0050000000000000001
    L3_16     writeoff_17  0.02
    L3_16     stage2_17  -0.0049999999999999975
    L3_16     stage3_16  -1
    L3_16     stage3_17  0.98995
    L3_16     provision_16  0.24800000000000003
    L3_16     in_16     -0.0050000000000000001
    L3_17     writeoff_18  0.02
    L3_17     stage2_18  -0.0049999999999999975
    L3_17     stage3_17  -1
    L3_17     stage3_18  0.98995
    L3_17     provision_17  0.24800000000000003
    L3_17     in_17     -0.0050000000000000001
    L3_18     writeoff_19  0.02
    L3_18     stage2_19  -0.0049999999999999975
    L3_18     stage3_18  -1
    L3_18     stage3_19  0.98995
    L3_18     provision_18  0.24800000000000003
    L3_18     in_18     -0.0050000000000000001
    L3_19     writeoff_20  0.02
    L3_19     stage2_20  -0.0049999999999999975
    L3_19     stage3_19  -1
    L3_19     stage3_20  0.98995
    L3_19     provision_19  0.24800000000000003
    L3_19     in_19     -0.0050000000000000001
    L3_20     writeoff_21  0.02
    L3_20     stage2_21  -0.0049999999999999975
    L3_20     stage3_20  -1
    L3_20     stage3_21  0.98995
    L3_20     provision_20  0.24800000000000003
    L3_20     in_20     -0.0050000000000000001
    L3_21     writeoff_22  0.02
    L3_21     stage2_22  -0.0049999999999999975
    L3_21     stage3_21  -1
    L3_21     stage3_22  0.98995
    L3_21     provision_21  0.24800000000000003
    L3_21     in_21     -0.0050000000000000001
    L3_22     writeoff_23  0.02
    L3_22     stage2_23  -0.0049999999999999975
    L3_22     stage3_22  -1
    L3_22     stage3_23  0.98995
    L3_22     provision_22  0.24800000000000003
    L3_22     in_22     -0.0050000000000000001
    L3_23     writeoff_24  0.02
    L3_23     stage2_24  -0.0049999999999999975
    L3_23     stage3_23  -1
    L3_23     stage3_24  0.98995
    L3_23     provision_23  0.24800000000000003
    L3_23     in_23     -0.0050000000000000001
    L3_24     writeoff_25  0.02
    L3_24     stage2_25  -0.0049999999999999975
    L3_24     stage3_24  -1
    L3_24     stage3_25  0.98995
    L3_24     provision_24  0.24800000000000003
    L3_24     in_24     -0.0050000000000000001
    L3_25     writeoff_26  0.02
    L3_25     stage2_26  -0.0049999999999999975
    L3_25     stage3_25  -1
    L3_25     stage3_26  0.98995
    L3_25     provision_25  0.24800000000000003
    L3_25     in_25     -0.0050000000000000001
    L3_26     writeoff_27  0.02
    L3_26     stage2_27  -0.0049999999999999975
    L3_26     stage3_26  -1
    L3_26     stage3_27  0.98995
    L3_26     provision_26  0.24800000000000003
    L3_26     in_26     -0.0050000000000000001
    L3_27     writeoff_28  0.02
    L3_27     stage2_28  -0.0049999999999999975
    L3_27     stage3_27  -1
    L3_27     stage3_28  0.98995
    L3_27     provision_27  0.24800000000000003
    L3_27     in_27     -0.0050000000000000001
    L3_28     writeoff_29  0.02
    L3_28     stage2_29  -0.0049999999999999975
    L3_28     stage3_28  -1
    L3_28     stage3_29  0.98995
    L3_28     provision_28  0.24800000000000003
    L3_28     in_28     -0.0050000000000000001
    L3_29     writeoff_30  0.02
    L3_29     stage2_30  -0.0049999999999999975
    L3_29     stage3_29  -1
    L3_29     stage3_30  0.98995
    L3_29     provision_29  0.24800000000000003
    L3_29     in_29     -0.0050000000000000001
    L3_30     writeoff_31  0.02
    L3_30     stage2_31  -0.0049999999999999975
    L3_30     stage3_30  -1
    L3_30     stage3_31  0.98995
    L3_30     provision_30  0.24800000000000003
    L3_30     in_30     -0.0050000000000000001
    L3_31     writeoff_32  0.02
    L3_31     stage2_32  -0.0049999999999999975
    L3_31     stage3_31  -1
    L3_31     stage3_32  0.98995
    L3_31     provision_31  0.24800000000000003
    L3_31     in_31     -0.0050000000000000001
    L3_32     writeoff_33  0.02
    L3_32     stage2_33  -0.0049999999999999975
    L3_32     stage3_32  -1
    L3_32     stage3_33  0.98995
    L3_32     provision_32  0.24800000000000003
    L3_32     in_32     -0.0050000000000000001
    L3_33     writeoff_34  0.02
    L3_33     stage2_34  -0.0049999999999999975
    L3_33     stage3_33  -1
    L3_33     stage3_34  0.98995
    L3_33     provision_33  0.24800000000000003
    L3_33     in_33     -0.0050000000000000001
    L3_34     writeoff_35  0.02
    L3_34     stage2_35  -0.0049999999999999975
    L3_34     stage3_34  -1
    L3_34     stage3_35  0.98995
    L3_34     provision_34  0.24800000000000003
    L3_34     in_34     -0.0050000000000000001
    L3_35     writeoff_36  0.02
    L3_35     stage2_36  -0.0049999999999999975
    L3_35     stage3_35  -1
    L3_35     stage3_36  0.98995
    L3_35     provision_35  0.24800000000000003
    L3_35     in_35     -0.0050000000000000001
    L3_36     writeoff_37  0.02
    L3_36     stage2_37  -0.0049999999999999975
    L3_36     stage3_36  -1
    L3_36     stage3_37  0.98995
    L3_36     provision_36  0.24800000000000003
    L3_36     in_36     -0.0050000000000000001
    L3_37     writeoff_38  0.02
    L3_37     stage2_38  -0.0049999999999999975
    L3_37     stage3_37  -1
    L3_37     stage3_38  0.98995
    L3_37     provision_37  0.24800000000000003
    L3_37     in_37     -0.0050000000000000001
    L3_38     writeoff_39  0.02
    L3_38     stage2_39  -0.0049999999999999975
    L3_38     stage3_38  -1
    L3_38     stage3_39  0.98995
    L3_38     provision_38  0.24800000000000003
    L3_38     in_38     -0.0050000000000000001
    L3_39     writeoff_40  0.02
    L3_39     stage2_40  -0.0049999999999999975
    L3_39     stage3_39  -1
    L3_39     stage3_40  0.98995
    L3_39     provision_39  0.24800000000000003
    L3_39     in_39     -0.0050000000000000001
    L3_40     writeoff_41  0.02
    L3_40     stage2_41  -0.0049999999999999975
    L3_40     stage3_40  -1
    L3_40     stage3_41  0.98995
    L3_40     provision_40  0.24800000000000003
    L3_40     in_40     -0.0050000000000000001
    L3_41     writeoff_42  0.02
    L3_41     stage2_42  -0.0049999999999999975
    L3_41     stage3_41  -1
    L3_41     stage3_42  0.98995
    L3_41     provision_41  0.24800000000000003
    L3_41     in_41     -0.0050000000000000001
    L3_42     writeoff_43  0.02
    L3_42     stage2_43  -0.0049999999999999975
    L3_42     stage3_42  -1
    L3_42     stage3_43  0.98995
    L3_42     provision_42  0.24800000000000003
    L3_42     in_42     -0.0050000000000000001
    L3_43     writeoff_44  0.02
    L3_43     stage2_44  -0.0049999999999999975
    L3_43     stage3_43  -1
    L3_43     stage3_44  0.98995
    L3_43     provision_43  0.24800000000000003
    L3_43     in_43     -0.0050000000000000001
    L3_44     writeoff_45  0.02
    L3_44     stage2_45  -0.0049999999999999975
    L3_44     stage3_44  -1
    L3_44     stage3_45  0.98995
    L3_44     provision_44  0.24800000000000003
    L3_44     in_44     -0.0050000000000000001
    L3_45     writeoff_46  0.02
    L3_45     stage2_46  -0.0049999999999999975
    L3_45     stage3_45  -1
    L3_45     stage3_46  0.98995
    L3_45     provision_45  0.24800000000000003
    L3_45     in_45     -0.0050000000000000001
    L3_46     writeoff_47  0.02
    L3_46     stage2_47  -0.0049999999999999975
    L3_46     stage3_46  -1
    L3_46     stage3_47  0.98995
    L3_46     provision_46  0.24800000000000003
    L3_46     in_46     -0.0050000000000000001
    L3_47     writeoff_48  0.02
    L3_47     stage2_48  -0.0049999999999999975
    L3_47     stage3_47  -1
    L3_47     stage3_48  0.98995
    L3_47     provision_47  0.24800000000000003
    L3_47     in_47     -0.0050000000000000001
    L3_48     writeoff_49  0.02
    L3_48     stage2_49  -0.0049999999999999975
    L3_48     stage3_48  -1
    L3_48     stage3_49  0.98995
    L3_48     provision_48  0.24800000000000003
    L3_48     in_48     -0.0050000000000000001
    L3_49     writeoff_50  0.02
    L3_49     stage2_50  -0.0049999999999999975
    L3_49     stage3_49  -1
    L3_49     stage3_50  0.98995
    L3_49     provision_49  0.24800000000000003
    L3_49     in_49     -0.0050000000000000001
    L3_50     writeoff_51  0.02
    L3_50     stage2_51  -0.0049999999999999975
    L3_50     stage3_50  -1
    L3_50     stage3_51  0.98995
    L3_50     provision_50  0.24800000000000003
    L3_50     in_50     -0.0050000000000000001
    L3_51     writeoff_52  0.02
    L3_51     stage2_52  -0.0049999999999999975
    L3_51     stage3_51  -1
    L3_51     stage3_52  0.98995
    L3_51     provision_51  0.24800000000000003
    L3_51     in_51     -0.0050000000000000001
    L3_52     writeoff_53  0.02
    L3_52     stage2_53  -0.0049999999999999975
    L3_52     stage3_52  -1
    L3_52     stage3_53  0.98995
    L3_52     provision_52  0.24800000000000003
    L3_52     in_52     -0.0050000000000000001
    L3_53     writeoff_54  0.02
    L3_53     stage2_54  -0.0049999999999999975
    L3_53     stage3_53  -1
    L3_53     stage3_54  0.98995
    L3_53     provision_53  0.24800000000000003
    L3_53     in_53     -0.0050000000000000001
    L3_54     writeoff_55  0.02
    L3_54     stage2_55  -0.0049999999999999975
    L3_54     stage3_54  -1
    L3_54     stage3_55  0.98995
    L3_54     provision_54  0.24800000000000003
    L3_54     in_54     -0.0050000000000000001
    L3_55     writeoff_56  0.02
    L3_55     stage2_56  -0.0049999999999999975
    L3_55     stage3_55  -1
    L3_55     stage3_56  0.98995
    L3_55     provision_55  0.24800000000000003
    L3_55     in_55     -0.0050000000000000001
    L3_56     writeoff_57  0.02
    L3_56     stage2_57  -0.0049999999999999975
    L3_56     stage3_56  -1
    L3_56     stage3_57  0.98995
    L3_56     provision_56  0.24800000000000003
    L3_56     in_56     -0.0050000000000000001
    L3_57     writeoff_58  0.02
    L3_57     stage2_58  -0.0049999999999999975
    L3_57     stage3_57  -1
    L3_57     stage3_58  0.98995
    L3_57     provision_57  0.24800000000000003
    L3_57     in_57     -0.0050000000000000001
    L3_58     writeoff_59  0.02
    L3_58     stage2_59  -0.0049999999999999975
    L3_58     stage3_58  -1
    L3_58     stage3_59  0.98995
    L3_58     provision_58  0.24800000000000003
    L3_58     in_58     -0.0050000000000000001
    L3_59     writeoff_60  0.02
    L3_59     stage2_60  -0.0049999999999999975
    L3_59     stage3_59  -1
    L3_59     stage3_60  0.98995
    L3_59     provision_59  0.24800000000000003
    L3_59     in_59     -0.0050000000000000001
    L3_60     Obj       -0.019999999999999997
    L3_60     stage3_60  -1
    L3_60     provision_60  0.24800000000000003
    L3_60     in_60     -0.0050000000000000001
    WO_1      writeoff_1  1
    WO_1      stage3_1  1
    WO_1      loan_1    -1
    WO_1      imp_1     1
    WO_2      writeoff_2  -1
    WO_2      stage3_2  -0.99999999999999989
    WO_2      loan_2    -1
    WO_2      imp_2     1
    WO_3      writeoff_3  -1
    WO_3      stage3_3  -0.99999999999999989
    WO_3      loan_3    -1
    WO_3      imp_3     1
    WO_4      writeoff_4  -1
    WO_4      stage3_4  -0.99999999999999989
    WO_4      loan_4    -1
    WO_4      imp_4     1
    WO_5      writeoff_5  -1
    WO_5      stage3_5  -0.99999999999999989
    WO_5      loan_5    -1
    WO_5      imp_5     1
    WO_6      writeoff_6  -1
    WO_6      stage3_6  -0.99999999999999989
    WO_6      loan_6    -1
    WO_6      imp_6     1
    WO_7      writeoff_7  -1
    WO_7      stage3_7  -0.99999999999999989
    WO_7      loan_7    -1
    WO_7      imp_7     1
    WO_8      writeoff_8  -1
    WO_8      stage3_8  -0.99999999999999989
    WO_8      loan_8    -1
    WO_8      imp_8     1
    WO_9      writeoff_9  -1
    WO_9      stage3_9  -0.99999999999999989
    WO_9      loan_9    -1
    WO_9      imp_9     1
    WO_10     writeoff_10  -1
    WO_10     stage3_10  -0.99999999999999989
    WO_10     loan_10   -1
    WO_10     imp_10    1
    WO_11     writeoff_11  -1
    WO_11     stage3_11  -0.99999999999999989
    WO_11     loan_11   -1
    WO_11     imp_11    1
    WO_12     writeoff_12  -1
    WO_12     stage3_12  -0.99999999999999989
    WO_12     loan_12   -1
    WO_12     imp_12    1
    WO_13     writeoff_13  -1
    WO_13     stage3_13  -0.99999999999999989
    WO_13     loan_13   -1
    WO_13     imp_13    1
    WO_14     writeoff_14  -1
    WO_14     stage3_14  -0.99999999999999989
    WO_14     loan_14   -1
    WO_14     imp_14    1
    WO_15     writeoff_15  -1
    WO_15     stage3_15  -0.99999999999999989
    WO_15     loan_15   -1
    WO_15     imp_15    1
    WO_16     writeoff_16  -1
    WO_16     stage3_16  -0.99999999999999989
    WO_16     loan_16   -1
    WO_16     imp_16    1
    WO_17     writeoff_17  -1
    WO_17     stage3_17  -0.99999999999999989
    WO_17     loan_17   -1
    WO_17     imp_17    1
    WO_18     writeoff_18  -1
    WO_18     stage3_18  -0.99999999999999989
    WO_18     loan_18   -1
    WO_18     imp_18    1
    WO_19     writeoff_19  -1
    WO_19     stage3_19  -0.99999999999999989
    WO_19     loan_19   -1
    WO_19     imp_19    1
    WO_20     writeoff_20  -1
    WO_20     stage3_20  -0.99999999999999989
    WO_20     loan_20   -1
    WO_20     imp_20    1
    WO_21     writeoff_21  -1
    WO_21     stage3_21  -0.99999999999999989
    WO_21     loan_21   -1
    WO_21     imp_21    1
    WO_22     writeoff_22  -1
    WO_22     stage3_22  -0.99999999999999989
    WO_22     loan_22   -1
    WO_22     imp_22    1
    WO_23     writeoff_23  -1
    WO_23     stage3_23  -0.99999999999999989
    WO_23     loan_23   -1
    WO_23     imp_23    1
    WO_24     writeoff_24  -1
    WO_24     stage3_24  -0.99999999999999989
    WO_24     loan_24   -1
    WO_24     imp_24    1
    WO_25     writeoff_25  -1
    WO_25     stage3_25  -0.99999999999999989
    WO_25     loan_25   -1
    WO_25     imp_25    1
    WO_26     writeoff_26  -1
    WO_26     stage3_26  -0.99999999999999989
    WO_26     loan_26   -1
    WO_26     imp_26    1
    WO_27     writeoff_27  -1
    WO_27     stage3_27  -0.99999999999999989
    WO_27     loan_27   -1
    WO_27     imp_27    1
    WO_28     writeoff_28  -1
    WO_28     stage3_28  -0.99999999999999989
    WO_28     loan_28   -1
    WO_28     imp_28    1
    WO_29     writeoff_29  -1
    WO_29     stage3_29  -0.99999999999999989
    WO_29     loan_29   -1
    WO_29     imp_29    1
    WO_30     writeoff_30  -1
    WO_30     stage3_30  -0.99999999999999989
    WO_30     loan_30   -1
    WO_30     imp_30    1
    WO_31     writeoff_31  -1
    WO_31     stage3_31  -0.99999999999999989
    WO_31     loan_31   -1
    WO_31     imp_31    1
    WO_32     writeoff_32  -1
    WO_32     stage3_32  -0.99999999999999989
    WO_32     loan_32   -1
    WO_32     imp_32    1
    WO_33     writeoff_33  -1
    WO_33     stage3_33  -0.99999999999999989
    WO_33     loan_33   -1
    WO_33     imp_33    1
    WO_34     writeoff_34  -1
    WO_34     stage3_34  -0.99999999999999989
    WO_34     loan_34   -1
    WO_34     imp_34    1
    WO_35     writeoff_35  -1
    WO_35     stage3_35  -0.99999999999999989
    WO_35     loan_35   -1
    WO_35     imp_35    1
    WO_36     writeoff_36  -1
    WO_36     stage3_36  -0.99999999999999989
    WO_36     loan_36   -1
    WO_36     imp_36    1
    WO_37     writeoff_37  -1
    WO_37     stage3_37  -0.99999999999999989
    WO_37     loan_37   -1
    WO_37     imp_37    1
    WO_38     writeoff_38  -1
    WO_38     stage3_38  -0.99999999999999989
    WO_38     loan_38   -1
    WO_38     imp_38    1
    WO_39     writeoff_39  -1
    WO_39     stage3_39  -0.99999999999999989
    WO_39     loan_39   -1
    WO_39     imp_39    1
    WO_40     writeoff_40  -1
    WO_40     stage3_40  -0.99999999999999989
    WO_40     loan_40   -1
    WO_40     imp_40    1
    WO_41     writeoff_41  -1
    WO_41     stage3_41  -0.99999999999999989
    WO_41     loan_41   -1
    WO_41     imp_41    1
    WO_42     writeoff_42  -1
    WO_42     stage3_42  -0.99999999999999989
    WO_42     loan_42   -1
    WO_42     imp_42    1
    WO_43     writeoff_43  -1
    WO_43     stage3_43  -0.99999999999999989
    WO_43     loan_43   -1
    WO_43     imp_43    1
    WO_44     writeoff_44  -1
    WO_44     stage3_44  -0.99999999999999989
    WO_44     loan_44   -1
    WO_44     imp_44    1
    WO_45     writeoff_45  -1
    WO_45     stage3_45  -0.99999999999999989
    WO_45     loan_45   -1
    WO_45     imp_45    1
    WO_46     writeoff_46  -1
    WO_46     stage3_46  -0.99999999999999989
    WO_46     loan_46   -1
    WO_46     imp_46    1
    WO_47     writeoff_47  -1
    WO_47     stage3_47  -0.99999999999999989
    WO_47     loan_47   -1
    WO_47     imp_47    1
    WO_48     writeoff_48  -1
    WO_48     stage3_48  -0.99999999999999989
    WO_48     loan_48   -1
    WO_48     imp_48    1
    WO_49     writeoff_49  -1
    WO_49     stage3_49  -0.99999999999999989
    WO_49     loan_49   -1
    WO_49     imp_49    1
    WO_50     writeoff_50  -1
    WO_50     stage3_50  -0.99999999999999989
    WO_50     loan_50   -1
    WO_50     imp_50    1
    WO_51     writeoff_51  -1
    WO_51     stage3_51  -0.99999999999999989
    WO_51     loan_51   -1
    WO_51     imp_51    1
    WO_52     writeoff_52  -1
    WO_52     stage3_52  -0.99999999999999989
    WO_52     loan_52   -1
    WO_52     imp_52    1
    WO_53     writeoff_53  -1
    WO_53     stage3_53  -0.99999999999999989
    WO_53     loan_53   -1
    WO_53     imp_53    1
    WO_54     writeoff_54  -1
    WO_54     stage3_54  -0.99999999999999989
    WO_54     loan_54   -1
    WO_54     imp_54    1
    WO_55     writeoff_55  -1
    WO_55     stage3_55  -0.99999999999999989
    WO_55     loan_55   -1
    WO_55     imp_55    1
    WO_56     writeoff_56  -1
    WO_56     stage3_56  -0.99999999999999989
    WO_56     loan_56   -1
    WO_56     imp_56    1
    WO_57     writeoff_57  -1
    WO_57     stage3_57  -0.99999999999999989
    WO_57     loan_57   -1
    WO_57     imp_57    1
    WO_58     writeoff_58  -1
    WO_58     stage3_58  -0.99999999999999989
    WO_58     loan_58   -1
    WO_58     imp_58    1
    WO_59     writeoff_59  -1
    WO_59     stage3_59  -0.99999999999999989
    WO_59     loan_59   -1
    WO_59     imp_59    1
    WO_60     writeoff_60  -1
    WO_60     stage3_60  -0.99999999999999989
    WO_60     loan_60   -1
    WO_60     imp_60    1
    PR_1      provision_1  -1
    PR_1      balance_1  -1
    PR_1      imp_1     1
    PR_1      imp_2     -1
    PR_1      lev_min_1  0.032500000000000001
    PR_1      lev_buf_1  0.037499999999999999
    PR_2      provision_2  -1
    PR_2      balance_2  -1
    PR_2      imp_2     1
    PR_2      imp_3     -1
    PR_2      lev_min_2  0.032500000000000001
    PR_2      lev_buf_2  0.037499999999999999
    PR_3      provision_3  -1
    PR_3      balance_3  -1
    PR_3      imp_3     1
    PR_3      imp_4     -1
    PR_3      lev_min_3  0.032500000000000001
    PR_3      lev_buf_3  0.037499999999999999
    PR_4      provision_4  -1
    PR_4      balance_4  -1
    PR_4      imp_4     1
    PR_4      imp_5     -1
    PR_4      lev_min_4  0.032500000000000001
    PR_4      lev_buf_4  0.037499999999999999
    PR_5      provision_5  -1
    PR_5      balance_5  -1
    PR_5      imp_5     1
    PR_5      imp_6     -1
    PR_5      lev_min_5  0.032500000000000001
    PR_5      lev_buf_5  0.037499999999999999
    PR_6      provision_6  -1
    PR_6      balance_6  -1
    PR_6      imp_6     1
    PR_6      imp_7     -1
    PR_6      lev_min_6  0.032500000000000001
    PR_6      lev_buf_6  0.037499999999999999
    PR_7      provision_7  -1
    PR_7      balance_7  -1
    PR_7      imp_7     1
    PR_7      imp_8     -1
    PR_7      lev_min_7  0.032500000000000001
    PR_7      lev_buf_7  0.037499999999999999
    PR_8      provision_8  -1
    PR_8      balance_8  -1
    PR_8      imp_8     1
    PR_8      imp_9     -1
    PR_8      lev_min_8  0.032500000000000001
    PR_8      lev_buf_8  0.037499999999999999
    PR_9      provision_9  -1
    PR_9      balance_9  -1
    PR_9      imp_9     1
    PR_9      imp_10    -1
    PR_9      lev_min_9  0.032500000000000001
    PR_9      lev_buf_9  0.037499999999999999
    PR_10     provision_10  -1
    PR_10     balance_10  -1
    PR_10     imp_10    1
    PR_10     imp_11    -1
    PR_10     lev_min_10  0.032500000000000001
    PR_10     lev_buf_10  0.037499999999999999
    PR_11     provision_11  -1
    PR_11     balance_11  -1
    PR_11     imp_11    1
    PR_11     imp_12    -1
    PR_11     lev_min_11  0.032500000000000001
    PR_11     lev_buf_11  0.037499999999999999
    PR_12     provision_12  -1
    PR_12     balance_12  -1
    PR_12     imp_12    1
    PR_12     imp_13    -1
    PR_12     lev_min_12  0.032500000000000001
    PR_12     lev_buf_12  0.037499999999999999
    PR_13     provision_13  -1
    PR_13     balance_13  -1
    PR_13     imp_13    1
    PR_13     imp_14    -1
    PR_13     lev_min_13  0.032500000000000001
    PR_13     lev_buf_13  0.037499999999999999
    PR_14     provision_14  -1
    PR_14     balance_14  -1
    PR_14     imp_14    1
    PR_14     imp_15    -1
    PR_14     lev_min_14  0.032500000000000001
    PR_14     lev_buf_14  0.037499999999999999
    PR_15     provision_15  -1
    PR_15     balance_15  -1
    PR_15     imp_15    1
    PR_15     imp_16    -1
    PR_15     lev_min_15  0.032500000000000001
    PR_15     lev_buf_15  0.037499999999999999
    PR_16     provision_16  -1
    PR_16     balance_16  -1
    PR_16     imp_16    1
    PR_16     imp_17    -1
    PR_16     lev_min_16  0.032500000000000001
    PR_16     lev_buf_16  0.037499999999999999
    PR_17     provision_17  -1
    PR_17     balance_17  -1
    PR_17     imp_17    1
    PR_17     imp_18    -1
    PR_17     lev_min_17  0.032500000000000001
    PR_17     lev_buf_17  0.037499999999999999
    PR_18     provision_18  -1
    PR_18     balance_18  -1
    PR_18     imp_18    1
    PR_18     imp_19    -1
    PR_18     lev_min_18  0.032500000000000001
    PR_18     lev_buf_18  0.037499999999999999
    PR_19     provision_19  -1
    PR_19     balance_19  -1
    PR_19     imp_19    1
    PR_19     imp_20    -1
    PR_19     lev_min_19  0.032500000000000001
    PR_19     lev_buf_19  0.037499999999999999
    PR_20     provision_20  -1
    PR_20     balance_20  -1
    PR_20     imp_20    1
    PR_20     imp_21    -1
    PR_20     lev_min_20  0.032500000000000001
    PR_20     lev_buf_20  0.037499999999999999
    PR_21     provision_21  -1
    PR_21     balance_21  -1
    PR_21     imp_21    1
    PR_21     imp_22    -1
    PR_21     lev_min_21  0.032500000000000001
    PR_21     lev_buf_21  0.037499999999999999
    PR_22     provision_22  -1
    PR_22     balance_22  -1
    PR_22     imp_22    1
    PR_22     imp_23    -1
    PR_22     lev_min_22  0.032500000000000001
    PR_22     lev_buf_22  0.037499999999999999
    PR_23     provision_23  -1
    PR_23     balance_23  -1
    PR_23     imp_23    1
    PR_23     imp_24    -1
    PR_23     lev_min_23  0.032500000000000001
    PR_23     lev_buf_23  0.037499999999999999
    PR_24     provision_24  -1
    PR_24     balance_24  -1
    PR_24     imp_24    1
    PR_24     imp_25    -1
    PR_24     lev_min_24  0.032500000000000001
    PR_24     lev_buf_24  0.037499999999999999
    PR_25     provision_25  -1
    PR_25     balance_25  -1
    PR_25     imp_25    1
    PR_25     imp_26    -1
    PR_25     lev_min_25  0.032500000000000001
    PR_25     lev_buf_25  0.037499999999999999
    PR_26     provision_26  -1
    PR_26     balance_26  -1
    PR_26     imp_26    1
    PR_26     imp_27    -1
    PR_26     lev_min_26  0.032500000000000001
    PR_26     lev_buf_26  0.037499999999999999
    PR_27     provision_27  -1
    PR_27     balance_27  -1
    PR_27     imp_27    1
    PR_27     imp_28    -1
    PR_27     lev_min_27  0.032500000000000001
    PR_27     lev_buf_27  0.037499999999999999
    PR_28     provision_28  -1
    PR_28     balance_28  -1
    PR_28     imp_28    1
    PR_28     imp_29    -1
    PR_28     lev_min_28  0.032500000000000001
    PR_28     lev_buf_28  0.037499999999999999
    PR_29     provision_29  -1
    PR_29     balance_29  -1
    PR_29     imp_29    1
    PR_29     imp_30    -1
    PR_29     lev_min_29  0.032500000000000001
    PR_29     lev_buf_29  0.037499999999999999
    PR_30     provision_30  -1
    PR_30     balance_30  -1
    PR_30     imp_30    1
    PR_30     imp_31    -1
    PR_30     lev_min_30  0.032500000000000001
    PR_30     lev_buf_30  0.037499999999999999
    PR_31     provision_31  -1
    PR_31     balance_31  -1
    PR_31     imp_31    1
    PR_31     imp_32    -1
    PR_31     lev_min_31  0.032500000000000001
    PR_31     lev_buf_31  0.037499999999999999
    PR_32     provision_32  -1
    PR_32     balance_32  -1
    PR_32     imp_32    1
    PR_32     imp_33    -1
    PR_32     lev_min_32  0.032500000000000001
    PR_32     lev_buf_32  0.037499999999999999
    PR_33     provision_33  -1
    PR_33     balance_33  -1
    PR_33     imp_33    1
    PR_33     imp_34    -1
    PR_33     lev_min_33  0.032500000000000001
    PR_33     lev_buf_33  0.037499999999999999
    PR_34     provision_34  -1
    PR_34     balance_34  -1
    PR_34     imp_34    1
    PR_34     imp_35    -1
    PR_34     lev_min_34  0.032500000000000001
    PR_34     lev_buf_34  0.037499999999999999
    PR_35     provision_35  -1
    PR_35     balance_35  -1
    PR_35     imp_35    1
    PR_35     imp_36    -1
    PR_35     lev_min_35  0.032500000000000001
    PR_35     lev_buf_35  0.037499999999999999
    PR_36     provision_36  -1
    PR_36     balance_36  -1
    PR_36     imp_36    1
    PR_36     imp_37    -1
    PR_36     lev_min_36  0.032500000000000001
    PR_36     lev_buf_36  0.037499999999999999
    PR_37     provision_37  -1
    PR_37     balance_37  -1
    PR_37     imp_37    1
    PR_37     imp_38    -1
    PR_37     lev_min_37  0.032500000000000001
    PR_37     lev_buf_37  0.037499999999999999
    PR_38     provision_38  -1
    PR_38     balance_38  -1
    PR_38     imp_38    1
    PR_38     imp_39    -1
    PR_38     lev_min_38  0.032500000000000001
    PR_38     lev_buf_38  0.037499999999999999
    PR_39     provision_39  -1
    PR_39     balance_39  -1
    PR_39     imp_39    1
    PR_39     imp_40    -1
    PR_39     lev_min_39  0.032500000000000001
    PR_39     lev_buf_39  0.037499999999999999
    PR_40     provision_40  -1
    PR_40     balance_40  -1
    PR_40     imp_40    1
    PR_40     imp_41    -1
    PR_40     lev_min_40  0.032500000000000001
    PR_40     lev_buf_40  0.037499999999999999
    PR_41     provision_41  -1
    PR_41     balance_41  -1
    PR_41     imp_41    1
    PR_41     imp_42    -1
    PR_41     lev_min_41  0.032500000000000001
    PR_41     lev_buf_41  0.037499999999999999
    PR_42     provision_42  -1
    PR_42     balance_42  -1
    PR_42     imp_42    1
    PR_42     imp_43    -1
    PR_42     lev_min_42  0.032500000000000001
    PR_42     lev_buf_42  0.037499999999999999
    PR_43     provision_43  -1
    PR_43     balance_43  -1
    PR_43     imp_43    1
    PR_43     imp_44    -1
    PR_43     lev_min_43  0.032500000000000001
    PR_43     lev_buf_43  0.037499999999999999
    PR_44     provision_44  -1
    PR_44     balance_44  -1
    PR_44     imp_44    1
    PR_44     imp_45    -1
    PR_44     lev_min_44  0.032500000000000001
    PR_44     lev_buf_44  0.037499999999999999
    PR_45     provision_45  -1
    PR_45     balance_45  -1
    PR_45     imp_45    1
    PR_45     imp_46    -1
    PR_45     lev_min_45  0.032500000000000001
    PR_45     lev_buf_45  0.037499999999999999
    PR_46     provision_46  -1
    PR_46     balance_46  -1
    PR_46     imp_46    1
    PR_46     imp_47    -1
    PR_46     lev_min_46  0.032500000000000001
    PR_46     lev_buf_46  0.037499999999999999
    PR_47     provision_47  -1
    PR_47     balance_47  -1
    PR_47     imp_47    1
    PR_47     imp_48    -1
    PR_47     lev_min_47  0.032500000000000001
    PR_47     lev_buf_47  0.037499999999999999
    PR_48     provision_48  -1
    PR_48     balance_48  -1
    PR_48     imp_48    1
    PR_48     imp_49    -1
    PR_48     lev_min_48  0.032500000000000001
    PR_48     lev_buf_48  0.037499999999999999
    PR_49     provision_49  -1
    PR_49     balance_49  -1
    PR_49     imp_49    1
    PR_49     imp_50    -1
    PR_49     lev_min_49  0.032500000000000001
    PR_49     lev_buf_49  0.037499999999999999
    PR_50     provision_50  -1
    PR_50     balance_50  -1
    PR_50     imp_50    1
    PR_50     imp_51    -1
    PR_50     lev_min_50  0.032500000000000001
    PR_50     lev_buf_50  0.037499999999999999
    PR_51     provision_51  -1
    PR_51     balance_51  -1
    PR_51     imp_51    1
    PR_51     imp_52    -1
    PR_51     lev_min_51  0.032500000000000001
    PR_51     lev_buf_51  0.037499999999999999
    PR_52     provision_52  -1
    PR_52     balance_52  -1
    PR_52     imp_52    1
    PR_52     imp_53    -1
    PR_52     lev_min_52  0.032500000000000001
    PR_52     lev_buf_52  0.037499999999999999
    PR_53     provision_53  -1
    PR_53     balance_53  -1
    PR_53     imp_53    1
    PR_53     imp_54    -1
    PR_53     lev_min_53  0.032500000000000001
    PR_53     lev_buf_53  0.037499999999999999
    PR_54     provision_54  -1
    PR_54     balance_54  -1
    PR_54     imp_54    1
    PR_54     imp_55    -1
    PR_54     lev_min_54  0.032500000000000001
    PR_54     lev_buf_54  0.037499999999999999
    PR_55     provision_55  -1
    PR_55     balance_55  -1
    PR_55     imp_55    1
    PR_55     imp_56    -1
    PR_55     lev_min_55  0.032500000000000001
    PR_55     lev_buf_55  0.037499999999999999
    PR_56     provision_56  -1
    PR_56     balance_56  -1
    PR_56     imp_56    1
    PR_56     imp_57    -1
    PR_56     lev_min_56  0.032500000000000001
    PR_56     lev_buf_56  0.037499999999999999
    PR_57     provision_57  -1
    PR_57     balance_57  -1
    PR_57     imp_57    1
    PR_57     imp_58    -1
    PR_57     lev_min_57  0.032500000000000001
    PR_57     lev_buf_57  0.037499999999999999
    PR_58     provision_58  -1
    PR_58     balance_58  -1
    PR_58     imp_58    1
    PR_58     imp_59    -1
    PR_58     lev_min_58  0.032500000000000001
    PR_58     lev_buf_58  0.037499999999999999
    PR_59     provision_59  -1
    PR_59     balance_59  -1
    PR_59     imp_59    1
    PR_59     imp_60    -1
    PR_59     lev_min_59  0.032500000000000001
    PR_59     lev_buf_59  0.037499999999999999
    PR_60     provision_60  -1
    PR_60     balance_60  -1
    PR_60     imp_60    1
    PR_60     lev_min_60  0.032500000000000001
    PR_60     lev_buf_60  0.037499999999999999
    ws_1      short_whole_1  -1
    ws_1      short_whole_4  -1
    ws_1      out_3     1
    ws_2      short_whole_2  1
    ws_2      short_whole_5  -1
    ws_2      out_4     1
    ws_3      short_whole_3  1
    ws_3      short_whole_6  -1
    ws_3      out_5     1
    ws_4      short_whole_4  1
    ws_4      short_whole_7  -1
    ws_4      out_6     1
    ws_5      short_whole_5  1
    ws_5      short_whole_8  -1
    ws_5      out_7     1
    ws_6      short_whole_6  1
    ws_6      short_whole_9  -1
    ws_6      out_8     1
    ws_7      short_whole_7  1
    ws_7      short_whole_10  -1
    ws_7      out_9     1
    ws_8      short_whole_8  1
    ws_8      short_whole_11  -1
    ws_8      out_10    1
    ws_9      short_whole_9  1
    ws_9      short_whole_12  -1
    ws_9      out_11    1
    ws_10     short_whole_10  1
    ws_10     short_whole_13  -1
    ws_10     out_12    1
    ws_11     short_whole_11  1
    ws_11     short_whole_14  -1
    ws_11     out_13    1
    ws_12     short_whole_12  1
    ws_12     short_whole_15  -1
    ws_12     out_14    1
    ws_13     short_whole_13  1
    ws_13     short_whole_16  -1
    ws_13     out_15    1
    ws_14     short_whole_14  1
    ws_14     short_whole_17  -1
    ws_14     out_16    1
    ws_15     short_whole_15  1
    ws_15     short_whole_18  -1
    ws_15     out_17    1
    ws_16     short_whole_16  1
    ws_16     short_whole_19  -1
    ws_16     out_18    1
    ws_17     short_whole_17  1
    ws_17     short_whole_20  -1
    ws_17     out_19    1
    ws_18     short_whole_18  1
    ws_18     short_whole_21  -1
    ws_18     out_20    1
    ws_19     short_whole_19  1
    ws_19     short_whole_22  -1
    ws_19     out_21    1
    ws_20     short_whole_20  1
    ws_20     short_whole_23  -1
    ws_20     out_22    1
    ws_21     short_whole_21  1
    ws_21     short_whole_24  -1
    ws_21     out_23    1
    ws_22     short_whole_22  1
    ws_22     short_whole_25  -1
    ws_22     out_24    1
    ws_23     short_whole_23  1
    ws_23     short_whole_26  -1
    ws_23     out_25    1
    ws_24     short_whole_24  1
    ws_24     short_whole_27  -1
    ws_24     out_26    1
    ws_25     short_whole_25  1
    ws_25     short_whole_28  -1
    ws_25     out_27    1
    ws_26     short_whole_26  1
    ws_26     short_whole_29  -1
    ws_26     out_28    1
    ws_27     short_whole_27  1
    ws_27     short_whole_30  -1
    ws_27     out_29    1
    ws_28     short_whole_28  1
    ws_28     short_whole_31  -1
    ws_28     out_30    1
    ws_29     short_whole_29  1
    ws_29     short_whole_32  -1
    ws_29     out_31    1
    ws_30     short_whole_30  1
    ws_30     short_whole_33  -1
    ws_30     out_32    1
    ws_31     short_whole_31  1
    ws_31     short_whole_34  -1
    ws_31     out_33    1
    ws_32     short_whole_32  1
    ws_32     short_whole_35  -1
    ws_32     out_34    1
    ws_33     short_whole_33  1
    ws_33     short_whole_36  -1
    ws_33     out_35    1
    ws_34     short_whole_34  1
    ws_34     short_whole_37  -1
    ws_34     out_36    1
    ws_35     short_whole_35  1
    ws_35     short_whole_38  -1
    ws_35     out_37    1
    ws_36     short_whole_36  1
    ws_36     short_whole_39  -1
    ws_36     out_38    1
    ws_37     short_whole_37  1
    ws_37     short_whole_40  -1
    ws_37     out_39    1
    ws_38     short_whole_38  1
    ws_38     short_whole_41  -1
    ws_38     out_40    1
    ws_39     short_whole_39  1
    ws_39     short_whole_42  -1
    ws_39     out_41    1
    ws_40     short_whole_40  1
    ws_40     short_whole_43  -1
    ws_40     out_42    1
    ws_41     short_whole_41  1
    ws_41     short_whole_44  -1
    ws_41     out_43    1
    ws_42     short_whole_42  1
    ws_42     short_whole_45  -1
    ws_42     out_44    1
    ws_43     short_whole_43  1
    ws_43     short_whole_46  -1
    ws_43     out_45    1
    ws_44     short_whole_44  1
    ws_44     short_whole_47  -1
    ws_44     out_46    1
    ws_45     short_whole_45  1
    ws_45     short_whole_48  -1
    ws_45     out_47    1
    ws_46     short_whole_46  1
    ws_46     short_whole_49  -1
    ws_46     out_48    1
    ws_47     short_whole_47  1
    ws_47     short_whole_50  -1
    ws_47     out_49    1
    ws_48     short_whole_48  1
    ws_48     short_whole_51  -1
    ws_48     out_50    1
    ws_49     short_whole_49  1
    ws_49     short_whole_52  -1
    ws_49     out_51    1
    ws_50     short_whole_50  1
    ws_50     short_whole_53  -1
    ws_50     out_52    1
    ws_51     short_whole_51  1
    ws_51     short_whole_54  -1
    ws_51     out_53    1
    ws_52     short_whole_52  1
    ws_52     short_whole_55  -1
    ws_52     out_54    1
    ws_53     short_whole_53  1
    ws_53     short_whole_56  -1
    ws_53     out_55    1
    ws_54     short_whole_54  1
    ws_54     short_whole_57  -1
    ws_54     out_56    1
    ws_55     short_whole_55  1
    ws_55     short_whole_58  -1
    ws_55     out_57    1
    ws_56     short_whole_56  1
    ws_56     short_whole_59  -1
    ws_56     out_58    1
    ws_57     short_whole_57  1
    ws_57     short_whole_60  -1
    ws_57     out_59    1
    ws_58     short_whole_58  1
    ws_58     out_60    1
    ws_59     short_whole_59  1
    ws_60     short_whole_60  1
    WS_1      short_whole_1  1
    WS_1      short_whole_2  1
    WS_1      balance_1  -1
    WS_1      ie_2      0.0034096041666666667
    WS_2      short_whole_2  -1
    WS_2      short_whole_3  1
    WS_2      balance_2  -1
    WS_2      ie_3      0.0034025424999999999
    WS_3      short_whole_3  -1
    WS_3      short_whole_4  1
    WS_3      balance_3  -1
    WS_3      ie_4      0.0033954799999999998
    WS_4      short_whole_4  -1
    WS_4      short_whole_5  1
    WS_4      balance_4  -1
    WS_4      ie_5      0.003388418333333333
    WS_5      short_whole_5  -1
    WS_5      short_whole_6  1
    WS_5      balance_5  -1
    WS_5      ie_6      0.0033813558333333328
    WS_6      short_whole_6  -1
    WS_6      short_whole_7  1
    WS_6      balance_6  -1
    WS_6      ie_7      0.0033742941666666665
    WS_7      short_whole_7  -1
    WS_7      short_whole_8  1
    WS_7      balance_7  -1
    WS_7      ie_8      0.0033672316666666668
    WS_8      short_whole_8  -1
    WS_8      short_whole_9  1
    WS_8      balance_8  -1
    WS_8      ie_9      0.0033601691666666667
    WS_9      short_whole_9  -1
    WS_9      short_whole_10  1
    WS_9      balance_9  -1
    WS_9      ie_10     0.0033531074999999999
    WS_10     short_whole_10  -1
    WS_10     short_whole_11  1
    WS_10     balance_10  -1
    WS_10     ie_11     0.0033460449999999997
    WS_11     short_whole_11  -1
    WS_11     short_whole_12  1
    WS_11     balance_11  -1
    WS_11     ie_12     0.0033389833333333334
    WS_12     short_whole_12  -1
    WS_12     short_whole_13  1
    WS_12     balance_12  -1
    WS_12     ie_13     0.0033319208333333333
    WS_13     short_whole_13  -1
    WS_13     short_whole_14  1
    WS_13     balance_13  -1
    WS_13     ie_14     0.0033248591666666665
    WS_14     short_whole_14  -1
    WS_14     short_whole_15  1
    WS_14     balance_14  -1
    WS_14     ie_15     0.0033177966666666663
    WS_15     short_whole_15  -1
    WS_15     short_whole_16  1
    WS_15     balance_15  -1
    WS_15     ie_16     0.0033107341666666667
    WS_16     short_whole_16  -1
    WS_16     short_whole_17  1
    WS_16     balance_16  -1
    WS_16     ie_17     0.0033036724999999994
    WS_17     short_whole_17  -1
    WS_17     short_whole_18  1
    WS_17     balance_17  -1
    WS_17     ie_18     0.0032966100000000002
    WS_18     short_whole_18  -1
    WS_18     short_whole_19  1
    WS_18     balance_18  -1
    WS_18     ie_19     0.0032895483333333334
    WS_19     short_whole_19  -1
    WS_19     short_whole_20  1
    WS_19     balance_19  -1
    WS_19     ie_20     0.0032824858333333332
    WS_20     short_whole_20  -1
    WS_20     short_whole_21  1
    WS_20     balance_20  -1
    WS_20     ie_21     0.0032754233333333331
    WS_21     short_whole_21  -1
    WS_21     short_whole_22  1
    WS_21     balance_21  -1
    WS_21     ie_22     0.0032683616666666663
    WS_22     short_whole_22  -1
    WS_22     short_whole_23  1
    WS_22     balance_22  -1
    WS_22     ie_23     0.0032612991666666662
    WS_23     short_whole_23  -1
    WS_23     short_whole_24  1
    WS_23     balance_23  -1
    WS_23     ie_24     0.0032542374999999998
    WS_24     short_whole_24  -1
    WS_24     short_whole_25  1
    WS_24     balance_24  -1
    WS_24     ie_25     0.0032471749999999997
    WS_25     short_whole_25  -1
    WS_25     short_whole_26  1
    WS_25     balance_25  -1
    WS_25     ie_26     0.0032401133333333329
    WS_26     short_whole_26  -1
    WS_26     short_whole_27  1
    WS_26     balance_26  -1
    WS_26     ie_27     0.0032330508333333332
    WS_27     short_whole_27  -1
    WS_27     short_whole_28  1
    WS_27     balance_27  -1
    WS_27     ie_28     0.0032259883333333331
    WS_28     short_whole_28  -1
    WS_28     short_whole_29  1
    WS_28     balance_28  -1
    WS_28     ie_29     0.0032189266666666667
    WS_29     short_whole_29  -1
    WS_29     short_whole_30  1
    WS_29     balance_29  -1
    WS_29     ie_30     0.0032118641666666666
    WS_30     short_whole_30  -1
    WS_30     short_whole_31  1
    WS_30     balance_30  -1
    WS_30     ie_31     0.0032048024999999998
    WS_31     short_whole_31  -1
    WS_31     short_whole_32  1
    WS_31     balance_31  -1
    WS_31     ie_32     0.0031977399999999997
    WS_32     short_whole_32  -1
    WS_32     short_whole_33  1
    WS_32     balance_32  -1
    WS_32     ie_33     0.0031906783333333329
    WS_33     short_whole_33  -1
    WS_33     short_whole_34  1
    WS_33     balance_33  -1
    WS_33     ie_34     0.0031836158333333328
    WS_34     short_whole_34  -1
    WS_34     short_whole_35  1
    WS_34     balance_34  -1
    WS_34     ie_35     0.0031765533333333335
    WS_35     short_whole_35  -1
    WS_35     short_whole_36  1
    WS_35     balance_35  -1
    WS_35     ie_36     0.0031694916666666667
    WS_36     short_whole_36  -1
    WS_36     short_whole_37  1
    WS_36     balance_36  -1
    WS_36     ie_37     0.0031624291666666666
    WS_37     short_whole_37  -1
    WS_37     short_whole_38  1
    WS_37     balance_37  -1
    WS_37     ie_38     0.0031553674999999998
    WS_38     short_whole_38  -1
    WS_38     short_whole_39  1
    WS_38     balance_38  -1
    WS_38     ie_39     0.0031483049999999997
    WS_39     short_whole_39  -1
    WS_39     short_whole_40  1
    WS_39     balance_39  -1
    WS_39     ie_40     0.0031412433333333333
    WS_40     short_whole_40  -1
    WS_40     short_whole_41  1
    WS_40     balance_40  -1
    WS_40     ie_41     0.0031341808333333332
    WS_41     short_whole_41  -1
    WS_41     short_whole_42  1
    WS_41     balance_41  -1
    WS_41     ie_42     0.0031271183333333331
    WS_42     short_whole_42  -1
    WS_42     short_whole_43  1
    WS_42     balance_42  -1
    WS_42     ie_43     0.0031200566666666663
    WS_43     short_whole_43  -1
    WS_43     short_whole_44  1
    WS_43     balance_43  -1
    WS_43     ie_44     0.0031129941666666666
    WS_44     short_whole_44  -1
    WS_44     short_whole_45  1
    WS_44     balance_44  -1
    WS_44     ie_45     0.0031059325000000002
    WS_45     short_whole_45  -1
    WS_45     short_whole_46  1
    WS_45     balance_45  -1
    WS_45     ie_46     0.0030988700000000001
    WS_46     short_whole_46  -1
    WS_46     short_whole_47  1
    WS_46     balance_46  -1
    WS_46     ie_47     0.0030918075
    WS_47     short_whole_47  -1
    WS_47     short_whole_48  1
    WS_47     balance_47  -1
    WS_47     ie_48     0.0030847458333333332
    WS_48     short_whole_48  -1
    WS_48     short_whole_49  1
    WS_48     balance_48  -1
    WS_48     ie_49     0.0030776833333333331
    WS_49     short_whole_49  -1
    WS_49     short_whole_50  1
    WS_49     balance_49  -1
    WS_49     ie_50     0.0030706216666666663
    WS_50     short_whole_50  -1
    WS_50     short_whole_51  1
    WS_50     balance_50  -1
    WS_50     ie_51     0.0030635591666666661
    WS_51     short_whole_51  -1
    WS_51     short_whole_52  1
    WS_51     balance_51  -1
    WS_51     ie_52     0.0030564974999999998
    WS_52     short_whole_52  -1
    WS_52     short_whole_53  1
    WS_52     balance_52  -1
    WS_52     ie_53     0.0030494350000000001
    WS_53     short_whole_53  -1
    WS_53     short_whole_54  1
    WS_53     balance_53  -1
    WS_53     ie_54     0.0030423725
    WS_54     short_whole_54  -1
    WS_54     short_whole_55  1
    WS_54     balance_54  -1
    WS_54     ie_55     0.0030353108333333332
    WS_55     short_whole_55  -1
    WS_55     short_whole_56  1
    WS_55     balance_55  -1
    WS_55     ie_56     0.003028248333333333
    WS_56     short_whole_56  -1
    WS_56     short_whole_57  1
    WS_56     balance_56  -1
    WS_56     ie_57     0.0030211866666666667
    WS_57     short_whole_57  -1
    WS_57     short_whole_58  1
    WS_57     balance_57  -1
    WS_57     ie_58     0.0030141241666666665
    WS_58     short_whole_58  -1
    WS_58     short_whole_59  1
    WS_58     balance_58  -1
    WS_58     ie_59     0.0030070624999999998
    WS_59     short_whole_59  -1
    WS_59     short_whole_60  1
    WS_59     balance_59  -1
    WS_59     ie_60     0.0029999999999999996
    WS_60     Obj       -0.0029999999999999996
    WS_60     short_whole_60  -1
    WS_60     balance_60  -1
    LF_1      lf_1      1
    LF_1      lf_2      0.98999999999999999
    LF_1      ii_2      -0.0044096041666666658
    LF_1      bb_2      -0.00016666666666666666
    LF_2      lf_2      -1
    LF_2      lf_3      0.98999999999999999
    LF_2      ii_3      -0.0044025424999999995
    LF_2      bb_3      -0.00016666666666666666
    LF_3      lf_3      -1
    LF_3      lf_4      0.98999999999999999
    LF_3      ii_4      -0.0043954799999999994
    LF_3      bb_4      -0.00016666666666666666
    LF_4      lf_4      -1
    LF_4      lf_5      0.98999999999999999
    LF_4      ii_5      -0.004388418333333333
    LF_4      bb_5      -0.00016666666666666666
    LF_5      lf_5      -1
    LF_5      lf_6      0.98999999999999999
    LF_5      ii_6      -0.0043813558333333329
    LF_5      bb_6      -0.00016666666666666666
    LF_6      lf_6      -1
    LF_6      lf_7      0.98999999999999999
    LF_6      ii_7      -0.0043742941666666665
    LF_6      bb_7      -0.00016666666666666666
    LF_7      lf_7      -1
    LF_7      lf_8      0.98999999999999999
    LF_7      ii_8      -0.0043672316666666664
    LF_7      bb_8      -0.00016666666666666666
    LF_8      lf_8      -1
    LF_8      lf_9      0.98999999999999999
    LF_8      ii_9      -0.0043601691666666663
    LF_8      bb_9      -0.00016666666666666666
    LF_9      lf_9      -1
    LF_9      lf_10     0.98999999999999999
    LF_9      ii_10     -0.0043531074999999999
    LF_9      bb_10     -0.00016666666666666666
    LF_10     lf_10     -1
    LF_10     lf_11     0.98999999999999999
    LF_10     ii_11     -0.0043460449999999998
    LF_10     bb_11     -0.00016666666666666666
    LF_11     lf_11     -1
    LF_11     lf_12     0.98999999999999999
    LF_11     ii_12     -0.0043389833333333325
    LF_11     bb_12     -0.00016666666666666666
    LF_12     lf_12     -1
    LF_12     lf_13     0.98999999999999999
    LF_12     ii_13     -0.0043319208333333324
    LF_12     bb_13     -0.00016666666666666666
    LF_13     lf_13     -1
    LF_13     lf_14     0.98999999999999999
    LF_13     ii_14     -0.0043248591666666661
    LF_13     bb_14     -0.00016666666666666666
    LF_14     lf_14     -1
    LF_14     lf_15     0.98999999999999999
    LF_14     ii_15     -0.0043177966666666668
    LF_14     bb_15     -0.00016666666666666666
    LF_15     lf_15     -1
    LF_15     lf_16     0.98999999999999999
    LF_15     ii_16     -0.0043107341666666667
    LF_15     bb_16     -0.00016666666666666666
    LF_16     lf_16     -1
    LF_16     lf_17     0.98999999999999999
    LF_16     ii_17     -0.0043036724999999994
    LF_16     bb_17     -0.00016666666666666666
    LF_17     lf_17     -1
    LF_17     lf_18     0.98999999999999999
    LF_17     ii_18     -0.0042966099999999993
    LF_17     bb_18     -0.00016666666666666666
    LF_18     lf_18     -1
    LF_18     lf_19     0.98999999999999999
    LF_18     ii_19     -0.004289548333333333
    LF_18     bb_19     -0.00016666666666666666
    LF_19     lf_19     -1
    LF_19     lf_20     0.98999999999999999
    LF_19     ii_20     -0.0042824858333333328
    LF_19     bb_20     -0.00016666666666666666
    LF_20     lf_20     -1
    LF_20     lf_21     0.98999999999999999
    LF_20     ii_21     -0.0042754233333333327
    LF_20     bb_21     -0.00016666666666666666
    LF_21     lf_21     -1
    LF_21     lf_22     0.98999999999999999
    LF_21     ii_22     -0.0042683616666666663
    LF_21     bb_22     -0.00016666666666666666
    LF_22     lf_22     -1
    LF_22     lf_23     0.98999999999999999
    LF_22     ii_23     -0.0042612991666666662
    LF_22     bb_23     -0.00016666666666666666
    LF_23     lf_23     -1
    LF_23     lf_24     0.98999999999999999
    LF_23     ii_24     -0.004254237499999999
    LF_23     bb_24     -0.00016666666666666666
    LF_24     lf_24     -1
    LF_24     lf_25     0.98999999999999999
    LF_24     ii_25     -0.0042471749999999997
    LF_24     bb_25     -0.00016666666666666666
    LF_25     lf_25     -1
    LF_25     lf_26     0.98999999999999999
    LF_25     ii_26     -0.0042401133333333334
    LF_25     bb_26     -0.00016666666666666666
    LF_26     lf_26     -1
    LF_26     lf_27     0.98999999999999999
    LF_26     ii_27     -0.0042330508333333332
    LF_26     bb_27     -0.00016666666666666666
    LF_27     lf_27     -1
    LF_27     lf_28     0.98999999999999999
    LF_27     ii_28     -0.0042259883333333331
    LF_27     bb_28     -0.00016666666666666666
    LF_28     lf_28     -1
    LF_28     lf_29     0.98999999999999999
    LF_28     ii_29     -0.0042189266666666659
    LF_28     bb_29     -0.00016666666666666666
    LF_29     lf_29     -1
    LF_29     lf_30     0.98999999999999999
    LF_29     ii_30     -0.0042118641666666658
    LF_29     bb_30     -0.00016666666666666666
    LF_30     lf_30     -1
    LF_30     lf_31     0.98999999999999999
    LF_30     ii_31     -0.0042048024999999994
    LF_30     bb_31     -0.00016666666666666666
    LF_31     lf_31     -1
    LF_31     lf_32     0.98999999999999999
    LF_31     ii_32     -0.0041977399999999993
    LF_31     bb_32     -0.00016666666666666666
    LF_32     lf_32     -1
    LF_32     lf_33     0.98999999999999999
    LF_32     ii_33     -0.0041906783333333329
    LF_32     bb_33     -0.00016666666666666666
    LF_33     lf_33     -1
    LF_33     lf_34     0.98999999999999999
    LF_33     ii_34     -0.0041836158333333328
    LF_33     bb_34     -0.00016666666666666666
    LF_34     lf_34     -1
    LF_34     lf_35     0.98999999999999999
    LF_34     ii_35     -0.0041765533333333327
    LF_34     bb_35     -0.00016666666666666666
    LF_35     lf_35     -1
    LF_35     lf_36     0.98999999999999999
    LF_35     ii_36     -0.0041694916666666663
    LF_35     bb_36     -0.00016666666666666666
    LF_36     lf_36     -1
    LF_36     lf_37     0.98999999999999999
    LF_36     ii_37     -0.0041624291666666662
    LF_36     bb_37     -0.00016666666666666666
    LF_37     lf_37     -1
    LF_37     lf_38     0.98999999999999999
    LF_37     ii_38     -0.0041553674999999998
    LF_37     bb_38     -0.00016666666666666666
    LF_38     lf_38     -1
    LF_38     lf_39     0.98999999999999999
    LF_38     ii_39     -0.0041483049999999997
    LF_38     bb_39     -0.00016666666666666666
    LF_39     lf_39     -1
    LF_39     lf_40     0.98999999999999999
    LF_39     ii_40     -0.0041412433333333325
    LF_39     bb_40     -0.00016666666666666666
    LF_40     lf_40     -1
    LF_40     lf_41     0.98999999999999999
    LF_40     ii_41     -0.0041341808333333323
    LF_40     bb_41     -0.00016666666666666666
    LF_41     lf_41     -1
    LF_41     lf_42     0.98999999999999999
    LF_41     ii_42     -0.0041271183333333331
    LF_41     bb_42     -0.00016666666666666666
    LF_42     lf_42     -1
    LF_42     lf_43     0.98999999999999999
    LF_42     ii_43     -0.0041200566666666667
    LF_42     bb_43     -0.00016666666666666666
    LF_43     lf_43     -1
    LF_43     lf_44     0.98999999999999999
    LF_43     ii_44     -0.0041129941666666666
    LF_43     bb_44     -0.00016666666666666666
    LF_44     lf_44     -1
    LF_44     lf_45     0.98999999999999999
    LF_44     ii_45     -0.0041059324999999994
    LF_44     bb_45     -0.00016666666666666666
    LF_45     lf_45     -1
    LF_45     lf_46     0.98999999999999999
    LF_45     ii_46     -0.0040988699999999993
    LF_45     bb_46     -0.00016666666666666666
    LF_46     lf_46     -1
    LF_46     lf_47     0.98999999999999999
    LF_46     ii_47     -0.0040918074999999991
    LF_46     bb_47     -0.00016666666666666666
    LF_47     lf_47     -1
    LF_47     lf_48     0.98999999999999999
    LF_47     ii_48     -0.0040847458333333328
    LF_47     bb_48     -0.00016666666666666666
    LF_48     lf_48     -1
    LF_48     lf_49     0.98999999999999999
    LF_48     ii_49     -0.0040776833333333326
    LF_48     bb_49     -0.00016666666666666666
    LF_49     lf_49     -1
    LF_49     lf_50     0.98999999999999999
    LF_49     ii_50     -0.0040706216666666663
    LF_49     bb_50     -0.00016666666666666666
    LF_50     lf_50     -1
    LF_50     lf_51     0.98999999999999999
    LF_50     ii_51     -0.0040635591666666662
    LF_50     bb_51     -0.00016666666666666666
    LF_51     lf_51     -1
    LF_51     lf_52     0.98999999999999999
    LF_51     ii_52     -0.0040564974999999998
    LF_51     bb_52     -0.00016666666666666666
    LF_52     lf_52     -1
    LF_52     lf_53     0.98999999999999999
    LF_52     ii_53     -0.0040494349999999997
    LF_52     bb_53     -0.00016666666666666666
    LF_53     lf_53     -1
    LF_53     lf_54     0.98999999999999999
    LF_53     ii_54     -0.0040423724999999995
    LF_53     bb_54     -0.00016666666666666666
    LF_54     lf_54     -1
    LF_54     lf_55     0.98999999999999999
    LF_54     ii_55     -0.0040353108333333332
    LF_54     bb_55     -0.00016666666666666666
    LF_55     lf_55     -1
    LF_55     lf_56     0.98999999999999999
    LF_55     ii_56     -0.0040282483333333331
    LF_55     bb_56     -0.00016666666666666666
    LF_56     lf_56     -1
    LF_56     lf_57     0.98999999999999999
    LF_56     ii_57     -0.0040211866666666658
    LF_56     bb_57     -0.00016666666666666666
    LF_57     lf_57     -1
    LF_57     lf_58     0.98999999999999999
    LF_57     ii_58     -0.0040141241666666657
    LF_57     bb_58     -0.00016666666666666666
    LF_58     lf_58     -1
    LF_58     lf_59     0.98999999999999999
    LF_58     ii_59     -0.0040070624999999993
    LF_58     bb_59     -0.00016666666666666666
    LF_59     lf_59     -1
    LF_59     lf_60     0.98999999999999999
    LF_59     ii_60     -0.0040000000000000001
    LF_59     bb_60     -0.00016666666666666666
    LF_60     Obj       -0.0040000000000000001
    LF_60     lf_60     -1
    LR_1      lr_1      1
    LR_1      lr_2      0.98999999999999999
    LR_1      ii_2      0.083333333333333329
    LR_2      lr_2      -1
    LR_2      lr_3      0.98999999999999999
    LR_2      ii_3      0.083333333333333329
    LR_3      lr_3      -1
    LR_3      lr_4      0.98999999999999999
    LR_3      ii_4      0.083333333333333329
    LR_4      lr_4      -1
    LR_4      lr_5      0.98999999999999999
    LR_4      ii_5      0.083333333333333329
    LR_5      lr_5      -1
    LR_5      lr_6      0.98999999999999999
    LR_5      ii_6      0.083333333333333329
    LR_6      lr_6      -1
    LR_6      lr_7      0.98999999999999999
    LR_6      ii_7      0.083333333333333329
    LR_7      lr_7      -1
    LR_7      lr_8      0.98999999999999999
    LR_7      ii_8      0.083333333333333329
    LR_8      lr_8      -1
    LR_8      lr_9      0.98999999999999999
    LR_8      ii_9      0.083333333333333329
    LR_9      lr_9      -1
    LR_9      lr_10     0.98999999999999999
    LR_9      ii_10     0.083333333333333329
    LR_10     lr_10     -1
    LR_10     lr_11     0.98999999999999999
    LR_10     ii_11     0.083333333333333329
    LR_11     lr_11     -1
    LR_11     lr_12     0.98999999999999999
    LR_11     ii_12     0.083333333333333329
    LR_12     lr_12     -1
    LR_12     lr_13     0.98999999999999999
    LR_12     ii_13     0.083333333333333329
    LR_13     lr_13     -1
    LR_13     lr_14     0.98999999999999999
    LR_13     ii_14     0.083333333333333329
    LR_14     lr_14     -1
    LR_14     lr_15     0.98999999999999999
    LR_14     ii_15     0.083333333333333329
    LR_15     lr_15     -1
    LR_15     lr_16     0.98999999999999999
    LR_15     ii_16     0.083333333333333329
    LR_16     lr_16     -1
    LR_16     lr_17     0.98999999999999999
    LR_16     ii_17     0.083333333333333329
    LR_17     lr_17     -1
    LR_17     lr_18     0.98999999999999999
    LR_17     ii_18     0.083333333333333329
    LR_18     lr_18     -1
    LR_18     lr_19     0.98999999999999999
    LR_18     ii_19     0.083333333333333329
    LR_19     lr_19     -1
    LR_19     lr_20     0.98999999999999999
    LR_19     ii_20     0.083333333333333329
    LR_20     lr_20     -1
    LR_20     lr_21     0.98999999999999999
    LR_20     ii_21     0.083333333333333329
    LR_21     lr_21     -1
    LR_21     lr_22     0.98999999999999999
    LR_21     ii_22     0.083333333333333329
    LR_22     lr_22     -1
    LR_22     lr_23     0.98999999999999999
    LR_22     ii_23     0.083333333333333329
    LR_23     lr_23     -1
    LR_23     lr_24     0.98999999999999999
    LR_23     ii_24     0.083333333333333329
    LR_24     lr_24     -1
    LR_24     lr_25     0.98999999999999999
    LR_24     ii_25     0.083333333333333329
    LR_25     lr_25     -1
    LR_25     lr_26     0.98999999999999999
    LR_25     ii_26     0.083333333333333329
    LR_26     lr_26     -1
    LR_26     lr_27     0.98999999999999999
    LR_26     ii_27     0.083333333333333329
    LR_27     lr_27     -1
    LR_27     lr_28     0.98999999999999999
    LR_27     ii_28     0.083333333333333329
    LR_28     lr_28     -1
    LR_28     lr_29     0.98999999999999999
    LR_28     ii_29     0.083333333333333329
    LR_29     lr_29     -1
    LR_29     lr_30     0.98999999999999999
    LR_29     ii_30     0.083333333333333329
    LR_30     lr_30     -1
    LR_30     lr_31     0.98999999999999999
    LR_30     ii_31     0.083333333333333329
    LR_31     lr_31     -1
    LR_31     lr_32     0.98999999999999999
    LR_31     ii_32     0.083333333333333329
    LR_32     lr_32     -1
    LR_32     lr_33     0.98999999999999999
    LR_32     ii_33     0.083333333333333329
    LR_33     lr_33     -1
    LR_33     lr_34     0.98999999999999999
    LR_33     ii_34     0.083333333333333329
    LR_34     lr_34     -1
    LR_34     lr_35     0.98999999999999999
    LR_34     ii_35     0.083333333333333329
    LR_35     lr_35     -1
    LR_35     lr_36     0.98999999999999999
    LR_35     ii_36     0.083333333333333329
    LR_36     lr_36     -1
    LR_36     lr_37     0.98999999999999999
    LR_36     ii_37     0.083333333333333329
    LR_37     lr_37     -1
    LR_37     lr_38     0.98999999999999999
    LR_37     ii_38     0.083333333333333329
    LR_38     lr_38     -1
    LR_38     lr_39     0.98999999999999999
    LR_38     ii_39     0.083333333333333329
    LR_39     lr_39     -1
    LR_39     lr_40     0.98999999999999999
    LR_39     ii_40     0.083333333333333329
    LR_40     lr_40     -1
    LR_40     lr_41     0.98999999999999999
    LR_40     ii_41     0.083333333333333329
    LR_41     lr_41     -1
    LR_41     lr_42     0.98999999999999999
    LR_41     ii_42     0.083333333333333329
    LR_42     lr_42     -1
    LR_42     lr_43     0.98999999999999999
    LR_42     ii_43     0.083333333333333329
    LR_43     lr_43     -1
    LR_43     lr_44     0.98999999999999999
    LR_43     ii_44     0.083333333333333329
    LR_44     lr_44     -1
    LR_44     lr_45     0.98999999999999999
    LR_44     ii_45     0.083333333333333329
    LR_45     lr_45     -1
    LR_45     lr_46     0.98999999999999999
    LR_45     ii_46     0.083333333333333329
    LR_46     lr_46     -1
    LR_46     lr_47     0.98999999999999999
    LR_46     ii_47     0.083333333333333329
    LR_47     lr_47     -1
    LR_47     lr_48     0.98999999999999999
    LR_47     ii_48     0.083333333333333329
    LR_48     lr_48     -1
    LR_48     lr_49     0.98999999999999999
    LR_48     ii_49     0.083333333333333329
    LR_49     lr_49     -1
    LR_49     lr_50     0.98999999999999999
    LR_49     ii_50     0.083333333333333329
    LR_50     lr_50     -1
    LR_50     lr_51     0.98999999999999999
    LR_50     ii_51     0.083333333333333329
    LR_51     lr_51     -1
    LR_51     lr_52     0.98999999999999999
    LR_51     ii_52     0.083333333333333329
    LR_52     lr_52     -1
    LR_52     lr_53     0.98999999999999999
    LR_52     ii_53     0.083333333333333329
    LR_53     lr_53     -1
    LR_53     lr_54     0.98999999999999999
    LR_53     ii_54     0.083333333333333329
    LR_54     lr_54     -1
    LR_54     lr_55     0.98999999999999999
    LR_54     ii_55     0.083333333333333329
    LR_55     lr_55     -1
    LR_55     lr_56     0.98999999999999999
    LR_55     ii_56     0.083333333333333329
    LR_56     lr_56     -1
    LR_56     lr_57     0.98999999999999999
    LR_56     ii_57     0.083333333333333329
    LR_57     lr_57     -1
    LR_57     lr_58     0.98999999999999999
    LR_57     ii_58     0.083333333333333329
    LR_58     lr_58     -1
    LR_58     lr_59     0.98999999999999999
    LR_58     ii_59     0.083333333333333329
    LR_59     lr_59     -1
    LR_59     lr_60     0.98999999999999999
    LR_59     ii_60     0.083333333333333329
    LR_60     Obj       0.083333333333333329
    LR_60     lr_60     -1
    LM_1      lm_1      1
    LM_1      lm_2      0.98999999999999999
    LM_1      bb_2      0.083333333333333329
    LM_2      lm_2      -1
    LM_2      lm_3      0.98999999999999999
    LM_2      bb_3      0.083333333333333329
    LM_3      lm_3      -1
    LM_3      lm_4      0.98999999999999999
    LM_3      bb_4      0.083333333333333329
    LM_4      lm_4      -1
    LM_4      lm_5      0.98999999999999999
    LM_4      bb_5      0.083333333333333329
    LM_5      lm_5      -1
    LM_5      lm_6      0.98999999999999999
    LM_5      bb_6      0.083333333333333329
    LM_6      lm_6      -1
    LM_6      lm_7      0.98999999999999999
    LM_6      bb_7      0.083333333333333329
    LM_7      lm_7      -1
    LM_7      lm_8      0.98999999999999999
    LM_7      bb_8      0.083333333333333329
    LM_8      lm_8      -1
    LM_8      lm_9      0.98999999999999999
    LM_8      bb_9      0.083333333333333329
    LM_9      lm_9      -1
    LM_9      lm_10     0.98999999999999999
    LM_9      bb_10     0.083333333333333329
    LM_10     lm_10     -1
    LM_10     lm_11     0.98999999999999999
    LM_10     bb_11     0.083333333333333329
    LM_11     lm_11     -1
    LM_11     lm_12     0.98999999999999999
    LM_11     bb_12     0.083333333333333329
    LM_12     lm_12     -1
    LM_12     lm_13     0.98999999999999999
    LM_12     bb_13     0.083333333333333329
    LM_13     lm_13     -1
    LM_13     lm_14     0.98999999999999999
    LM_13     bb_14     0.083333333333333329
    LM_14     lm_14     -1
    LM_14     lm_15     0.98999999999999999
    LM_14     bb_15     0.083333333333333329
    LM_15     lm_15     -1
    LM_15     lm_16     0.98999999999999999
    LM_15     bb_16     0.083333333333333329
    LM_16     lm_16     -1
    LM_16     lm_17     0.98999999999999999
    LM_16     bb_17     0.083333333333333329
    LM_17     lm_17     -1
    LM_17     lm_18     0.98999999999999999
    LM_17     bb_18     0.083333333333333329
    LM_18     lm_18     -1
    LM_18     lm_19     0.98999999999999999
    LM_18     bb_19     0.083333333333333329
    LM_19     lm_19     -1
    LM_19     lm_20     0.98999999999999999
    LM_19     bb_20     0.083333333333333329
    LM_20     lm_20     -1
    LM_20     lm_21     0.98999999999999999
    LM_20     bb_21     0.083333333333333329
    LM_21     lm_21     -1
    LM_21     lm_22     0.98999999999999999
    LM_21     bb_22     0.083333333333333329
    LM_22     lm_22     -1
    LM_22     lm_23     0.98999999999999999
    LM_22     bb_23     0.083333333333333329
    LM_23     lm_23     -1
    LM_23     lm_24     0.98999999999999999
    LM_23     bb_24     0.083333333333333329
    LM_24     lm_24     -1
    LM_24     lm_25     0.98999999999999999
    LM_24     bb_25     0.083333333333333329
    LM_25     lm_25     -1
    LM_25     lm_26     0.98999999999999999
    LM_25     bb_26     0.083333333333333329
    LM_26     lm_26     -1
    LM_26     lm_27     0.98999999999999999
    LM_26     bb_27     0.083333333333333329
    LM_27     lm_27     -1
    LM_27     lm_28     0.98999999999999999
    LM_27     bb_28     0.083333333333333329
    LM_28     lm_28     -1
    LM_28     lm_29     0.98999999999999999
    LM_28     bb_29     0.083333333333333329
    LM_29     lm_29     -1
    LM_29     lm_30     0.98999999999999999
    LM_29     bb_30     0.083333333333333329
    LM_30     lm_30     -1
    LM_30     lm_31     0.98999999999999999
    LM_30     bb_31     0.083333333333333329
    LM_31     lm_31     -1
    LM_31     lm_32     0.98999999999999999
    LM_31     bb_32     0.083333333333333329
    LM_32     lm_32     -1
    LM_32     lm_33     0.98999999999999999
    LM_32     bb_33     0.083333333333333329
    LM_33     lm_33     -1
    LM_33     lm_34     0.98999999999999999
    LM_33     bb_34     0.083333333333333329
    LM_34     lm_34     -1
    LM_34     lm_35     0.98999999999999999
    LM_34     bb_35     0.083333333333333329
    LM_35     lm_35     -1
    LM_35     lm_36     0.98999999999999999
    LM_35     bb_36     0.083333333333333329
    LM_36     lm_36     -1
    LM_36     lm_37     0.98999999999999999
    LM_36     bb_37     0.083333333333333329
    LM_37     lm_37     -1
    LM_37     lm_38     0.98999999999999999
    LM_37     bb_38     0.083333333333333329
    LM_38     lm_38     -1
    LM_38     lm_39     0.98999999999999999
    LM_38     bb_39     0.083333333333333329
    LM_39     lm_39     -1
    LM_39     lm_40     0.98999999999999999
    LM_39     bb_40     0.083333333333333329
    LM_40     lm_40     -1
    LM_40     lm_41     0.98999999999999999
    LM_40     bb_41     0.083333333333333329
    LM_41     lm_41     -1
    LM_41     lm_42     0.98999999999999999
    LM_41     bb_42     0.083333333333333329
    LM_42     lm_42     -1
    LM_42     lm_43     0.98999999999999999
    LM_42     bb_43     0.083333333333333329
    LM_43     lm_43     -1
    LM_43     lm_44     0.98999999999999999
    LM_43     bb_44     0.083333333333333329
    LM_44     lm_44     -1
    LM_44     lm_45     0.98999999999999999
    LM_44     bb_45     0.083333333333333329
    LM_45     lm_45     -1
    LM_45     lm_46     0.98999999999999999
    LM_45     bb_46     0.083333333333333329
    LM_46     lm_46     -1
    LM_46     lm_47     0.98999999999999999
    LM_46     bb_47     0.083333333333333329
    LM_47     lm_47     -1
    LM_47     lm_48     0.98999999999999999
    LM_47     bb_48     0.083333333333333329
    LM_48     lm_48     -1
    LM_48     lm_49     0.98999999999999999
    LM_48     bb_49     0.083333333333333329
    LM_49     lm_49     -1
    LM_49     lm_50     0.98999999999999999
    LM_49     bb_50     0.083333333333333329
    LM_50     lm_50     -1
    LM_50     lm_51     0.98999999999999999
    LM_50     bb_51     0.083333333333333329
    LM_51     lm_51     -1
    LM_51     lm_52     0.98999999999999999
    LM_51     bb_52     0.083333333333333329
    LM_52     lm_52     -1
    LM_52     lm_53     0.98999999999999999
    LM_52     bb_53     0.083333333333333329
    LM_53     lm_53     -1
    LM_53     lm_54     0.98999999999999999
    LM_53     bb_54     0.083333333333333329
    LM_54     lm_54     -1
    LM_54     lm_55     0.98999999999999999
    LM_54     bb_55     0.083333333333333329
    LM_55     lm_55     -1
    LM_55     lm_56     0.98999999999999999
    LM_55     bb_56     0.083333333333333329
    LM_56     lm_56     -1
    LM_56     lm_57     0.98999999999999999
    LM_56     bb_57     0.083333333333333329
    LM_57     lm_57     -1
    LM_57     lm_58     0.98999999999999999
    LM_57     bb_58     0.083333333333333329
    LM_58     lm_58     -1
    LM_58     lm_59     0.98999999999999999
    LM_58     bb_59     0.083333333333333329
    LM_59     lm_59     -1
    LM_59     lm_60     0.98999999999999999
    LM_59     bb_60     0.083333333333333329
    LM_60     lm_60     -1
    TR_1      tr_1      1
    TR_1      tr_2      1
    TR_1      ie_2      0.083333333333333329
    TR_2      tr_2      -1
    TR_2      tr_3      1
    TR_2      ie_3      0.083333333333333329
    TR_3      tr_3      -1
    TR_3      tr_4      1
    TR_3      ie_4      0.083333333333333329
    TR_4      tr_4      -1
    TR_4      tr_5      1
    TR_4      ie_5      0.083333333333333329
    TR_5      tr_5      -1
    TR_5      tr_6      1
    TR_5      ie_6      0.083333333333333329
    TR_6      tr_6      -1
    TR_6      tr_7      1
    TR_6      ie_7      0.083333333333333329
    TR_7      tr_7      -1
    TR_7      tr_8      1
    TR_7      ie_8      0.083333333333333329
    TR_8      tr_8      -1
    TR_8      tr_9      1
    TR_8      ie_9      0.083333333333333329
    TR_9      tr_9      -1
    TR_9      tr_10     1
    TR_9      ie_10     0.083333333333333329
    TR_10     tr_10     -1
    TR_10     tr_11     1
    TR_10     ie_11     0.083333333333333329
    TR_11     tr_11     -1
    TR_11     tr_12     1
    TR_11     ie_12     0.083333333333333329
    TR_12     tr_12     -1
    TR_12     tr_13     1
    TR_12     ie_13     0.083333333333333329
    TR_13     tr_13     -1
    TR_13     tr_14     1
    TR_13     ie_14     0.083333333333333329
    TR_14     tr_14     -1
    TR_14     tr_15     1
    TR_14     ie_15     0.083333333333333329
    TR_15     tr_15     -1
    TR_15     tr_16     1
    TR_15     ie_16     0.083333333333333329
    TR_16     tr_16     -1
    TR_16     tr_17     1
    TR_16     ie_17     0.083333333333333329
    TR_17     tr_17     -1
    TR_17     tr_18     1
    TR_17     ie_18     0.083333333333333329
    TR_18     tr_18     -1
    TR_18     tr_19     1
    TR_18     ie_19     0.083333333333333329
    TR_19     tr_19     -1
    TR_19     tr_20     1
    TR_19     ie_20     0.083333333333333329
    TR_20     tr_20     -1
    TR_20     tr_21     1
    TR_20     ie_21     0.083333333333333329
    TR_21     tr_21     -1
    TR_21     tr_22     1
    TR_21     ie_22     0.083333333333333329
    TR_22     tr_22     -1
    TR_22     tr_23     1
    TR_22     ie_23     0.083333333333333329
    TR_23     tr_23     -1
    TR_23     tr_24     1
    TR_23     ie_24     0.083333333333333329
    TR_24     tr_24     -1
    TR_24     tr_25     1
    TR_24     ie_25     0.083333333333333329
    TR_25     tr_25     -1
    TR_25     tr_26     1
    TR_25     ie_26     0.083333333333333329
    TR_26     tr_26     -1
    TR_26     tr_27     1
    TR_26     ie_27     0.083333333333333329
    TR_27     tr_27     -1
    TR_27     tr_28     1
    TR_27     ie_28     0.083333333333333329
    TR_28     tr_28     -1
    TR_28     tr_29     1
    TR_28     ie_29     0.083333333333333329
    TR_29     tr_29     -1
    TR_29     tr_30     1
    TR_29     ie_30     0.083333333333333329
    TR_30     tr_30     -1
    TR_30     tr_31     1
    TR_30     ie_31     0.083333333333333329
    TR_31     tr_31     -1
    TR_31     tr_32     1
    TR_31     ie_32     0.083333333333333329
    TR_32     tr_32     -1
    TR_32     tr_33     1
    TR_32     ie_33     0.083333333333333329
    TR_33     tr_33     -1
    TR_33     tr_34     1
    TR_33     ie_34     0.083333333333333329
    TR_34     tr_34     -1
    TR_34     tr_35     1
    TR_34     ie_35     0.083333333333333329
    TR_35     tr_35     -1
    TR_35     tr_36     1
    TR_35     ie_36     0.083333333333333329
    TR_36     tr_36     -1
    TR_36     tr_37     1
    TR_36     ie_37     0.083333333333333329
    TR_37     tr_37     -1
    TR_37     tr_38     1
    TR_37     ie_38     0.083333333333333329
    TR_38     tr_38     -1
    TR_38     tr_39     1
    TR_38     ie_39     0.083333333333333329
    TR_39     tr_39     -1
    TR_39     tr_40     1
    TR_39     ie_40     0.083333333333333329
    TR_40     tr_40     -1
    TR_40     tr_41     1
    TR_40     ie_41     0.083333333333333329
    TR_41     tr_41     -1
    TR_41     tr_42     1
    TR_41     ie_42     0.083333333333333329
    TR_42     tr_42     -1
    TR_42     tr_43     1
    TR_42     ie_43     0.083333333333333329
    TR_43     tr_43     -1
    TR_43     tr_44     1
    TR_43     ie_44     0.083333333333333329
    TR_44     tr_44     -1
    TR_44     tr_45     1
    TR_44     ie_45     0.083333333333333329
    TR_45     tr_45     -1
    TR_45     tr_46     1
    TR_45     ie_46     0.083333333333333329
    TR_46     tr_46     -1
    TR_46     tr_47     1
    TR_46     ie_47     0.083333333333333329
    TR_47     tr_47     -1
    TR_47     tr_48     1
    TR_47     ie_48     0.083333333333333329
    TR_48     tr_48     -1
    TR_48     tr_49     1
    TR_48     ie_49     0.083333333333333329
    TR_49     tr_49     -1
    TR_49     tr_50     1
    TR_49     ie_50     0.083333333333333329
    TR_50     tr_50     -1
    TR_50     tr_51     1
    TR_50     ie_51     0.083333333333333329
    TR_51     tr_51     -1
    TR_51     tr_52     1
    TR_51     ie_52     0.083333333333333329
    TR_52     tr_52     -1
    TR_52     tr_53     1
    TR_52     ie_53     0.083333333333333329
    TR_53     tr_53     -1
    TR_53     tr_54     1
    TR_53     ie_54     0.083333333333333329
    TR_54     tr_54     -1
    TR_54     tr_55     1
    TR_54     ie_55     0.083333333333333329
    TR_55     tr_55     -1
    TR_55     tr_56     1
    TR_55     ie_56     0.083333333333333329
    TR_56     tr_56     -1
    TR_56     tr_57     1
    TR_56     ie_57     0.083333333333333329
    TR_57     tr_57     -1
    TR_57     tr_58     1
    TR_57     ie_58     0.083333333333333329
    TR_58     tr_58     -1
    TR_58     tr_59     1
    TR_58     ie_59     0.083333333333333329
    TR_59     tr_59     -1
    TR_59     tr_60     1
    TR_59     ie_60     0.083333333333333329
    TR_60     Obj       -0.083333333333333329
    TR_60     tr_60     -1
    TM_1      tm_1      1
    TM_1      tm_2      1
    TM_1      bd_2      0.083333333333333329
    TM_2      tm_2      -1
    TM_2      tm_3      1
    TM_2      bd_3      0.083333333333333329
    TM_3      tm_3      -1
    TM_3      tm_4      1
    TM_3      bd_4      0.083333333333333329
    TM_4      tm_4      -1
    TM_4      tm_5      1
    TM_4      bd_5      0.083333333333333329
    TM_5      tm_5      -1
    TM_5      tm_6      1
    TM_5      bd_6      0.083333333333333329
    TM_6      tm_6      -1
    TM_6      tm_7      1
    TM_6      bd_7      0.083333333333333329
    TM_7      tm_7      -1
    TM_7      tm_8      1
    TM_7      bd_8      0.083333333333333329
    TM_8      tm_8      -1
    TM_8      tm_9      1
    TM_8      bd_9      0.083333333333333329
    TM_9      tm_9      -1
    TM_9      tm_10     1
    TM_9      bd_10     0.083333333333333329
    TM_10     tm_10     -1
    TM_10     tm_11     1
    TM_10     bd_11     0.083333333333333329
    TM_11     tm_11     -1
    TM_11     tm_12     1
    TM_11     bd_12     0.083333333333333329
    TM_12     tm_12     -1
    TM_12     tm_13     1
    TM_12     bd_13     0.083333333333333329
    TM_13     tm_13     -1
    TM_13     tm_14     1
    TM_13     bd_14     0.083333333333333329
    TM_14     tm_14     -1
    TM_14     tm_15     1
    TM_14     bd_15     0.083333333333333329
    TM_15     tm_15     -1
    TM_15     tm_16     1
    TM_15     bd_16     0.083333333333333329
    TM_16     tm_16     -1
    TM_16     tm_17     1
    TM_16     bd_17     0.083333333333333329
    TM_17     tm_17     -1
    TM_17     tm_18     1
    TM_17     bd_18     0.083333333333333329
    TM_18     tm_18     -1
    TM_18     tm_19     1
    TM_18     bd_19     0.083333333333333329
    TM_19     tm_19     -1
    TM_19     tm_20     1
    TM_19     bd_20     0.083333333333333329
    TM_20     tm_20     -1
    TM_20     tm_21     1
    TM_20     bd_21     0.083333333333333329
    TM_21     tm_21     -1
    TM_21     tm_22     1
    TM_21     bd_22     0.083333333333333329
    TM_22     tm_22     -1
    TM_22     tm_23     1
    TM_22     bd_23     0.083333333333333329
    TM_23     tm_23     -1
    TM_23     tm_24     1
    TM_23     bd_24     0.083333333333333329
    TM_24     tm_24     -1
    TM_24     tm_25     1
    TM_24     bd_25     0.083333333333333329
    TM_25     tm_25     -1
    TM_25     tm_26     1
    TM_25     bd_26     0.083333333333333329
    TM_26     tm_26     -1
    TM_26     tm_27     1
    TM_26     bd_27     0.083333333333333329
    TM_27     tm_27     -1
    TM_27     tm_28     1
    TM_27     bd_28     0.083333333333333329
    TM_28     tm_28     -1
    TM_28     tm_29     1
    TM_28     bd_29     0.083333333333333329
    TM_29     tm_29     -1
    TM_29     tm_30     1
    TM_29     bd_30     0.083333333333333329
    TM_30     tm_30     -1
    TM_30     tm_31     1
    TM_30     bd_31     0.083333333333333329
    TM_31     tm_31     -1
    TM_31     tm_32     1
    TM_31     bd_32     0.083333333333333329
    TM_32     tm_32     -1
    TM_32     tm_33     1
    TM_32     bd_33     0.083333333333333329
    TM_33     tm_33     -1
    TM_33     tm_34     1
    TM_33     bd_34     0.083333333333333329
    TM_34     tm_34     -1
    TM_34     tm_35     1
    TM_34     bd_35     0.083333333333333329
    TM_35     tm_35     -1
    TM_35     tm_36     1
    TM_35     bd_36     0.083333333333333329
    TM_36     tm_36     -1
    TM_36     tm_37     1
    TM_36     bd_37     0.083333333333333329
    TM_37     tm_37     -1
    TM_37     tm_38     1
    TM_37     bd_38     0.083333333333333329
    TM_38     tm_38     -1
    TM_38     tm_39     1
    TM_38     bd_39     0.083333333333333329
    TM_39     tm_39     -1
    TM_39     tm_40     1
    TM_39     bd_40     0.083333333333333329
    TM_40     tm_40     -1
    TM_40     tm_41     1
    TM_40     bd_41     0.083333333333333329
    TM_41     tm_41     -1
    TM_41     tm_42     1
    TM_41     bd_42     0.083333333333333329
    TM_42     tm_42     -1
    TM_42     tm_43     1
    TM_42     bd_43     0.083333333333333329
    TM_43     tm_43     -1
    TM_43     tm_44     1
    TM_43     bd_44     0.083333333333333329
    TM_44     tm_44     -1
    TM_44     tm_45     1
    TM_44     bd_45     0.083333333333333329
    TM_45     tm_45     -1
    TM_45     tm_46     1
    TM_45     bd_46     0.083333333333333329
    TM_46     tm_46     -1
    TM_46     tm_47     1
    TM_46     bd_47     0.083333333333333329
    TM_47     tm_47     -1
    TM_47     tm_48     1
    TM_47     bd_48     0.083333333333333329
    TM_48     tm_48     -1
    TM_48     tm_49     1
    TM_48     bd_49     0.083333333333333329
    TM_49     tm_49     -1
    TM_49     tm_50     1
    TM_49     bd_50     0.083333333333333329
    TM_50     tm_50     -1
    TM_50     tm_51     1
    TM_50     bd_51     0.083333333333333329
    TM_51     tm_51     -1
    TM_51     tm_52     1
    TM_51     bd_52     0.083333333333333329
    TM_52     tm_52     -1
    TM_52     tm_53     1
    TM_52     bd_53     0.083333333333333329
    TM_53     tm_53     -1
    TM_53     tm_54     1
    TM_53     bd_54     0.083333333333333329
    TM_54     tm_54     -1
    TM_54     tm_55     1
    TM_54     bd_55     0.083333333333333329
    TM_55     tm_55     -1
    TM_55     tm_56     1
    TM_55     bd_56     0.083333333333333329
    TM_56     tm_56     -1
    TM_56     tm_57     1
    TM_56     bd_57     0.083333333333333329
    TM_57     tm_57     -1
    TM_57     tm_58     1
    TM_57     bd_58     0.083333333333333329
    TM_58     tm_58     -1
    TM_58     tm_59     1
    TM_58     bd_59     0.083333333333333329
    TM_59     tm_59     -1
    TM_59     tm_60     1
    TM_59     bd_60     0.083333333333333329
    TM_60     tm_60     -1
    H1_1      liquid_1  1
    H1_1      l2_cap_1  -0.40000000000000002
    H1_1      ii_2      0.0031596041666666665
    H1_1      rsf_1     0.050000000000000003
    H1_1      lcr_min_1  1
    H1_1      lcr_cap_min_1  1
    H1_1      lcr_buf_1  1
    H1_1      lcr_cap_buf_1  1
    H1_2      liquid_2  1
    H1_2      l2_cap_2  -0.40000000000000002
    H1_2      ii_3      0.0031525424999999997
    H1_2      rsf_2     0.050000000000000003
    H1_2      lcr_min_2  1
    H1_2      lcr_cap_min_2  1
    H1_2      lcr_buf_2  1
    H1_2      lcr_cap_buf_2  1
    H1_3      liquid_3  1
    H1_3      l2_cap_3  -0.40000000000000002
    H1_3      ii_4      0.00314548
    H1_3      rsf_3     0.050000000000000003
    H1_3      lcr_min_3  1
    H1_3      lcr_cap_min_3  1
    H1_3      lcr_buf_3  1
    H1_3      lcr_cap_buf_3  1
    H1_4      liquid_4  1
    H1_4      l2_cap_4  -0.40000000000000002
    H1_4      ii_5      0.0031384183333333336
    H1_4      rsf_4     0.050000000000000003
    H1_4      lcr_min_4  1
    H1_4      lcr_cap_min_4  1
    H1_4      lcr_buf_4  1
    H1_4      lcr_cap_buf_4  1
    H1_5      liquid_5  1
    H1_5      l2_cap_5  -0.40000000000000002
    H1_5      ii_6      0.0031313558333333335
    H1_5      rsf_5     0.050000000000000003
    H1_5      lcr_min_5  1
    H1_5      lcr_cap_min_5  1
    H1_5      lcr_buf_5  1
    H1_5      lcr_cap_buf_5  1
    H1_6      liquid_6  1
    H1_6      l2_cap_6  -0.40000000000000002
    H1_6      ii_7      0.0031242941666666667
    H1_6      rsf_6     0.050000000000000003
    H1_6      lcr_min_6  1
    H1_6      lcr_cap_min_6  1
    H1_6      lcr_buf_6  1
    H1_6      lcr_cap_buf_6  1
    H1_7      liquid_7  1
    H1_7      l2_cap_7  -0.40000000000000002
    H1_7      ii_8      0.0031172316666666666
    H1_7      rsf_7     0.050000000000000003
    H1_7      lcr_min_7  1
    H1_7      lcr_cap_min_7  1
    H1_7      lcr_buf_7  1
    H1_7      lcr_cap_buf_7  1
    H1_8      liquid_8  1
    H1_8      l2_cap_8  -0.40000000000000002
    H1_8      ii_9      0.0031101691666666664
    H1_8      rsf_8     0.050000000000000003
    H1_8      lcr_min_8  1
    H1_8      lcr_cap_min_8  1
    H1_8      lcr_buf_8  1
    H1_8      lcr_cap_buf_8  1
    H1_9      liquid_9  1
    H1_9      l2_cap_9  -0.40000000000000002
    H1_9      ii_10     0.0031031074999999997
    H1_9      rsf_9     0.050000000000000003
    H1_9      lcr_min_9  1
    H1_9      lcr_cap_min_9  1
    H1_9      lcr_buf_9  1
    H1_9      lcr_cap_buf_9  1
    H1_10     liquid_10  1
    H1_10     l2_cap_10  -0.40000000000000002
    H1_10     ii_11     0.0030960449999999995
    H1_10     rsf_10    0.050000000000000003
    H1_10     lcr_min_10  1
    H1_10     lcr_cap_min_10  1
    H1_10     lcr_buf_10  1
    H1_10     lcr_cap_buf_10  1
    H1_11     liquid_11  1
    H1_11     l2_cap_11  -0.40000000000000002
    H1_11     ii_12     0.0030889833333333332
    H1_11     rsf_11    0.050000000000000003
    H1_11     lcr_min_11  1
    H1_11     lcr_cap_min_11  1
    H1_11     lcr_buf_11  1
    H1_11     lcr_cap_buf_11  1
    H1_12     liquid_12  1
    H1_12     l2_cap_12  -0.40000000000000002
    H1_12     ii_13     0.0030819208333333335
    H1_12     rsf_12    0.050000000000000003
    H1_12     lcr_min_12  1
    H1_12     lcr_cap_min_12  1
    H1_12     lcr_buf_12  1
    H1_12     lcr_cap_buf_12  1
    H1_13     liquid_13  1
    H1_13     l2_cap_13  -0.40000000000000002
    H1_13     ii_14     0.0030748591666666662
    H1_13     rsf_13    0.050000000000000003
    H1_13     lcr_min_13  1
    H1_13     lcr_cap_min_13  1
    H1_13     lcr_buf_13  1
    H1_13     lcr_cap_buf_13  1
    H1_14     liquid_14  1
    H1_14     l2_cap_14  -0.40000000000000002
    H1_14     ii_15     0.0030677966666666666
    H1_14     rsf_14    0.050000000000000003
    H1_14     lcr_min_14  1
    H1_14     lcr_cap_min_14  1
    H1_14     lcr_buf_14  1
    H1_14     lcr_cap_buf_14  1
    H1_15     liquid_15  1
    H1_15     l2_cap_15  -0.40000000000000002
    H1_15     ii_16     0.0030607341666666664
    H1_15     rsf_15    0.050000000000000003
    H1_15     lcr_min_15  1
    H1_15     lcr_cap_min_15  1
    H1_15     lcr_buf_15  1
    H1_15     lcr_cap_buf_15  1
    H1_16     liquid_16  1
    H1_16     l2_cap_16  -0.40000000000000002
    H1_16     ii_17     0.0030536725000000001
    H1_16     rsf_16    0.050000000000000003
    H1_16     lcr_min_16  1
    H1_16     lcr_cap_min_16  1
    H1_16     lcr_buf_16  1
    H1_16     lcr_cap_buf_16  1
    H1_17     liquid_17  1
    H1_17     l2_cap_17  -0.40000000000000002
    H1_17     ii_18     0.0030466099999999999
    H1_17     rsf_17    0.050000000000000003
    H1_17     lcr_min_17  1
    H1_17     lcr_cap_min_17  1
    H1_17     lcr_buf_17  1
    H1_17     lcr_cap_buf_17  1
    H1_18     liquid_18  1
    H1_18     l2_cap_18  -0.40000000000000002
    H1_18     ii_19     0.0030395483333333331
    H1_18     rsf_18    0.050000000000000003
    H1_18     lcr_min_18  1
    H1_18     lcr_cap_min_18  1
    H1_18     lcr_buf_18  1
    H1_18     lcr_cap_buf_18  1
    H1_19     liquid_19  1
    H1_19     l2_cap_19  -0.40000000000000002
    H1_19     ii_20     0.003032485833333333
    H1_19     rsf_19    0.050000000000000003
    H1_19     lcr_min_19  1
    H1_19     lcr_cap_min_19  1
    H1_19     lcr_buf_19  1
    H1_19     lcr_cap_buf_19  1
    H1_20     liquid_20  1
    H1_20     l2_cap_20  -0.40000000000000002
    H1_20     ii_21     0.0030254233333333333
    H1_20     rsf_20    0.050000000000000003
    H1_20     lcr_min_20  1
    H1_20     lcr_cap_min_20  1
    H1_20     lcr_buf_20  1
    H1_20     lcr_cap_buf_20  1
    H1_21     liquid_21  1
    H1_21     l2_cap_21  -0.40000000000000002
    H1_21     ii_22     0.0030183616666666661
    H1_21     rsf_21    0.050000000000000003
    H1_21     lcr_min_21  1
    H1_21     lcr_cap_min_21  1
    H1_21     lcr_buf_21  1
    H1_21     lcr_cap_buf_21  1
    H1_22     liquid_22  1
    H1_22     l2_cap_22  -0.40000000000000002
    H1_22     ii_23     0.0030112991666666668
    H1_22     rsf_22    0.050000000000000003
    H1_22     lcr_min_22  1
    H1_22     lcr_cap_min_22  1
    H1_22     lcr_buf_22  1
    H1_22     lcr_cap_buf_22  1
    H1_23     liquid_23  1
    H1_23     l2_cap_23  -0.40000000000000002
    H1_23     ii_24     0.0030042375000000001
    H1_23     rsf_23    0.050000000000000003
    H1_23     lcr_min_23  1
    H1_23     lcr_cap_min_23  1
    H1_23     lcr_buf_23  1
    H1_23     lcr_cap_buf_23  1
    H1_24     liquid_24  1
    H1_24     l2_cap_24  -0.40000000000000002
    H1_24     ii_25     0.0029971749999999999
    H1_24     rsf_24    0.050000000000000003
    H1_24     lcr_min_24  1
    H1_24     lcr_cap_min_24  1
    H1_24     lcr_buf_24  1
    H1_24     lcr_cap_buf_24  1
    H1_25     liquid_25  1
    H1_25     l2_cap_25  -0.40000000000000002
    H1_25     ii_26     0.0029901133333333331
    H1_25     rsf_25    0.050000000000000003
    H1_25     lcr_min_25  1
    H1_25     lcr_cap_min_25  1
    H1_25     lcr_buf_25  1
    H1_25     lcr_cap_buf_25  1
    H1_26     liquid_26  1
    H1_26     l2_cap_26  -0.40000000000000002
    H1_26     ii_27     0.002983050833333333
    H1_26     rsf_26    0.050000000000000003
    H1_26     lcr_min_26  1
    H1_26     lcr_cap_min_26  1
    H1_26     lcr_buf_26  1
    H1_26     lcr_cap_buf_26  1
    H1_27     liquid_27  1
    H1_27     l2_cap_27  -0.40000000000000002
    H1_27     ii_28     0.0029759883333333329
    H1_27     rsf_27    0.050000000000000003
    H1_27     lcr_min_27  1
    H1_27     lcr_cap_min_27  1
    H1_27     lcr_buf_27  1
    H1_27     lcr_cap_buf_27  1
    H1_28     liquid_28  1
    H1_28     l2_cap_28  -0.40000000000000002
    H1_28     ii_29     0.0029689266666666665
    H1_28     rsf_28    0.050000000000000003
    H1_28     lcr_min_28  1
    H1_28     lcr_cap_min_28  1
    H1_28     lcr_buf_28  1
    H1_28     lcr_cap_buf_28  1
    H1_29     liquid_29  1
    H1_29     l2_cap_29  -0.40000000000000002
    H1_29     ii_30     0.0029618641666666664
    H1_29     rsf_29    0.050000000000000003
    H1_29     lcr_min_29  1
    H1_29     lcr_cap_min_29  1
    H1_29     lcr_buf_29  1
    H1_29     lcr_cap_buf_29  1
    H1_30     liquid_30  1
    H1_30     l2_cap_30  -0.40000000000000002
    H1_30     ii_31     0.0029548024999999996
    H1_30     rsf_30    0.050000000000000003
    H1_30     lcr_min_30  1
    H1_30     lcr_cap_min_30  1
    H1_30     lcr_buf_30  1
    H1_30     lcr_cap_buf_30  1
    H1_31     liquid_31  1
    H1_31     l2_cap_31  -0.40000000000000002
    H1_31     ii_32     0.0029477399999999999
    H1_31     rsf_31    0.050000000000000003
    H1_31     lcr_min_31  1
    H1_31     lcr_cap_min_31  1
    H1_31     lcr_buf_31  1
    H1_31     lcr_cap_buf_31  1
    H1_32     liquid_32  1
    H1_32     l2_cap_32  -0.40000000000000002
    H1_32     ii_33     0.0029406783333333335
    H1_32     rsf_32    0.050000000000000003
    H1_32     lcr_min_32  1
    H1_32     lcr_cap_min_32  1
    H1_32     lcr_buf_32  1
    H1_32     lcr_cap_buf_32  1
    H1_33     liquid_33  1
    H1_33     l2_cap_33  -0.40000000000000002
    H1_33     ii_34     0.0029336158333333334
    H1_33     rsf_33    0.050000000000000003
    H1_33     lcr_min_33  1
    H1_33     lcr_cap_min_33  1
    H1_33     lcr_buf_33  1
    H1_33     lcr_cap_buf_33  1
    H1_34     liquid_34  1
    H1_34     l2_cap_34  -0.40000000000000002
    H1_34     ii_35     0.0029265533333333333
    H1_34     rsf_34    0.050000000000000003
    H1_34     lcr_min_34  1
    H1_34     lcr_cap_min_34  1
    H1_34     lcr_buf_34  1
    H1_34     lcr_cap_buf_34  1
    H1_35     liquid_35  1
    H1_35     l2_cap_35  -0.40000000000000002
    H1_35     ii_36     0.0029194916666666665
    H1_35     rsf_35    0.050000000000000003
    H1_35     lcr_min_35  1
    H1_35     lcr_cap_min_35  1
    H1_35     lcr_buf_35  1
    H1_35     lcr_cap_buf_35  1
    H1_36     liquid_36  1
    H1_36     l2_cap_36  -0.40000000000000002
    H1_36     ii_37     0.0029124291666666664
    H1_36     rsf_36    0.050000000000000003
    H1_36     lcr_min_36  1
    H1_36     lcr_cap_min_36  1
    H1_36     lcr_buf_36  1
    H1_36     lcr_cap_buf_36  1
    H1_37     liquid_37  1
    H1_37     l2_cap_37  -0.40000000000000002
    H1_37     ii_38     0.0029053674999999996
    H1_37     rsf_37    0.050000000000000003
    H1_37     lcr_min_37  1
    H1_37     lcr_cap_min_37  1
    H1_37     lcr_buf_37  1
    H1_37     lcr_cap_buf_37  1
    H1_38     liquid_38  1
    H1_38     l2_cap_38  -0.40000000000000002
    H1_38     ii_39     0.0028983049999999995
    H1_38     rsf_38    0.050000000000000003
    H1_38     lcr_min_38  1
    H1_38     lcr_cap_min_38  1
    H1_38     lcr_buf_38  1
    H1_38     lcr_cap_buf_38  1
    H1_39     liquid_39  1
    H1_39     l2_cap_39  -0.40000000000000002
    H1_39     ii_40     0.0028912433333333331
    H1_39     rsf_39    0.050000000000000003
    H1_39     lcr_min_39  1
    H1_39     lcr_cap_min_39  1
    H1_39     lcr_buf_39  1
    H1_39     lcr_cap_buf_39  1
    H1_40     liquid_40  1
    H1_40     l2_cap_40  -0.40000000000000002
    H1_40     ii_41     0.0028841808333333334
    H1_40     rsf_40    0.050000000000000003
    H1_40     lcr_min_40  1
    H1_40     lcr_cap_min_40  1
    H1_40     lcr_buf_40  1
    H1_40     lcr_cap_buf_40  1
    H1_41     liquid_41  1
    H1_41     l2_cap_41  -0.40000000000000002
    H1_41     ii_42     0.0028771183333333333
    H1_41     rsf_41    0.050000000000000003
    H1_41     lcr_min_41  1
    H1_41     lcr_cap_min_41  1
    H1_41     lcr_buf_41  1
    H1_41     lcr_cap_buf_41  1
    H1_42     liquid_42  1
    H1_42     l2_cap_42  -0.40000000000000002
    H1_42     ii_43     0.0028700566666666665
    H1_42     rsf_42    0.050000000000000003
    H1_42     lcr_min_42  1
    H1_42     lcr_cap_min_42  1
    H1_42     lcr_buf_42  1
    H1_42     lcr_cap_buf_42  1
    H1_43     liquid_43  1
    H1_43     l2_cap_43  -0.40000000000000002
    H1_43     ii_44     0.0028629941666666664
    H1_43     rsf_43    0.050000000000000003
    H1_43     lcr_min_43  1
    H1_43     lcr_cap_min_43  1
    H1_43     lcr_buf_43  1
    H1_43     lcr_cap_buf_43  1
    H1_44     liquid_44  1
    H1_44     l2_cap_44  -0.40000000000000002
    H1_44     ii_45     0.0028559325
    H1_44     rsf_44    0.050000000000000003
    H1_44     lcr_min_44  1
    H1_44     lcr_cap_min_44  1
    H1_44     lcr_buf_44  1
    H1_44     lcr_cap_buf_44  1
    H1_45     liquid_45  1
    H1_45     l2_cap_45  -0.40000000000000002
    H1_45     ii_46     0.0028488699999999999
    H1_45     rsf_45    0.050000000000000003
    H1_45     lcr_min_45  1
    H1_45     lcr_cap_min_45  1
    H1_45     lcr_buf_45  1
    H1_45     lcr_cap_buf_45  1
    H1_46     liquid_46  1
    H1_46     l2_cap_46  -0.40000000000000002
    H1_46     ii_47     0.0028418074999999998
    H1_46     rsf_46    0.050000000000000003
    H1_46     lcr_min_46  1
    H1_46     lcr_cap_min_46  1
    H1_46     lcr_buf_46  1
    H1_46     lcr_cap_buf_46  1
    H1_47     liquid_47  1
    H1_47     l2_cap_47  -0.40000000000000002
    H1_47     ii_48     0.002834745833333333
    H1_47     rsf_47    0.050000000000000003
    H1_47     lcr_min_47  1
    H1_47     lcr_cap_min_47  1
    H1_47     lcr_buf_47  1
    H1_47     lcr_cap_buf_47  1
    H1_48     liquid_48  1
    H1_48     l2_cap_48  -0.40000000000000002
    H1_48     ii_49     0.0028276833333333333
    H1_48     rsf_48    0.050000000000000003
    H1_48     lcr_min_48  1
    H1_48     lcr_cap_min_48  1
    H1_48     lcr_buf_48  1
    H1_48     lcr_cap_buf_48  1
    H1_49     liquid_49  1
    H1_49     l2_cap_49  -0.40000000000000002
    H1_49     ii_50     0.0028206216666666669
    H1_49     rsf_49    0.050000000000000003
    H1_49     lcr_min_49  1
    H1_49     lcr_cap_min_49  1
    H1_49     lcr_buf_49  1
    H1_49     lcr_cap_buf_49  1
    H1_50     liquid_50  1
    H1_50     l2_cap_50  -0.40000000000000002
    H1_50     ii_51     0.0028135591666666668
    H1_50     rsf_50    0.050000000000000003
    H1_50     lcr_min_50  1
    H1_50     lcr_cap_min_50  1
    H1_50     lcr_buf_50  1
    H1_50     lcr_cap_buf_50  1
    H1_51     liquid_51  1
    H1_51     l2_cap_51  -0.40000000000000002
    H1_51     ii_52     0.0028064975
    H1_51     rsf_51    0.050000000000000003
    H1_51     lcr_min_51  1
    H1_51     lcr_cap_min_51  1
    H1_51     lcr_buf_51  1
    H1_51     lcr_cap_buf_51  1
    H1_52     liquid_52  1
    H1_52     l2_cap_52  -0.40000000000000002
    H1_52     ii_53     0.0027994349999999999
    H1_52     rsf_52    0.050000000000000003
    H1_52     lcr_min_52  1
    H1_52     lcr_cap_min_52  1
    H1_52     lcr_buf_52  1
    H1_52     lcr_cap_buf_52  1
    H1_53     liquid_53  1
    H1_53     l2_cap_53  -0.40000000000000002
    H1_53     ii_54     0.0027923724999999997
    H1_53     rsf_53    0.050000000000000003
    H1_53     lcr_min_53  1
    H1_53     lcr_cap_min_53  1
    H1_53     lcr_buf_53  1
    H1_53     lcr_cap_buf_53  1
    H1_54     liquid_54  1
    H1_54     l2_cap_54  -0.40000000000000002
    H1_54     ii_55     0.0027853108333333329
    H1_54     rsf_54    0.050000000000000003
    H1_54     lcr_min_54  1
    H1_54     lcr_cap_min_54  1
    H1_54     lcr_buf_54  1
    H1_54     lcr_cap_buf_54  1
    H1_55     liquid_55  1
    H1_55     l2_cap_55  -0.40000000000000002
    H1_55     ii_56     0.0027782483333333328
    H1_55     rsf_55    0.050000000000000003
    H1_55     lcr_min_55  1
    H1_55     lcr_cap_min_55  1
    H1_55     lcr_buf_55  1
    H1_55     lcr_cap_buf_55  1
    H1_56     liquid_56  1
    H1_56     l2_cap_56  -0.40000000000000002
    H1_56     ii_57     0.0027711866666666665
    H1_56     rsf_56    0.050000000000000003
    H1_56     lcr_min_56  1
    H1_56     lcr_cap_min_56  1
    H1_56     lcr_buf_56  1
    H1_56     lcr_cap_buf_56  1
    H1_57     liquid_57  1
    H1_57     l2_cap_57  -0.40000000000000002
    H1_57     ii_58     0.0027641241666666668
    H1_57     rsf_57    0.050000000000000003
    H1_57     lcr_min_57  1
    H1_57     lcr_cap_min_57  1
    H1_57     lcr_buf_57  1
    H1_57     lcr_cap_buf_57  1
    H1_58     liquid_58  1
    H1_58     l2_cap_58  -0.40000000000000002
    H1_58     ii_59     0.0027570625
    H1_58     rsf_58    0.050000000000000003
    H1_58     lcr_min_58  1
    H1_58     lcr_cap_min_58  1
    H1_58     lcr_buf_58  1
    H1_58     lcr_cap_buf_58  1
    H1_59     liquid_59  1
    H1_59     l2_cap_59  -0.40000000000000002
    H1_59     ii_60     0.0027499999999999998
    H1_59     rsf_59    0.050000000000000003
    H1_59     lcr_min_59  1
    H1_59     lcr_cap_min_59  1
    H1_59     lcr_buf_59  1
    H1_59     lcr_cap_buf_59  1
    H1_60     Obj       0.0027499999999999998
    H1_60     liquid_60  1
    H1_60     l2_cap_60  -0.40000000000000002
    H1_60     rsf_60    0.050000000000000003
    H1_60     lcr_min_60  1
    H1_60     lcr_cap_min_60  1
    H1_60     lcr_buf_60  1
    H1_60     lcr_cap_buf_60  1
    H2_1      liquid_1  1
    H2_1      l2_haircut_1  -0.84999999999999998
    H2_1      ii_2      0.003326270833333333
    H2_1      rsf_1     0.14999999999999999
    H2_2      liquid_2  1
    H2_2      l2_haircut_2  -0.84999999999999998
    H2_2      ii_3      0.0033192091666666666
    H2_2      rsf_2     0.14999999999999999
    H2_3      liquid_3  1
    H2_3      l2_haircut_3  -0.84999999999999998
    H2_3      ii_4      0.0033121466666666665
    H2_3      rsf_3     0.14999999999999999
    H2_4      liquid_4  1
    H2_4      l2_haircut_4  -0.84999999999999998
    H2_4      ii_5      0.0033050849999999997
    H2_4      rsf_4     0.14999999999999999
    H2_5      liquid_5  1
    H2_5      l2_haircut_5  -0.84999999999999998
    H2_5      ii_6      0.0032980224999999996
    H2_5      rsf_5     0.14999999999999999
    H2_6      liquid_6  1
    H2_6      l2_haircut_6  -0.84999999999999998
    H2_6      ii_7      0.0032909608333333328
    H2_6      rsf_6     0.14999999999999999
    H2_7      liquid_7  1
    H2_7      l2_haircut_7  -0.84999999999999998
    H2_7      ii_8      0.0032838983333333335
    H2_7      rsf_7     0.14999999999999999
    H2_8      liquid_8  1
    H2_8      l2_haircut_8  -0.84999999999999998
    H2_8      ii_9      0.0032768358333333334
    H2_8      rsf_8     0.14999999999999999
    H2_9      liquid_9  1
    H2_9      l2_haircut_9  -0.84999999999999998
    H2_9      ii_10     0.0032697741666666666
    H2_9      rsf_9     0.14999999999999999
    H2_10     liquid_10  1
    H2_10     l2_haircut_10  -0.84999999999999998
    H2_10     ii_11     0.0032627116666666665
    H2_10     rsf_10    0.14999999999999999
    H2_11     liquid_11  1
    H2_11     l2_haircut_11  -0.84999999999999998
    H2_11     ii_12     0.0032556499999999997
    H2_11     rsf_11    0.14999999999999999
    H2_12     liquid_12  1
    H2_12     l2_haircut_12  -0.84999999999999998
    H2_12     ii_13     0.0032485874999999996
    H2_12     rsf_12    0.14999999999999999
    H2_13     liquid_13  1
    H2_13     l2_haircut_13  -0.84999999999999998
    H2_13     ii_14     0.0032415258333333332
    H2_13     rsf_13    0.14999999999999999
    H2_14     liquid_14  1
    H2_14     l2_haircut_14  -0.84999999999999998
    H2_14     ii_15     0.0032344633333333331
    H2_14     rsf_14    0.14999999999999999
    H2_15     liquid_15  1
    H2_15     l2_haircut_15  -0.84999999999999998
    H2_15     ii_16     0.0032274008333333334
    H2_15     rsf_15    0.14999999999999999
    H2_16     liquid_16  1
    H2_16     l2_haircut_16  -0.84999999999999998
    H2_16     ii_17     0.0032203391666666666
    H2_16     rsf_16    0.14999999999999999
    H2_17     liquid_17  1
    H2_17     l2_haircut_17  -0.84999999999999998
    H2_17     ii_18     0.0032132766666666665
    H2_17     rsf_17    0.14999999999999999
    H2_18     liquid_18  1
    H2_18     l2_haircut_18  -0.84999999999999998
    H2_18     ii_19     0.0032062150000000001
    H2_18     rsf_18    0.14999999999999999
    H2_19     liquid_19  1
    H2_19     l2_haircut_19  -0.84999999999999998
    H2_19     ii_20     0.0031991525
    H2_19     rsf_19    0.14999999999999999
    H2_20     liquid_20  1
    H2_20     l2_haircut_20  -0.84999999999999998
    H2_20     ii_21     0.0031920899999999999
    H2_20     rsf_20    0.14999999999999999
    H2_21     liquid_21  1
    H2_21     l2_haircut_21  -0.84999999999999998
    H2_21     ii_22     0.0031850283333333331
    H2_21     rsf_21    0.14999999999999999
    H2_22     liquid_22  1
    H2_22     l2_haircut_22  -0.84999999999999998
    H2_22     ii_23     0.0031779658333333329
    H2_22     rsf_22    0.14999999999999999
    H2_23     liquid_23  1
    H2_23     l2_haircut_23  -0.84999999999999998
    H2_23     ii_24     0.0031709041666666661
    H2_23     rsf_23    0.14999999999999999
    H2_24     liquid_24  1
    H2_24     l2_haircut_24  -0.84999999999999998
    H2_24     ii_25     0.0031638416666666669
    H2_24     rsf_24    0.14999999999999999
    H2_25     liquid_25  1
    H2_25     l2_haircut_25  -0.84999999999999998
    H2_25     ii_26     0.0031567800000000001
    H2_25     rsf_25    0.14999999999999999
    H2_26     liquid_26  1
    H2_26     l2_haircut_26  -0.84999999999999998
    H2_26     ii_27     0.0031497175
    H2_26     rsf_26    0.14999999999999999
    H2_27     liquid_27  1
    H2_27     l2_haircut_27  -0.84999999999999998
    H2_27     ii_28     0.0031426549999999998
    H2_27     rsf_27    0.14999999999999999
    H2_28     liquid_28  1
    H2_28     l2_haircut_28  -0.84999999999999998
    H2_28     ii_29     0.003135593333333333
    H2_28     rsf_28    0.14999999999999999
    H2_29     liquid_29  1
    H2_29     l2_haircut_29  -0.84999999999999998
    H2_29     ii_30     0.0031285308333333329
    H2_29     rsf_29    0.14999999999999999
    H2_30     liquid_30  1
    H2_30     l2_haircut_30  -0.84999999999999998
    H2_30     ii_31     0.0031214691666666666
    H2_30     rsf_30    0.14999999999999999
    H2_31     liquid_31  1
    H2_31     l2_haircut_31  -0.84999999999999998
    H2_31     ii_32     0.0031144066666666664
    H2_31     rsf_31    0.14999999999999999
    H2_32     liquid_32  1
    H2_32     l2_haircut_32  -0.84999999999999998
    H2_32     ii_33     0.0031073449999999996
    H2_32     rsf_32    0.14999999999999999
    H2_33     liquid_33  1
    H2_33     l2_haircut_33  -0.84999999999999998
    H2_33     ii_34     0.0031002824999999999
    H2_33     rsf_33    0.14999999999999999
    H2_34     liquid_34  1
    H2_34     l2_haircut_34  -0.84999999999999998
    H2_34     ii_35     0.0030932199999999998
    H2_34     rsf_34    0.14999999999999999
    H2_35     liquid_35  1
    H2_35     l2_haircut_35  -0.84999999999999998
    H2_35     ii_36     0.0030861583333333335
    H2_35     rsf_35    0.14999999999999999
    H2_36     liquid_36  1
    H2_36     l2_haircut_36  -0.84999999999999998
    H2_36     ii_37     0.0030790958333333333
    H2_36     rsf_36    0.14999999999999999
    H2_37     liquid_37  1
    H2_37     l2_haircut_37  -0.84999999999999998
    H2_37     ii_38     0.0030720341666666665
    H2_37     rsf_37    0.14999999999999999
    H2_38     liquid_38  1
    H2_38     l2_haircut_38  -0.84999999999999998
    H2_38     ii_39     0.0030649716666666664
    H2_38     rsf_38    0.14999999999999999
    H2_39     liquid_39  1
    H2_39     l2_haircut_39  -0.84999999999999998
    H2_39     ii_40     0.0030579099999999996
    H2_39     rsf_39    0.14999999999999999
    H2_40     liquid_40  1
    H2_40     l2_haircut_40  -0.84999999999999998
    H2_40     ii_41     0.0030508474999999995
    H2_40     rsf_40    0.14999999999999999
    H2_41     liquid_41  1
    H2_41     l2_haircut_41  -0.84999999999999998
    H2_41     ii_42     0.0030437850000000002
    H2_41     rsf_41    0.14999999999999999
    H2_42     liquid_42  1
    H2_42     l2_haircut_42  -0.84999999999999998
    H2_42     ii_43     0.0030367233333333334
    H2_42     rsf_42    0.14999999999999999
    H2_43     liquid_43  1
    H2_43     l2_haircut_43  -0.84999999999999998
    H2_43     ii_44     0.0030296608333333333
    H2_43     rsf_43    0.14999999999999999
    H2_44     liquid_44  1
    H2_44     l2_haircut_44  -0.84999999999999998
    H2_44     ii_45     0.0030225991666666665
    H2_44     rsf_44    0.14999999999999999
    H2_45     liquid_45  1
    H2_45     l2_haircut_45  -0.84999999999999998
    H2_45     ii_46     0.0030155366666666664
    H2_45     rsf_45    0.14999999999999999
    H2_46     liquid_46  1
    H2_46     l2_haircut_46  -0.84999999999999998
    H2_46     ii_47     0.0030084741666666663
    H2_46     rsf_46    0.14999999999999999
    H2_47     liquid_47  1
    H2_47     l2_haircut_47  -0.84999999999999998
    H2_47     ii_48     0.0030014124999999999
    H2_47     rsf_47    0.14999999999999999
    H2_48     liquid_48  1
    H2_48     l2_haircut_48  -0.84999999999999998
    H2_48     ii_49     0.0029943499999999998
    H2_48     rsf_48    0.14999999999999999
    H2_49     liquid_49  1
    H2_49     l2_haircut_49  -0.84999999999999998
    H2_49     ii_50     0.002987288333333333
    H2_49     rsf_49    0.14999999999999999
    H2_50     liquid_50  1
    H2_50     l2_haircut_50  -0.84999999999999998
    H2_50     ii_51     0.0029802258333333333
    H2_50     rsf_50    0.14999999999999999
    H2_51     liquid_51  1
    H2_51     l2_haircut_51  -0.84999999999999998
    H2_51     ii_52     0.0029731641666666669
    H2_51     rsf_51    0.14999999999999999
    H2_52     liquid_52  1
    H2_52     l2_haircut_52  -0.84999999999999998
    H2_52     ii_53     0.0029661016666666668
    H2_52     rsf_52    0.14999999999999999
    H2_53     liquid_53  1
    H2_53     l2_haircut_53  -0.84999999999999998
    H2_53     ii_54     0.0029590391666666667
    H2_53     rsf_53    0.14999999999999999
    H2_54     liquid_54  1
    H2_54     l2_haircut_54  -0.84999999999999998
    H2_54     ii_55     0.0029519774999999999
    H2_54     rsf_54    0.14999999999999999
    H2_55     liquid_55  1
    H2_55     l2_haircut_55  -0.84999999999999998
    H2_55     ii_56     0.0029449149999999998
    H2_55     rsf_55    0.14999999999999999
    H2_56     liquid_56  1
    H2_56     l2_haircut_56  -0.84999999999999998
    H2_56     ii_57     0.002937853333333333
    H2_56     rsf_56    0.14999999999999999
    H2_57     liquid_57  1
    H2_57     l2_haircut_57  -0.84999999999999998
    H2_57     ii_58     0.0029307908333333329
    H2_57     rsf_57    0.14999999999999999
    H2_58     liquid_58  1
    H2_58     l2_haircut_58  -0.84999999999999998
    H2_58     ii_59     0.0029237291666666665
    H2_58     rsf_58    0.14999999999999999
    H2_59     liquid_59  1
    H2_59     l2_haircut_59  -0.84999999999999998
    H2_59     ii_60     0.0029166666666666668
    H2_59     rsf_59    0.14999999999999999
    H2_60     Obj       0.0029166666666666668
    H2_60     liquid_60  1
    H2_60     l2_haircut_60  -0.84999999999999998
    H2_60     rsf_60    0.14999999999999999
    Q2_1      l2_haircut_1  1
    Q2_1      l2_cap_1  0.59999999999999998
    Q2_1      lcr_min_1  1
    Q2_1      lcr_cap_min_1  1
    Q2_1      lcr_buf_1  1
    Q2_1      lcr_cap_buf_1  1
    Q2_2      l2_haircut_2  1
    Q2_2      l2_cap_2  0.59999999999999998
    Q2_2      lcr_min_2  1
    Q2_2      lcr_cap_min_2  1
    Q2_2      lcr_buf_2  1
    Q2_2      lcr_cap_buf_2  1
    Q2_3      l2_haircut_3  1
    Q2_3      l2_cap_3  0.59999999999999998
    Q2_3      lcr_min_3  1
    Q2_3      lcr_cap_min_3  1
    Q2_3      lcr_buf_3  1
    Q2_3      lcr_cap_buf_3  1
    Q2_4      l2_haircut_4  1
    Q2_4      l2_cap_4  0.59999999999999998
    Q2_4      lcr_min_4  1
    Q2_4      lcr_cap_min_4  1
    Q2_4      lcr_buf_4  1
    Q2_4      lcr_cap_buf_4  1
    Q2_5      l2_haircut_5  1
    Q2_5      l2_cap_5  0.59999999999999998
    Q2_5      lcr_min_5  1
    Q2_5      lcr_cap_min_5  1
    Q2_5      lcr_buf_5  1
    Q2_5      lcr_cap_buf_5  1
    Q2_6      l2_haircut_6  1
    Q2_6      l2_cap_6  0.59999999999999998
    Q2_6      lcr_min_6  1
    Q2_6      lcr_cap_min_6  1
    Q2_6      lcr_buf_6  1
    Q2_6      lcr_cap_buf_6  1
    Q2_7      l2_haircut_7  1
    Q2_7      l2_cap_7  0.59999999999999998
    Q2_7      lcr_min_7  1
    Q2_7      lcr_cap_min_7  1
    Q2_7      lcr_buf_7  1
    Q2_7      lcr_cap_buf_7  1
    Q2_8      l2_haircut_8  1
    Q2_8      l2_cap_8  0.59999999999999998
    Q2_8      lcr_min_8  1
    Q2_8      lcr_cap_min_8  1
    Q2_8      lcr_buf_8  1
    Q2_8      lcr_cap_buf_8  1
    Q2_9      l2_haircut_9  1
    Q2_9      l2_cap_9  0.59999999999999998
    Q2_9      lcr_min_9  1
    Q2_9      lcr_cap_min_9  1
    Q2_9      lcr_buf_9  1
    Q2_9      lcr_cap_buf_9  1
    Q2_10     l2_haircut_10  1
    Q2_10     l2_cap_10  0.59999999999999998
    Q2_10     lcr_min_10  1
    Q2_10     lcr_cap_min_10  1
    Q2_10     lcr_buf_10  1
    Q2_10     lcr_cap_buf_10  1
    Q2_11     l2_haircut_11  1
    Q2_11     l2_cap_11  0.59999999999999998
    Q2_11     lcr_min_11  1
    Q2_11     lcr_cap_min_11  1
    Q2_11     lcr_buf_11  1
    Q2_11     lcr_cap_buf_11  1
    Q2_12     l2_haircut_12  1
    Q2_12     l2_cap_12  0.59999999999999998
    Q2_12     lcr_min_12  1
    Q2_12     lcr_cap_min_12  1
    Q2_12     lcr_buf_12  1
    Q2_12     lcr_cap_buf_12  1
    Q2_13     l2_haircut_13  1
    Q2_13     l2_cap_13  0.59999999999999998
    Q2_13     lcr_min_13  1
    Q2_13     lcr_cap_min_13  1
    Q2_13     lcr_buf_13  1
    Q2_13     lcr_cap_buf_13  1
    Q2_14     l2_haircut_14  1
    Q2_14     l2_cap_14  0.59999999999999998
    Q2_14     lcr_min_14  1
    Q2_14     lcr_cap_min_14  1
    Q2_14     lcr_buf_14  1
    Q2_14     lcr_cap_buf_14  1
    Q2_15     l2_haircut_15  1
    Q2_15     l2_cap_15  0.59999999999999998
    Q2_15     lcr_min_15  1
    Q2_15     lcr_cap_min_15  1
    Q2_15     lcr_buf_15  1
    Q2_15     lcr_cap_buf_15  1
    Q2_16     l2_haircut_16  1
    Q2_16     l2_cap_16  0.59999999999999998
    Q2_16     lcr_min_16  1
    Q2_16     lcr_cap_min_16  1
    Q2_16     lcr_buf_16  1
    Q2_16     lcr_cap_buf_16  1
    Q2_17     l2_haircut_17  1
    Q2_17     l2_cap_17  0.59999999999999998
    Q2_17     lcr_min_17  1
    Q2_17     lcr_cap_min_17  1
    Q2_17     lcr_buf_17  1
    Q2_17     lcr_cap_buf_17  1
    Q2_18     l2_haircut_18  1
    Q2_18     l2_cap_18  0.59999999999999998
    Q2_18     lcr_min_18  1
    Q2_18     lcr_cap_min_18  1
    Q2_18     lcr_buf_18  1
    Q2_18     lcr_cap_buf_18  1
    Q2_19     l2_haircut_19  1
    Q2_19     l2_cap_19  0.59999999999999998
    Q2_19     lcr_min_19  1
    Q2_19     lcr_cap_min_19  1
    Q2_19     lcr_buf_19  1
    Q2_19     lcr_cap_buf_19  1
    Q2_20     l2_haircut_20  1
    Q2_20     l2_cap_20  0.59999999999999998
    Q2_20     lcr_min_20  1
    Q2_20     lcr_cap_min_20  1
    Q2_20     lcr_buf_20  1
    Q2_20     lcr_cap_buf_20  1
    Q2_21     l2_haircut_21  1
    Q2_21     l2_cap_21  0.59999999999999998
    Q2_21     lcr_min_21  1
    Q2_21     lcr_cap_min_21  1
    Q2_21     lcr_buf_21  1
    Q2_21     lcr_cap_buf_21  1
    Q2_22     l2_haircut_22  1
    Q2_22     l2_cap_22  0.59999999999999998
    Q2_22     lcr_min_22  1
    Q2_22     lcr_cap_min_22  1
    Q2_22     lcr_buf_22  1
    Q2_22     lcr_cap_buf_22  1
    Q2_23     l2_haircut_23  1
    Q2_23     l2_cap_23  0.59999999999999998
    Q2_23     lcr_min_23  1
    Q2_23     lcr_cap_min_23  1
    Q2_23     lcr_buf_23  1
    Q2_23     lcr_cap_buf_23  1
    Q2_24     l2_haircut_24  1
    Q2_24     l2_cap_24  0.59999999999999998
    Q2_24     lcr_min_24  1
    Q2_24     lcr_cap_min_24  1
    Q2_24     lcr_buf_24  1
    Q2_24     lcr_cap_buf_24  1
    Q2_25     l2_haircut_25  1
    Q2_25     l2_cap_25  0.59999999999999998
    Q2_25     lcr_min_25  1
    Q2_25     lcr_cap_min_25  1
    Q2_25     lcr_buf_25  1
    Q2_25     lcr_cap_buf_25  1
    Q2_26     l2_haircut_26  1
    Q2_26     l2_cap_26  0.59999999999999998
    Q2_26     lcr_min_26  1
    Q2_26     lcr_cap_min_26  1
    Q2_26     lcr_buf_26  1
    Q2_26     lcr_cap_buf_26  1
    Q2_27     l2_haircut_27  1
    Q2_27     l2_cap_27  0.59999999999999998
    Q2_27     lcr_min_27  1
    Q2_27     lcr_cap_min_27  1
    Q2_27     lcr_buf_27  1
    Q2_27     lcr_cap_buf_27  1
    Q2_28     l2_haircut_28  1
    Q2_28     l2_cap_28  0.59999999999999998
    Q2_28     lcr_min_28  1
    Q2_28     lcr_cap_min_28  1
    Q2_28     lcr_buf_28  1
    Q2_28     lcr_cap_buf_28  1
    Q2_29     l2_haircut_29  1
    Q2_29     l2_cap_29  0.59999999999999998
    Q2_29     lcr_min_29  1
    Q2_29     lcr_cap_min_29  1
    Q2_29     lcr_buf_29  1
    Q2_29     lcr_cap_buf_29  1
    Q2_30     l2_haircut_30  1
    Q2_30     l2_cap_30  0.59999999999999998
    Q2_30     lcr_min_30  1
    Q2_30     lcr_cap_min_30  1
    Q2_30     lcr_buf_30  1
    Q2_30     lcr_cap_buf_30  1
    Q2_31     l2_haircut_31  1
    Q2_31     l2_cap_31  0.59999999999999998
    Q2_31     lcr_min_31  1
    Q2_31     lcr_cap_min_31  1
    Q2_31     lcr_buf_31  1
    Q2_31     lcr_cap_buf_31  1
    Q2_32     l2_haircut_32  1
    Q2_32     l2_cap_32  0.59999999999999998
    Q2_32     lcr_min_32  1
    Q2_32     lcr_cap_min_32  1
    Q2_32     lcr_buf_32  1
    Q2_32     lcr_cap_buf_32  1
    Q2_33     l2_haircut_33  1
    Q2_33     l2_cap_33  0.59999999999999998
    Q2_33     lcr_min_33  1
    Q2_33     lcr_cap_min_33  1
    Q2_33     lcr_buf_33  1
    Q2_33     lcr_cap_buf_33  1
    Q2_34     l2_haircut_34  1
    Q2_34     l2_cap_34  0.59999999999999998
    Q2_34     lcr_min_34  1
    Q2_34     lcr_cap_min_34  1
    Q2_34     lcr_buf_34  1
    Q2_34     lcr_cap_buf_34  1
    Q2_35     l2_haircut_35  1
    Q2_35     l2_cap_35  0.59999999999999998
    Q2_35     lcr_min_35  1
    Q2_35     lcr_cap_min_35  1
    Q2_35     lcr_buf_35  1
    Q2_35     lcr_cap_buf_35  1
    Q2_36     l2_haircut_36  1
    Q2_36     l2_cap_36  0.59999999999999998
    Q2_36     lcr_min_36  1
    Q2_36     lcr_cap_min_36  1
    Q2_36     lcr_buf_36  1
    Q2_36     lcr_cap_buf_36  1
    Q2_37     l2_haircut_37  1
    Q2_37     l2_cap_37  0.59999999999999998
    Q2_37     lcr_min_37  1
    Q2_37     lcr_cap_min_37  1
    Q2_37     lcr_buf_37  1
    Q2_37     lcr_cap_buf_37  1
    Q2_38     l2_haircut_38  1
    Q2_38     l2_cap_38  0.59999999999999998
    Q2_38     lcr_min_38  1
    Q2_38     lcr_cap_min_38  1
    Q2_38     lcr_buf_38  1
    Q2_38     lcr_cap_buf_38  1
    Q2_39     l2_haircut_39  1
    Q2_39     l2_cap_39  0.59999999999999998
    Q2_39     lcr_min_39  1
    Q2_39     lcr_cap_min_39  1
    Q2_39     lcr_buf_39  1
    Q2_39     lcr_cap_buf_39  1
    Q2_40     l2_haircut_40  1
    Q2_40     l2_cap_40  0.59999999999999998
    Q2_40     lcr_min_40  1
    Q2_40     lcr_cap_min_40  1
    Q2_40     lcr_buf_40  1
    Q2_40     lcr_cap_buf_40  1
    Q2_41     l2_haircut_41  1
    Q2_41     l2_cap_41  0.59999999999999998
    Q2_41     lcr_min_41  1
    Q2_41     lcr_cap_min_41  1
    Q2_41     lcr_buf_41  1
    Q2_41     lcr_cap_buf_41  1
    Q2_42     l2_haircut_42  1
    Q2_42     l2_cap_42  0.59999999999999998
    Q2_42     lcr_min_42  1
    Q2_42     lcr_cap_min_42  1
    Q2_42     lcr_buf_42  1
    Q2_42     lcr_cap_buf_42  1
    Q2_43     l2_haircut_43  1
    Q2_43     l2_cap_43  0.59999999999999998
    Q2_43     lcr_min_43  1
    Q2_43     lcr_cap_min_43  1
    Q2_43     lcr_buf_43  1
    Q2_43     lcr_cap_buf_43  1
    Q2_44     l2_haircut_44  1
    Q2_44     l2_cap_44  0.59999999999999998
    Q2_44     lcr_min_44  1
    Q2_44     lcr_cap_min_44  1
    Q2_44     lcr_buf_44  1
    Q2_44     lcr_cap_buf_44  1
    Q2_45     l2_haircut_45  1
    Q2_45     l2_cap_45  0.59999999999999998
    Q2_45     lcr_min_45  1
    Q2_45     lcr_cap_min_45  1
    Q2_45     lcr_buf_45  1
    Q2_45     lcr_cap_buf_45  1
    Q2_46     l2_haircut_46  1
    Q2_46     l2_cap_46  0.59999999999999998
    Q2_46     lcr_min_46  1
    Q2_46     lcr_cap_min_46  1
    Q2_46     lcr_buf_46  1
    Q2_46     lcr_cap_buf_46  1
    Q2_47     l2_haircut_47  1
    Q2_47     l2_cap_47  0.59999999999999998
    Q2_47     lcr_min_47  1
    Q2_47     lcr_cap_min_47  1
    Q2_47     lcr_buf_47  1
    Q2_47     lcr_cap_buf_47  1
    Q2_48     l2_haircut_48  1
    Q2_48     l2_cap_48  0.59999999999999998
    Q2_48     lcr_min_48  1
    Q2_48     lcr_cap_min_48  1
    Q2_48     lcr_buf_48  1
    Q2_48     lcr_cap_buf_48  1
    Q2_49     l2_haircut_49  1
    Q2_49     l2_cap_49  0.59999999999999998
    Q2_49     lcr_min_49  1
    Q2_49     lcr_cap_min_49  1
    Q2_49     lcr_buf_49  1
    Q2_49     lcr_cap_buf_49  1
    Q2_50     l2_haircut_50  1
    Q2_50     l2_cap_50  0.59999999999999998
    Q2_50     lcr_min_50  1
    Q2_50     lcr_cap_min_50  1
    Q2_50     lcr_buf_50  1
    Q2_50     lcr_cap_buf_50  1
    Q2_51     l2_haircut_51  1
    Q2_51     l2_cap_51  0.59999999999999998
    Q2_51     lcr_min_51  1
    Q2_51     lcr_cap_min_51  1
    Q2_51     lcr_buf_51  1
    Q2_51     lcr_cap_buf_51  1
    Q2_52     l2_haircut_52  1
    Q2_52     l2_cap_52  0.59999999999999998
    Q2_52     lcr_min_52  1
    Q2_52     lcr_cap_min_52  1
    Q2_52     lcr_buf_52  1
    Q2_52     lcr_cap_buf_52  1
    Q2_53     l2_haircut_53  1
    Q2_53     l2_cap_53  0.59999999999999998
    Q2_53     lcr_min_53  1
    Q2_53     lcr_cap_min_53  1
    Q2_53     lcr_buf_53  1
    Q2_53     lcr_cap_buf_53  1
    Q2_54     l2_haircut_54  1
    Q2_54     l2_cap_54  0.59999999999999998
    Q2_54     lcr_min_54  1
    Q2_54     lcr_cap_min_54  1
    Q2_54     lcr_buf_54  1
    Q2_54     lcr_cap_buf_54  1
    Q2_55     l2_haircut_55  1
    Q2_55     l2_cap_55  0.59999999999999998
    Q2_55     lcr_min_55  1
    Q2_55     lcr_cap_min_55  1
    Q2_55     lcr_buf_55  1
    Q2_55     lcr_cap_buf_55  1
    Q2_56     l2_haircut_56  1
    Q2_56     l2_cap_56  0.59999999999999998
    Q2_56     lcr_min_56  1
    Q2_56     lcr_cap_min_56  1
    Q2_56     lcr_buf_56  1
    Q2_56     lcr_cap_buf_56  1
    Q2_57     l2_haircut_57  1
    Q2_57     l2_cap_57  0.59999999999999998
    Q2_57     lcr_min_57  1
    Q2_57     lcr_cap_min_57  1
    Q2_57     lcr_buf_57  1
    Q2_57     lcr_cap_buf_57  1
    Q2_58     l2_haircut_58  1
    Q2_58     l2_cap_58  0.59999999999999998
    Q2_58     lcr_min_58  1
    Q2_58     lcr_cap_min_58  1
    Q2_58     lcr_buf_58  1
    Q2_58     lcr_cap_buf_58  1
    Q2_59     l2_haircut_59  1
    Q2_59     l2_cap_59  0.59999999999999998
    Q2_59     lcr_min_59  1
    Q2_59     lcr_cap_min_59  1
    Q2_59     lcr_buf_59  1
    Q2_59     lcr_cap_buf_59  1
    Q2_60     l2_haircut_60  1
    Q2_60     l2_cap_60  0.59999999999999998
    Q2_60     lcr_min_60  1
    Q2_60     lcr_cap_min_60  1
    Q2_60     lcr_buf_60  1
    Q2_60     lcr_cap_buf_60  1
    TL_1      tl_1      -1
    TL_1      tl_2      1
    TL_2      tl_2      -1
    TL_2      tl_3      1
    TL_3      tl_3      -1
    TL_3      tl_4      1
    TL_4      tl_4      -1
    TL_4      tl_5      1
    TL_5      tl_5      -1
    TL_5      tl_6      1
    TL_6      tl_6      -1
    TL_6      tl_7      1
    TL_7      tl_7      -1
    TL_7      tl_8      1
    TL_8      tl_8      -1
    TL_8      tl_9      1
    TL_9      tl_9      -1
    TL_9      tl_10     1
    TL_10     tl_10     -1
    TL_10     tl_11     1
    TL_11     tl_11     -1
    TL_11     tl_12     1
    TL_12     tl_12     -1
    TL_12     tl_13     1
    TL_13     tl_13     -1
    TL_13     tl_14     1
    TL_14     tl_14     -1
    TL_14     tl_15     1
    TL_15     tl_15     -1
    TL_15     tl_16     1
    TL_16     tl_16     -1
    TL_16     tl_17     1
    TL_17     tl_17     -1
    TL_17     tl_18     1
    TL_18     tl_18     -1
    TL_18     tl_19     1
    TL_19     tl_19     -1
    TL_19     tl_20     1
    TL_20     tl_20     -1
    TL_20     tl_21     1
    TL_21     tl_21     -1
    TL_21     tl_22     1
    TL_22     tl_22     -1
    TL_22     tl_23     1
    TL_23     tl_23     -1
    TL_23     tl_24     1
    TL_24     tl_24     -1
    TL_24     tl_25     1
    TL_25     tl_25     -1
    TL_25     tl_26     1
    TL_26     tl_26     -1
    TL_26     tl_27     1
    TL_27     tl_27     -1
    TL_27     tl_28     1
    TL_28     tl_28     -1
    TL_28     tl_29     1
    TL_29     tl_29     -1
    TL_29     tl_30     1
    TL_30     tl_30     -1
    TL_30     tl_31     1
    TL_31     tl_31     -1
    TL_31     tl_32     1
    TL_32     tl_32     -1
    TL_32     tl_33     1
    TL_33     tl_33     -1
    TL_33     tl_34     1
    TL_34     tl_34     -1
    TL_34     tl_35     1
    TL_35     tl_35     -1
    TL_35     tl_36     1
    TL_36     tl_36     -1
    TL_36     tl_37     1
    TL_37     tl_37     -1
    TL_37     tl_38     1
    TL_38     tl_38     -1
    TL_38     tl_39     1
    TL_39     tl_39     -1
    TL_39     tl_40     1
    TL_40     tl_40     -1
    TL_40     tl_41     1
    TL_41     tl_41     -1
    TL_41     tl_42     1
    TL_42     tl_42     -1
    TL_42     tl_43     1
    TL_43     tl_43     -1
    TL_43     tl_44     1
    TL_44     tl_44     -1
    TL_44     tl_45     1
    TL_45     tl_45     -1
    TL_45     tl_46     1
    TL_46     tl_46     -1
    TL_46     tl_47     1
    TL_47     tl_47     -1
    TL_47     tl_48     1
    TL_48     tl_48     -1
    TL_48     tl_49     1
    TL_49     tl_49     -1
    TL_49     tl_50     1
    TL_50     tl_50     -1
    TL_50     tl_51     1
    TL_51     tl_51     -1
    TL_51     tl_52     1
    TL_52     tl_52     -1
    TL_52     tl_53     1
    TL_53     tl_53     -1
    TL_53     tl_54     1
    TL_54     tl_54     -1
    TL_54     tl_55     1
    TL_55     tl_55     -1
    TL_55     tl_56     1
    TL_56     tl_56     -1
    TL_56     tl_57     1
    TL_57     tl_57     -1
    TL_57     tl_58     1
    TL_58     tl_58     -1
    TL_58     tl_59     1
    TL_59     tl_59     -1
    TL_59     tl_60     1
    TL_60     tl_60     -1
    TLU_1     tl_1      -1
    TLU_1     tl_use_1  1
    TLU_1     tax_1     -0.25
    TLU_2     tl_2      -1
    TLU_2     tl_use_2  1
    TLU_2     tax_2     -0.25
    TLU_3     tl_3      -1
    TLU_3     tl_use_3  1
    TLU_3     tax_3     -0.25
    TLU_4     tl_4      -1
    TLU_4     tl_use_4  1
    TLU_4     tax_4     -0.25
    TLU_5     tl_5      -1
    TLU_5     tl_use_5  1
    TLU_5     tax_5     -0.25
    TLU_6     tl_6      -1
    TLU_6     tl_use_6  1
    TLU_6     tax_6     -0.25
    TLU_7     tl_7      -1
    TLU_7     tl_use_7  1
    TLU_7     tax_7     -0.25
    TLU_8     tl_8      -1
    TLU_8     tl_use_8  1
    TLU_8     tax_8     -0.25
    TLU_9     tl_9      -1
    TLU_9     tl_use_9  1
    TLU_9     tax_9     -0.25
    TLU_10    tl_10     -1
    TLU_10    tl_use_10  1
    TLU_10    tax_10    -0.25
    TLU_11    tl_11     -1
    TLU_11    tl_use_11  1
    TLU_11    tax_11    -0.25
    TLU_12    tl_12     -1
    TLU_12    tl_use_12  1
    TLU_12    tax_12    -0.25
    TLU_13    tl_13     -1
    TLU_13    tl_use_13  1
    TLU_13    tax_13    -0.25
    TLU_14    tl_14     -1
    TLU_14    tl_use_14  1
    TLU_14    tax_14    -0.25
    TLU_15    tl_15     -1
    TLU_15    tl_use_15  1
    TLU_15    tax_15    -0.25
    TLU_16    tl_16     -1
    TLU_16    tl_use_16  1
    TLU_16    tax_16    -0.25
    TLU_17    tl_17     -1
    TLU_17    tl_use_17  1
    TLU_17    tax_17    -0.25
    TLU_18    tl_18     -1
    TLU_18    tl_use_18  1
    TLU_18    tax_18    -0.25
    TLU_19    tl_19     -1
    TLU_19    tl_use_19  1
    TLU_19    tax_19    -0.25
    TLU_20    tl_20     -1
    TLU_20    tl_use_20  1
    TLU_20    tax_20    -0.25
    TLU_21    tl_21     -1
    TLU_21    tl_use_21  1
    TLU_21    tax_21    -0.25
    TLU_22    tl_22     -1
    TLU_22    tl_use_22  1
    TLU_22    tax_22    -0.25
    TLU_23    tl_23     -1
    TLU_23    tl_use_23  1
    TLU_23    tax_23    -0.25
    TLU_24    tl_24     -1
    TLU_24    tl_use_24  1
    TLU_24    tax_24    -0.25
    TLU_25    tl_25     -1
    TLU_25    tl_use_25  1
    TLU_25    tax_25    -0.25
    TLU_26    tl_26     -1
    TLU_26    tl_use_26  1
    TLU_26    tax_26    -0.25
    TLU_27    tl_27     -1
    TLU_27    tl_use_27  1
    TLU_27    tax_27    -0.25
    TLU_28    tl_28     -1
    TLU_28    tl_use_28  1
    TLU_28    tax_28    -0.25
    TLU_29    tl_29     -1
    TLU_29    tl_use_29  1
    TLU_29    tax_29    -0.25
    TLU_30    tl_30     -1
    TLU_30    tl_use_30  1
    TLU_30    tax_30    -0.25
    TLU_31    tl_31     -1
    TLU_31    tl_use_31  1
    TLU_31    tax_31    -0.25
    TLU_32    tl_32     -1
    TLU_32    tl_use_32  1
    TLU_32    tax_32    -0.25
    TLU_33    tl_33     -1
    TLU_33    tl_use_33  1
    TLU_33    tax_33    -0.25
    TLU_34    tl_34     -1
    TLU_34    tl_use_34  1
    TLU_34    tax_34    -0.25
    TLU_35    tl_35     -1
    TLU_35    tl_use_35  1
    TLU_35    tax_35    -0.25
    TLU_36    tl_36     -1
    TLU_36    tl_use_36  1
    TLU_36    tax_36    -0.25
    TLU_37    tl_37     -1
    TLU_37    tl_use_37  1
    TLU_37    tax_37    -0.25
    TLU_38    tl_38     -1
    TLU_38    tl_use_38  1
    TLU_38    tax_38    -0.25
    TLU_39    tl_39     -1
    TLU_39    tl_use_39  1
    TLU_39    tax_39    -0.25
    TLU_40    tl_40     -1
    TLU_40    tl_use_40  1
    TLU_40    tax_40    -0.25
    TLU_41    tl_41     -1
    TLU_41    tl_use_41  1
    TLU_41    tax_41    -0.25
    TLU_42    tl_42     -1
    TLU_42    tl_use_42  1
    TLU_42    tax_42    -0.25
    TLU_43    tl_43     -1
    TLU_43    tl_use_43  1
    TLU_43    tax_43    -0.25
    TLU_44    tl_44     -1
    TLU_44    tl_use_44  1
    TLU_44    tax_44    -0.25
    TLU_45    tl_45     -1
    TLU_45    tl_use_45  1
    TLU_45    tax_45    -0.25
    TLU_46    tl_46     -1
    TLU_46    tl_use_46  1
    TLU_46    tax_46    -0.25
    TLU_47    tl_47     -1
    TLU_47    tl_use_47  1
    TLU_47    tax_47    -0.25
    TLU_48    tl_48     -1
    TLU_48    tl_use_48  1
    TLU_48    tax_48    -0.25
    TLU_49    tl_49     -1
    TLU_49    tl_use_49  1
    TLU_49    tax_49    -0.25
    TLU_50    tl_50     -1
    TLU_50    tl_use_50  1
    TLU_50    tax_50    -0.25
    TLU_51    tl_51     -1
    TLU_51    tl_use_51  1
    TLU_51    tax_51    -0.25
    TLU_52    tl_52     -1
    TLU_52    tl_use_52  1
    TLU_52    tax_52    -0.25
    TLU_53    tl_53     -1
    TLU_53    tl_use_53  1
    TLU_53    tax_53    -0.25
    TLU_54    tl_54     -1
    TLU_54    tl_use_54  1
    TLU_54    tax_54    -0.25
    TLU_55    tl_55     -1
    TLU_55    tl_use_55  1
    TLU_55    tax_55    -0.25
    TLU_56    tl_56     -1
    TLU_56    tl_use_56  1
    TLU_56    tax_56    -0.25
    TLU_57    tl_57     -1
    TLU_57    tl_use_57  1
    TLU_57    tax_57    -0.25
    TLU_58    tl_58     -1
    TLU_58    tl_use_58  1
    TLU_58    tax_58    -0.25
    TLU_59    tl_59     -1
    TLU_59    tl_use_59  1
    TLU_59    tax_59    -0.25
    TLU_60    tl_60     -1
    TLU_60    tl_use_60  1
    TLU_60    tax_60    -0.25
RHS
    RHS_V     writeoff_1  0.59999999999999998
    RHS_V     stage2_1  302.75
    RHS_V     stage3_1  30.483499999999999
    RHS_V     loan_1    -3960
    RHS_V     term_1    825
    RHS_V     term_2    75
    RHS_V     term_3    75
    RHS_V     term_4    75
    RHS_V     term_5    75
    RHS_V     term_6    75
    RHS_V     term_7    75
    RHS_V     term_8    75
    RHS_V     term_9    75
    RHS_V     term_10   75
    RHS_V     term_11   75
    RHS_V     term_12   75
    RHS_V     whole_1   550
    RHS_V     whole_4   50
    RHS_V     whole_7   50
    RHS_V     whole_10  50
    RHS_V     whole_13  50
    RHS_V     whole_16  50
    RHS_V     whole_19  50
    RHS_V     whole_22  50
    RHS_V     whole_25  50
    RHS_V     whole_28  50
    RHS_V     whole_31  50
    RHS_V     whole_34  50
    RHS_V     capital_1  277.66000000000003
    RHS_V     balance_1  -60
    RHS_V     balance_2  -60
    RHS_V     balance_3  -60
    RHS_V     balance_4  -60
    RHS_V     balance_5  -60
    RHS_V     balance_6  -60
    RHS_V     balance_7  -60
    RHS_V     balance_8  -60
    RHS_V     balance_9  -60
    RHS_V     balance_10  -60
    RHS_V     balance_11  -60
    RHS_V     balance_12  -60
    RHS_V     balance_13  -60
    RHS_V     balance_14  -60
    RHS_V     balance_15  -60
    RHS_V     balance_16  -60
    RHS_V     balance_17  -60
    RHS_V     balance_18  -60
    RHS_V     balance_19  -60
    RHS_V     balance_20  -60
    RHS_V     balance_21  -60
    RHS_V     balance_22  -60
    RHS_V     balance_23  -60
    RHS_V     balance_24  -60
    RHS_V     balance_25  -60
    RHS_V     balance_26  -60
    RHS_V     balance_27  -60
    RHS_V     balance_28  -60
    RHS_V     balance_29  -60
    RHS_V     balance_30  -60
    RHS_V     balance_31  -60
    RHS_V     balance_32  -60
    RHS_V     balance_33  -60
    RHS_V     balance_34  -60
    RHS_V     balance_35  -60
    RHS_V     balance_36  -60
    RHS_V     balance_37  -60
    RHS_V     balance_38  -60
    RHS_V     balance_39  -60
    RHS_V     balance_40  -60
    RHS_V     balance_41  -60
    RHS_V     balance_42  -60
    RHS_V     balance_43  -60
    RHS_V     balance_44  -60
    RHS_V     balance_45  -60
    RHS_V     balance_46  -60
    RHS_V     balance_47  -60
    RHS_V     balance_48  -60
    RHS_V     balance_49  -60
    RHS_V     balance_50  -60
    RHS_V     balance_51  -60
    RHS_V     balance_52  -60
    RHS_V     balance_53  -60
    RHS_V     balance_54  -60
    RHS_V     balance_55  -60
    RHS_V     balance_56  -60
    RHS_V     balance_57  -60
    RHS_V     balance_58  -60
    RHS_V     balance_59  -60
    RHS_V     balance_60  -60
    RHS_V     lf_1      1225.9311551566861
    RHS_V     lf_2      47.140688448433124
    RHS_V     lf_3      47.140688448433124
    RHS_V     lf_4      47.140688448433124
    RHS_V     lf_5      47.140688448433124
    RHS_V     lf_6      47.140688448433124
    RHS_V     lf_7      47.140688448433124
    RHS_V     lf_8      47.140688448433124
    RHS_V     lf_9      47.140688448433124
    RHS_V     lf_10     47.140688448433124
    RHS_V     lf_11     47.140688448433124
    RHS_V     lf_12     47.140688448433124
    RHS_V     lf_13     47.140688448433124
    RHS_V     lf_14     47.140688448433124
    RHS_V     lf_15     47.140688448433124
    RHS_V     lf_16     47.140688448433124
    RHS_V     lf_17     47.140688448433124
    RHS_V     lf_18     47.140688448433124
    RHS_V     lf_19     47.140688448433124
    RHS_V     lf_20     47.140688448433124
    RHS_V     lf_21     47.140688448433124
    RHS_V     lf_22     47.140688448433124
    RHS_V     lf_23     47.140688448433124
    RHS_V     lf_24     47.140688448433124
    RHS_V     lr_1      67.788177501555936
    RHS_V     lr_2      2.7239120157473162
    RHS_V     lr_3      2.7136641014855116
    RHS_V     lr_4      2.703416187223707
    RHS_V     lr_5      2.6931678015550178
    RHS_V     lr_6      2.6829198872932123
    RHS_V     lr_7      2.6726719730314077
    RHS_V     lr_8      2.6624240587696026
    RHS_V     lr_9      2.6521761445077976
    RHS_V     lr_10     2.6419282302459925
    RHS_V     lr_11     2.6316803159841879
    RHS_V     lr_12     2.6214324017223829
    RHS_V     lr_13     2.6111840160536937
    RHS_V     lr_14     2.6009361017918891
    RHS_V     lr_15     2.590688187530084
    RHS_V     lr_16     2.580440273268279
    RHS_V     lr_17     2.5701923590064744
    RHS_V     lr_18     2.5599444447446698
    RHS_V     lr_19     2.5496965304828647
    RHS_V     lr_20     2.5394486162210597
    RHS_V     lr_21     2.52920023055237
    RHS_V     lr_22     2.5189523162905654
    RHS_V     lr_23     2.5087044020287603
    RHS_V     lr_24     2.4984564877669553
    RHS_V     lm_1      2.4518623103133721
    RHS_V     lm_2      0.094281376896866262
    RHS_V     lm_3      0.094281376896866262
    RHS_V     lm_4      0.094281376896866262
    RHS_V     lm_5      0.094281376896866262
    RHS_V     lm_6      0.094281376896866262
    RHS_V     lm_7      0.094281376896866262
    RHS_V     lm_8      0.094281376896866262
    RHS_V     lm_9      0.094281376896866262
    RHS_V     lm_10     0.094281376896866262
    RHS_V     lm_11     0.094281376896866262
    RHS_V     lm_12     0.094281376896866262
    RHS_V     lm_13     0.094281376896866262
    RHS_V     lm_14     0.094281376896866262
    RHS_V     lm_15     0.094281376896866262
    RHS_V     lm_16     0.094281376896866262
    RHS_V     lm_17     0.094281376896866262
    RHS_V     lm_18     0.094281376896866262
    RHS_V     lm_19     0.094281376896866262
    RHS_V     lm_20     0.094281376896866262
    RHS_V     lm_21     0.094281376896866262
    RHS_V     lm_22     0.094281376896866262
    RHS_V     lm_23     0.094281376896866262
    RHS_V     lm_24     0.094281376896866262
    RHS_V     tr_1      31.724999999999998
    RHS_V     tr_2      2.91818175
    RHS_V     tr_3      2.9113635000000002
    RHS_V     tr_4      2.90454525
    RHS_V     tr_5      2.8977270000000002
    RHS_V     tr_6      2.8909087500000004
    RHS_V     tr_7      2.88409125
    RHS_V     tr_8      2.8772729999999997
    RHS_V     tr_9      2.8704547499999999
    RHS_V     tr_10     2.8636364999999997
    RHS_V     tr_11     2.8568182499999999
    RHS_V     tr_12     2.8500000000000001
    RHS_V     tm_1      2.4750000000000001
    RHS_V     tm_2      0.22500000000000001
    RHS_V     tm_3      0.22500000000000001
    RHS_V     tm_4      0.22500000000000001
    RHS_V     tm_5      0.22500000000000001
    RHS_V     tm_6      0.22500000000000001
    RHS_V     tm_7      0.22500000000000001
    RHS_V     tm_8      0.22500000000000001
    RHS_V     tm_9      0.22500000000000001
    RHS_V     tm_10     0.22500000000000001
    RHS_V     tm_11     0.22500000000000001
    RHS_V     tm_12     0.22500000000000001
    RHS_V     ii_1      19.316694420916981
    RHS_V     ie_1      12.0875
    RHS_V     imp_1     22.34
    RHS_V     pbt_1     4
    RHS_V     pbt_2     4.0066059999999997
    RHS_V     pbt_3     4.0132240000000001
    RHS_V     pbt_4     4.0198520000000002
    RHS_V     pbt_5     4.026491
    RHS_V     pbt_6     4.0331409999999996
    RHS_V     pbt_7     4.0398019999999999
    RHS_V     pbt_8     4.0464739999999999
    RHS_V     pbt_9     4.0531569999999997
    RHS_V     pbt_10    4.0598510000000001
    RHS_V     pbt_11    4.0665560000000003
    RHS_V     pbt_12    4.0732730000000004
    RHS_V     pbt_13    4.0800000000000001
    RHS_V     pbt_14    4.0867380000000004
    RHS_V     pbt_15    4.0934879999999998
    RHS_V     pbt_16    4.1002489999999998
    RHS_V     pbt_17    4.1070209999999996
    RHS_V     pbt_18    4.113804
    RHS_V     pbt_19    4.1205980000000002
    RHS_V     pbt_20    4.1274040000000003
    RHS_V     pbt_21    4.13422
    RHS_V     pbt_22    4.1410479999999996
    RHS_V     pbt_23    4.147888
    RHS_V     pbt_24    4.154738
    RHS_V     pbt_25    4.1616
    RHS_V     pbt_26    4.1684729999999997
    RHS_V     pbt_27    4.1753580000000001
    RHS_V     pbt_28    4.1822540000000004
    RHS_V     pbt_29    4.1891610000000004
    RHS_V     pbt_30    4.1960800000000003
    RHS_V     pbt_31    4.2030099999999999
    RHS_V     pbt_32    4.2099520000000004
    RHS_V     pbt_33    4.2169049999999997
    RHS_V     pbt_34    4.2238689999999997
    RHS_V     pbt_35    4.2308450000000004
    RHS_V     pbt_36    4.2378330000000002
    RHS_V     pbt_37    4.2448319999999997
    RHS_V     pbt_38    4.251843
    RHS_V     pbt_39    4.2588650000000001
    RHS_V     pbt_40    4.2658990000000001
    RHS_V     pbt_41    4.2729439999999999
    RHS_V     pbt_42    4.2800010000000004
    RHS_V     pbt_43    4.2870699999999999
    RHS_V     pbt_44    4.2941510000000003
    RHS_V     pbt_45    4.3012430000000004
    RHS_V     pbt_46    4.3083470000000004
    RHS_V     pbt_47    4.3154620000000001
    RHS_V     pbt_48    4.3225899999999999
    RHS_V     pbt_49    4.3297290000000004
    RHS_V     pbt_50    4.3368799999999998
    RHS_V     pbt_51    4.344042
    RHS_V     pbt_52    4.3512170000000001
    RHS_V     pbt_53    4.358403
    RHS_V     pbt_54    4.3656009999999998
    RHS_V     pbt_55    4.3728119999999997
    RHS_V     pbt_56    4.3800340000000002
    RHS_V     pbt_57    4.3872679999999997
    RHS_V     pbt_58    4.394514
    RHS_V     pbt_59    4.4017710000000001
    RHS_V     pbt_60    4.4090410000000002
    RHS_V     tl_1      -10
    RHS_V     bd_1      0.90000000000000002
    RHS_V     bb_1      0.66666666666666663
    RHS_V     spend_1   0.5
    RHS_V     rwa_1     250
    RHS_V     rwa_2     250
    RHS_V     rwa_3     250
    RHS_V     rwa_4     250
    RHS_V     rwa_5     250
    RHS_V     rwa_6     250
    RHS_V     rwa_7     250
    RHS_V     rwa_8     250
    RHS_V     rwa_9     250
    RHS_V     rwa_10    250
    RHS_V     rwa_11    250
    RHS_V     rwa_12    250
    RHS_V     rwa_13    250
    RHS_V     rwa_14    250
    RHS_V     rwa_15    250
    RHS_V     rwa_16    250
    RHS_V     rwa_17    250
    RHS_V     rwa_18    250
    RHS_V     rwa_19    250
    RHS_V     rwa_20    250
    RHS_V     rwa_21    250
    RHS_V     rwa_22    250
    RHS_V     rwa_23    250
    RHS_V     rwa_24    250
    RHS_V     rwa_25    250
    RHS_V     rwa_26    250
    RHS_V     rwa_27    250
    RHS_V     rwa_28    250
    RHS_V     rwa_29    250
    RHS_V     rwa_30    250
    RHS_V     rwa_31    250
    RHS_V     rwa_32    250
    RHS_V     rwa_33    250
    RHS_V     rwa_34    250
    RHS_V     rwa_35    250
    RHS_V     rwa_36    250
    RHS_V     rwa_37    250
    RHS_V     rwa_38    250
    RHS_V     rwa_39    250
    RHS_V     rwa_40    250
    RHS_V     rwa_41    250
    RHS_V     rwa_42    250
    RHS_V     rwa_43    250
    RHS_V     rwa_44    250
    RHS_V     rwa_45    250
    RHS_V     rwa_46    250
    RHS_V     rwa_47    250
    RHS_V     rwa_48    250
    RHS_V     rwa_49    250
    RHS_V     rwa_50    250
    RHS_V     rwa_51    250
    RHS_V     rwa_52    250
    RHS_V     rwa_53    250
    RHS_V     rwa_54    250
    RHS_V     rwa_55    250
    RHS_V     rwa_56    250
    RHS_V     rwa_57    250
    RHS_V     rwa_58    250
    RHS_V     rwa_59    250
    RHS_V     rwa_60    250
    RHS_V     out_1     -7.5
    RHS_V     out_2     -7.5
    RHS_V     out_3     -57.5
    RHS_V     out_4     -7.5
    RHS_V     out_5     -7.5
    RHS_V     out_6     -57.5
    RHS_V     out_7     -7.5
    RHS_V     out_8     -7.5
    RHS_V     out_9     -57.5
    RHS_V     out_10    -7.5
    RHS_V     out_11    -7.5
    RHS_V     out_12    -50
    RHS_V     out_15    -50
    RHS_V     out_18    -50
    RHS_V     out_21    -50
    RHS_V     out_24    -50
    RHS_V     out_27    -50
    RHS_V     out_30    -50
    RHS_V     out_33    -50
    RHS_V     asf_1     -450
    RHS_V     asf_2     -400
    RHS_V     asf_3     -400
    RHS_V     asf_4     -400
    RHS_V     asf_5     -350
    RHS_V     asf_6     -350
    RHS_V     asf_7     -350
    RHS_V     asf_8     -300
    RHS_V     asf_9     -300
    RHS_V     asf_10    -300
    RHS_V     asf_11    -250
    RHS_V     asf_12    -250
    RHS_V     asf_13    -250
    RHS_V     asf_14    -200
    RHS_V     asf_15    -200
    RHS_V     asf_16    -200
    RHS_V     asf_17    -150
    RHS_V     asf_18    -150
    RHS_V     asf_19    -150
    RHS_V     asf_20    -100
    RHS_V     asf_21    -100
    RHS_V     asf_22    -100
    RHS_V     asf_23    -50
    RHS_V     asf_24    -50
    RHS_V     asf_25    -50
    RHS_V     asf_26    -25
    RHS_V     asf_27    -25
    RHS_V     asf_28    -25
    RHS_V     rsf_1     -60
    RHS_V     rsf_2     -60
    RHS_V     rsf_3     -60
    RHS_V     rsf_4     -60
    RHS_V     rsf_5     -60
    RHS_V     rsf_6     -60
    RHS_V     rsf_7     -60
    RHS_V     rsf_8     -60
    RHS_V     rsf_9     -60
    RHS_V     rsf_10    -60
    RHS_V     rsf_11    -60
    RHS_V     rsf_12    -60
    RHS_V     rsf_13    -60
    RHS_V     rsf_14    -60
    RHS_V     rsf_15    -60
    RHS_V     rsf_16    -60
    RHS_V     rsf_17    -60
    RHS_V     rsf_18    -60
    RHS_V     rsf_19    -60
    RHS_V     rsf_20    -60
    RHS_V     rsf_21    -60
    RHS_V     rsf_22    -60
    RHS_V     rsf_23    -60
    RHS_V     rsf_24    -60
    RHS_V     rsf_25    -60
    RHS_V     rsf_26    -60
    RHS_V     rsf_27    -60
    RHS_V     rsf_28    -60
    RHS_V     rsf_29    -60
    RHS_V     rsf_30    -60
    RHS_V     rsf_31    -60
    RHS_V     rsf_32    -60
    RHS_V     rsf_33    -60
    RHS_V     rsf_34    -60
    RHS_V     rsf_35    -60
    RHS_V     rsf_36    -60
    RHS_V     rsf_37    -60
    RHS_V     rsf_38    -60
    RHS_V     rsf_39    -60
    RHS_V     rsf_40    -60
    RHS_V     rsf_41    -60
    RHS_V     rsf_42    -60
    RHS_V     rsf_43    -60
    RHS_V     rsf_44    -60
    RHS_V     rsf_45    -60
    RHS_V     rsf_46    -60
    RHS_V     rsf_47    -60
    RHS_V     rsf_48    -60
    RHS_V     rsf_49    -60
    RHS_V     rsf_50    -60
    RHS_V     rsf_51    -60
    RHS_V     rsf_52    -60
    RHS_V     rsf_53    -60
    RHS_V     rsf_54    -60
    RHS_V     rsf_55    -60
    RHS_V     rsf_56    -60
    RHS_V     rsf_57    -60
    RHS_V     rsf_58    -60
    RHS_V     rsf_59    -60
    RHS_V     rsf_60    -60
    RHS_V     lev_min_1  1.9500000000000002
    RHS_V     lev_min_2  1.9500000000000002
    RHS_V     lev_min_3  1.9500000000000002
    RHS_V     lev_min_4  1.9500000000000002
    RHS_V     lev_min_5  1.9500000000000002
    RHS_V     lev_min_6  1.9500000000000002
    RHS_V     lev_min_7  1.9500000000000002
    RHS_V     lev_min_8  1.9500000000000002
    RHS_V     lev_min_9  1.9500000000000002
    RHS_V     lev_min_10  1.9500000000000002
    RHS_V     lev_min_11  1.9500000000000002
    RHS_V     lev_min_12  1.9500000000000002
    RHS_V     lev_min_13  1.9500000000000002
    RHS_V     lev_min_14  1.9500000000000002
    RHS_V     lev_min_15  1.9500000000000002
    RHS_V     lev_min_16  1.9500000000000002
    RHS_V     lev_min_17  1.9500000000000002
    RHS_V     lev_min_18  1.9500000000000002
    RHS_V     lev_min_19  1.9500000000000002
    RHS_V     lev_min_20  1.9500000000000002
    RHS_V     lev_min_21  1.9500000000000002
    RHS_V     lev_min_22  1.9500000000000002
    RHS_V     lev_min_23  1.9500000000000002
    RHS_V     lev_min_24  1.9500000000000002
    RHS_V     lev_min_25  1.9500000000000002
    RHS_V     lev_min_26  1.9500000000000002
    RHS_V     lev_min_27  1.9500000000000002
    RHS_V     lev_min_28  1.9500000000000002
    RHS_V     lev_min_29  1.9500000000000002
    RHS_V     lev_min_30  1.9500000000000002
    RHS_V     lev_min_31  1.9500000000000002
    RHS_V     lev_min_32  1.9500000000000002
    RHS_V     lev_min_33  1.9500000000000002
    RHS_V     lev_min_34  1.9500000000000002
    RHS_V     lev_min_35  1.9500000000000002
    RHS_V     lev_min_36  1.9500000000000002
    RHS_V     lev_min_37  1.9500000000000002
    RHS_V     lev_min_38  1.9500000000000002
    RHS_V     lev_min_39  1.9500000000000002
    RHS_V     lev_min_40  1.9500000000000002
    RHS_V     lev_min_41  1.9500000000000002
    RHS_V     lev_min_42  1.9500000000000002
    RHS_V     lev_min_43  1.9500000000000002
    RHS_V     lev_min_44  1.9500000000000002
    RHS_V     lev_min_45  1.9500000000000002
    RHS_V     lev_min_46  1.9500000000000002
    RHS_V     lev_min_47  1.9500000000000002
    RHS_V     lev_min_48  1.9500000000000002
    RHS_V     lev_min_49  1.9500000000000002
    RHS_V     lev_min_50  1.9500000000000002
    RHS_V     lev_min_51  1.9500000000000002
    RHS_V     lev_min_52  1.9500000000000002
    RHS_V     lev_min_53  1.9500000000000002
    RHS_V     lev_min_54  1.9500000000000002
    RHS_V     lev_min_55  1.9500000000000002
    RHS_V     lev_min_56  1.9500000000000002
    RHS_V     lev_min_57  1.9500000000000002
    RHS_V     lev_min_58  1.9500000000000002
    RHS_V     lev_min_59  1.9500000000000002
    RHS_V     lev_min_60  1.9500000000000002
    RHS_V     lev_buf_1  2.25
    RHS_V     lev_buf_2  2.25
    RHS_V     lev_buf_3  2.25
    RHS_V     lev_buf_4  2.25
    RHS_V     lev_buf_5  2.25
    RHS_V     lev_buf_6  2.25
    RHS_V     lev_buf_7  2.25
    RHS_V     lev_buf_8  2.25
    RHS_V     lev_buf_9  2.25
    RHS_V     lev_buf_10  2.25
    RHS_V     lev_buf_11  2.25
    RHS_V     lev_buf_12  2.25
    RHS_V     lev_buf_13  2.25
    RHS_V     lev_buf_14  2.25
    RHS_V     lev_buf_15  2.25
    RHS_V     lev_buf_16  2.25
    RHS_V     lev_buf_17  2.25
    RHS_V     lev_buf_18  2.25
    RHS_V     lev_buf_19  2.25
    RHS_V     lev_buf_20  2.25
    RHS_V     lev_buf_21  2.25
    RHS_V     lev_buf_22  2.25
    RHS_V     lev_buf_23  2.25
    RHS_V     lev_buf_24  2.25
    RHS_V     lev_buf_25  2.25
    RHS_V     lev_buf_26  2.25
    RHS_V     lev_buf_27  2.25
    RHS_V     lev_buf_28  2.25
    RHS_V     lev_buf_29  2.25
    RHS_V     lev_buf_30  2.25
    RHS_V     lev_buf_31  2.25
    RHS_V     lev_buf_32  2.25
    RHS_V     lev_buf_33  2.25
    RHS_V     lev_buf_34  2.25
    RHS_V     lev_buf_35  2.25
    RHS_V     lev_buf_36  2.25
    RHS_V     lev_buf_37  2.25
    RHS_V     lev_buf_38  2.25
    RHS_V     lev_buf_39  2.25
    RHS_V     lev_buf_40  2.25
    RHS_V     lev_buf_41  2.25
    RHS_V     lev_buf_42  2.25
    RHS_V     lev_buf_43  2.25
    RHS_V     lev_buf_44  2.25
    RHS_V     lev_buf_45  2.25
    RHS_V     lev_buf_46  2.25
    RHS_V     lev_buf_47  2.25
    RHS_V     lev_buf_48  2.25
    RHS_V     lev_buf_49  2.25
    RHS_V     lev_buf_50  2.25
    RHS_V     lev_buf_51  2.25
    RHS_V     lev_buf_52  2.25
    RHS_V     lev_buf_53  2.25
    RHS_V     lev_buf_54  2.25
    RHS_V     lev_buf_55  2.25
    RHS_V     lev_buf_56  2.25
    RHS_V     lev_buf_57  2.25
    RHS_V     lev_buf_58  2.25
    RHS_V     lev_buf_59  2.25
    RHS_V     lev_buf_60  2.25
    RHS_V     end_loans  4000
BOUNDS
 LO BOUND     x_1       20
 UP BOUND     x_1       80
 LO BOUND     x_2       20
 UP BOUND     x_2       80
 LO BOUND     x_3       20
 UP BOUND     x_3       80
 LO BOUND     x_4       20
 UP BOUND     x_4       80
 LO BOUND     x_5       20
 UP BOUND     x_5       80
 LO BOUND     x_6       20
 UP BOUND     x_6       80
 LO BOUND     x_7       20
 UP BOUND     x_7       80
 LO BOUND     x_8       20
 UP BOUND     x_8       80
 LO BOUND     x_9       20
 UP BOUND     x_9       80
 LO BOUND     x_10      20
 UP BOUND     x_10      80
 LO BOUND     x_11      20
 UP BOUND     x_11      80
 LO BOUND     x_12      20
 UP BOUND     x_12      80
 LO BOUND     x_13      20
 UP BOUND     x_13      80
 LO BOUND     x_14      20
 UP BOUND     x_14      80
 LO BOUND     x_15      20
 UP BOUND     x_15      80
 LO BOUND     x_16      20
 UP BOUND     x_16      80
 LO BOUND     x_17      20
 UP BOUND     x_17      80
 LO BOUND     x_18      20
 UP BOUND     x_18      80
 LO BOUND     x_19      20
 UP BOUND     x_19      80
 LO BOUND     x_20      20
 UP BOUND     x_20      80
 LO BOUND     x_21      20
 UP BOUND     x_21      80
 LO BOUND     x_22      20
 UP BOUND     x_22      80
 LO BOUND     x_23      20
 UP BOUND     x_23      80
 LO BOUND     x_24      20
 UP BOUND     x_24      80
 LO BOUND     x_25      20
 UP BOUND     x_25      80
 LO BOUND     x_26      20
 UP BOUND     x_26      80
 LO BOUND     x_27      20
 UP BOUND     x_27      80
 LO BOUND     x_28      20
 UP BOUND     x_28      80
 LO BOUND     x_29      20
 UP BOUND     x_29      80
 LO BOUND     x_30      20
 UP BOUND     x_30      80
 LO BOUND     x_31      20
 UP BOUND     x_31      80
 LO BOUND     x_32      20
 UP BOUND     x_32      80
 LO BOUND     x_33      20
 UP BOUND     x_33      80
 LO BOUND     x_34      20
 UP BOUND     x_34      80
 LO BOUND     x_35      20
 UP BOUND     x_35      80
 LO BOUND     x_36      20
 UP BOUND     x_36      80
 LO BOUND     x_37      20
 UP BOUND     x_37      80
 LO BOUND     x_38      20
 UP BOUND     x_38      80
 LO BOUND     x_39      20
 UP BOUND     x_39      80
 LO BOUND     x_40      20
 UP BOUND     x_40      80
 LO BOUND     x_41      20
 UP BOUND     x_41      80
 LO BOUND     x_42      20
 UP BOUND     x_42      80
 LO BOUND     x_43      20
 UP BOUND     x_43      80
 LO BOUND     x_44      20
 UP BOUND     x_44      80
 LO BOUND     x_45      20
 UP BOUND     x_45      80
 LO BOUND     x_46      20
 UP BOUND     x_46      80
 LO BOUND     x_47      20
 UP BOUND     x_47      80
 LO BOUND     x_48      20
 UP BOUND     x_48      80
 LO BOUND     x_49      20
 UP BOUND     x_49      80
 LO BOUND     x_50      20
 UP BOUND     x_50      80
 LO BOUND     x_51      20
 UP BOUND     x_51      80
 LO BOUND     x_52      20
 UP BOUND     x_52      80
 LO BOUND     x_53      20
 UP BOUND     x_53      80
 LO BOUND     x_54      20
 UP BOUND     x_54      80
 LO BOUND     x_55      20
 UP BOUND     x_55      80
 LO BOUND     x_56      20
 UP BOUND     x_56      80
 LO BOUND     x_57      20
 UP BOUND     x_57      80
 LO BOUND     x_58      20
 UP BOUND     x_58      80
 LO BOUND     x_59      20
 UP BOUND     x_59      80
 LO BOUND     x_60      20
 UP BOUND     x_60      80
 LO BOUND     y_1       50
 UP BOUND     y_1       110
 LO BOUND     y_2       50
 UP BOUND     y_2       110
 LO BOUND     y_3       50
 UP BOUND     y_3       110
 LO BOUND     y_4       50
 UP BOUND     y_4       110
 LO BOUND     y_5       50
 UP BOUND     y_5       110
 LO BOUND     y_6       50
 UP BOUND     y_6       110
 LO BOUND     y_7       50
 UP BOUND     y_7       110
 LO BOUND     y_8       50
 UP BOUND     y_8       110
 LO BOUND     y_9       50
 UP BOUND     y_9       110
 LO BOUND     y_10      50
 UP BOUND     y_10      110
 LO BOUND     y_11      50
 UP BOUND     y_11      110
 LO BOUND     y_12      50
 UP BOUND     y_12      110
 LO BOUND     y_13      50
 UP BOUND     y_13      110
 LO BOUND     y_14      50
 UP BOUND     y_14      110
 LO BOUND     y_15      50
 UP BOUND     y_15      110
 LO BOUND     y_16      50
 UP BOUND     y_16      110
 LO BOUND     y_17      50
 UP BOUND     y_17      110
 LO BOUND     y_18      50
 UP BOUND     y_18      110
 LO BOUND     y_19      50
 UP BOUND     y_19      110
 LO BOUND     y_20      50
 UP BOUND     y_20      110
 LO BOUND     y_21      50
 UP BOUND     y_21      110
 LO BOUND     y_22      50
 UP BOUND     y_22      110
 LO BOUND     y_23      50
 UP BOUND     y_23      110
 LO BOUND     y_24      50
 UP BOUND     y_24      110
 LO BOUND     y_25      50
 UP BOUND     y_25      110
 LO BOUND     y_26      50
 UP BOUND     y_26      110
 LO BOUND     y_27      50
 UP BOUND     y_27      110
 LO BOUND     y_28      50
 UP BOUND     y_28      110
 LO BOUND     y_29      50
 UP BOUND     y_29      110
 LO BOUND     y_30      50
 UP BOUND     y_30      110
 LO BOUND     y_31      50
 UP BOUND     y_31      110
 LO BOUND     y_32      50
 UP BOUND     y_32      110
 LO BOUND     y_33      50
 UP BOUND     y_33      110
 LO BOUND     y_34      50
 UP BOUND     y_34      110
 LO BOUND     y_35      50
 UP BOUND     y_35      110
 LO BOUND     y_36      50
 UP BOUND     y_36      110
 LO BOUND     y_37      50
 UP BOUND     y_37      110
 LO BOUND     y_38      50
 UP BOUND     y_38      110
 LO BOUND     y_39      50
 UP BOUND     y_39      110
 LO BOUND     y_40      50
 UP BOUND     y_40      110
 LO BOUND     y_41      50
 UP BOUND     y_41      110
 LO BOUND     y_42      50
 UP BOUND     y_42      110
 LO BOUND     y_43      50
 UP BOUND     y_43      110
 LO BOUND     y_44      50
 UP BOUND     y_44      110
 LO BOUND     y_45      50
 UP BOUND     y_45      110
 LO BOUND     y_46      50
 UP BOUND     y_46      110
 LO BOUND     y_47      50
 UP BOUND     y_47      110
 LO BOUND     y_48      50
 UP BOUND     y_48      110
 LO BOUND     y_49      50
 UP BOUND     y_49      110
 LO BOUND     y_50      50
 UP BOUND     y_50      110
 LO BOUND     y_51      50
 UP BOUND     y_51      110
 LO BOUND     y_52      50
 UP BOUND     y_52      110
 LO BOUND     y_53      50
 UP BOUND     y_53      110
 LO BOUND     y_54      50
 UP BOUND     y_54      110
 LO BOUND     y_55      50
 UP BOUND     y_55      110
 LO BOUND     y_56      50
 UP BOUND     y_56      110
 LO BOUND     y_57      50
 UP BOUND     y_57      110
 LO BOUND     y_58      50
 UP BOUND     y_58      110
 LO BOUND     y_59      50
 UP BOUND     y_59      110
 LO BOUND     y_60      50
 UP BOUND     y_60      110
 LO BOUND     S_1       1700
 UP BOUND     S_1       2100
 LO BOUND     S_2       1700
 UP BOUND     S_2       2100
 LO BOUND     S_3       1700
 UP BOUND     S_3       2100
 LO BOUND     S_4       1700
 UP BOUND     S_4       2100
 LO BOUND     S_5       1700
 UP BOUND     S_5       2100
 LO BOUND     S_6       1700
 UP BOUND     S_6       2100
 LO BOUND     S_7       1700
 UP BOUND     S_7       2100
 LO BOUND     S_8       1700
 UP BOUND     S_8       2100
 LO BOUND     S_9       1700
 UP BOUND     S_9       2100
 LO BOUND     S_10      1700
 UP BOUND     S_10      2100
 LO BOUND     S_11      1700
 UP BOUND     S_11      2100
 LO BOUND     S_12      1700
 UP BOUND     S_12      2100
 LO BOUND     S_13      1700
 UP BOUND     S_13      2100
 LO BOUND     S_14      1700
 UP BOUND     S_14      2100
 LO BOUND     S_15      1700
 UP BOUND     S_15      2100
 LO BOUND     S_16      1700
 UP BOUND     S_16      2100
 LO BOUND     S_17      1700
 UP BOUND     S_17      2100
 LO BOUND     S_18      1700
 UP BOUND     S_18      2100
 LO BOUND     S_19      1700
 UP BOUND     S_19      2100
 LO BOUND     S_20      1700
 UP BOUND     S_20      2100
 LO BOUND     S_21      1700
 UP BOUND     S_21      2100
 LO BOUND     S_22      1700
 UP BOUND     S_22      2100
 LO BOUND     S_23      1700
 UP BOUND     S_23      2100
 LO BOUND     S_24      1700
 UP BOUND     S_24      2100
 LO BOUND     S_25      1700
 UP BOUND     S_25      2100
 LO BOUND     S_26      1700
 UP BOUND     S_26      2100
 LO BOUND     S_27      1700
 UP BOUND     S_27      2100
 LO BOUND     S_28      1700
 UP BOUND     S_28      2100
 LO BOUND     S_29      1700
 UP BOUND     S_29      2100
 LO BOUND     S_30      1700
 UP BOUND     S_30      2100
 LO BOUND     S_31      1700
 UP BOUND     S_31      2100
 LO BOUND     S_32      1700
 UP BOUND     S_32      2100
 LO BOUND     S_33      1700
 UP BOUND     S_33      2100
 LO BOUND     S_34      1700
 UP BOUND     S_34      2100
 LO BOUND     S_35      1700
 UP BOUND     S_35      2100
 LO BOUND     S_36      1700
 UP BOUND     S_36      2100
 LO BOUND     S_37      1700
 UP BOUND     S_37      2100
 LO BOUND     S_38      1700
 UP BOUND     S_38      2100
 LO BOUND     S_39      1700
 UP BOUND     S_39      2100
 LO BOUND     S_40      1700
 UP BOUND     S_40      2100
 LO BOUND     S_41      1700
 UP BOUND     S_41      2100
 LO BOUND     S_42      1700
 UP BOUND     S_42      2100
 LO BOUND     S_43      1700
 UP BOUND     S_43      2100
 LO BOUND     S_44      1700
 UP BOUND     S_44      2100
 LO BOUND     S_45      1700
 UP BOUND     S_45      2100
 LO BOUND     S_46      1700
 UP BOUND     S_46      2100
 LO BOUND     S_47      1700
 UP BOUND     S_47      2100
 LO BOUND     S_48      1700
 UP BOUND     S_48      2100
 LO BOUND     S_49      1700
 UP BOUND     S_49      2100
 LO BOUND     S_50      1700
 UP BOUND     S_50      2100
 LO BOUND     S_51      1700
 UP BOUND     S_51      2100
 LO BOUND     S_52      1700
 UP BOUND     S_52      2100
 LO BOUND     S_53      1700
 UP BOUND     S_53      2100
 LO BOUND     S_54      1700
 UP BOUND     S_54      2100
 LO BOUND     S_55      1700
 UP BOUND     S_55      2100
 LO BOUND     S_56      1700
 UP BOUND     S_56      2100
 LO BOUND     S_57      1700
 UP BOUND     S_57      2100
 LO BOUND     S_58      1700
 UP BOUND     S_58      2100
 LO BOUND     S_59      1700
 UP BOUND     S_59      2100
 LO BOUND     S_60      1700
 UP BOUND     S_60      2100
 LO BOUND     U_1       850
 UP BOUND     U_1       1050
 LO BOUND     U_2       850
 UP BOUND     U_2       1050
 LO BOUND     U_3       850
 UP BOUND     U_3       1050
 LO BOUND     U_4       850
 UP BOUND     U_4       1050
 LO BOUND     U_5       850
 UP BOUND     U_5       1050
 LO BOUND     U_6       850
 UP BOUND     U_6       1050
 LO BOUND     U_7       850
 UP BOUND     U_7       1050
 LO BOUND     U_8       850
 UP BOUND     U_8       1050
 LO BOUND     U_9       850
 UP BOUND     U_9       1050
 LO BOUND     U_10      850
 UP BOUND     U_10      1050
 LO BOUND     U_11      850
 UP BOUND     U_11      1050
 LO BOUND     U_12      850
 UP BOUND     U_12      1050
 LO BOUND     U_13      850
 UP BOUND     U_13      1050
 LO BOUND     U_14      850
 UP BOUND     U_14      1050
 LO BOUND     U_15      850
 UP BOUND     U_15      1050
 LO BOUND     U_16      850
 UP BOUND     U_16      1050
 LO BOUND     U_17      850
 UP BOUND     U_17      1050
 LO BOUND     U_18      850
 UP BOUND     U_18      1050
 LO BOUND     U_19      850
 UP BOUND     U_19      1050
 LO BOUND     U_20      850
 UP BOUND     U_20      1050
 LO BOUND     U_21      850
 UP BOUND     U_21      1050
 LO BOUND     U_22      850
 UP BOUND     U_22      1050
 LO BOUND     U_23      850
 UP BOUND     U_23      1050
 LO BOUND     U_24      850
 UP BOUND     U_24      1050
 LO BOUND     U_25      850
 UP BOUND     U_25      1050
 LO BOUND     U_26      850
 UP BOUND     U_26      1050
 LO BOUND     U_27      850
 UP BOUND     U_27      1050
 LO BOUND     U_28      850
 UP BOUND     U_28      1050
 LO BOUND     U_29      850
 UP BOUND     U_29      1050
 LO BOUND     U_30      850
 UP BOUND     U_30      1050
 LO BOUND     U_31      850
 UP BOUND     U_31      1050
 LO BOUND     U_32      850
 UP BOUND     U_32      1050
 LO BOUND     U_33      850
 UP BOUND     U_33      1050
 LO BOUND     U_34      850
 UP BOUND     U_34      1050
 LO BOUND     U_35      850
 UP BOUND     U_35      1050
 LO BOUND     U_36      850
 UP BOUND     U_36      1050
 LO BOUND     U_37      850
 UP BOUND     U_37      1050
 LO BOUND     U_38      850
 UP BOUND     U_38      1050
 LO BOUND     U_39      850
 UP BOUND     U_39      1050
 LO BOUND     U_40      850
 UP BOUND     U_40      1050
 LO BOUND     U_41      850
 UP BOUND     U_41      1050
 LO BOUND     U_42      850
 UP BOUND     U_42      1050
 LO BOUND     U_43      850
 UP BOUND     U_43      1050
 LO BOUND     U_44      850
 UP BOUND     U_44      1050
 LO BOUND     U_45      850
 UP BOUND     U_45      1050
 LO BOUND     U_46      850
 UP BOUND     U_46      1050
 LO BOUND     U_47      850
 UP BOUND     U_47      1050
 LO BOUND     U_48      850
 UP BOUND     U_48      1050
 LO BOUND     U_49      850
 UP BOUND     U_49      1050
 LO BOUND     U_50      850
 UP BOUND     U_50      1050
 LO BOUND     U_51      850
 UP BOUND     U_51      1050
 LO BOUND     U_52      850
 UP BOUND     U_52      1050
 LO BOUND     U_53      850
 UP BOUND     U_53      1050
 LO BOUND     U_54      850
 UP BOUND     U_54      1050
 LO BOUND     U_55      850
 UP BOUND     U_55      1050
 LO BOUND     U_56      850
 UP BOUND     U_56      1050
 LO BOUND     U_57      850
 UP BOUND     U_57      1050
 LO BOUND     U_58      850
 UP BOUND     U_58      1050
 LO BOUND     U_59      850
 UP BOUND     U_59      1050
 LO BOUND     U_60      850
 UP BOUND     U_60      1050
 FR BOUND     L_1     
 FR BOUND     L_2     
 FR BOUND     L_3     
 FR BOUND     L_4     
 FR BOUND     L_5     
 FR BOUND     L_6     
 FR BOUND     L_7     
 FR BOUND     L_8     
 FR BOUND     L_9     
 FR BOUND     L_10    
 FR BOUND     L_11    
 FR BOUND     L_12    
 FR BOUND     L_13    
 FR BOUND     L_14    
 FR BOUND     L_15    
 FR BOUND     L_16    
 FR BOUND     L_17    
 FR BOUND     L_18    
 FR BOUND     L_19    
 FR BOUND     L_20    
 FR BOUND     L_21    
 FR BOUND     L_22    
 FR BOUND     L_23    
 FR BOUND     L_24    
 FR BOUND     L_25    
 FR BOUND     L_26    
 FR BOUND     L_27    
 FR BOUND     L_28    
 FR BOUND     L_29    
 FR BOUND     L_30    
 FR BOUND     L_31    
 FR BOUND     L_32    
 FR BOUND     L_33    
 FR BOUND     L_34    
 FR BOUND     L_35    
 FR BOUND     L_36    
 FR BOUND     L_37    
 FR BOUND     L_38    
 FR BOUND     L_39    
 FR BOUND     L_40    
 FR BOUND     L_41    
 FR BOUND     L_42    
 FR BOUND     L_43    
 FR BOUND     L_44    
 FR BOUND     L_45    
 FR BOUND     L_46    
 FR BOUND     L_47    
 FR BOUND     L_48    
 FR BOUND     L_49    
 FR BOUND     L_50    
 FR BOUND     L_51    
 FR BOUND     L_52    
 FR BOUND     L_53    
 FR BOUND     L_54    
 FR BOUND     L_55    
 FR BOUND     L_56    
 FR BOUND     L_57    
 FR BOUND     L_58    
 FR BOUND     L_59    
 FR BOUND     L_60    
 FR BOUND     T_1     
 FR BOUND     T_2     
 FR BOUND     T_3     
 FR BOUND     T_4     
 FR BOUND     T_5     
 FR BOUND     T_6     
 FR BOUND     T_7     
 FR BOUND     T_8     
 FR BOUND     T_9     
 FR BOUND     T_10    
 FR BOUND     T_11    
 FR BOUND     T_12    
 FR BOUND     T_13    
 FR BOUND     T_14    
 FR BOUND     T_15    
 FR BOUND     T_16    
 FR BOUND     T_17    
 FR BOUND     T_18    
 FR BOUND     T_19    
 FR BOUND     T_20    
 FR BOUND     T_21    
 FR BOUND     T_22    
 FR BOUND     T_23    
 FR BOUND     T_24    
 FR BOUND     T_25    
 FR BOUND     T_26    
 FR BOUND     T_27    
 FR BOUND     T_28    
 FR BOUND     T_29    
 FR BOUND     T_30    
 FR BOUND     T_31    
 FR BOUND     T_32    
 FR BOUND     T_33    
 FR BOUND     T_34    
 FR BOUND     T_35    
 FR BOUND     T_36    
 FR BOUND     T_37    
 FR BOUND     T_38    
 FR BOUND     T_39    
 FR BOUND     T_40    
 FR BOUND     T_41    
 FR BOUND     T_42    
 FR BOUND     T_43    
 FR BOUND     T_44    
 FR BOUND     T_45    
 FR BOUND     T_46    
 FR BOUND     T_47    
 FR BOUND     T_48    
 FR BOUND     T_49    
 FR BOUND     T_50    
 FR BOUND     T_51    
 FR BOUND     T_52    
 FR BOUND     T_53    
 FR BOUND     T_54    
 FR BOUND     T_55    
 FR BOUND     T_56    
 FR BOUND     T_57    
 FR BOUND     T_58    
 FR BOUND     T_59    
 FR BOUND     T_60    
 FR BOUND     W_1     
 FR BOUND     W_2     
 FR BOUND     W_3     
 FR BOUND     W_4     
 FR BOUND     W_5     
 FR BOUND     W_6     
 FR BOUND     W_7     
 FR BOUND     W_8     
 FR BOUND     W_9     
 FR BOUND     W_10    
 FR BOUND     W_11    
 FR BOUND     W_12    
 FR BOUND     W_13    
 FR BOUND     W_14    
 FR BOUND     W_15    
 FR BOUND     W_16    
 FR BOUND     W_17    
 FR BOUND     W_18    
 FR BOUND     W_19    
 FR BOUND     W_20    
 FR BOUND     W_21    
 FR BOUND     W_22    
 FR BOUND     W_23    
 FR BOUND     W_24    
 FR BOUND     W_25    
 FR BOUND     W_26    
 FR BOUND     W_27    
 FR BOUND     W_28    
 FR BOUND     W_29    
 FR BOUND     W_30    
 FR BOUND     W_31    
 FR BOUND     W_32    
 FR BOUND     W_33    
 FR BOUND     W_34    
 FR BOUND     W_35    
 FR BOUND     W_36    
 FR BOUND     W_37    
 FR BOUND     W_38    
 FR BOUND     W_39    
 FR BOUND     W_40    
 FR BOUND     W_41    
 FR BOUND     W_42    
 FR BOUND     W_43    
 FR BOUND     W_44    
 FR BOUND     W_45    
 FR BOUND     W_46    
 FR BOUND     W_47    
 FR BOUND     W_48    
 FR BOUND     W_49    
 FR BOUND     W_50    
 FR BOUND     W_51    
 FR BOUND     W_52    
 FR BOUND     W_53    
 FR BOUND     W_54    
 FR BOUND     W_55    
 FR BOUND     W_56    
 FR BOUND     W_57    
 FR BOUND     W_58    
 FR BOUND     W_59    
 FR BOUND     W_60    
 FR BOUND     K_1     
 FR BOUND     K_2     
 FR BOUND     K_3     
 FR BOUND     K_4     
 FR BOUND     K_5     
 FR BOUND     K_6     
 FR BOUND     K_7     
 FR BOUND     K_8     
 FR BOUND     K_9     
 FR BOUND     K_10    
 FR BOUND     K_11    
 FR BOUND     K_12    
 FR BOUND     K_13    
 FR BOUND     K_14    
 FR BOUND     K_15    
 FR BOUND     K_16    
 FR BOUND     K_17    
 FR BOUND     K_18    
 FR BOUND     K_19    
 FR BOUND     K_20    
 FR BOUND     K_21    
 FR BOUND     K_22    
 FR BOUND     K_23    
 FR BOUND     K_24    
 FR BOUND     K_25    
 FR BOUND     K_26    
 FR BOUND     K_27    
 FR BOUND     K_28    
 FR BOUND     K_29    
 FR BOUND     K_30    
 FR BOUND     K_31    
 FR BOUND     K_32    
 FR BOUND     K_33    
 FR BOUND     K_34    
 FR BOUND     K_35    
 FR BOUND     K_36    
 FR BOUND     K_37    
 FR BOUND     K_38    
 FR BOUND     K_39    
 FR BOUND     K_40    
 FR BOUND     K_41    
 FR BOUND     K_42    
 FR BOUND     K_43    
 FR BOUND     K_44    
 FR BOUND     K_45    
 FR BOUND     K_46    
 FR BOUND     K_47    
 FR BOUND     K_48    
 FR BOUND     K_49    
 FR BOUND     K_50    
 FR BOUND     K_51    
 FR BOUND     K_52    
 FR BOUND     K_53    
 FR BOUND     K_54    
 FR BOUND     K_55    
 FR BOUND     K_56    
 FR BOUND     K_57    
 FR BOUND     K_58    
 FR BOUND     K_59    
 FR BOUND     K_60    
 FR BOUND     MD_1    
 FR BOUND     MD_2    
 FR BOUND     MD_3    
 FR BOUND     MD_4    
 FR BOUND     MD_5    
 FR BOUND     MD_6    
 FR BOUND     MD_7    
 FR BOUND     MD_8    
 FR BOUND     MD_9    
 FR BOUND     MD_10   
 FR BOUND     MD_11   
 FR BOUND     MD_12   
 FR BOUND     MD_13   
 FR BOUND     MD_14   
 FR BOUND     MD_15   
 FR BOUND     MD_16   
 FR BOUND     MD_17   
 FR BOUND     MD_18   
 FR BOUND     MD_19   
 FR BOUND     MD_20   
 FR BOUND     MD_21   
 FR BOUND     MD_22   
 FR BOUND     MD_23   
 FR BOUND     MD_24   
 FR BOUND     MD_25   
 FR BOUND     MD_26   
 FR BOUND     MD_27   
 FR BOUND     MD_28   
 FR BOUND     MD_29   
 FR BOUND     MD_30   
 FR BOUND     MD_31   
 FR BOUND     MD_32   
 FR BOUND     MD_33   
 FR BOUND     MD_34   
 FR BOUND     MD_35   
 FR BOUND     MD_36   
 FR BOUND     MD_37   
 FR BOUND     MD_38   
 FR BOUND     MD_39   
 FR BOUND     MD_40   
 FR BOUND     MD_41   
 FR BOUND     MD_42   
 FR BOUND     MD_43   
 FR BOUND     MD_44   
 FR BOUND     MD_45   
 FR BOUND     MD_46   
 FR BOUND     MD_47   
 FR BOUND     MD_48   
 FR BOUND     MD_49   
 FR BOUND     MD_50   
 FR BOUND     MD_51   
 FR BOUND     MD_52   
 FR BOUND     MD_53   
 FR BOUND     MD_54   
 FR BOUND     MD_55   
 FR BOUND     MD_56   
 FR BOUND     MD_57   
 FR BOUND     MD_58   
 FR BOUND     MD_59   
 FR BOUND     MD_60   
 FR BOUND     MB_1    
 FR BOUND     MB_2    
 FR BOUND     MB_3    
 FR BOUND     MB_4    
 FR BOUND     MB_5    
 FR BOUND     MB_6    
 FR BOUND     MB_7    
 FR BOUND     MB_8    
 FR BOUND     MB_9    
 FR BOUND     MB_10   
 FR BOUND     MB_11   
 FR BOUND     MB_12   
 FR BOUND     MB_13   
 FR BOUND     MB_14   
 FR BOUND     MB_15   
 FR BOUND     MB_16   
 FR BOUND     MB_17   
 FR BOUND     MB_18   
 FR BOUND     MB_19   
 FR BOUND     MB_20   
 FR BOUND     MB_21   
 FR BOUND     MB_22   
 FR BOUND     MB_23   
 FR BOUND     MB_24   
 FR BOUND     MB_25   
 FR BOUND     MB_26   
 FR BOUND     MB_27   
 FR BOUND     MB_28   
 FR BOUND     MB_29   
 FR BOUND     MB_30   
 FR BOUND     MB_31   
 FR BOUND     MB_32   
 FR BOUND     MB_33   
 FR BOUND     MB_34   
 FR BOUND     MB_35   
 FR BOUND     MB_36   
 FR BOUND     MB_37   
 FR BOUND     MB_38   
 FR BOUND     MB_39   
 FR BOUND     MB_40   
 FR BOUND     MB_41   
 FR BOUND     MB_42   
 FR BOUND     MB_43   
 FR BOUND     MB_44   
 FR BOUND     MB_45   
 FR BOUND     MB_46   
 FR BOUND     MB_47   
 FR BOUND     MB_48   
 FR BOUND     MB_49   
 FR BOUND     MB_50   
 FR BOUND     MB_51   
 FR BOUND     MB_52   
 FR BOUND     MB_53   
 FR BOUND     MB_54   
 FR BOUND     MB_55   
 FR BOUND     MB_56   
 FR BOUND     MB_57   
 FR BOUND     MB_58   
 FR BOUND     MB_59   
 FR BOUND     MB_60   
 FR BOUND     BD_1    
 FR BOUND     BD_2    
 FR BOUND     BD_3    
 FR BOUND     BD_4    
 FR BOUND     BD_5    
 FR BOUND     BD_6    
 FR BOUND     BD_7    
 FR BOUND     BD_8    
 FR BOUND     BD_9    
 FR BOUND     BD_10   
 FR BOUND     BD_11   
 FR BOUND     BD_12   
 FR BOUND     BD_13   
 FR BOUND     BD_14   
 FR BOUND     BD_15   
 FR BOUND     BD_16   
 FR BOUND     BD_17   
 FR BOUND     BD_18   
 FR BOUND     BD_19   
 FR BOUND     BD_20   
 FR BOUND     BD_21   
 FR BOUND     BD_22   
 FR BOUND     BD_23   
 FR BOUND     BD_24   
 FR BOUND     BD_25   
 FR BOUND     BD_26   
 FR BOUND     BD_27   
 FR BOUND     BD_28   
 FR BOUND     BD_29   
 FR BOUND     BD_30   
 FR BOUND     BD_31   
 FR BOUND     BD_32   
 FR BOUND     BD_33   
 FR BOUND     BD_34   
 FR BOUND     BD_35   
 FR BOUND     BD_36   
 FR BOUND     BD_37   
 FR BOUND     BD_38   
 FR BOUND     BD_39   
 FR BOUND     BD_40   
 FR BOUND     BD_41   
 FR BOUND     BD_42   
 FR BOUND     BD_43   
 FR BOUND     BD_44   
 FR BOUND     BD_45   
 FR BOUND     BD_46   
 FR BOUND     BD_47   
 FR BOUND     BD_48   
 FR BOUND     BD_49   
 FR BOUND     BD_50   
 FR BOUND     BD_51   
 FR BOUND     BD_52   
 FR BOUND     BD_53   
 FR BOUND     BD_54   
 FR BOUND     BD_55   
 FR BOUND     BD_56   
 FR BOUND     BD_57   
 FR BOUND     BD_58   
 FR BOUND     BD_59   
 FR BOUND     BD_60   
 FR BOUND     BB_1    
 FR BOUND     BB_2    
 FR BOUND     BB_3    
 FR BOUND     BB_4    
 FR BOUND     BB_5    
 FR BOUND     BB_6    
 FR BOUND     BB_7    
 FR BOUND     BB_8    
 FR BOUND     BB_9    
 FR BOUND     BB_10   
 FR BOUND     BB_11   
 FR BOUND     BB_12   
 FR BOUND     BB_13   
 FR BOUND     BB_14   
 FR BOUND     BB_15   
 FR BOUND     BB_16   
 FR BOUND     BB_17   
 FR BOUND     BB_18   
 FR BOUND     BB_19   
 FR BOUND     BB_20   
 FR BOUND     BB_21   
 FR BOUND     BB_22   
 FR BOUND     BB_23   
 FR BOUND     BB_24   
 FR BOUND     BB_25   
 FR BOUND     BB_26   
 FR BOUND     BB_27   
 FR BOUND     BB_28   
 FR BOUND     BB_29   
 FR BOUND     BB_30   
 FR BOUND     BB_31   
 FR BOUND     BB_32   
 FR BOUND     BB_33   
 FR BOUND     BB_34   
 FR BOUND     BB_35   
 FR BOUND     BB_36   
 FR BOUND     BB_37   
 FR BOUND     BB_38   
 FR BOUND     BB_39   
 FR BOUND     BB_40   
 FR BOUND     BB_41   
 FR BOUND     BB_42   
 FR BOUND     BB_43   
 FR BOUND     BB_44   
 FR BOUND     BB_45   
 FR BOUND     BB_46   
 FR BOUND     BB_47   
 FR BOUND     BB_48   
 FR BOUND     BB_49   
 FR BOUND     BB_50   
 FR BOUND     BB_51   
 FR BOUND     BB_52   
 FR BOUND     BB_53   
 FR BOUND     BB_54   
 FR BOUND     BB_55   
 FR BOUND     BB_56   
 FR BOUND     BB_57   
 FR BOUND     BB_58   
 FR BOUND     BB_59   
 FR BOUND     BB_60   
 FR BOUND     II_1    
 FR BOUND     II_2    
 FR BOUND     II_3    
 FR BOUND     II_4    
 FR BOUND     II_5    
 FR BOUND     II_6    
 FR BOUND     II_7    
 FR BOUND     II_8    
 FR BOUND     II_9    
 FR BOUND     II_10   
 FR BOUND     II_11   
 FR BOUND     II_12   
 FR BOUND     II_13   
 FR BOUND     II_14   
 FR BOUND     II_15   
 FR BOUND     II_16   
 FR BOUND     II_17   
 FR BOUND     II_18   
 FR BOUND     II_19   
 FR BOUND     II_20   
 FR BOUND     II_21   
 FR BOUND     II_22   
 FR BOUND     II_23   
 FR BOUND     II_24   
 FR BOUND     II_25   
 FR BOUND     II_26   
 FR BOUND     II_27   
 FR BOUND     II_28   
 FR BOUND     II_29   
 FR BOUND     II_30   
 FR BOUND     II_31   
 FR BOUND     II_32   
 FR BOUND     II_33   
 FR BOUND     II_34   
 FR BOUND     II_35   
 FR BOUND     II_36   
 FR BOUND     II_37   
 FR BOUND     II_38   
 FR BOUND     II_39   
 FR BOUND     II_40   
 FR BOUND     II_41   
 FR BOUND     II_42   
 FR BOUND     II_43   
 FR BOUND     II_44   
 FR BOUND     II_45   
 FR BOUND     II_46   
 FR BOUND     II_47   
 FR BOUND     II_48   
 FR BOUND     II_49   
 FR BOUND     II_50   
 FR BOUND     II_51   
 FR BOUND     II_52   
 FR BOUND     II_53   
 FR BOUND     II_54   
 FR BOUND     II_55   
 FR BOUND     II_56   
 FR BOUND     II_57   
 FR BOUND     II_58   
 FR BOUND     II_59   
 FR BOUND     II_60   
 FR BOUND     IE_1    
 FR BOUND     IE_2    
 FR BOUND     IE_3    
 FR BOUND     IE_4    
 FR BOUND     IE_5    
 FR BOUND     IE_6    
 FR BOUND     IE_7    
 FR BOUND     IE_8    
 FR BOUND     IE_9    
 FR BOUND     IE_10   
 FR BOUND     IE_11   
 FR BOUND     IE_12   
 FR BOUND     IE_13   
 FR BOUND     IE_14   
 FR BOUND     IE_15   
 FR BOUND     IE_16   
 FR BOUND     IE_17   
 FR BOUND     IE_18   
 FR BOUND     IE_19   
 FR BOUND     IE_20   
 FR BOUND     IE_21   
 FR BOUND     IE_22   
 FR BOUND     IE_23   
 FR BOUND     IE_24   
 FR BOUND     IE_25   
 FR BOUND     IE_26   
 FR BOUND     IE_27   
 FR BOUND     IE_28   
 FR BOUND     IE_29   
 FR BOUND     IE_30   
 FR BOUND     IE_31   
 FR BOUND     IE_32   
 FR BOUND     IE_33   
 FR BOUND     IE_34   
 FR BOUND     IE_35   
 FR BOUND     IE_36   
 FR BOUND     IE_37   
 FR BOUND     IE_38   
 FR BOUND     IE_39   
 FR BOUND     IE_40   
 FR BOUND     IE_41   
 FR BOUND     IE_42   
 FR BOUND     IE_43   
 FR BOUND     IE_44   
 FR BOUND     IE_45   
 FR BOUND     IE_46   
 FR BOUND     IE_47   
 FR BOUND     IE_48   
 FR BOUND     IE_49   
 FR BOUND     IE_50   
 FR BOUND     IE_51   
 FR BOUND     IE_52   
 FR BOUND     IE_53   
 FR BOUND     IE_54   
 FR BOUND     IE_55   
 FR BOUND     IE_56   
 FR BOUND     IE_57   
 FR BOUND     IE_58   
 FR BOUND     IE_59   
 FR BOUND     IE_60   
 FR BOUND     IMP_1   
 FR BOUND     IMP_2   
 FR BOUND     IMP_3   
 FR BOUND     IMP_4   
 FR BOUND     IMP_5   
 FR BOUND     IMP_6   
 FR BOUND     IMP_7   
 FR BOUND     IMP_8   
 FR BOUND     IMP_9   
 FR BOUND     IMP_10  
 FR BOUND     IMP_11  
 FR BOUND     IMP_12  
 FR BOUND     IMP_13  
 FR BOUND     IMP_14  
 FR BOUND     IMP_15  
 FR BOUND     IMP_16  
 FR BOUND     IMP_17  
 FR BOUND     IMP_18  
 FR BOUND     IMP_19  
 FR BOUND     IMP_20  
 FR BOUND     IMP_21  
 FR BOUND     IMP_22  
 FR BOUND     IMP_23  
 FR BOUND     IMP_24  
 FR BOUND     IMP_25  
 FR BOUND     IMP_26  
 FR BOUND     IMP_27  
 FR BOUND     IMP_28  
 FR BOUND     IMP_29  
 FR BOUND     IMP_30  
 FR BOUND     IMP_31  
 FR BOUND     IMP_32  
 FR BOUND     IMP_33  
 FR BOUND     IMP_34  
 FR BOUND     IMP_35  
 FR BOUND     IMP_36  
 FR BOUND     IMP_37  
 FR BOUND     IMP_38  
 FR BOUND     IMP_39  
 FR BOUND     IMP_40  
 FR BOUND     IMP_41  
 FR BOUND     IMP_42  
 FR BOUND     IMP_43  
 FR BOUND     IMP_44  
 FR BOUND     IMP_45  
 FR BOUND     IMP_46  
 FR BOUND     IMP_47  
 FR BOUND     IMP_48  
 FR BOUND     IMP_49  
 FR BOUND     IMP_50  
 FR BOUND     IMP_51  
 FR BOUND     IMP_52  
 FR BOUND     IMP_53  
 FR BOUND     IMP_54  
 FR BOUND     IMP_55  
 FR BOUND     IMP_56  
 FR BOUND     IMP_57  
 FR BOUND     IMP_58  
 FR BOUND     IMP_59  
 FR BOUND     IMP_60  
 FR BOUND     PBT_1   
 FR BOUND     PBT_2   
 FR BOUND     PBT_3   
 FR BOUND     PBT_4   
 FR BOUND     PBT_5   
 FR BOUND     PBT_6   
 FR BOUND     PBT_7   
 FR BOUND     PBT_8   
 FR BOUND     PBT_9   
 FR BOUND     PBT_10  
 FR BOUND     PBT_11  
 FR BOUND     PBT_12  
 FR BOUND     PBT_13  
 FR BOUND     PBT_14  
 FR BOUND     PBT_15  
 FR BOUND     PBT_16  
 FR BOUND     PBT_17  
 FR BOUND     PBT_18  
 FR BOUND     PBT_19  
 FR BOUND     PBT_20  
 FR BOUND     PBT_21  
 FR BOUND     PBT_22  
 FR BOUND     PBT_23  
 FR BOUND     PBT_24  
 FR BOUND     PBT_25  
 FR BOUND     PBT_26  
 FR BOUND     PBT_27  
 FR BOUND     PBT_28  
 FR BOUND     PBT_29  
 FR BOUND     PBT_30  
 FR BOUND     PBT_31  
 FR BOUND     PBT_32  
 FR BOUND     PBT_33  
 FR BOUND     PBT_34  
 FR BOUND     PBT_35  
 FR BOUND     PBT_36  
 FR BOUND     PBT_37  
 FR BOUND     PBT_38  
 FR BOUND     PBT_39  
 FR BOUND     PBT_40  
 FR BOUND     PBT_41  
 FR BOUND     PBT_42  
 FR BOUND     PBT_43  
 FR BOUND     PBT_44  
 FR BOUND     PBT_45  
 FR BOUND     PBT_46  
 FR BOUND     PBT_47  
 FR BOUND     PBT_48  
 FR BOUND     PBT_49  
 FR BOUND     PBT_50  
 FR BOUND     PBT_51  
 FR BOUND     PBT_52  
 FR BOUND     PBT_53  
 FR BOUND     PBT_54  
 FR BOUND     PBT_55  
 FR BOUND     PBT_56  
 FR BOUND     PBT_57  
 FR BOUND     PBT_58  
 FR BOUND     PBT_59  
 FR BOUND     PBT_60  
 FR BOUND     TAX_1   
 FR BOUND     TAX_2   
 FR BOUND     TAX_3   
 FR BOUND     TAX_4   
 FR BOUND     TAX_5   
 FR BOUND     TAX_6   
 FR BOUND     TAX_7   
 FR BOUND     TAX_8   
 FR BOUND     TAX_9   
 FR BOUND     TAX_10  
 FR BOUND     TAX_11  
 FR BOUND     TAX_12  
 FR BOUND     TAX_13  
 FR BOUND     TAX_14  
 FR BOUND     TAX_15  
 FR BOUND     TAX_16  
 FR BOUND     TAX_17  
 FR BOUND     TAX_18  
 FR BOUND     TAX_19  
 FR BOUND     TAX_20  
 FR BOUND     TAX_21  
 FR BOUND     TAX_22  
 FR BOUND     TAX_23  
 FR BOUND     TAX_24  
 FR BOUND     TAX_25  
 FR BOUND     TAX_26  
 FR BOUND     TAX_27  
 FR BOUND     TAX_28  
 FR BOUND     TAX_29  
 FR BOUND     TAX_30  
 FR BOUND     TAX_31  
 FR BOUND     TAX_32  
 FR BOUND     TAX_33  
 FR BOUND     TAX_34  
 FR BOUND     TAX_35  
 FR BOUND     TAX_36  
 FR BOUND     TAX_37  
 FR BOUND     TAX_38  
 FR BOUND     TAX_39  
 FR BOUND     TAX_40  
 FR BOUND     TAX_41  
 FR BOUND     TAX_42  
 FR BOUND     TAX_43  
 FR BOUND     TAX_44  
 FR BOUND     TAX_45  
 FR BOUND     TAX_46  
 FR BOUND     TAX_47  
 FR BOUND     TAX_48  
 FR BOUND     TAX_49  
 FR BOUND     TAX_50  
 FR BOUND     TAX_51  
 FR BOUND     TAX_52  
 FR BOUND     TAX_53  
 FR BOUND     TAX_54  
 FR BOUND     TAX_55  
 FR BOUND     TAX_56  
 FR BOUND     TAX_57  
 FR BOUND     TAX_58  
 FR BOUND     TAX_59  
 FR BOUND     TAX_60  
 FR BOUND     NP_1    
 FR BOUND     NP_2    
 FR BOUND     NP_3    
 FR BOUND     NP_4    
 FR BOUND     NP_5    
 FR BOUND     NP_6    
 FR BOUND     NP_7    
 FR BOUND     NP_8    
 FR BOUND     NP_9    
 FR BOUND     NP_10   
 FR BOUND     NP_11   
 FR BOUND     NP_12   
 FR BOUND     NP_13   
 FR BOUND     NP_14   
 FR BOUND     NP_15   
 FR BOUND     NP_16   
 FR BOUND     NP_17   
 FR BOUND     NP_18   
 FR BOUND     NP_19   
 FR BOUND     NP_20   
 FR BOUND     NP_21   
 FR BOUND     NP_22   
 FR BOUND     NP_23   
 FR BOUND     NP_24   
 FR BOUND     NP_25   
 FR BOUND     NP_26   
 FR BOUND     NP_27   
 FR BOUND     NP_28   
 FR BOUND     NP_29   
 FR BOUND     NP_30   
 FR BOUND     NP_31   
 FR BOUND     NP_32   
 FR BOUND     NP_33   
 FR BOUND     NP_34   
 FR BOUND     NP_35   
 FR BOUND     NP_36   
 FR BOUND     NP_37   
 FR BOUND     NP_38   
 FR BOUND     NP_39   
 FR BOUND     NP_40   
 FR BOUND     NP_41   
 FR BOUND     NP_42   
 FR BOUND     NP_43   
 FR BOUND     NP_44   
 FR BOUND     NP_45   
 FR BOUND     NP_46   
 FR BOUND     NP_47   
 FR BOUND     NP_48   
 FR BOUND     NP_49   
 FR BOUND     NP_50   
 FR BOUND     NP_51   
 FR BOUND     NP_52   
 FR BOUND     NP_53   
 FR BOUND     NP_54   
 FR BOUND     NP_55   
 FR BOUND     NP_56   
 FR BOUND     NP_57   
 FR BOUND     NP_58   
 FR BOUND     NP_59   
 FR BOUND     NP_60   
 FR BOUND     RWA_1   
 FR BOUND     RWA_2   
 FR BOUND     RWA_3   
 FR BOUND     RWA_4   
 FR BOUND     RWA_5   
 FR BOUND     RWA_6   
 FR BOUND     RWA_7   
 FR BOUND     RWA_8   
 FR BOUND     RWA_9   
 FR BOUND     RWA_10  
 FR BOUND     RWA_11  
 FR BOUND     RWA_12  
 FR BOUND     RWA_13  
 FR BOUND     RWA_14  
 FR BOUND     RWA_15  
 FR BOUND     RWA_16  
 FR BOUND     RWA_17  
 FR BOUND     RWA_18  
 FR BOUND     RWA_19  
 FR BOUND     RWA_20  
 FR BOUND     RWA_21  
 FR BOUND     RWA_22  
 FR BOUND     RWA_23  
 FR BOUND     RWA_24  
 FR BOUND     RWA_25  
 FR BOUND     RWA_26  
 FR BOUND     RWA_27  
 FR BOUND     RWA_28  
 FR BOUND     RWA_29  
 FR BOUND     RWA_30  
 FR BOUND     RWA_31  
 FR BOUND     RWA_32  
 FR BOUND     RWA_33  
 FR BOUND     RWA_34  
 FR BOUND     RWA_35  
 FR BOUND     RWA_36  
 FR BOUND     RWA_37  
 FR BOUND     RWA_38  
 FR BOUND     RWA_39  
 FR BOUND     RWA_40  
 FR BOUND     RWA_41  
 FR BOUND     RWA_42  
 FR BOUND     RWA_43  
 FR BOUND     RWA_44  
 FR BOUND     RWA_45  
 FR BOUND     RWA_46  
 FR BOUND     RWA_47  
 FR BOUND     RWA_48  
 FR BOUND     RWA_49  
 FR BOUND     RWA_50  
 FR BOUND     RWA_51  
 FR BOUND     RWA_52  
 FR BOUND     RWA_53  
 FR BOUND     RWA_54  
 FR BOUND     RWA_55  
 FR BOUND     RWA_56  
 FR BOUND     RWA_57  
 FR BOUND     RWA_58  
 FR BOUND     RWA_59  
 FR BOUND     RWA_60  
 FR BOUND     OUT_1   
 FR BOUND     OUT_2   
 FR BOUND     OUT_3   
 FR BOUND     OUT_4   
 FR BOUND     OUT_5   
 FR BOUND     OUT_6   
 FR BOUND     OUT_7   
 FR BOUND     OUT_8   
 FR BOUND     OUT_9   
 FR BOUND     OUT_10  
 FR BOUND     OUT_11  
 FR BOUND     OUT_12  
 FR BOUND     OUT_13  
 FR BOUND     OUT_14  
 FR BOUND     OUT_15  
 FR BOUND     OUT_16  
 FR BOUND     OUT_17  
 FR BOUND     OUT_18  
 FR BOUND     OUT_19  
 FR BOUND     OUT_20  
 FR BOUND     OUT_21  
 FR BOUND     OUT_22  
 FR BOUND     OUT_23  
 FR BOUND     OUT_24  
 FR BOUND     OUT_25  
 FR BOUND     OUT_26  
 FR BOUND     OUT_27  
 FR BOUND     OUT_28  
 FR BOUND     OUT_29  
 FR BOUND     OUT_30  
 FR BOUND     OUT_31  
 FR BOUND     OUT_32  
 FR BOUND     OUT_33  
 FR BOUND     OUT_34  
 FR BOUND     OUT_35  
 FR BOUND     OUT_36  
 FR BOUND     OUT_37  
 FR BOUND     OUT_38  
 FR BOUND     OUT_39  
 FR BOUND     OUT_40  
 FR BOUND     OUT_41  
 FR BOUND     OUT_42  
 FR BOUND     OUT_43  
 FR BOUND     OUT_44  
 FR BOUND     OUT_45  
 FR BOUND     OUT_46  
 FR BOUND     OUT_47  
 FR BOUND     OUT_48  
 FR BOUND     OUT_49  
 FR BOUND     OUT_50  
 FR BOUND     OUT_51  
 FR BOUND     OUT_52  
 FR BOUND     OUT_53  
 FR BOUND     OUT_54  
 FR BOUND     OUT_55  
 FR BOUND     OUT_56  
 FR BOUND     OUT_57  
 FR BOUND     OUT_58  
 FR BOUND     OUT_59  
 FR BOUND     OUT_60  
 FR BOUND     IN_1    
 FR BOUND     IN_2    
 FR BOUND     IN_3    
 FR BOUND     IN_4    
 FR BOUND     IN_5    
 FR BOUND     IN_6    
 FR BOUND     IN_7    
 FR BOUND     IN_8    
 FR BOUND     IN_9    
 FR BOUND     IN_10   
 FR BOUND     IN_11   
 FR BOUND     IN_12   
 FR BOUND     IN_13   
 FR BOUND     IN_14   
 FR BOUND     IN_15   
 FR BOUND     IN_16   
 FR BOUND     IN_17   
 FR BOUND     IN_18   
 FR BOUND     IN_19   
 FR BOUND     IN_20   
 FR BOUND     IN_21   
 FR BOUND     IN_22   
 FR BOUND     IN_23   
 FR BOUND     IN_24   
 FR BOUND     IN_25   
 FR BOUND     IN_26   
 FR BOUND     IN_27   
 FR BOUND     IN_28   
 FR BOUND     IN_29   
 FR BOUND     IN_30   
 FR BOUND     IN_31   
 FR BOUND     IN_32   
 FR BOUND     IN_33   
 FR BOUND     IN_34   
 FR BOUND     IN_35   
 FR BOUND     IN_36   
 FR BOUND     IN_37   
 FR BOUND     IN_38   
 FR BOUND     IN_39   
 FR BOUND     IN_40   
 FR BOUND     IN_41   
 FR BOUND     IN_42   
 FR BOUND     IN_43   
 FR BOUND     IN_44   
 FR BOUND     IN_45   
 FR BOUND     IN_46   
 FR BOUND     IN_47   
 FR BOUND     IN_48   
 FR BOUND     IN_49   
 FR BOUND     IN_50   
 FR BOUND     IN_51   
 FR BOUND     IN_52   
 FR BOUND     IN_53   
 FR BOUND     IN_54   
 FR BOUND     IN_55   
 FR BOUND     IN_56   
 FR BOUND     IN_57   
 FR BOUND     IN_58   
 FR BOUND     IN_59   
 FR BOUND     IN_60   
 FR BOUND     ASF_1   
 FR BOUND     ASF_2   
 FR BOUND     ASF_3   
 FR BOUND     ASF_4   
 FR BOUND     ASF_5   
 FR BOUND     ASF_6   
 FR BOUND     ASF_7   
 FR BOUND     ASF_8   
 FR BOUND     ASF_9   
 FR BOUND     ASF_10  
 FR BOUND     ASF_11  
 FR BOUND     ASF_12  
 FR BOUND     ASF_13  
 FR BOUND     ASF_14  
 FR BOUND     ASF_15  
 FR BOUND     ASF_16  
 FR BOUND     ASF_17  
 FR BOUND     ASF_18  
 FR BOUND     ASF_19  
 FR BOUND     ASF_20  
 FR BOUND     ASF_21  
 FR BOUND     ASF_22  
 FR BOUND     ASF_23  
 FR BOUND     ASF_24  
 FR BOUND     ASF_25  
 FR BOUND     ASF_26  
 FR BOUND     ASF_27  
 FR BOUND     ASF_28  
 FR BOUND     ASF_29  
 FR BOUND     ASF_30  
 FR BOUND     ASF_31  
 FR BOUND     ASF_32  
 FR BOUND     ASF_33  
 FR BOUND     ASF_34  
 FR BOUND     ASF_35  
 FR BOUND     ASF_36  
 FR BOUND     ASF_37  
 FR BOUND     ASF_38  
 FR BOUND     ASF_39  
 FR BOUND     ASF_40  
 FR BOUND     ASF_41  
 FR BOUND     ASF_42  
 FR BOUND     ASF_43  
 FR BOUND     ASF_44  
 FR BOUND     ASF_45  
 FR BOUND     ASF_46  
 FR BOUND     ASF_47  
 FR BOUND     ASF_48  
 FR BOUND     ASF_49  
 FR BOUND     ASF_50  
 FR BOUND     ASF_51  
 FR BOUND     ASF_52  
 FR BOUND     ASF_53  
 FR BOUND     ASF_54  
 FR BOUND     ASF_55  
 FR BOUND     ASF_56  
 FR BOUND     ASF_57  
 FR BOUND     ASF_58  
 FR BOUND     ASF_59  
 FR BOUND     ASF_60  
 FR BOUND     RSF_1   
 FR BOUND     RSF_2   
 FR BOUND     RSF_3   
 FR BOUND     RSF_4   
 FR BOUND     RSF_5   
 FR BOUND     RSF_6   
 FR BOUND     RSF_7   
 FR BOUND     RSF_8   
 FR BOUND     RSF_9   
 FR BOUND     RSF_10  
 FR BOUND     RSF_11  
 FR BOUND     RSF_12  
 FR BOUND     RSF_13  
 FR BOUND     RSF_14  
 FR BOUND     RSF_15  
 FR BOUND     RSF_16  
 FR BOUND     RSF_17  
 FR BOUND     RSF_18  
 FR BOUND     RSF_19  
 FR BOUND     RSF_20  
 FR BOUND     RSF_21  
 FR BOUND     RSF_22  
 FR BOUND     RSF_23  
 FR BOUND     RSF_24  
 FR BOUND     RSF_25  
 FR BOUND     RSF_26  
 FR BOUND     RSF_27  
 FR BOUND     RSF_28  
 FR BOUND     RSF_29  
 FR BOUND     RSF_30  
 FR BOUND     RSF_31  
 FR BOUND     RSF_32  
 FR BOUND     RSF_33  
 FR BOUND     RSF_34  
 FR BOUND     RSF_35  
 FR BOUND     RSF_36  
 FR BOUND     RSF_37  
 FR BOUND     RSF_38  
 FR BOUND     RSF_39  
 FR BOUND     RSF_40  
 FR BOUND     RSF_41  
 FR BOUND     RSF_42  
 FR BOUND     RSF_43  
 FR BOUND     RSF_44  
 FR BOUND     RSF_45  
 FR BOUND     RSF_46  
 FR BOUND     RSF_47  
 FR BOUND     RSF_48  
 FR BOUND     RSF_49  
 FR BOUND     RSF_50  
 FR BOUND     RSF_51  
 FR BOUND     RSF_52  
 FR BOUND     RSF_53  
 FR BOUND     RSF_54  
 FR BOUND     RSF_55  
 FR BOUND     RSF_56  
 FR BOUND     RSF_57  
 FR BOUND     RSF_58  
 FR BOUND     RSF_59  
 FR BOUND     RSF_60  
 FR BOUND     L2_1    
 FR BOUND     L2_2    
 FR BOUND     L2_3    
 FR BOUND     L2_4    
 FR BOUND     L2_5    
 FR BOUND     L2_6    
 FR BOUND     L2_7    
 FR BOUND     L2_8    
 FR BOUND     L2_9    
 FR BOUND     L2_10   
 FR BOUND     L2_11   
 FR BOUND     L2_12   
 FR BOUND     L2_13   
 FR BOUND     L2_14   
 FR BOUND     L2_15   
 FR BOUND     L2_16   
 FR BOUND     L2_17   
 FR BOUND     L2_18   
 FR BOUND     L2_19   
 FR BOUND     L2_20   
 FR BOUND     L2_21   
 FR BOUND     L2_22   
 FR BOUND     L2_23   
 FR BOUND     L2_24   
 FR BOUND     L2_25   
 FR BOUND     L2_26   
 FR BOUND     L2_27   
 FR BOUND     L2_28   
 FR BOUND     L2_29   
 FR BOUND     L2_30   
 FR BOUND     L2_31   
 FR BOUND     L2_32   
 FR BOUND     L2_33   
 FR BOUND     L2_34   
 FR BOUND     L2_35   
 FR BOUND     L2_36   
 FR BOUND     L2_37   
 FR BOUND     L2_38   
 FR BOUND     L2_39   
 FR BOUND     L2_40   
 FR BOUND     L2_41   
 FR BOUND     L2_42   
 FR BOUND     L2_43   
 FR BOUND     L2_44   
 FR BOUND     L2_45   
 FR BOUND     L2_46   
 FR BOUND     L2_47   
 FR BOUND     L2_48   
 FR BOUND     L2_49   
 FR BOUND     L2_50   
 FR BOUND     L2_51   
 FR BOUND     L2_52   
 FR BOUND     L2_53   
 FR BOUND     L2_54   
 FR BOUND     L2_55   
 FR BOUND     L2_56   
 FR BOUND     L2_57   
 FR BOUND     L2_58   
 FR BOUND     L2_59   
 FR BOUND     L2_60   
 FR BOUND     L3_1    
 FR BOUND     L3_2    
 FR BOUND     L3_3    
 FR BOUND     L3_4    
 FR BOUND     L3_5    
 FR BOUND     L3_6    
 FR BOUND     L3_7    
 FR BOUND     L3_8    
 FR BOUND     L3_9    
 FR BOUND     L3_10   
 FR BOUND     L3_11   
 FR BOUND     L3_12   
 FR BOUND     L3_13   
 FR BOUND     L3_14   
 FR BOUND     L3_15   
 FR BOUND     L3_16   
 FR BOUND     L3_17   
 FR BOUND     L3_18   
 FR BOUND     L3_19   
 FR BOUND     L3_20   
 FR BOUND     L3_21   
 FR BOUND     L3_22   
 FR BOUND     L3_23   
 FR BOUND     L3_24   
 FR BOUND     L3_25   
 FR BOUND     L3_26   
 FR BOUND     L3_27   
 FR BOUND     L3_28   
 FR BOUND     L3_29   
 FR BOUND     L3_30   
 FR BOUND     L3_31   
 FR BOUND     L3_32   
 FR BOUND     L3_33   
 FR BOUND     L3_34   
 FR BOUND     L3_35   
 FR BOUND     L3_36   
 FR BOUND     L3_37   
 FR BOUND     L3_38   
 FR BOUND     L3_39   
 FR BOUND     L3_40   
 FR BOUND     L3_41   
 FR BOUND     L3_42   
 FR BOUND     L3_43   
 FR BOUND     L3_44   
 FR BOUND     L3_45   
 FR BOUND     L3_46   
 FR BOUND     L3_47   
 FR BOUND     L3_48   
 FR BOUND     L3_49   
 FR BOUND     L3_50   
 FR BOUND     L3_51   
 FR BOUND     L3_52   
 FR BOUND     L3_53   
 FR BOUND     L3_54   
 FR BOUND     L3_55   
 FR BOUND     L3_56   
 FR BOUND     L3_57   
 FR BOUND     L3_58   
 FR BOUND     L3_59   
 FR BOUND     L3_60   
 FR BOUND     PR_1    
 FR BOUND     PR_2    
 FR BOUND     PR_3    
 FR BOUND     PR_4    
 FR BOUND     PR_5    
 FR BOUND     PR_6    
 FR BOUND     PR_7    
 FR BOUND     PR_8    
 FR BOUND     PR_9    
 FR BOUND     PR_10   
 FR BOUND     PR_11   
 FR BOUND     PR_12   
 FR BOUND     PR_13   
 FR BOUND     PR_14   
 FR BOUND     PR_15   
 FR BOUND     PR_16   
 FR BOUND     PR_17   
 FR BOUND     PR_18   
 FR BOUND     PR_19   
 FR BOUND     PR_20   
 FR BOUND     PR_21   
 FR BOUND     PR_22   
 FR BOUND     PR_23   
 FR BOUND     PR_24   
 FR BOUND     PR_25   
 FR BOUND     PR_26   
 FR BOUND     PR_27   
 FR BOUND     PR_28   
 FR BOUND     PR_29   
 FR BOUND     PR_30   
 FR BOUND     PR_31   
 FR BOUND     PR_32   
 FR BOUND     PR_33   
 FR BOUND     PR_34   
 FR BOUND     PR_35   
 FR BOUND     PR_36   
 FR BOUND     PR_37   
 FR BOUND     PR_38   
 FR BOUND     PR_39   
 FR BOUND     PR_40   
 FR BOUND     PR_41   
 FR BOUND     PR_42   
 FR BOUND     PR_43   
 FR BOUND     PR_44   
 FR BOUND     PR_45   
 FR BOUND     PR_46   
 FR BOUND     PR_47   
 FR BOUND     PR_48   
 FR BOUND     PR_49   
 FR BOUND     PR_50   
 FR BOUND     PR_51   
 FR BOUND     PR_52   
 FR BOUND     PR_53   
 FR BOUND     PR_54   
 FR BOUND     PR_55   
 FR BOUND     PR_56   
 FR BOUND     PR_57   
 FR BOUND     PR_58   
 FR BOUND     PR_59   
 FR BOUND     PR_60   
 FR BOUND     WS_1    
 FR BOUND     WS_2    
 FR BOUND     WS_3    
 FR BOUND     WS_4    
 FR BOUND     WS_5    
 FR BOUND     WS_6    
 FR BOUND     WS_7    
 FR BOUND     WS_8    
 FR BOUND     WS_9    
 FR BOUND     WS_10   
 FR BOUND     WS_11   
 FR BOUND     WS_12   
 FR BOUND     WS_13   
 FR BOUND     WS_14   
 FR BOUND     WS_15   
 FR BOUND     WS_16   
 FR BOUND     WS_17   
 FR BOUND     WS_18   
 FR BOUND     WS_19   
 FR BOUND     WS_20   
 FR BOUND     WS_21   
 FR BOUND     WS_22   
 FR BOUND     WS_23   
 FR BOUND     WS_24   
 FR BOUND     WS_25   
 FR BOUND     WS_26   
 FR BOUND     WS_27   
 FR BOUND     WS_28   
 FR BOUND     WS_29   
 FR BOUND     WS_30   
 FR BOUND     WS_31   
 FR BOUND     WS_32   
 FR BOUND     WS_33   
 FR BOUND     WS_34   
 FR BOUND     WS_35   
 FR BOUND     WS_36   
 FR BOUND     WS_37   
 FR BOUND     WS_38   
 FR BOUND     WS_39   
 FR BOUND     WS_40   
 FR BOUND     WS_41   
 FR BOUND     WS_42   
 FR BOUND     WS_43   
 FR BOUND     WS_44   
 FR BOUND     WS_45   
 FR BOUND     WS_46   
 FR BOUND     WS_47   
 FR BOUND     WS_48   
 FR BOUND     WS_49   
 FR BOUND     WS_50   
 FR BOUND     WS_51   
 FR BOUND     WS_52   
 FR BOUND     WS_53   
 FR BOUND     WS_54   
 FR BOUND     WS_55   
 FR BOUND     WS_56   
 FR BOUND     WS_57   
 FR BOUND     WS_58   
 FR BOUND     WS_59   
 FR BOUND     WS_60   
 FR BOUND     LF_1    
 FR BOUND     LF_2    
 FR BOUND     LF_3    
 FR BOUND     LF_4    
 FR BOUND     LF_5    
 FR BOUND     LF_6    
 FR BOUND     LF_7    
 FR BOUND     LF_8    
 FR BOUND     LF_9    
 FR BOUND     LF_10   
 FR BOUND     LF_11   
 FR BOUND     LF_12   
 FR BOUND     LF_13   
 FR BOUND     LF_14   
 FR BOUND     LF_15   
 FR BOUND     LF_16   
 FR BOUND     LF_17   
 FR BOUND     LF_18   
 FR BOUND     LF_19   
 FR BOUND     LF_20   
 FR BOUND     LF_21   
 FR BOUND     LF_22   
 FR BOUND     LF_23   
 FR BOUND     LF_24   
 FR BOUND     LF_25   
 FR BOUND     LF_26   
 FR BOUND     LF_27   
 FR BOUND     LF_28   
 FR BOUND     LF_29   
 FR BOUND     LF_30   
 FR BOUND     LF_31   
 FR BOUND     LF_32   
 FR BOUND     LF_33   
 FR BOUND     LF_34   
 FR BOUND     LF_35   
 FR BOUND     LF_36   
 FR BOUND     LF_37   
 FR BOUND     LF_38   
 FR BOUND     LF_39   
 FR BOUND     LF_40   
 FR BOUND     LF_41   
 FR BOUND     LF_42   
 FR BOUND     LF_43   
 FR BOUND     LF_44   
 FR BOUND     LF_45   
 FR BOUND     LF_46   
 FR BOUND     LF_47   
 FR BOUND     LF_48   
 FR BOUND     LF_49   
 FR BOUND     LF_50   
 FR BOUND     LF_51   
 FR BOUND     LF_52   
 FR BOUND     LF_53   
 FR BOUND     LF_54   
 FR BOUND     LF_55   
 FR BOUND     LF_56   
 FR BOUND     LF_57   
 FR BOUND     LF_58   
 FR BOUND     LF_59   
 FR BOUND     LF_60   
 FR BOUND     LR_1    
 FR BOUND     LR_2    
 FR BOUND     LR_3    
 FR BOUND     LR_4    
 FR BOUND     LR_5    
 FR BOUND     LR_6    
 FR BOUND     LR_7    
 FR BOUND     LR_8    
 FR BOUND     LR_9    
 FR BOUND     LR_10   
 FR BOUND     LR_11   
 FR BOUND     LR_12   
 FR BOUND     LR_13   
 FR BOUND     LR_14   
 FR BOUND     LR_15   
 FR BOUND     LR_16   
 FR BOUND     LR_17   
 FR BOUND     LR_18   
 FR BOUND     LR_19   
 FR BOUND     LR_20   
 FR BOUND     LR_21   
 FR BOUND     LR_22   
 FR BOUND     LR_23   
 FR BOUND     LR_24   
 FR BOUND     LR_25   
 FR BOUND     LR_26   
 FR BOUND     LR_27   
 FR BOUND     LR_28   
 FR BOUND     LR_29   
 FR BOUND     LR_30   
 FR BOUND     LR_31   
 FR BOUND     LR_32   
 FR BOUND     LR_33   
 FR BOUND     LR_34   
 FR BOUND     LR_35   
 FR BOUND     LR_36   
 FR BOUND     LR_37   
 FR BOUND     LR_38   
 FR BOUND     LR_39   
 FR BOUND     LR_40   
 FR BOUND     LR_41   
 FR BOUND     LR_42   
 FR BOUND     LR_43   
 FR BOUND     LR_44   
 FR BOUND     LR_45   
 FR BOUND     LR_46   
 FR BOUND     LR_47   
 FR BOUND     LR_48   
 FR BOUND     LR_49   
 FR BOUND     LR_50   
 FR BOUND     LR_51   
 FR BOUND     LR_52   
 FR BOUND     LR_53   
 FR BOUND     LR_54   
 FR BOUND     LR_55   
 FR BOUND     LR_56   
 FR BOUND     LR_57   
 FR BOUND     LR_58   
 FR BOUND     LR_59   
 FR BOUND     LR_60   
 FR BOUND     LM_1    
 FR BOUND     LM_2    
 FR BOUND     LM_3    
 FR BOUND     LM_4    
 FR BOUND     LM_5    
 FR BOUND     LM_6    
 FR BOUND     LM_7    
 FR BOUND     LM_8    
 FR BOUND     LM_9    
 FR BOUND     LM_10   
 FR BOUND     LM_11   
 FR BOUND     LM_12   
 FR BOUND     LM_13   
 FR BOUND     LM_14   
 FR BOUND     LM_15   
 FR BOUND     LM_16   
 FR BOUND     LM_17   
 FR BOUND     LM_18   
 FR BOUND     LM_19   
 FR BOUND     LM_20   
 FR BOUND     LM_21   
 FR BOUND     LM_22   
 FR BOUND     LM_23   
 FR BOUND     LM_24   
 FR BOUND     LM_25   
 FR BOUND     LM_26   
 FR BOUND     LM_27   
 FR BOUND     LM_28   
 FR BOUND     LM_29   
 FR BOUND     LM_30   
 FR BOUND     LM_31   
 FR BOUND     LM_32   
 FR BOUND     LM_33   
 FR BOUND     LM_34   
 FR BOUND     LM_35   
 FR BOUND     LM_36   
 FR BOUND     LM_37   
 FR BOUND     LM_38   
 FR BOUND     LM_39   
 FR BOUND     LM_40   
 FR BOUND     LM_41   
 FR BOUND     LM_42   
 FR BOUND     LM_43   
 FR BOUND     LM_44   
 FR BOUND     LM_45   
 FR BOUND     LM_46   
 FR BOUND     LM_47   
 FR BOUND     LM_48   
 FR BOUND     LM_49   
 FR BOUND     LM_50   
 FR BOUND     LM_51   
 FR BOUND     LM_52   
 FR BOUND     LM_53   
 FR BOUND     LM_54   
 FR BOUND     LM_55   
 FR BOUND     LM_56   
 FR BOUND     LM_57   
 FR BOUND     LM_58   
 FR BOUND     LM_59   
 FR BOUND     LM_60   
 FR BOUND     TR_1    
 FR BOUND     TR_2    
 FR BOUND     TR_3    
 FR BOUND     TR_4    
 FR BOUND     TR_5    
 FR BOUND     TR_6    
 FR BOUND     TR_7    
 FR BOUND     TR_8    
 FR BOUND     TR_9    
 FR BOUND     TR_10   
 FR BOUND     TR_11   
 FR BOUND     TR_12   
 FR BOUND     TR_13   
 FR BOUND     TR_14   
 FR BOUND     TR_15   
 FR BOUND     TR_16   
 FR BOUND     TR_17   
 FR BOUND     TR_18   
 FR BOUND     TR_19   
 FR BOUND     TR_20   
 FR BOUND     TR_21   
 FR BOUND     TR_22   
 FR BOUND     TR_23   
 FR BOUND     TR_24   
 FR BOUND     TR_25   
 FR BOUND     TR_26   
 FR BOUND     TR_27   
 FR BOUND     TR_28   
 FR BOUND     TR_29   
 FR BOUND     TR_30   
 FR BOUND     TR_31   
 FR BOUND     TR_32   
 FR BOUND     TR_33   
 FR BOUND     TR_34   
 FR BOUND     TR_35   
 FR BOUND     TR_36   
 FR BOUND     TR_37   
 FR BOUND     TR_38   
 FR BOUND     TR_39   
 FR BOUND     TR_40   
 FR BOUND     TR_41   
 FR BOUND     TR_42   
 FR BOUND     TR_43   
 FR BOUND     TR_44   
 FR BOUND     TR_45   
 FR BOUND     TR_46   
 FR BOUND     TR_47   
 FR BOUND     TR_48   
 FR BOUND     TR_49   
 FR BOUND     TR_50   
 FR BOUND     TR_51   
 FR BOUND     TR_52   
 FR BOUND     TR_53   
 FR BOUND     TR_54   
 FR BOUND     TR_55   
 FR BOUND     TR_56   
 FR BOUND     TR_57   
 FR BOUND     TR_58   
 FR BOUND     TR_59   
 FR BOUND     TR_60   
 FR BOUND     TM_1    
 FR BOUND     TM_2    
 FR BOUND     TM_3    
 FR BOUND     TM_4    
 FR BOUND     TM_5    
 FR BOUND     TM_6    
 FR BOUND     TM_7    
 FR BOUND     TM_8    
 FR BOUND     TM_9    
 FR BOUND     TM_10   
 FR BOUND     TM_11   
 FR BOUND     TM_12   
 FR BOUND     TM_13   
 FR BOUND     TM_14   
 FR BOUND     TM_15   
 FR BOUND     TM_16   
 FR BOUND     TM_17   
 FR BOUND     TM_18   
 FR BOUND     TM_19   
 FR BOUND     TM_20   
 FR BOUND     TM_21   
 FR BOUND     TM_22   
 FR BOUND     TM_23   
 FR BOUND     TM_24   
 FR BOUND     TM_25   
 FR BOUND     TM_26   
 FR BOUND     TM_27   
 FR BOUND     TM_28   
 FR BOUND     TM_29   
 FR BOUND     TM_30   
 FR BOUND     TM_31   
 FR BOUND     TM_32   
 FR BOUND     TM_33   
 FR BOUND     TM_34   
 FR BOUND     TM_35   
 FR BOUND     TM_36   
 FR BOUND     TM_37   
 FR BOUND     TM_38   
 FR BOUND     TM_39   
 FR BOUND     TM_40   
 FR BOUND     TM_41   
 FR BOUND     TM_42   
 FR BOUND     TM_43   
 FR BOUND     TM_44   
 FR BOUND     TM_45   
 FR BOUND     TM_46   
 FR BOUND     TM_47   
 FR BOUND     TM_48   
 FR BOUND     TM_49   
 FR BOUND     TM_50   
 FR BOUND     TM_51   
 FR BOUND     TM_52   
 FR BOUND     TM_53   
 FR BOUND     TM_54   
 FR BOUND     TM_55   
 FR BOUND     TM_56   
 FR BOUND     TM_57   
 FR BOUND     TM_58   
 FR BOUND     TM_59   
 FR BOUND     TM_60   
ENDATA
